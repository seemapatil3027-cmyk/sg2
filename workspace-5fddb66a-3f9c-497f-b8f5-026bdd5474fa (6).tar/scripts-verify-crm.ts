import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const leads = await db.lead.count();
  const acts = await db.leadActivity.count();
  const users = await db.user.count();
  const enr = await db.enrollment.count();
  const pay = await db.payment.count();
  const tracks = await db.track.count();
  console.log(JSON.stringify({ leads, acts, users, enr, pay, tracks }));
  const byStatus: Record<string, number> = {};
  for (const l of await db.lead.findMany({ select: { status: true, assignedTo: true, name: true } })) {
    byStatus[l.status] = (byStatus[l.status] ?? 0) + 1;
  }
  console.log("byStatus", JSON.stringify(byStatus));
  console.log("users", JSON.stringify(await db.user.findMany({ select: { email: true, role: true, name: true } })));
}
main().finally(() => db.$disconnect());
