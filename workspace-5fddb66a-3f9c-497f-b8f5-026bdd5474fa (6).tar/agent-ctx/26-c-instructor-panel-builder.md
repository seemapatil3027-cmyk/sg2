# Task ID: 26-c
# Agent: instructor-panel-builder
# Task: READ-ONLY Instructor console at /instructor (gate UX + teaching portfolio, live sessions, enrollments, mentor peers)

## Files Created
- `src/app/instructor/page.tsx` — async server component, `dynamic = "force-dynamic"`, metadata `title: { absolute: "Instructor | SkillGorila" }` + `robots: { index: false, follow: false }`
- `src/components/instructor/instructor-login.tsx` — client branded sign-in card (email+password with labels/autoComplete, POST /api/auth/signin, 401 → inline "Invalid credentials", success → notifyUserChanged() + router.refresh(), demo-email hint without password)
- `src/components/instructor/instructor-sign-out.tsx` — client sign-out button (POST /api/auth/signout → notifyUserChanged() + router.refresh(), Loader2 pending, aria-label, className passthrough)

## Gate Behavior (verified E2E)
1. No session → centered InstructorLogin card (rounded-3xl, border, shadow-lg, purple brand)
2. `role === "STUDENT"` → "Access denied" card: "You're signed in as Student" + "The instructor console is for our teaching team." + "Go to My Dashboard" (→ /dashboard) + Sign out
3. INSTRUCTOR/ADMIN → full console; ADMIN additionally shows gold "Viewing as admin" badge

## Console Sections (all reads best-effort in one try/catch — never 500s)
- Header: section-label "Teaching Console" + h1 + Instructor badge + profile chip (InitialAvatar/name/email) + InstructorSignOut
- Stats (grid 1→2→4): Active Courses = 5, Career Tracks = 7, Total Learners = sum of parseInt-able course.learners → "1.3k" honest compact format ("—" if none parseable; "34.K"/"4K" skipped), Live Sessions = Σ track.liveClasses = 142
- My Courses: all 5 courses w/ lucide icon map (Sparkles fallback), level badge, learners, gold Star rating, weeks, chapters JSON length, top-3 skill chips; `max-h-96 overflow-y-auto nice-scrollbar`
- Live sessions: first 4 tracks × deterministic rotating slots (Mon·7PM / Wed·7PM / Fri·7PM / Sat·11AM) — NO Date.now() in server render; Online (purple) / Classroom (gold) badges
- Recent enrollments: leads source ∈ {enroll, masterclass} newest-first max 8 (itemSlug chip or "—", formatDate); DB currently 0 leads → gold Inbox empty state
- Mentor peers: first 4 mentors, compact cards w/ InitialAvatar + role · company + education

## Verification
- `bunx tsc --noEmit` → 0 errors; `bun run lint` → 0 problems
- E2E (agent-browser, isolated `--session`): sign-out→card ✓, wrong password→"Invalid credentials" ✓, instructor@skillgorila.com→console w/ real data ✓, header sign-out→card ✓, student@skillgorila.com→Access denied ✓, admin@skillgorila.com→"Viewing as admin" ✓
- No horizontal scroll at 1440x900 or 390x844; VLM QA desktop PASS (mobile PASS after swapping `truncate` → wrapping `leading-snug` on session titles)
- Screenshots: /tmp/task26c-instructor-desktop.png, /tmp/task26c-instructor-mobile.png, /tmp/task26c-instructor-denied.png (bonus)
- dev.log: GET /instructor 200, auth POSTs 200, no runtime errors (only prisma:query noise)
- No test data created (only pre-seeded accounts used; zero DB writes)

## Notes for Next Agents
- Navbar + /signin already deep-link INSTRUCTOR→/instructor, ADMIN→/-admin — both land correctly now
- Enrollments section auto-populates when enroll/masterclass leads exist — no code change needed
- Total Learners skips unparseable learner strings by design ("keep honest" rule)
- Env quirk: native agent-browser clicks can silently no-op right after an RSC refresh (and the parallel 26-a agent shares the DEFAULT session — use `agent-browser --session <name>`); re-snapshot for fresh refs or dispatch `.click()` via eval
