# Task ID: 7-d
# Agent: placement-pages-builder
# Task: Placement & Hire-From-Us pages (placement-assistance, placement-stats, success-stories, hire-from-us)

## Files Created
- `src/app/placement-assistance/page.tsx` — metadata "Job Placements At 300+ Partner Hiring Companies"
- `src/app/placement-stats/page.tsx` — metadata "Placement Stats — Empowering Your Career Transformation"
- `src/app/success-stories/page.tsx` — metadata "SkilloVilla Success Stories | Achievements that Inspire"
- `src/app/hire-from-us/page.tsx` — metadata "Hire Data Analysts & Data Scientists"
- `src/components/placement/student-badge.tsx` — server-safe chip (Fresher → orange, hike → green)
- `src/components/placement/partner-tabs.tsx` — client, MNC/Unicorn/Startup pill tabs + CompanyGrid
- `src/components/placement/candidates-marquee.tsx` — client, seamless marquee of candidate cards (doubled array)

## Conventions Followed
- Pages are async SERVER components importing `getPlacedStudents`, `getFaqs`, `getCompanies` from `@/lib/data` (no own-API fetch). Per-page `export const metadata`.
- Shared comps used: `Section`, `SectionHeading`, `LeadForm`, `LeadDialogButton`, `FaqSection`, `CallbackBanner`, `CompanyGrid`, `InitialAvatar`. No shared/layout files modified.
- Tokens: `bg-[#EFE9F7]` hero bands, `bg-primary hover:bg-brand-dark`, `text-brand`, `bg-brand-soft`, `text-accento`, `.section-label`, `text-ink`/`text-ink-soft`, `.bg-brand-gradient`, green badges `bg-[#DCF2E4] text-[#15803D]`, orange chip `bg-accento-soft text-accento`.
- `/placement-assistance` stats card overlaps hero via `-mt-16` (hero has pb-28 sm:pb-32). Dividers are per-cell responsive borders (works in 2-col and 4-col).
- `/placement-stats` student cards stack first+last name via `name.split(" ")`; hike chip uppercased (`"40% hike".toUpperCase()` → "40% HIKE").
- `/success-stories` masonry uses `columns-1 sm:columns-2 lg:columns-3` + `break-inside-avoid mb-5`; brochure link `/api/brochure?track=data-analytics-and-ai` (slug verified in seed).
- `/hire-from-us` marquee uses global `.animate-marquee` + `.marquee-paused` with `aria-hidden` on duplicated half; hire form posts via shared `LeadForm source="hire"`.

## Verification
- `bunx eslint` on my 7 files → 0 problems.
- `bunx tsc --noEmit` filtered to my files → 0 errors.
- Repo-wide `bun run lint` still reports 3 PRE-EXISTING errors in `src/components/layout/navbar.tsx` (`react-hooks/set-state-in-effect`, `react-hooks/static-components` ×2) + 1 warning in `shared/masterclass-section.tsx` — NOT mine, untouched per scope. Whoever owns layout should fix.
- Dev server NOT started (per instructions).

## Notes for Next Agents
- Need a candidate chip elsewhere? Reuse `StudentBadge` from `@/components/placement/student-badge` (server-safe, no "use client").
- `PartnerTabs` takes `Record<"mnc"|"unicorn"|"startup", Company[]>` — fetch all three arrays server-side and pass down.
- Empty `hike`+`status` students simply render no chip (e.g. Aashish Panda).
