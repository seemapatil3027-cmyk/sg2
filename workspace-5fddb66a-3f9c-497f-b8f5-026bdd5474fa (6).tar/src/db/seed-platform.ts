/* Boot-time provisioning for the RBAC matrix + a realistic demo dataset so
 * every dashboard, chart and pipeline renders with meaningful data.
 * Every step is gated on "table empty" — existing data is never touched. */
import type { PrismaClient } from "@prisma/client";
import { DEFAULT_ROLES } from "@/lib/rbac";

export async function ensureRoles(client: PrismaClient): Promise<boolean> {
  const count = await client.role.count();
  if (count > 0) return false;
  for (const role of DEFAULT_ROLES) {
    await client.role.create({
      data: {
        key: role.key,
        name: role.name,
        description: role.description,
        permissions: JSON.stringify(role.permissions),
        isSystem: true,
        order: role.order,
      },
    });
  }
  return true;
}

const DAY = 24 * 60 * 60 * 1000;
function daysFromNow(n: number): Date {
  return new Date(Date.now() + n * DAY);
}

/** Seeds demo CRM + LMS data (gated on empty tables). */
export async function ensurePlatformDemoData(client: PrismaClient): Promise<void> {
  await ensureOrganizationsAndContacts(client);
  await ensureDealsAndActivities(client);
  await ensureCategories(client);
  await ensureLmsContent(client);
  await ensureEnrollmentsProgressCerts(client);
  await ensureNotifications(client);
}

async function ensureOrganizationsAndContacts(client: PrismaClient) {
  if ((await client.organization.count()) > 0) return;
  const users = await client.user.findMany();
  const crmManager = users.find((u) => u.role === "CRM_MANAGER");
  const crmExec = users.find((u) => u.role === "CRM_EXECUTIVE");

  const orgs = [
    { name: "Infosys Ltd.", domain: "infosys.com", industry: "IT Services", size: "1000+", city: "Bengaluru" },
    { name: "Tata Consultancy Services", domain: "tcs.com", industry: "IT Services", size: "1000+", city: "Mumbai" },
    { name: "Zeta Suites", domain: "zetasuites.com", industry: "Hospitality", size: "51-200", city: "Pune" },
    { name: "FinEdge Capital", domain: "finedge.io", industry: "FinTech", size: "201-1000", city: "Mumbai" },
    { name: "BrightPath EdTech", domain: "brightpath.in", industry: "EdTech", size: "11-50", city: "Hyderabad" },
    { name: "Orbit Logistics", domain: "orbitlog.com", industry: "Logistics", size: "51-200", city: "Delhi NCR" },
  ];
  const createdOrgs: { id: string; name: string }[] = [];
  for (const [i, org] of orgs.entries()) {
    const created = await client.organization.create({
      data: {
        ...org,
        phone: `+91 9${(800000000 + i * 11111111).toString().slice(0, 9)}`,
        website: `https://www.${org.domain}`,
        ownerId: i % 2 === 0 ? crmManager?.id ?? null : crmExec?.id ?? null,
        notes: "Key account — quarterly business review scheduled.",
      },
    });
    createdOrgs.push({ id: created.id, name: created.name });
  }

  const contacts = [
    { name: "Kavita Rao", title: "L&D Manager", org: 0, source: "campaign", lifecycle: "CUSTOMER", city: "Bengaluru" },
    { name: "Suresh Nair", title: "HR Director", org: 1, source: "inbound", lifecycle: "CONTACT", city: "Mumbai" },
    { name: "Ananya Iyer", title: "Data Analyst", org: 3, source: "website", lifecycle: "CUSTOMER", city: "Mumbai" },
    { name: "Vikram Shah", title: "Ops Head", org: 5, source: "referral", lifecycle: "CONTACT", city: "Delhi NCR" },
    { name: "Divya Menon", title: "Talent Lead", org: 4, source: "event", lifecycle: "CONTACT", city: "Hyderabad" },
    { name: "Rohan Gupta", title: "Product Manager", org: 3, source: "website", lifecycle: "CUSTOMER", city: "Pune" },
    { name: "Sneha Patil", title: "Business Analyst", org: 2, source: "outbound", lifecycle: "CONTACT", city: "Pune" },
    { name: "Aditya Rao", title: "Consultant", org: 0, source: "referral", lifecycle: "CUSTOMER", city: "Bengaluru" },
  ];
  for (const [i, c] of contacts.entries()) {
    await client.contact.create({
      data: {
        name: c.name,
        email: `${c.name.toLowerCase().replace(/[^a-z]+/g, ".")}@${orgs[c.org].domain}`,
        phone: `+91 8${(700000000 + i * 12345679).toString().slice(0, 9)}`,
        title: c.title,
        organizationId: createdOrgs[c.org].id,
        ownerId: i % 2 === 0 ? crmExec?.id ?? null : crmManager?.id ?? null,
        source: c.source,
        lifecycle: c.lifecycle,
        status: "ACTIVE",
        city: c.city,
        notes: i % 3 === 0 ? "Prefers WhatsApp over email." : null,
      },
    });
  }
}

async function ensureDealsAndActivities(client: PrismaClient) {
  if ((await client.deal.count()) > 0) return;
  const users = await client.user.findMany();
  const crmManager = users.find((u) => u.role === "CRM_MANAGER");
  const crmExec = users.find((u) => u.role === "CRM_EXECUTIVE");
  const contacts = await client.contact.findMany();
  const orgs = await client.organization.findMany();

  const deals = [
    { title: "Data Analytics Track — 12 seats", value: 720000, stage: "NEGOTIATION", probability: 75, contact: 0, close: 18 },
    { title: "SAP FICO Corporate Batch", value: 480000, stage: "PROPOSAL", probability: 55, contact: 1, close: 30 },
    { title: "FinEdge Analytics Upskilling", value: 360000, stage: "WON", probability: 100, contact: 2, close: -6 },
    { title: "Orbit Ops Team SQL Bootcamp", value: 150000, stage: "QUALIFIED", probability: 40, contact: 3, close: 25 },
    { title: "BrightPath Instructor Partnership", value: 90000, stage: "CONTACTED", probability: 20, contact: 4, close: 40 },
    { title: "Rohan Gupta — Full Stack Track", value: 65000, stage: "WON", probability: 100, contact: 5, close: -12 },
    { title: "Zeta Suites Excel + BI Program", value: 85000, stage: "PROPOSAL", probability: 50, contact: 6, close: 22 },
    { title: "Infosys Winter Campus Drive", value: 1200000, stage: "QUALIFIED", probability: 35, contact: 7, close: 45 },
    { title: "TCS Digital Lab Renewal", value: 540000, stage: "NEW", probability: 10, contact: 1, close: 60 },
    { title: "Orbit Logistics Power BI Deal", value: 120000, stage: "LOST", probability: 0, contact: 3, close: -20 },
  ];
  const createdDeals: { id: string; title: string; stage: string }[] = [];
  for (const [i, d] of deals.entries()) {
    const created = await client.deal.create({
      data: {
        title: d.title,
        value: d.value,
        stage: d.stage,
        status: d.stage === "WON" ? "WON" : d.stage === "LOST" ? "LOST" : "OPEN",
        probability: d.probability,
        expectedCloseAt: daysFromNow(d.close),
        closedAt: d.stage === "WON" || d.stage === "LOST" ? daysFromNow(d.close) : null,
        lostReason: d.stage === "LOST" ? "Chose a lower-priced competitor" : null,
        ownerId: i % 2 === 0 ? crmManager?.id ?? null : crmExec?.id ?? null,
        contactId: contacts[d.contact]?.id ?? null,
        organizationId: contacts[d.contact]?.organizationId ?? orgs[d.contact % orgs.length]?.id ?? null,
        notes: "Budget approved — decision by end of month." ,
      },
    });
    createdDeals.push({ id: created.id, title: created.title, stage: created.stage });
  }

  // Activities: open tasks + completed history for the pipeline
  const acts: {
    type: string; subject: string; status: string; priority: string; due: number | null;
    deal?: number; contact?: number; owner?: "mgr" | "exec";
  }[] = [
    { type: "TASK", subject: "Send revised proposal to Infosys L&D", status: "OPEN", priority: "HIGH", due: 1, deal: 7, owner: "mgr" },
    { type: "CALL", subject: "Follow-up call — negotiation round 2", status: "OPEN", priority: "HIGH", due: 0, deal: 0, owner: "mgr" },
    { type: "MEETING", subject: "Demo session with FinEdge analytics team", status: "COMPLETED", priority: "MEDIUM", due: -2, deal: 2, owner: "exec" },
    { type: "FOLLOW_UP", subject: "Check proposal response — TCS digital lab", status: "OPEN", priority: "MEDIUM", due: 3, deal: 8, owner: "exec" },
    { type: "TASK", subject: "Prepare ROI one-pager for Zeta Suites", status: "OPEN", priority: "MEDIUM", due: 2, deal: 6, owner: "mgr" },
    { type: "EMAIL", subject: "Winter campus drive intro deck shared", status: "COMPLETED", priority: "LOW", due: -1, deal: 7, owner: "mgr" },
    { type: "TASK", subject: "Collect learner list for Orbit SQL bootcamp", status: "OPEN", priority: "HIGH", due: 1, contact: 3, owner: "exec" },
    { type: "CALL", subject: "Intro call — BrightPath partnership", status: "COMPLETED", priority: "MEDIUM", due: -3, deal: 4, owner: "exec" },
    { type: "FOLLOW_UP", subject: "Negotiation follow-up — seat pricing", status: "OPEN", priority: "HIGH", due: -1, deal: 0, owner: "mgr" },
    { type: "MEETING", subject: "QBR — Orbit Logistics key account", status: "OPEN", priority: "MEDIUM", due: 7, contact: 3, owner: "mgr" },
    { type: "TASK", subject: "Update CRM stage — BrightPath opportunity", status: "OPEN", priority: "LOW", due: 4, deal: 4, owner: "exec" },
    { type: "NOTE", subject: "Competitor quoted 10% lower on corporate batch", status: "COMPLETED", priority: "MEDIUM", due: null, deal: 1, owner: "mgr" },
  ];
  for (const a of acts) {
    await client.activity.create({
      data: {
        type: a.type,
        subject: a.subject,
        status: a.status,
        priority: a.priority,
        dueAt: a.due === null ? null : daysFromNow(a.due),
        completedAt: a.status === "COMPLETED" ? daysFromNow((a.due ?? 0)) : null,
        dealId: a.deal !== undefined ? createdDeals[a.deal]?.id ?? null : null,
        contactId: a.contact !== undefined ? contacts[a.contact]?.id ?? null : null,
        ownerId: a.owner === "mgr" ? crmManager?.id ?? null : crmExec?.id ?? null,
        createdBy: "demo-seed@skillgorila.com",
      },
    });
  }
}

async function ensureCategories(client: PrismaClient) {
  if ((await client.courseCategory.count()) > 0) return;
  const cats = [
    { name: "Data & Analytics", slug: "data-analytics", color: "#5d18be" },
    { name: "SAP & Enterprise", slug: "sap-enterprise", color: "#f97316" },
    { name: "Full Stack Development", slug: "full-stack", color: "#16a34a" },
    { name: "Business & Product", slug: "business-product", color: "#ffb020" },
  ];
  for (const [i, c] of cats.entries()) {
    await client.courseCategory.create({ data: { ...c, order: i } });
  }
}

async function ensureLmsContent(client: PrismaClient) {
  const users = await client.user.findMany();
  const instructor = users.find((u) => u.role === "INSTRUCTOR");
  const lmsManager = users.find((u) => u.role === "LMS_MANAGER");

  // Attach modules/lessons to up to two existing public courses (they may not
  // exist yet on a truly fresh DB — seed.ts runs first at boot).
  const courses = await client.course.findMany({ take: 3, orderBy: { order: "asc" } });
  if (courses.length === 0) return;

  const cat = await client.courseCategory.findFirst();
  if (cat) {
    for (const c of courses) {
      if (!c.categoryId) {
        await client.course.update({
          where: { id: c.id },
          data: { categoryId: cat.id, ownerId: c.ownerId ?? instructor?.id ?? lmsManager?.id ?? null },
        });
      }
    }
  }

  if ((await client.module.count()) > 0) return;
  const target = courses[0];
  const modules = [
    { title: "Foundations & Tooling", description: "Setup, core concepts and the analytics toolchain.", lessons: [
      { title: "Welcome & program roadmap", type: "VIDEO", durationMin: 12, isPreview: true },
      { title: "Spreadsheets to SQL — mindset shift", type: "VIDEO", durationMin: 18, isPreview: false },
      { title: "Environment setup guide", type: "DOCUMENT", durationMin: 15, isPreview: false },
    ] },
    { title: "SQL for Analysts", description: "From SELECT to window functions with real datasets.", lessons: [
      { title: "SELECT, WHERE & ORDER BY", type: "VIDEO", durationMin: 22, isPreview: false },
      { title: "Joins — inner, left, self", type: "VIDEO", durationMin: 26, isPreview: false },
      { title: "SQL fundamentals quiz", type: "QUIZ", durationMin: 15, isPreview: false },
      { title: "Retail dataset — hands-on lab", type: "ASSIGNMENT", durationMin: 45, isPreview: false },
    ] },
    { title: "Dashboards & Storytelling", description: "Turn queries into decisions with BI dashboards.", lessons: [
      { title: "Chart selection & design principles", type: "VIDEO", durationMin: 20, isPreview: false },
      { title: "KPI dashboard build-along", type: "VIDEO", durationMin: 32, isPreview: false },
      { title: "Capstone dashboard submission", type: "ASSIGNMENT", durationMin: 60, isPreview: false },
    ] },
  ];
  let mi = 0;
  for (const m of modules) {
    const createdModule = await client.module.create({
      data: { courseId: target.id, title: m.title, description: m.description, order: mi++ },
    });
    let li = 0;
    for (const l of m.lessons) {
      const lesson = await client.lesson.create({
        data: { moduleId: createdModule.id, title: l.title, type: l.type, durationMin: l.durationMin, isPreview: l.isPreview, order: li++, url: l.type === "VIDEO" ? "https://www.youtube.com/watch?v=dQw4w9WgXcQ" : null, body: l.type === "DOCUMENT" || l.type === "ASSIGNMENT" ? "Follow the step-by-step instructions in this lesson. Submit your work for review by the training team." : null },
      });
      if (l.type === "QUIZ") {
        const quiz = await client.quiz.create({
          data: { courseId: target.id, lessonId: lesson.id, title: "SQL Fundamentals Quiz", description: "10 questions covering SELECT, JOINs and aggregation.", passScore: 60, timeLimitMin: 15 },
        });
        const questions = [
          { text: "Which clause filters rows BEFORE grouping?", options: JSON.stringify(["WHERE", "HAVING", "GROUP BY", "ORDER BY"]), correct: JSON.stringify([0]) },
          { text: "INNER JOIN returns…", options: JSON.stringify(["All rows from both tables", "Only matching rows", "All left rows + matches", "Cartesian product"]), correct: JSON.stringify([1]) },
          { text: "COUNT(*) counts NULL values too.", options: JSON.stringify(["True", "False"]), correct: JSON.stringify([1]) },
          { text: "Which function replaces NULL with a default?", options: JSON.stringify(["NVL()", "COALESCE()", "Both A and B", "ISNULL() only"]), correct: JSON.stringify([2]) },
        ];
        let qi = 0;
        for (const q of questions) {
          await client.quizQuestion.create({ data: { quizId: quiz.id, text: q.text, type: q.options === JSON.stringify(["True", "False"]) ? "BOOLEAN" : "SINGLE", options: q.options, correct: q.correct, points: 1, order: qi++ } });
        }
      }
      if (l.type === "ASSIGNMENT") {
        await client.assignment.create({
          data: { courseId: target.id, lessonId: lesson.id, title: l.title.replace("Capstone ", "Capstone: ").replace("Retail dataset", "Lab:"), instructions: "Work on the provided dataset and submit your workbook plus a short summary of insights.", maxPoints: 100, dueInDays: 14 },
        });
      }
    }
  }
}

async function ensureEnrollmentsProgressCerts(client: PrismaClient) {
  const courses = await client.course.findMany({ take: 3, orderBy: { order: "asc" } });
  if (courses.length === 0) return;
  const contacts = await client.contact.findMany({ take: 6 });
  if (contacts.length === 0) return;
  const users = await client.user.findMany();
  const instructor = users.find((u) => u.role === "INSTRUCTOR");

  // Batch
  if ((await client.batch.count()) === 0 && courses[0]) {
    await client.batch.create({
      data: { name: "DA-0126", courseId: courses[0].id, instructorId: instructor?.id ?? null, startsAt: daysFromNow(-21), endsAt: daysFromNow(70), capacity: 40, status: "ACTIVE" },
    });
    await client.batch.create({
      data: { name: "DA-0326", courseId: courses[0].id, instructorId: instructor?.id ?? null, startsAt: daysFromNow(35), endsAt: daysFromNow(130), capacity: 40, status: "UPCOMING" },
    });
  }

  if ((await client.enrollment.count({ where: { contactId: { not: null } } })) > 0) return;
  const lessons = await client.lesson.findMany({ orderBy: { order: "asc" } });
  const quiz = await client.quiz.findFirst();
  const assignment = await client.assignment.findFirst();
  const demoEnrollments = [
    { contact: 0, progress: 100, status: "COMPLETED" },
    { contact: 2, progress: 64, status: "ACTIVE" },
    { contact: 5, progress: 32, status: "ACTIVE" },
    { contact: 6, progress: 10, status: "ACTIVE" },
    { contact: 4, progress: 0, status: "ACTIVE" },
  ];
  for (const [i, e] of demoEnrollments.entries()) {
    const contact = contacts[e.contact];
    if (!contact) continue;
    const created = await client.enrollment.create({
      data: {
        contactId: contact.id,
        learnerName: contact.name,
        courseId: courses[0].id,
        itemSlug: courses[0].slug,
        itemType: "course",
        batchName: i < 3 ? "DA-0126" : "DA-0326",
        status: e.status,
        progress: e.progress,
      },
    });
    // lesson progress rows up to the target %
    const doneCount = Math.round((lessons.length * e.progress) / 100);
    for (const lesson of lessons.slice(0, doneCount)) {
      await client.lessonProgress.create({ data: { enrollmentId: created.id, lessonId: lesson.id } }).catch(() => undefined);
    }
    // a quiz attempt for the learner who is mid-course
    if (quiz && i === 1) {
      await client.quizAttempt.create({
        data: { quizId: quiz.id, enrollmentId: created.id, answers: JSON.stringify([[0], [1], [1], [2]]), score: 3, maxScore: 4, passed: true },
      });
    }
    // an assignment submission awaiting grade + one graded
    if (assignment && i === 1) {
      await client.assignmentSubmission.create({
        data: { assignmentId: assignment.id, enrollmentId: created.id, contentText: "Submitted retail lab workbook with 6 insights and a churn cohort analysis.", status: "SUBMITTED" },
      });
    }
    if (assignment && i === 0) {
      await client.assignmentSubmission.create({
        data: { assignmentId: assignment.id, enrollmentId: created.id, contentText: "Capstone dashboard with executive summary.", status: "GRADED", grade: 92, feedback: "Excellent storytelling — minor formatting feedback sent.", gradedBy: "instructor@skillgorila.com", gradedAt: daysFromNow(-3) },
      });
    }
    // certificate for the completed learner
    if (e.status === "COMPLETED") {
      const serial = `SG-CERT-${new Date().getFullYear()}-0000${i + 1}`;
      await client.certificate.create({
        data: { serial, enrollmentId: created.id, learnerName: contact.name, courseId: courses[0].id, courseTitle: courses[0].title, grade: "A", issuedBy: "SkillGorila Certification Desk" },
      }).catch(() => undefined);
    }
  }
}

async function ensureNotifications(client: PrismaClient) {
  if ((await client.notification.count()) > 0) return;
  const users = await client.user.findMany();
  for (const u of users.slice(0, 4)) {
    await client.notification.create({
      data: { userId: u.id, title: "Welcome to the new SkillGorila platform", body: "CRM and LMS are now one connected workspace. Explore your dashboard to get started.", type: "SUCCESS", link: "/dashboard" },
    });
  }
}
