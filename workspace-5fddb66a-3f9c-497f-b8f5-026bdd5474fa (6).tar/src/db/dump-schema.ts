/* Regenerates prisma/schema.sql from the live SQLite database so that the
 * boot-time bootstrap (applySchema) can provision fresh deployments.
 * Run: bunx tsx src/db/dump-schema.ts */
import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";
import { resolvedDatabaseUrl } from "@/lib/db-url";

async function main() {
  const client = new PrismaClient({ datasourceUrl: resolvedDatabaseUrl });
  try {
    const rows = await client.$queryRaw<{ name: string; sql: string }[]>`
      SELECT name, sql FROM sqlite_master
      WHERE type IN ('table','index') AND sql IS NOT NULL AND name NOT LIKE 'sqlite_%'
      ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END, name`;
    const tables = rows.filter((r) => r.sql.trimStart().toUpperCase().startsWith("CREATE TABLE"));
    const indexes = rows.filter((r) => !r.sql.trimStart().toUpperCase().startsWith("CREATE TABLE"));
    const out = [
      "-- SkillGorila SQLite schema (auto-generated from the live database).",
      "-- Applied idempotently at boot by src/db/bootstrap.ts (applySchema).",
      "",
      ...tables.map((t) => `${t.sql};\n`),
      ...indexes.map((i) => `${i.sql};\n`),
    ].join("\n");
    const dest = path.join(process.cwd(), "prisma", "schema.sql");
    fs.writeFileSync(dest, out);
    console.log(`[dump-schema] wrote ${tables.length} tables + ${indexes.length} indexes -> ${dest}`);
  } finally {
    await client.$disconnect();
  }
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
