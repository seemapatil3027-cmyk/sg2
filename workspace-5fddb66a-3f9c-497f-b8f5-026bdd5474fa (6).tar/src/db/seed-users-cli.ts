/* CLI entry for core account provisioning — run with: npm run db:seed:users */
import { PrismaClient } from "@prisma/client";
import { ensureCoreAccounts } from "./core-accounts";
import { resolvedDatabaseUrl } from "../lib/db-url";

async function main() {
  const client = new PrismaClient({
    datasourceUrl: resolvedDatabaseUrl,
    log: ["error"],
  });
  try {
    await ensureCoreAccounts(client);
    const users = await client.user.findMany({
      select: { email: true, name: true, role: true },
      orderBy: { role: "asc" },
    });
    console.log("Core accounts ready:");
    for (const u of users) console.log(`  ${u.role.padEnd(10)} ${u.email} (${u.name})`);
  } finally {
    await client.$disconnect();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
