/* Core platform accounts — shared by the boot-time bootstrap and the
 * `db:seed:users` CLI. Idempotent: creates missing accounts, fixes stale
 * roles, and NEVER overwrites an existing password.
 *
 * Staff-only: students no longer log in to the platform. The legacy demo
 * student account (student@skillgorila.com) is intentionally NOT provisioned
 * anymore — existing rows stay as internal learner records. */
import type { PrismaClient } from "@prisma/client";
import { hashPassword } from "@/lib/password";
import type { RoleKey } from "@/lib/rbac";

export interface CoreAccount {
  email: string;
  name: string;
  role: RoleKey;
  password: string;
}

export const CORE_ACCOUNTS: readonly CoreAccount[] = [
  {
    email: "superadmin@skillgorila.com",
    name: "Super Admin",
    role: "SUPER_ADMIN",
    password: "Super@123",
  },
  {
    email: "admin@skillgorila.com",
    name: "Platform Admin",
    role: "ADMIN",
    password: "Admin@123",
  },
  {
    email: "crm.manager@skillgorila.com",
    name: "Meera Krishnan",
    role: "CRM_MANAGER",
    password: "Crm@123",
  },
  {
    email: "crm.executive@skillgorila.com",
    name: "Arjun Mehta",
    role: "CRM_EXECUTIVE",
    password: "Crm@123",
  },
  {
    email: "counsellor@skillgorila.com",
    name: "Priya Sharma",
    role: "CRM_EXECUTIVE",
    password: "Counsellor@123",
  },
  {
    email: "lms.manager@skillgorila.com",
    name: "Sana Qureshi",
    role: "LMS_MANAGER",
    password: "Lms@123",
  },
  {
    email: "instructor@skillgorila.com",
    name: "Rahul Verma",
    role: "INSTRUCTOR",
    password: "Instructor@123",
  },
  {
    email: "employee@skillgorila.com",
    name: "Neha Kulkarni",
    role: "EMPLOYEE",
    password: "Employee@123",
  },
] as const;

export async function ensureCoreAccounts(client: PrismaClient): Promise<void> {
  for (const acct of CORE_ACCOUNTS) {
    const existing = await client.user.findUnique({ where: { email: acct.email } });
    if (existing && existing.role === acct.role) continue;
    if (!existing) {
      await client.user.create({
        data: {
          name: acct.name,
          email: acct.email,
          passwordHash: hashPassword(acct.password),
          role: acct.role,
          isActive: true,
        },
      });
    } else {
      // record exists with a stale role — fix the role, keep the password
      await client.user.update({ where: { email: acct.email }, data: { role: acct.role } });
    }
  }
}
