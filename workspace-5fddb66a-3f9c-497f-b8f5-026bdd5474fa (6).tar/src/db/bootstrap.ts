import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";
import { resolvedDatabaseUrl, databaseFilePath } from "@/lib/db-url";
import { ensureCoreAccounts } from "./core-accounts";
import { ensureCrmDemoData } from "./seed-crm";
import { ensureRoles, ensurePlatformDemoData } from "./seed-platform";
import { runSeed } from "./seed";

/**
 * Self-provisioning database bootstrap.
 *
 * Runs once per server instance (instrumentation.ts) and makes a fresh
 * deployment work with ZERO manual DB steps:
 *   1. Ensures the SQLite directory/file location exists.
 *   2. Applies any missing tables from prisma/schema.sql (idempotent —
 *      existing tables and data are never touched; works on databases from
 *      older deployments that are missing newer tables).
 *   3. If the content tables are empty → applies seed data (tracks, courses,
 *      mentors, testimonials, blogs, FAQs, users…).
 */

const CORE_TABLES = ["User", "Track", "Course"];

let inFlight: Promise<boolean> | null = null;

async function existingTables(client: PrismaClient): Promise<Set<string>> {
  const rows = await client.$queryRaw<{ name: string }[]>`SELECT name FROM sqlite_master WHERE type = 'table'`;
  return new Set(rows.map((r) => r.name));
}

/** Make every DDL statement idempotent so partial databases converge safely. */
function makeIdempotent(statement: string): string {
  return statement
    .replace(/^CREATE TABLE /i, "CREATE TABLE IF NOT EXISTS ")
    .replace(/^CREATE UNIQUE INDEX /i, "CREATE UNIQUE INDEX IF NOT EXISTS ")
    .replace(/^CREATE INDEX /i, "CREATE INDEX IF NOT EXISTS ");
}

async function applySchema(client: PrismaClient): Promise<boolean> {
  const schemaPath = path.join(process.cwd(), "prisma", "schema.sql");
  if (!fs.existsSync(schemaPath)) {
    console.warn(
      `[db-bootstrap] prisma/schema.sql not found at ${schemaPath} — cannot auto-provision schema`
    );
    return false;
  }
  const raw = fs.readFileSync(schemaPath, "utf8");
  const statements = raw
    .split(/;\s*\n/)
    .map((s) => s.replace(/^\s*--.*$/gm, "").trim())
    .filter((s) => s.length > 0)
    .map(makeIdempotent);

  for (const statement of statements) {
    try {
      await client.$executeRawUnsafe(statement);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (/already exists/i.test(message)) continue;
      throw error;
    }
  }
  return true;
}

async function seedIfEmpty(client: PrismaClient): Promise<boolean> {
  const trackCount = await client.track.count();
  if (trackCount > 0) return false;
  await runSeed(client);
  return true;
}

/**
 * Column-level migrations for databases created by older deployments.
 * Every entry is applied idempotently (column existence is checked first),
 * so any deployed database converges to the current schema on boot.
 */
const COLUMN_MIGRATIONS: { table: string; column: string; ddl: string }[] = [
  { table: "User", column: "role", ddl: `ALTER TABLE "User" ADD COLUMN "role" TEXT NOT NULL DEFAULT 'STUDENT'` },
  { table: "User", column: "phone", ddl: `ALTER TABLE "User" ADD COLUMN "phone" TEXT` },
  { table: "User", column: "isActive", ddl: `ALTER TABLE "User" ADD COLUMN "isActive" BOOLEAN NOT NULL DEFAULT 1` },
  { table: "User", column: "lastLoginAt", ddl: `ALTER TABLE "User" ADD COLUMN "lastLoginAt" DATETIME` },
  { table: "Lead", column: "status", ddl: `ALTER TABLE "Lead" ADD COLUMN "status" TEXT NOT NULL DEFAULT 'NEW'` },
  { table: "Lead", column: "assignedTo", ddl: `ALTER TABLE "Lead" ADD COLUMN "assignedTo" TEXT` },
  { table: "Lead", column: "score", ddl: `ALTER TABLE "Lead" ADD COLUMN "score" INTEGER NOT NULL DEFAULT 0` },
  { table: "Lead", column: "ownerId", ddl: `ALTER TABLE "Lead" ADD COLUMN "ownerId" TEXT` },
  { table: "Lead", column: "contactId", ddl: `ALTER TABLE "Lead" ADD COLUMN "contactId" TEXT` },
  { table: "Lead", column: "convertedAt", ddl: `ALTER TABLE "Lead" ADD COLUMN "convertedAt" DATETIME` },
  { table: "Lead", column: "lostReason", ddl: `ALTER TABLE "Lead" ADD COLUMN "lostReason" TEXT` },
  { table: "Lead", column: "city", ddl: `ALTER TABLE "Lead" ADD COLUMN "city" TEXT` },
  { table: "Lead", column: "education", ddl: `ALTER TABLE "Lead" ADD COLUMN "education" TEXT` },
  { table: "Lead", column: "experience", ddl: `ALTER TABLE "Lead" ADD COLUMN "experience" TEXT` },
  { table: "Lead", column: "program", ddl: `ALTER TABLE "Lead" ADD COLUMN "program" TEXT` },
  { table: "Lead", column: "mode", ddl: `ALTER TABLE "Lead" ADD COLUMN "mode" TEXT` },
  { table: "Lead", column: "nextFollowUpAt", ddl: `ALTER TABLE "Lead" ADD COLUMN "nextFollowUpAt" DATETIME` },
  { table: "Course", column: "thumbnail", ddl: `ALTER TABLE "Course" ADD COLUMN "thumbnail" TEXT` },
  { table: "Course", column: "status", ddl: `ALTER TABLE "Course" ADD COLUMN "status" TEXT NOT NULL DEFAULT 'PUBLISHED'` },
  { table: "Course", column: "ownerId", ddl: `ALTER TABLE "Course" ADD COLUMN "ownerId" TEXT` },
  { table: "Course", column: "categoryId", ddl: `ALTER TABLE "Course" ADD COLUMN "categoryId" TEXT` },
  { table: "Enrollment", column: "contactId", ddl: `ALTER TABLE "Enrollment" ADD COLUMN "contactId" TEXT` },
  { table: "Enrollment", column: "learnerName", ddl: `ALTER TABLE "Enrollment" ADD COLUMN "learnerName" TEXT NOT NULL DEFAULT ''` },
  { table: "Enrollment", column: "courseId", ddl: `ALTER TABLE "Enrollment" ADD COLUMN "courseId" TEXT` },
];

async function ensureColumns(client: PrismaClient): Promise<number> {
  let applied = 0;
  for (const mig of COLUMN_MIGRATIONS) {
    try {
      const cols = await client.$queryRawUnsafe<{ name: string }[]>(
        `PRAGMA table_info("${mig.table}")`
      );
      if (cols.some((c) => c.name === mig.column)) continue;
      await client.$executeRawUnsafe(mig.ddl);
      applied += 1;
    } catch {
      // table does not exist yet → schema.sql will create it with the column
    }
  }
  return applied;
}

/**
 * Old deployments created Enrollment.userId as NOT NULL; the platform now
 * supports staff-managed learners (contactId) without a user account. SQLite
 * cannot ALTER a NOT NULL constraint, so rebuild the table once if needed.
 */
async function relaxEnrollmentUserId(client: PrismaClient): Promise<boolean> {
  try {
    const cols = await client.$queryRawUnsafe<{ name: string; notnull: number }[]>(
      `PRAGMA table_info("Enrollment")`
    );
    const userId = cols.find((c) => c.name === "userId");
    if (!userId || userId.notnull === 0) return false;

    const schemaPath = path.join(process.cwd(), "prisma", "schema.sql");
    if (!fs.existsSync(schemaPath)) return false;
    const raw = fs.readFileSync(schemaPath, "utf8");
    const match = raw.match(/CREATE TABLE "Enrollment" \([\s\S]*?\);/);
    if (!match) return false;
    const createNew = match[0].replace(/"Enrollment"/, '"Enrollment__rebuild"').replace(/;$/, ";");
    await client.$executeRawUnsafe(`DROP TABLE IF EXISTS "Enrollment__rebuild"`);
    await client.$executeRawUnsafe(createNew);
    await client.$executeRawUnsafe(
      `INSERT INTO "Enrollment__rebuild" (id, userId, contactId, learnerName, courseId, itemSlug, itemType, batchName, status, progress, sourceLeadId, enrolledAt, updatedAt)
       SELECT id, userId, contactId, learnerName, courseId, itemSlug, itemType, batchName, status, progress, sourceLeadId, enrolledAt, updatedAt FROM "Enrollment"`
    );
    await client.$executeRawUnsafe(`DROP TABLE "Enrollment"`);
    await client.$executeRawUnsafe(`ALTER TABLE "Enrollment__rebuild" RENAME TO "Enrollment"`);
    console.log("[db-bootstrap] Enrollment.userId relaxed to nullable (table rebuilt)");
    return true;
  } catch (error) {
    console.error("[db-bootstrap] Enrollment rebuild skipped:", error);
    return false;
  }
}

async function bootstrap(): Promise<boolean> {
  const startedAt = Date.now();

  // make sure the target directory exists (fresh servers ship without db/)
  if (databaseFilePath) {
    fs.mkdirSync(path.dirname(databaseFilePath), { recursive: true });
  }

  const client = new PrismaClient({
    datasourceUrl: resolvedDatabaseUrl,
    log: ["error"],
  });
  try {
    const tables = await existingTables(client);
    const missingCore = !CORE_TABLES.every((t) => tables.has(t));

    // Always converge the schema — every statement is IF NOT EXISTS, so this
    // creates any tables the running database is missing (new deploys, old
    // deploys that predate LeadActivity/Enrollment/Payment, etc.) and is a
    // no-op for fully current databases.
    await applySchema(client);
    const columnsAdded = await ensureColumns(client);
    await relaxEnrollmentUserId(client);
    const rolesSeeded = await ensureRoles(client);
    const seeded = await seedIfEmpty(client);
    await ensureCoreAccounts(client);
    await ensureCrmDemoData(client);
    await ensurePlatformDemoData(client);

    if (missingCore || seeded || columnsAdded > 0 || rolesSeeded) {
      console.log(
        `[db-bootstrap] database ready in ${Date.now() - startedAt}ms ` +
          `(schema: ${missingCore ? "created" : "converged"}, seed: ${seeded ? "applied" : "skipped"}, ` +
          `columns added: ${columnsAdded}, roles: ${rolesSeeded ? "seeded" : "present"}, core accounts: ready)`
      );
    }
    return true;
  } finally {
    await client.$disconnect().catch(() => undefined);
  }
}

/** Idempotent, single-flight — safe to call from instrumentation and /api/health. */
export function bootstrapDatabase(): Promise<boolean> {
  if (!inFlight) {
    inFlight = bootstrap().catch((error) => {
      inFlight = null; // allow a retry on the next call (e.g. after a fix + restart)
      console.error("[db-bootstrap] failed:", error);
      return false;
    });
  }
  return inFlight;
}
