/* CLI entry for the main seed — run with: npm run db:seed */
import { PrismaClient } from "@prisma/client";
import { runSeed } from "./seed";
import { resolvedDatabaseUrl } from "../lib/db-url";

async function main() {
  const client = new PrismaClient({
    datasourceUrl: resolvedDatabaseUrl,
    log: ["error"],
  });
  try {
    await runSeed(client);
  } finally {
    await client.$disconnect();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
