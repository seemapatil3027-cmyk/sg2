/* CRM demo data — ensures any deployment has a realistic, ready-to-explore
 * pipeline: demo leads across all stages, activity timelines, and an active
 * enrollment + payment history for the documented student account.
 * Idempotent: demo leads are only created when the Lead table is empty, and
 * the demo student's enrollment/payments are only created when absent. */
import type { PrismaClient } from "@prisma/client";

const COUNSELLOR = "counsellor@skillgorila.com";
const STUDENT = "student@skillgorila.com";

const LEAD_STATUSES = [
  "New",
  "Assigned",
  "Contacted",
  "Counselling",
  "Demo",
  "Interested",
  "Payment Pending",
  "Enrolled",
] as const;

interface DemoLead {
  name: string;
  phone: string;
  email: string;
  source: string;
  city: string;
  education: string;
  experience: string;
  program: string;
  itemSlug: string;
  mode: string;
  status: (typeof LEAD_STATUSES)[number];
  leadScore?: number;
  hoursAgo: number;
}

const DEMO_LEADS: DemoLead[] = [
  {
    name: "Rahul Sharma", phone: "9820011234", email: "rahul.sharma@example.com",
    source: "contact", city: "Pune", education: "B.Tech Mechanical", experience: "2 years",
    program: "Data Analytics & Generative AI", itemSlug: "data-analytics-and-ai", mode: "online",
    status: "Counselling", leadScore: 82, hoursAgo: 26,
  },
  {
    name: "Priya Patil", phone: "9876500123", email: "priya.patil@example.com",
    source: "callback", city: "Mumbai", education: "B.Com", experience: "Fresher",
    program: "SAP FICO", itemSlug: "sap-fico", mode: "classroom",
    status: "New", leadScore: 54, hoursAgo: 3,
  },
  {
    name: "Amit Verma", phone: "9910023456", email: "amit.verma@example.com",
    source: "assessment", city: "Delhi NCR", education: "BCA", experience: "1 year",
    program: "Data Analytics & Generative AI", itemSlug: "data-analytics-and-ai", mode: "online",
    status: "Interested", leadScore: 90, hoursAgo: 50,
  },
  {
    name: "Sneha Iyer", phone: "9845012345", email: "sneha.iyer@example.com",
    source: "brochure", city: "Bangalore", education: "B.E. Computer Science", experience: "3 years",
    program: "Full Stack Software Development", itemSlug: "full-stack-software-development", mode: "online",
    status: "Demo", leadScore: 76, hoursAgo: 9,
  },
  {
    name: "Vikram Singh", phone: "9811023456", email: "vikram.singh@example.com",
    source: "masterclass", city: "Jaipur", education: "BBA", experience: "4 years",
    program: "Digital Marketing Mastery", itemSlug: "digital-marketing-mastery", mode: "hybrid",
    status: "Contacted", leadScore: 61, hoursAgo: 33,
  },
  {
    name: "Ananya Das", phone: "9836012345", email: "ananya.das@example.com",
    source: "assessment", city: "Kolkata", education: "B.Sc Statistics", experience: "Fresher",
    program: "Data Analytics & Generative AI", itemSlug: "data-analytics-and-ai", mode: "online",
    status: "Payment Pending", leadScore: 88, hoursAgo: 70,
  },
  {
    name: "Karan Mehta", phone: "9898012345", email: "karan.mehta@example.com",
    source: "enroll", city: "Ahmedabad", education: "B.Tech IT", experience: "2 years",
    program: "SAP FICO", itemSlug: "sap-fico", mode: "online",
    status: "Enrolled", leadScore: 85, hoursAgo: 120,
  },
  {
    name: "Divya Nair", phone: "9847012345", email: "divya.nair@example.com",
    source: "contact", city: "Kochi", education: "M.Com", experience: "1 year",
    program: "Data Analytics & Generative AI", itemSlug: "data-analytics-and-ai", mode: "online",
    status: "Assigned", leadScore: 58, hoursAgo: 14,
  },
  {
    name: "Rohit Kulkarni", phone: "9822012345", email: "rohit.kulkarni@example.com",
    source: "callback", city: "Nagpur", education: "Diploma Engineering", experience: "5 years",
    program: "Full Stack Software Development", itemSlug: "full-stack-software-development", mode: "online",
    status: "New", leadScore: 49, hoursAgo: 1,
  },
];

function noteWithScore(lead: DemoLead): string {
  const parts: string[] = [];
  if (lead.leadScore != null) parts.push(`leadScore:${lead.leadScore}`);
  parts.push(`recommended:${lead.itemSlug}`);
  parts.push(`[crm-demo] goal: switch into ${lead.program}`);
  return parts.join(" | ");
}

export async function ensureCrmDemoData(client: PrismaClient): Promise<void> {
  /* ---- Demo leads + activity timelines (only when no leads exist) ---- */
  const leadCount = await client.lead.count();
  if (leadCount === 0) {
    for (const lead of DEMO_LEADS) {
      const createdAt = new Date(Date.now() - lead.hoursAgo * 3600_000);
      const created = await client.lead.create({
        data: {
          name: lead.name,
          phone: lead.phone,
          email: lead.email,
          source: lead.source,
          note: noteWithScore(lead),
          itemSlug: lead.itemSlug,
          status: lead.status,
          assignedTo: lead.status === "New" ? null : COUNSELLOR,
          city: lead.city,
          education: lead.education,
          experience: lead.experience,
          program: lead.program,
          mode: lead.mode,
          createdAt,
          updatedAt: createdAt,
        },
      });

      const activities: { type: string; title: string; detail?: string; minsLater: number }[] = [
        {
          type: "note",
          title: "Lead created",
          detail: `Captured from website (${lead.source}) — interested in ${lead.program}.`,
          minsLater: 0,
        },
      ];
      if (lead.status !== "New") {
        activities.push({
          type: "assigned",
          title: "Assigned to counsellor",
          detail: "Auto-routed by program specialty.",
          minsLater: 7,
        });
        activities.push({
          type: "call",
          title: "Call attempted",
          detail: "Spoke briefly — shared program overview, sounded interested.",
          minsLater: 40,
        });
        activities.push({
          type: "whatsapp",
          title: "WhatsApp sent",
          detail: `Brochure + batch details for ${lead.program} shared.`,
          minsLater: 65,
        });
      }
      if (["Counselling", "Demo", "Interested", "Payment Pending", "Enrolled"].includes(lead.status)) {
        activities.push({
          type: "counselling",
          title: "Counselling completed",
          detail: `Goal mapped to ${lead.program}. Current CTC ₹5.5 LPA → expected ₹10 LPA. Recommended batch: Nov 2026.`,
          minsLater: 180,
        });
      }
      if (["Demo", "Interested", "Payment Pending", "Enrolled"].includes(lead.status)) {
        activities.push({
          type: "demo",
          title: "Demo class scheduled",
          detail: "Invitation sent for this week's live demo session.",
          minsLater: 300,
        });
      }
      if (["Payment Pending", "Enrolled"].includes(lead.status)) {
        activities.push({
          type: "payment_link",
          title: "Payment link sent",
          detail: "Installment plan (2 payments) shared over email + WhatsApp.",
          minsLater: 420,
        });
      }
      if (lead.status === "Enrolled") {
        activities.push({
          type: "converted",
          title: "Converted to student",
          detail: "Payment verified — enrollment activated, LMS access granted.",
          minsLater: 600,
        });
      }

      for (const act of activities) {
        await client.leadActivity.create({
          data: {
            leadId: created.id,
            type: act.type,
            title: act.title,
            detail: act.detail,
            createdBy: act.type === "note" ? null : COUNSELLOR,
            createdAt: new Date(createdAt.getTime() + act.minsLater * 60_000),
          },
        });
      }
    }
  }

  /* ---- Demo student's active enrollment + payment history ---- */
  const student = await client.user.findUnique({ where: { email: STUDENT } });
  if (student) {
    const existingEnrollment = await client.enrollment.findFirst({
      where: { userId: student.id },
    });
    if (!existingEnrollment) {
      const track = await client.track.findUnique({ where: { slug: "data-analytics-and-ai" } });
      const enrollment = await client.enrollment.create({
        data: {
          userId: student.id,
          itemSlug: "data-analytics-and-ai",
          itemType: "track",
          batchName: "DA-1126",
          status: "ACTIVE",
          progress: 18,
          enrolledAt: new Date(Date.now() - 12 * 24 * 3600_000),
        },
      });
      await client.payment.create({
        data: {
          userId: student.id,
          enrollmentId: enrollment.id,
          amount: 30000,
          plan: "installment",
          status: "PAID",
          method: "upi",
          note: track ? `Installment 1 — ${track.title}` : "Installment 1",
          createdAt: new Date(Date.now() - 12 * 24 * 3600_000),
        },
      });
      await client.payment.create({
        data: {
          userId: student.id,
          enrollmentId: enrollment.id,
          amount: 15000,
          plan: "installment",
          status: "PENDING",
          method: "link",
          note: "Installment 2 — due 15 Dec",
          dueAt: new Date(Date.now() + 20 * 24 * 3600_000),
        },
      });
    }
  }
}
