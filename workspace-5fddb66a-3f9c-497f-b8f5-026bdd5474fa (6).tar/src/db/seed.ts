/* Seed data module — exports runSeed(client). CLI entry: src/db/seed-cli.ts (npm run db:seed) */
import { PrismaClient } from "@prisma/client";

let db: PrismaClient;

const tracks = [
  {
    slug: "data-analytics-and-ai",
    title: "Data Analytics & Generative AI",
    description:
      "Become an AI-Powered Data Analyst in 5 Months. Master Excel, Statistics, Power BI, SQL, Python, and AI to drive data driven decisions. Build job-ready skills with real projects, live mentorship, and placement support.",
    icon: "BarChart3",
    enrollments: "4k+",
    liveClasses: 20,
    projects: 7,
    hrPerWeek: 14,
    discount: "15% Off",
    limitedSeats: true,
    expertLogos: ["Excel", "Microsoft", "HP"],
    learners: "4K+",
    packageUpto: "8L",
    jobs: "3,217+",
    companies: "300+",
    weeks: 20,
    hrsPerDay: 2,
    mode: "online",
    badge: "No coding skills required ✌️",
    industryInsight:
      "By 2030, 93% of companies globally will rely on data analytics for decision-making and they want analysts who can work with AI. With 25% growth in data analyst roles expected this decade, professionals who combine analytics with AI skills are the most sought-after in the job market today.",
    openings: "1 lac+",
    avgCtc: "8 LPA",
    avgHike: "45%",
    skills: ["Advanced Prompting", "AI Workflow Automation", "AI Agent Building", "Excel Mastery", "Statistics", "Data Querying", "Data Visualization", "Python for Analytics"],
    outcomes: [
      "Walk away with the ability to clean, analyze, and present data in Excel",
      "Learn to write SQL queries that extract data from any database",
      "Gain hands-on skills to analyze data and automate tasks using Python",
      "Build dashboards and reports in Power BI that tell a clear story",
      "Gain the skills to apply statistical methods to real-world business problems",
      "Master the art of writing prompts that get accurate AI outputs",
      "Create automated workflows that connect tools and run without manual effort",
      "Design AI agents that can research, analyze, and act on their own",
    ],
    syllabus: [
      { title: "Excel: Beginner to Advanced", weeks: 3, tags: ["Excel", "Data Analysis", "Data Manipulation"] },
      { title: "SQL: Beginner to Advanced", weeks: 4, tags: ["SQL", "Postgres", "Exploratory Analysis"] },
      { title: "Structured Problem Solving and Case Studies", weeks: 2, tags: ["SWOT", "BCG Matrix", "McKinsey 7S"] },
      { title: "Data Visualization in Power BI", weeks: 3, tags: ["Data Visualisation", "Power BI", "Dashboarding"] },
      { title: "Python Fundamentals", weeks: 4, tags: ["Python Fundamentals", "Data Visualization"] },
      { title: "Generative AI", weeks: 4, tags: ["Prompt Engineering", "AI Agents", "Workflow Automation"] },
    ],
    projectsList: [
      { title: "Jio Finding target market", description: "Analyse the telecom data of india and find where should Jio invest its capital expense by understanding different user segments in different cities." },
      { title: "Interview Scheduling Agent", description: "Develop an advanced autonomous AI agent designed to manage the entire process of interview scheduling. This agent will engage in natural conversations with candidates, ensuring a seamless experience while coordinating with interviewers' calendars." },
      { title: "Sales Call Analysis Platform", description: "Develop a comprehensive platform that allows managers to easily upload their sales call recordings. This platform will utilize AI technology to provide accurate transcriptions, valuable conversation insights, and tailored coaching tips aimed at enhancing overall performance." },
      { title: "Swiggy Drone Delivery", description: "Find out how the Swiggy drone delivery system should be designed for optimal outcomes for business, customers and delivery partners." },
      { title: "Flipkart Category Management", description: "Use systematic analysis to find how category managers use trends to plan campaigns, inventories and ecommerce strategies." },
    ],
    highlights: [
      "Master the skills with short conceptual videos, reading materials and quizzes",
      "Work on industry projects to build your resume",
      "Undergo mock interviews with industry experts",
      "Get interview invites from 300+ partner companies and land your dream job",
    ],
    order: 1,
  },
  {
    slug: "data-analytics-offline",
    title: "Data Analytics Classroom Program",
    description:
      "A 4 months in-classroom Data Analytics Program with live sessions, hands-on projects, and real-world case studies. Taught by Deepak Kharol, an IIT Delhi alumnus with 10+ years of experience at Mu Sigma, Swiggy, Cuemath, and PayU.",
    icon: "School",
    enrollments: "1k+",
    liveClasses: 20,
    projects: 7,
    hrPerWeek: 14,
    discount: "20% Off",
    limitedSeats: true,
    expertLogos: ["Excel", "Microsoft", "HP"],
    learners: "1K+",
    packageUpto: "8L",
    jobs: "2,150+",
    companies: "300+",
    weeks: 16,
    hrsPerDay: 2,
    mode: "classroom",
    badge: "In-classroom in Bangalore 🏫",
    industryInsight:
      "Classroom programs create 2x more peer learning and accountability. With Bengaluru hiring 38% of India's data analysts, learning in-classroom in the heart of the startup capital gives you direct access to the ecosystem, meetups and recruiters.",
    openings: "80K+",
    avgCtc: "8 LPA",
    avgHike: "45%",
    skills: ["Excel Mastery", "Statistics", "SQL", "Data Visualization", "Power BI", "Python for Analytics", "Case Studies"],
    outcomes: [
      "Learn in-classroom with direct interaction with Deepak Kharol (IIT Delhi)",
      "Solve real business case studies from Mu Sigma, Swiggy and PayU",
      "Build 7 portfolio-worthy analytics projects",
      "Get end-to-end placement support with 300+ hiring partners",
      "Practice in mock interviews and get personalised feedback",
      "Network with peers and alumni in Bangalore",
    ],
    syllabus: [
      { title: "Excel: Beginner to Advanced", weeks: 3, tags: ["Excel", "Data Analysis", "Data Manipulation"] },
      { title: "SQL: Beginner to Advanced", weeks: 4, tags: ["SQL", "Postgres", "Exploratory Analysis"] },
      { title: "Structured Problem Solving and Case Studies", weeks: 2, tags: ["SWOT", "BCG Matrix", "McKinsey 7S"] },
      { title: "Data Visualization in Power BI", weeks: 3, tags: ["Data Visualisation", "Power BI", "Dashboarding"] },
      { title: "Python Fundamentals", weeks: 4, tags: ["Python Fundamentals", "Data Visualization"] },
    ],
    projectsList: [
      { title: "Swiggy Drone Delivery", description: "Find out how the Swiggy drone delivery system should be designed for optimal outcomes for business, customers and delivery partners." },
      { title: "Flipkart Category Management", description: "Use systematic analysis to find how category managers use trends to plan campaigns, inventories and ecommerce strategies." },
      { title: "Harley Davidson Dealer Stock Management", description: "Run an inventory planning exercise for a dealership and derive insights to manage stock planning. How to plan for supply and demand and measure seasonality of such businesses." },
      { title: "HCL Technologies Digital Marketing", description: "Experience how HCL used its website metrics to drive its digital acquisition strategy and how it improved the customer experience from various metrics and user journey." },
    ],
    highlights: [
      "In-classroom live sessions in Bangalore",
      "Taught by Deepak Kharol, IIT Delhi alumnus, 10+ yrs at Mu Sigma, Swiggy, Cuemath, PayU",
      "Hands-on projects and real-world case studies",
      "Placement support with 300+ partner companies",
    ],
    order: 2,
  },
  {
    slug: "ai-mastery-program",
    title: "AI Mastery Program",
    description:
      "Transform into an AI Generalist with hands-on training across design, analytics, automation & development. Build versatile skills to deploy AI solutions in any domain through real-world projects.",
    icon: "Sparkles",
    enrollments: "1k+",
    liveClasses: 10,
    projects: 27,
    hrPerWeek: 10,
    discount: "15% Off",
    limitedSeats: true,
    expertLogos: ["OpenAI", "Microsoft", "HP"],
    learners: "1K+",
    packageUpto: "12L",
    jobs: "1,800+",
    companies: "300+",
    weeks: 12,
    hrsPerDay: 2,
    mode: "online",
    badge: "No coding skills required ✌️",
    industryInsight:
      "AI job postings have grown 21x since 2022 and AI-fluent professionals command up to 40% higher salaries. Companies across every domain — design, marketing, analytics, engineering — are hunting for AI generalists who can ship AI-powered solutions.",
    openings: "50K+",
    avgCtc: "10 LPA",
    avgHike: "50%",
    skills: ["Prompt Engineering", "AI Design Tools", "AI Automation", "AI Agents", "AI Analytics", "AI Development"],
    outcomes: [
      "Master advanced prompting to get production-quality AI outputs",
      "Design stunning assets with AI design tools",
      "Automate repetitive workflows across your favourite tools",
      "Build and deploy AI agents that act on their own",
      "Analyse data with AI and ship insights faster",
      "Build a portfolio of 27 real-world AI projects",
    ],
    syllabus: [
      { title: "Foundations of Generative AI", weeks: 2, tags: ["LLMs", "Prompting", "AI Landscape"] },
      { title: "AI for Design & Content", weeks: 2, tags: ["Image Gen", "Video Gen", "Copywriting"] },
      { title: "AI Workflow Automation", weeks: 3, tags: ["Zapier", "Make", "APIs"] },
      { title: "Building AI Agents", weeks: 3, tags: ["Agents", "RAG", "Tool Use"] },
      { title: "AI for Analytics & Development", weeks: 2, tags: ["AI Analytics", "Vibe Coding"] },
    ],
    projectsList: [
      { title: "Interview Scheduling Agent", description: "Develop an advanced autonomous AI agent designed to manage the entire process of interview scheduling, engaging in natural conversations with candidates and coordinating with interviewers' calendars." },
      { title: "Sales Call Analysis Platform", description: "Develop a comprehensive platform that allows managers to upload sales call recordings and get accurate transcriptions, valuable conversation insights, and tailored coaching tips." },
      { title: "Personal Brand Content Engine", description: "Build an automated content pipeline that researches trends, drafts posts, generates visuals and schedules a month of content across platforms." },
    ],
    highlights: [
      "10 live classes with AI practitioners",
      "27 hands-on AI projects across domains",
      "Build a portfolio that proves AI fluency",
      "Career support to position you as an AI generalist",
    ],
    order: 3,
  },
  {
    slug: "data-analytics-python",
    title: "Data Analytics + Python",
    description:
      "Understand the root cause of business problems by breaking down the details structurally before presenting solutions. Build and strengthen analytical and problem-solving skills to solve business problems effortlessly.",
    icon: "LineChart",
    enrollments: "4k+",
    liveClasses: 20,
    projects: 7,
    hrPerWeek: 14,
    discount: "Flat 18% off",
    limitedSeats: true,
    expertLogos: ["Excel", "Microsoft", "HP"],
    learners: "4K+",
    packageUpto: "8L",
    jobs: "3,217+",
    companies: "300+",
    weeks: 20,
    hrsPerDay: 2,
    mode: "online",
    badge: "No coding skills required ✌️",
    industryInsight:
      "Python is the #1 language for analytics hiring — 72% of data analyst job descriptions list it. Combining Excel, SQL and Python makes you a full-stack analyst who can automate reporting and answer deeper business questions.",
    openings: "1 lac+",
    avgCtc: "8 LPA",
    avgHike: "45%",
    skills: ["Excel Mastery", "Statistics", "SQL", "Python", "Data Visualization", "Problem Solving"],
    outcomes: [
      "Structure business problems like a consultant",
      "Master Excel and SQL for day-to-day analytics",
      "Automate analysis and reporting with Python",
      "Present insights that drive decisions",
      "Build 7 industry projects for your portfolio",
      "Get ready for analyst interviews with mocks",
    ],
    syllabus: [
      { title: "Excel: Beginner to Advanced", weeks: 3, tags: ["Excel", "Data Analysis", "Data Manipulation"] },
      { title: "SQL: Beginner to Advanced", weeks: 4, tags: ["SQL", "Postgres", "Exploratory Analysis"] },
      { title: "Structured Problem Solving and Case Studies", weeks: 2, tags: ["SWOT", "BCG Matrix", "McKinsey 7S"] },
      { title: "Python Fundamentals", weeks: 4, tags: ["Python Fundamentals", "Data Visualization"] },
      { title: "Data Analytics with Python", weeks: 4, tags: ["Pandas", "NumPy", "Matplotlib"] },
    ],
    projectsList: [
      { title: "Jio Finding target market", description: "Analyse the telecom data of india and find where should Jio invest its capital expense by understanding different user segments in different cities." },
      { title: "Monetisation of seasonal event", description: "Seasonal events in various countries trigger huge traffic on the website with various intents. Google wants to monetize the opportunity by identifying seasonal events in various geographical locations." },
      { title: "Flipkart Category Management", description: "Use systematic analysis to find how category managers use trends to plan campaigns, inventories and ecommerce strategies." },
    ],
    highlights: [
      "Structured problem-solving curriculum",
      "Learn Excel, SQL and Python end to end",
      "Solve real industry case studies",
      "Placement support with 300+ partners",
    ],
    order: 4,
  },
  {
    slug: "data-science-and-ai",
    title: "Data Science & AI",
    description:
      "Master statistics, machine learning and AI to become an industry-ready Data Scientist. Learn Python, ML algorithms, GenAI and MLOps with live mentorship from top 1% experts and dedicated placement support.",
    icon: "BrainCircuit",
    enrollments: "3k+",
    liveClasses: 24,
    projects: 9,
    hrPerWeek: 15,
    discount: "11% Off",
    limitedSeats: true,
    expertLogos: ["Fractal", "Hewlett Packard", "Google"],
    learners: "3K+",
    packageUpto: "12L",
    jobs: "2,600+",
    companies: "300+",
    weeks: 24,
    hrsPerDay: 2,
    mode: "online",
    badge: "For serious data careers 🚀",
    industryInsight:
      "Data scientist roles are projected to grow 35% this decade, and hybrid AI+ML skillsets are the fastest growing segment. Average CTC for data scientists in India is now ₹12 LPA with senior roles crossing ₹30 LPA.",
    openings: "75K+",
    avgCtc: "12 LPA",
    avgHike: "55%",
    skills: ["Python", "Statistics", "Machine Learning", "Deep Learning", "Generative AI", "MLOps"],
    outcomes: [
      "Master Python for data science end to end",
      "Build and evaluate ML models with confidence",
      "Understand deep learning and GenAI fundamentals",
      "Deploy models and monitor them in production",
      "Build 9 portfolio projects from real industry problems",
      "Ace data science interviews with expert mocks",
    ],
    syllabus: [
      { title: "Python for Data Science", weeks: 4, tags: ["Python", "Pandas", "NumPy"] },
      { title: "Statistics Foundations", weeks: 3, tags: ["Descriptive", "Inferential", "Hypothesis Testing"] },
      { title: "Machine Learning", weeks: 6, tags: ["Regression", "Classification", "Clustering"] },
      { title: "Deep Learning & GenAI", weeks: 5, tags: ["Neural Nets", "LLMs", "Transformers"] },
      { title: "MLOps & Deployment", weeks: 3, tags: ["Deployment", "Monitoring", "CI/CD"] },
      { title: "Case Studies & Capstone", weeks: 3, tags: ["Capstone", "Interview Prep"] },
    ],
    projectsList: [
      { title: "Churn Prediction for OTT platform", description: "Build a churn prediction model on subscriber data and translate model outputs into retention strategies for the business." },
      { title: "Recommendation Engine for E-commerce", description: "Design a recommendation system that personalises product feeds and measure its impact on basket size and conversion." },
      { title: "Demand Forecasting for Quick Commerce", description: "Forecast SKU-level demand for a quick-commerce player and optimise dark-store inventory accordingly." },
    ],
    highlights: [
      "Learn from data scientists at Fractal, HP and Google",
      "End-to-end ML lifecycle coverage",
      "9 projects including a capstone",
      "Dedicated placement support",
    ],
    order: 5,
  },
  {
    slug: "data-science-machine-learning",
    title: "Data Science & Machine Learning",
    description:
      "Become a Machine Learning expert. Master Python, statistics and ML algorithms with hands-on projects and case studies curated by industry experts, plus complete placement assistance.",
    icon: "Network",
    enrollments: "2k+",
    liveClasses: 22,
    projects: 8,
    hrPerWeek: 14,
    discount: "10% Off",
    limitedSeats: true,
    expertLogos: ["Fractal", "Mu Sigma", "Google"],
    learners: "2K+",
    packageUpto: "11L",
    jobs: "2,100+",
    companies: "300+",
    weeks: 22,
    hrsPerDay: 2,
    mode: "online",
    badge: "No coding skills required ✌️",
    industryInsight:
      "ML engineer is among the top 5 fastest-growing jobs in India. Companies need practitioners who can go from data to deployed models — a skill gap that commands premium salaries.",
    openings: "60K+",
    avgCtc: "11 LPA",
    avgHike: "52%",
    skills: ["Python", "Statistics", "ML Algorithms", "Feature Engineering", "Model Evaluation", "Deployment"],
    outcomes: [
      "Implement classic ML algorithms from scratch and with sklearn",
      "Engineer features that lift model performance",
      "Evaluate models the way the industry expects",
      "Deploy models as APIs",
      "Solve 8 real business problems with ML",
      "Get interview-ready with mock sessions",
    ],
    syllabus: [
      { title: "Python for Data Science", weeks: 4, tags: ["Python", "Pandas", "NumPy"] },
      { title: "Statistics Foundations", weeks: 3, tags: ["Descriptive", "Inferential", "Probability"] },
      { title: "Supervised Learning", weeks: 5, tags: ["Regression", "Trees", "Ensembles"] },
      { title: "Unsupervised Learning", weeks: 3, tags: ["Clustering", "PCA"] },
      { title: "Model Deployment", weeks: 3, tags: ["APIs", "Cloud", "Monitoring"] },
      { title: "Case Studies", weeks: 4, tags: ["Capstone", "Interview Prep"] },
    ],
    projectsList: [
      { title: "Credit Risk Modelling", description: "Build a credit risk model for a lending business and calibrate thresholds to balance approval rate and default rate." },
      { title: "Customer Segmentation", description: "Segment retail customers using RFM and clustering, and design targeted campaigns for each segment." },
      { title: "Price Elasticity Analysis", description: "Estimate price elasticity for categories in an e-commerce catalogue and recommend pricing moves." },
    ],
    highlights: [
      "ML depth from basics to deployment",
      "Curated case studies from top companies",
      "8 hands-on projects",
      "Placement assistance included",
    ],
    order: 6,
  },
  {
    slug: "software-development",
    title: "Software Development",
    description:
      "Become a full-stack software engineer. Master DSA, system design and modern web development with mentors from Google, Facebook and Paytm, and get placement support to land SDE roles.",
    icon: "Code2",
    enrollments: "2k+",
    liveClasses: 26,
    projects: 6,
    hrPerWeek: 16,
    discount: "12% Off",
    limitedSeats: true,
    expertLogos: ["Google", "Facebook", "Paytm"],
    learners: "2K+",
    packageUpto: "15L",
    jobs: "1,900+",
    companies: "300+",
    weeks: 26,
    hrsPerDay: 3,
    mode: "online",
    badge: "For SDE aspirants 💻",
    industryInsight:
      "India's product engineering hiring is back with 20% YoY growth. Full-stack engineers who know DSA and system design are clearing interviews at product companies with packages up to 30 LPA.",
    openings: "1.2 lac+",
    avgCtc: "10 LPA",
    avgHike: "60%",
    skills: ["DSA", "System Design", "React", "Node.js", "Databases", "Git"],
    outcomes: [
      "Solve DSA problems with confidence in interviews",
      "Design scalable systems and explain trade-offs",
      "Build full-stack apps with React and Node.js",
      "Work with SQL and NoSQL databases like a pro",
      "Collaborate with Git like a professional team",
      "Build 6 production-grade portfolio projects",
    ],
    syllabus: [
      { title: "Programming Foundations", weeks: 4, tags: ["JS/TS", "Git", "Problem Solving"] },
      { title: "Data Structures & Algorithms", weeks: 8, tags: ["Arrays", "Trees", "Graphs", "DP"] },
      { title: "Frontend with React", weeks: 4, tags: ["React", "State", "Hooks"] },
      { title: "Backend with Node.js", weeks: 5, tags: ["Node", "APIs", "Databases"] },
      { title: "System Design", weeks: 3, tags: ["Scalability", "Caching", "Queues"] },
      { title: "Interview Preparation", weeks: 2, tags: ["Mocks", "Resume"] },
    ],
    projectsList: [
      { title: "Realtime Chat Application", description: "Build a realtime chat app with sockets, presence, typing indicators and message history persistence." },
      { title: "E-commerce Platform", description: "Build a full-stack e-commerce app with catalog, cart, payments and an admin dashboard." },
      { title: "URL Shortener at Scale", description: "Design and build a URL shortener with analytics, caching and rate limiting; reason about scale." },
    ],
    highlights: [
      "Mentors from Google, Facebook and Paytm",
      "DSA to system design, end to end",
      "6 production-grade projects",
      "Placement support for SDE roles",
    ],
    order: 7,
  },
];

const courses = [
  {
    slug: "python-for-data-science",
    title: "Python For Data Science",
    description:
      "Learn Python programming fundamentals to analyze and visualize data. Explore Python data structures to reveal findings and present insights through various visualization techniques.",
    learners: "380",
    rating: "4.7/5",
    weeks: 8,
    hrsPerDay: 3,
    level: "Beginner Level",
    prerequisite: "No coding experience required",
    icon: "Braces",
    skills: ["Python Fundamentals", "Data Visualization", "NumPy", "Seaborn", "Matplotlib", "Pandas", "Data Manipulation"],
    highlights: [
      "Enhance productivity using Python by taking leverage from its simplicity and vast libraries' support",
      "Python helps to focus on problem-solving rather than understanding complex programming syntax",
      "Fetch, convert, manage and enhance data quality from diverse data sources",
      "Most data science and data mining platforms take leverage from Python as it's a simple and easy-to-learn language",
      "Proficient in Python programming functions and libraries to solve challenging real-world problems",
    ],
    chapters: [
      { title: "Introduction to Python programming", mins: 30, videos: 3, readings: 0, quizzes: 0 },
      { title: "Variables and Overview of Data types", mins: 75, videos: 2, readings: 1, quizzes: 1 },
      { title: "Operators", mins: 30, videos: 1, readings: 0, quizzes: 1 },
      { title: "Basic Data Types", mins: 60, videos: 8, readings: 6, quizzes: 4 },
      { title: "Conditional and Control Flow", mins: 90, videos: 4, readings: 0, quizzes: 2 },
      { title: "List comprehension", mins: 30, videos: 1, readings: 1, quizzes: 0 },
      { title: "User Defined Functions", mins: 45, videos: 3, readings: 0, quizzes: 1 },
      { title: "Map, Reduce, Filter", mins: 75, videos: 2, readings: 7, quizzes: 0 },
    ],
    order: 1,
  },
  {
    slug: "data-analytics-and-statistics-using-python",
    title: "Data Analytics and Statistics Using Python",
    description:
      "Learn the math behind data science and master the art of maneuvering through complex data effortlessly.",
    learners: "670",
    rating: "4.6/5",
    weeks: 10,
    hrsPerDay: 3,
    level: "Intermediate Level",
    prerequisite: "Basic Python knowledge",
    icon: "Sigma",
    skills: ["Descriptive Statistics", "Inferential Statistics", "Hypothesis Testing", "Pandas", "Data Cleaning", "EDA"],
    highlights: [
      "Master descriptive and inferential statistics with real datasets",
      "Learn hypothesis testing and confidence intervals the practical way",
      "Clean, transform and explore data using Pandas like a professional analyst",
      "Build a statistical toolkit that powers every data science decision",
      "Solve business problems end-to-end with structured analysis",
    ],
    chapters: [
      { title: "Introduction to Statistics", mins: 45, videos: 3, readings: 1, quizzes: 1 },
      { title: "Descriptive Statistics", mins: 90, videos: 6, readings: 2, quizzes: 2 },
      { title: "Probability Distributions", mins: 75, videos: 5, readings: 2, quizzes: 1 },
      { title: "Sampling and Estimation", mins: 60, videos: 4, readings: 1, quizzes: 2 },
      { title: "Hypothesis Testing", mins: 120, videos: 7, readings: 3, quizzes: 3 },
      { title: "Correlation and Regression", mins: 90, videos: 5, readings: 2, quizzes: 2 },
      { title: "EDA with Pandas", mins: 120, videos: 8, readings: 4, quizzes: 2 },
    ],
    order: 2,
  },
  {
    slug: "machine-learning-using-python",
    title: "Machine Learning using Python",
    description:
      "Learn all about algorithms from the industry experts and become a machine learning prodigy.",
    learners: "240",
    rating: "4.6/5",
    weeks: 12,
    hrsPerDay: 4,
    level: "Advanced Level",
    prerequisite: "Python and statistics basics",
    icon: "Cpu",
    skills: ["Regression", "Classification", "Clustering", "Model Evaluation", "Feature Engineering", "scikit-learn"],
    highlights: [
      "Implement classic ML algorithms from scratch and with scikit-learn",
      "Learn the intuition behind every algorithm, not just the code",
      "Evaluate and tune models the way the industry expects",
      "Work on datasets from real business problems",
      "Build a strong foundation for advanced AI roles",
    ],
    chapters: [
      { title: "ML Fundamentals", mins: 60, videos: 4, readings: 1, quizzes: 1 },
      { title: "Linear Regression", mins: 90, videos: 6, readings: 2, quizzes: 2 },
      { title: "Logistic Regression", mins: 90, videos: 5, readings: 2, quizzes: 2 },
      { title: "Decision Trees and Ensembles", mins: 120, videos: 8, readings: 3, quizzes: 2 },
      { title: "Unsupervised Learning", mins: 90, videos: 5, readings: 2, quizzes: 1 },
      { title: "Model Evaluation and Tuning", mins: 75, videos: 4, readings: 2, quizzes: 2 },
      { title: "End-to-end ML Project", mins: 150, videos: 6, readings: 4, quizzes: 1 },
    ],
    order: 3,
  },
  {
    slug: "excel-beginner-to-advanced",
    title: "Excel: Beginner to Advanced",
    description:
      "Learn to manipulate complex data and derive insights through various visualization techniques by using the most popular tool and functions of Excel.",
    learners: "34.K",
    rating: "5/5",
    weeks: 4,
    hrsPerDay: 2,
    level: "Beginner Level",
    prerequisite: "No prerequisites",
    icon: "Table",
    skills: ["Excel Formulas", "Pivot Tables", "Lookup Functions", "Data Cleaning", "Charts", "Dashboards"],
    highlights: [
      "Master formulas, lookups and pivot tables with hands-on practice",
      "Clean messy data in minutes instead of hours",
      "Build interactive dashboards that impress stakeholders",
      "Learn shortcuts and tricks used by top analysts daily",
      "Earn the most recognised skill badge in any office",
    ],
    chapters: [
      { title: "Excel Basics and Interface", mins: 45, videos: 4, readings: 1, quizzes: 1 },
      { title: "Essential Formulas", mins: 90, videos: 8, readings: 2, quizzes: 2 },
      { title: "Lookup Functions", mins: 75, videos: 6, readings: 2, quizzes: 2 },
      { title: "Data Cleaning Techniques", mins: 60, videos: 5, readings: 1, quizzes: 1 },
      { title: "Pivot Tables", mins: 90, videos: 6, readings: 2, quizzes: 2 },
      { title: "Charts and Visualization", mins: 75, videos: 5, readings: 1, quizzes: 1 },
      { title: "Dashboard Building", mins: 120, videos: 7, readings: 3, quizzes: 1 },
    ],
    order: 4,
  },
  {
    slug: "sql-beginner-to-advanced",
    title: "SQL: Beginner to Advanced",
    description:
      "Make data-driven decisions by using the most widely used analytics techniques in the industry.",
    learners: "4K",
    rating: "4.6/5",
    weeks: 6,
    hrsPerDay: 2,
    level: "Beginner Level",
    prerequisite: "No coding experience required",
    icon: "Database",
    skills: ["SQL Basics", "Joins", "Aggregations", "Window Functions", "CTEs", "Query Optimization"],
    highlights: [
      "Write queries from day one with a hands-on Postgres environment",
      "Master joins, aggregations and subqueries with practice problems",
      "Learn window functions and CTEs that separate pros from beginners",
      "Optimize slow queries and understand execution plans",
      "Practice interview-style SQL problems with solutions",
    ],
    chapters: [
      { title: "Introduction to Databases and SQL", mins: 45, videos: 3, readings: 2, quizzes: 1 },
      { title: "Filtering and Sorting", mins: 60, videos: 5, readings: 1, quizzes: 2 },
      { title: "Aggregate Functions", mins: 75, videos: 5, readings: 2, quizzes: 2 },
      { title: "Joins", mins: 90, videos: 7, readings: 2, quizzes: 3 },
      { title: "Subqueries and CTEs", mins: 90, videos: 6, readings: 2, quizzes: 2 },
      { title: "Window Functions", mins: 75, videos: 5, readings: 1, quizzes: 2 },
      { title: "Query Optimization", mins: 60, videos: 4, readings: 2, quizzes: 1 },
    ],
    order: 5,
  },
];

const mentors = [
  { name: "Abhishek Srivastava", role: "Lead Data Scientist", company: "Hewlett Packard", ex: "Ex. Infosys", education: "IIM Bangalore", order: 1 },
  { name: "Lakshmanan Ravi", role: "Data Analytics Instructor", company: "Skillovilla", ex: "Ex. Exafluence Education", education: "Visvesvaraya National Institute of Technology", order: 2 },
  { name: "Swayam Prava Swain", role: "Data Analytics Instructor", company: "Skillovilla", ex: "Ex. ExcelR Solutions", education: "Orissa University of Agriculture and Technology", order: 3 },
  { name: "Swayam Kumar", role: "Data Analyst", company: "Skillovilla", ex: "Ex. Masai", education: "Hemwati Nandan Bahuguna Garhwal University", order: 4 },
  { name: "Rajat Agrawal", role: "Co-founder and CTO", company: "SkilloVilla", ex: "Ex. Swiggy", education: "IIIT Hyderabad", order: 5 },
  { name: "Siddardha Garimella", role: "Senior Engineering Manager", company: "Swiggy", ex: "Ex. InsanelyGood", education: "IIT Madras", order: 6 },
  { name: "Preeti Kumari", role: "Analytics Consultant", company: "EXL", ex: "Ex. Deloitte", education: "IIT Roorkee", order: 7 },
  { name: "Binod Gupta", role: "Business Operation Analyst - II", company: "Rackspace Technology", ex: "Ex. Virtual Employee Pvt. Ltd.", education: "University of Allahabad", order: 8 },
  { name: "Vishnu Gupta", role: "Software Engineer", company: "Google", ex: "Ex. Walmart Labs, Ex. Epic", education: "IIT Delhi", order: 9 },
  { name: "Ekta Negi", role: "Senior Data Scientist", company: "Fractal", ex: "Ex. IBM", education: "Bharathi Vidyapeeth", order: 10 },
  { name: "Gaurav Kaushik", role: "Senior Decision Scientist", company: "Fractal", ex: "Ex. Mu Sigma", education: "GLIM", order: 11 },
  { name: "Shantanu Patil", role: "Software Engineer", company: "Facebook", ex: "Ex. Qualcomm", education: "IIIT Hyderabad", order: 12 },
  { name: "Gaurav Rawat", role: "Technical Business Analyst", company: "Ignitiv", ex: "Ex. Aligned Automation", education: "Asia Pacific Institute of Management", order: 13 },
  { name: "Sandhya Kharol", role: "Senior Product Analyst", company: "AppsForBharat", ex: "Ex. Swiggy, Zepto", education: "Banasthali Vidyapith", order: 14 },
  { name: "Eneeyan Nanmaran", role: "Senior Data Analyst", company: "Freshworks", ex: "Ex. Great Learning", education: "Anna University Chennai", order: 15 },
  { name: "Sharad Gupta", role: "Software Engineer - ML", company: "Instacart", ex: "Ex. Bloomberg LP", education: "IIIT Hyderabad", order: 16 },
  { name: "Shashank Yadav", role: "Software Engineer", company: "Arista Networks", ex: "Ex. Works Application", education: "IIIT Hyderabad", order: 17 },
  { name: "Abhishek Kumar Sangwan", role: "Founder", company: "Infraspec", ex: "Ex. Swiggy", education: "Army Institute of Technology", order: 18 },
  { name: "Raghav S", role: "Lead Engineer", company: "Paytm", ex: "Ex. Fanatics", education: "IIIT Hyderabad", order: 19 },
  { name: "Saksham Maheshwari", role: "Senior Software Engineer", company: "TeamSpirit Singapore", ex: "Ex. Works Application", education: "IIIT Hyderabad", order: 20 },
  { name: "Eshan Tiwari", role: "Product Analytics Lead", company: "Facebook", ex: "Ex. ZS Associates", education: "IIT Dhanbad", order: 21 },
  { name: "Anurag Meher", role: "Head of Data", company: "Snabbit", ex: "Ex. Uber", education: "IIT Kanpur", order: 22 },
];

const testimonials = [
  { name: "Prithwijit Paul", content: "Joining SkilloVilla has been one of the best decision of my life. The curriculum here starts from the basics to advanced levels. The live classes have helped me gain insights about the day to day job life which made me more confident as a Data Analyst. The mentors guided us through an extremely detailed curriculum with instant doubt clarification every time. SkilloVilla also prepared me for interviews via various sessions with the mentors. I am working in my dream job as a Data Analyst for Shadowfax. I recommend SkilloVilla to anyone who wants to get into Data Analysis and Data Science.", date: "27th October'21", order: 1 },
  { name: "Ansh Agrawal", content: "SkilloVilla helped me to connect with all the seniors in industry, the best of the best. My skills are upgraded by learning from their experiences. Would cherish live weekly sessions a lot.", date: "25th October'21", order: 2 },
  { name: "Sumit Desai", content: "Mentorship Sessions: I particularly found these to be the USP of SkilloVilla. Industry experts would address us and make us familiar with the real time problem statements and how to approach them. Special mention to Deepak Sir's sessions that were always informative and he kept us engaged by sharing his experiences. Amazing mentorship by him and the team. Would definitely recommend the course to get a head start towards a career as a data analyst.", date: "26th October'21", order: 3 },
  { name: "Rambardhan K", content: "Discussion about various real-life case studies is simply amazing. The Data Analytics career track at SkilloVilla made me industry-ready to pursue my career in this field. Awesome curriculum, best live lectures by actual leaders of industry and amazing doubt solving sessions.", date: "27th October'21", order: 4 },
  { name: "K.S. Jyothirmayi", content: "At SkilloVilla, the curriculum is very well structured. I had an end-to-end learning from basic skills to Advanced skills. The curriculum & my learning here helped me to tackle a lot of problems I have now at my job.", date: "6th November'21", order: 5 },
  { name: "Arpan Pal", content: "SkilloVilla changed my career and become a data analyst. The curriculum is very well structured and mentors helped me to grow exponentially and also the session with industry expert helped me everyday towards taking best job in market.", date: "9th November'21", order: 6 },
  { name: "Hirkani Madewar", content: "When firstly I had joined the group of skillovilla that time I was wondering how could I complete the course. It was going to hard for me, but because of the mentors and their guidance it was easy to understand each and every point. SkilloVilla is the platform for those who wants to make changes and get the great opportunities for job. Mentors of skillovilla are very supportive and guide very well.", date: "10th November'21", order: 7 },
  { name: "Zaheen Ahamed", content: "At SkilloVilla the curriculum is very well structured. I had an end to end learning from basic of fundamental skills to advanced once. The mentoring process is by the most efficient one, where I have improved my learning curve exponentially.", date: "10th November'21", order: 8 },
  { name: "Shraddha Pande", content: "SkilloVilla's online course helped me to explore the field of Data Science and Machine Learning. I learned and benefited immensely from the course, as the course design is meticulously well planned. This is a great place where you can learn from videos, industry experts, projects to sharpen your skills. The area of data science is new and fascinating to me and now I feel that I have a good foundation in it.", date: "10th November'21", order: 9 },
  { name: "Aniket More", content: "SkilloVilla has been very helpful in terms of knowledge gaining and even in placement support. Great career guidance and live lectures from industry people. I will recommend skillovilla to my friends as well.", date: "19th November'21", order: 10 },
  { name: "Jatin Mundra", content: "SkilloVilla's Data Analytics program is an end to end package for freshers and experienced professionals who want to break into the world of data. The program is structured in a very comprehensive manner which not just provides the course content in bite sized video formats but also Live lectures to have the industrial exposure which makes sure we are well aware of the best practices in the industry. Doubt clearing sessions are provided every week to clarify all the queries we come across. Post this, the placement program helps us to fetch interviews at the firms having great exposure to analytics roles.", date: "19th November'21", order: 11 },
  { name: "Tushara M R", content: "Thank you for a great course. Great presentation style with lots of opportunities to ask questions and talk about real life examples which all made for a really enjoyable and informative course. \"A wonderfully practical course - both personally and professionally.\"", date: "19th November'21", order: 12 },
  { name: "Akash Shrimangale", content: "The slides which affect directly to the understanding without confusion. This class only focuses on the actual content which you are going to use while you are actual working in any companies. Straight and simple slides of content. Also one thing I would like to mention, that the content is not enough to solve the assignment so we have to Google it and which ultimately helps to understand ourselves.", date: "19th November'21", order: 13 },
  { name: "Sanjana V", content: "Knowing the application of skills is as important as learning them. SkilloVilla helps you learn the application of skills in the industry. Great content as well as the live sessions which are more practical based. Mock sessions are the best. If one is able to clear the mock session then the person is job ready. Overall a great experience! Thank you Team.", date: "23rd November'21", order: 14 },
];

const placedStudents = [
  { name: "Prithwijit Paul", role: "Data Analyst", company: "Shadowfax", hike: null, status: "Fresher", story: "Joining SkilloVilla has been one of the best decisions of my life. The live classes gave me insights about day-to-day job life which made me confident as a Data Analyst. Today I work in my dream job at Shadowfax.", order: 1 },
  { name: "Balaji Sukkala", role: "Business Analyst", company: "GIVA", hike: null, status: "Fresher", story: "The structured curriculum and mentorship sessions made all the difference. From solving real case studies to mock interviews, SkilloVilla prepared me end-to-end for my Business Analyst role at GIVA.", order: 2 },
  { name: "Priyabrat Sahoo", role: "Data Scientist", company: "Accion Labs", hike: "44% hike", status: null, story: "The mentors from the top 1% of the industry helped me transition into data science. The placement team connected me with Accion Labs where I landed a 44% hike.", order: 3 },
  { name: "Jatin Mundra", role: "Data Associate", company: "Razorpay", hike: "75% hike", status: null, story: "SkilloVilla's Data Analytics program is an end to end package. The placement program helped me fetch interviews at firms with great analytics exposure, and I joined Razorpay with a 75% hike.", order: 4 },
  { name: "Prateek Mantri", role: "Data Analyst", company: "Udaan", hike: "64% hike", status: null, story: "Weekly live sessions with industry leaders and quick doubt resolution made me industry ready. I switched to Udaan with a 64% hike.", order: 5 },
  { name: "Abhijeet Kadam", role: "Data Scientist", company: "Accion Labs", hike: "33% hike", status: null, story: "The projects and case studies gave me stories to tell in interviews. Accion Labs picked me as a Data Scientist with a 33% hike.", order: 6 },
  { name: "Kunal Kanojia", role: "Data Analyst", company: "Shadowfax", hike: "85% hike", status: null, story: "From learning SQL to presenting case studies, everything was hands-on. I joined Shadowfax as a Data Analyst with an 85% hike.", order: 7 },
  { name: "Shubham Sharma", role: "Sr Associate - Analytics", company: "Affine", hike: "65% hike", status: null, story: "The mock interview sessions are the best. If you can clear the mocks, you are job ready. I joined Affine with a 65% hike.", order: 8 },
  { name: "Shreeyash Bothare", role: "Analyst", company: "Rivigo", hike: "75% hike", status: null, story: "Real-life case study discussions are simply amazing. SkilloVilla made me industry-ready and I joined Rivigo with a 75% hike.", order: 9 },
  { name: "Shaon Halder", role: "Sr Data Analyst", company: "Securekloud Technologies", hike: "33% hike", status: null, story: "The curriculum is very well structured with end-to-end learning from basics to advanced. I grew into a Senior Data Analyst role at Securekloud.", order: 10 },
  { name: "Garima Singla", role: "Business Analyst", company: "WNS Global Services", hike: "45% hike", status: null, story: "The career counselling and resume building sessions helped me present my best self. I joined WNS with a 45% hike.", order: 11 },
  { name: "Ritwik Mishra", role: "Business Analyst", company: "Sunstone", hike: "93% hike", status: null, story: "SkilloVilla's mentors and placement support changed my career trajectory. I joined Sunstone as a Business Analyst with a 93% hike.", order: 12 },
  { name: "Aashish Panda", role: "Data Analyst", company: "Quantum Phinance", hike: null, status: null, story: null, order: 13 },
  { name: "Gaurav Shekhar Gaikwad", role: "Research Associate", company: "Ameriprise Financial", hike: "34% hike", status: null, story: null, order: 14 },
  { name: "Sameer Asif", role: "Data Analyst", company: "Exly", hike: null, status: null, story: null, order: 15 },
  { name: "Anish Jain", role: "Sr. Business Analyst", company: "WNS Global Services", hike: null, status: null, story: null, order: 16 },
  { name: "Ajay Pandey", role: "Data Analyst", company: "Swiggy", hike: null, status: null, story: null, order: 17 },
  { name: "Jyoti Chhanwal", role: "Sr Data Analyst", company: "Securekloud Technologies", hike: null, status: null, story: null, order: 18 },
  { name: "T Jahnavi", role: "Technical Associate - Database", company: "Vaultoro", hike: "120% hike", status: null, story: null, order: 19 },
  { name: "Aniket Shingre", role: "Business Analyst", company: "Celebal Technologies", hike: null, status: null, story: null, order: 20 },
  { name: "Ayush Agarwal", role: "Business Analyst", company: "Razorpay", hike: "40% hike", status: null, story: null, order: 21 },
  { name: "Unnati Kesrwani", role: "Data Analyst Intern", company: "SkilloVilla", hike: null, status: null, story: null, order: 22 },
  { name: "Devashish Katiyar", role: "Software Developer", company: "Telus", hike: null, status: null, story: null, order: 23 },
  { name: "Samridhi Khanna", role: "Engineering Associate", company: "Rivigo", hike: "92% hike", status: null, story: null, order: 24 },
];

const companies = [
  { name: "Razorpay", category: "hiring", order: 1 },
  { name: "Swiggy", category: "hiring", order: 2 },
  { name: "Accenture", category: "hiring", order: 3 },
  { name: "Shadowfax", category: "hiring", order: 4 },
  { name: "Deloitte", category: "hiring", order: 5 },
  { name: "Axis Bank", category: "hiring", order: 6 },
  { name: "Citibank", category: "hiring", order: 7 },
  { name: "Zomato", category: "hiring", order: 8 },
  { name: "Mamaearth", category: "hiring", order: 9 },
  { name: "Flipkart", category: "hiring", order: 10 },
  { name: "EXL", category: "hiring", order: 11 },
  { name: "ZS", category: "hiring", order: 12 },
  { name: "Virtusa", category: "hiring", order: 13 },
  { name: "Amazon", category: "hiring", order: 14 },
  { name: "CRED", category: "hiring", order: 15 },
  { name: "Snapdeal", category: "hiring", order: 16 },
  { name: "Kaleyla", category: "hiring", order: 17 },
  { name: "Udaan", category: "hiring", order: 18 },
  { name: "Rivigo", category: "hiring", order: 19 },
  { name: "Mu Sigma", category: "hiring", order: 20 },
  { name: "Deloitte", category: "mnc", order: 1 },
  { name: "Accenture", category: "mnc", order: 2 },
  { name: "Citibank", category: "mnc", order: 3 },
  { name: "Amazon", category: "mnc", order: 4 },
  { name: "AXIS Bank", category: "mnc", order: 5 },
  { name: "HCL Technologies", category: "mnc", order: 6 },
  { name: "Virtusa", category: "mnc", order: 7 },
  { name: "EXL", category: "mnc", order: 8 },
  { name: "Swiggy", category: "unicorn", order: 1 },
  { name: "Razorpay", category: "unicorn", order: 2 },
  { name: "Zomato", category: "unicorn", order: 3 },
  { name: "Flipkart", category: "unicorn", order: 4 },
  { name: "Udaan", category: "unicorn", order: 5 },
  { name: "CRED", category: "unicorn", order: 6 },
  { name: "Mamaearth", category: "unicorn", order: 7 },
  { name: "Shadowfax", category: "startup", order: 1 },
  { name: "GIVA", category: "startup", order: 2 },
  { name: "Exly", category: "startup", order: 3 },
  { name: "Snabbit", category: "startup", order: 4 },
  { name: "AppsForBharat", category: "startup", order: 5 },
  { name: "Kaleyla", category: "startup", order: 6 },
];

const faqs = [
  { question: "What is the difference between Tracks and Courses?", answer: "Tracks are career-focused programmes that include multiple courses to enhance a graduate's expertise in a particular domain. Job placement assistance including resume building, interview preparation, and connecting with top companies is exclusively provided in a track without additional cost. However, a course does not provide employment assistance and is designed for people who are looking to upskill themselves in particular areas of expertise or technologies.", category: "general", order: 1 },
  { question: "Can you elaborate on the employment assistance that I will receive?", answer: "Once the courses in a track are completed, exclusive employment assistance is provided, which includes:\ni) Resume Building: A personal career coach is assigned to help you craft an effective resume.\nii) Mock Interviews: Multiple mock interviews with industry experts will prepare you to be interview-ready.\niii) Connecting with top companies: Help in securing interview invites at 300+ top partner companies to land your dream job.", category: "general", order: 2 },
  { question: "What is the mode of teaching?", answer: "We follow a multi-format mode of teaching. All concepts will be taught through videos, live classes from industry experts, reading materials, quizzes, projects, and more.", category: "general", order: 3 },
  { question: "Will there be live classes?", answer: "Yes, live classes are one of the key components of our curriculum. It will be conducted by industry experts who work at leading companies. In these live classes the concepts are taught as to how it can be applied to real-life situations, thus giving a holistic understanding of the work that you are expected to perform on the job.", category: "general", order: 4 },
  { question: "Will I receive a certificate for completion of the course/track?", answer: "Yes. Once you have completed all the courses and all the projects in a track, a specialization certificate that is recognized across the industry will be awarded to you. Individual certificates will also be granted for every course included in the track.", category: "general", order: 5 },
  { question: "Will I get lifetime access to the content?", answer: "Yes. You will get lifetime access to the content of the courses. Concepts, works, documents and videos can be accessed at any time for reference, ensuring a lifetime of learning.", category: "general", order: 6 },
  { question: "Do you guarantee a job at the end of the track?", answer: "We make you able enough to secure the job of your dreams. We provide exclusive placement assistance, prepare you to be interview-ready, help you nail the industry expectations and get interview invites for you in top companies. We are your companions in your journey from learning to earning and will never leave your side throughout this journey. But beyond our support, only you can land the job of your dreams.", category: "general", order: 7 },
  { question: "Why should I choose SkilloVilla's Data Analytics career track over other online analytics courses / online data analytics certification program?", answer: "Our Data Analytics career track focuses on enhancing a graduate's expertise in the field of data analytics and helping him/her land their dream job. Whereas, most online data analytics certificate programs focus only on the theoretical part with little to no job placement assistance. Moreover, SkilloVilla's career track fee is less than one-fourth of any other online data analytics courses.", category: "general", order: 8 },
  { question: "Why Should I choose SkilloVilla's Data Science Career track over any other online data science degree?", answer: "Our Data Science career track focuses on enhancing a graduate's expertise in the field of data science and helping him/her land their dream job. Whereas, most online data science degree courses focus only on the theoretical part with little to no job placement assistance. Moreover, SkilloVilla's career track fee is less than one-fourth of any online data science degree. Our Data Science career track is the only data science full course that you will need to land your dream job.", category: "general", order: 9 },
  { question: "Why should I choose SkilloVilla's Data Analytics career track over other online data analytics certificate program?", answer: "Our Data Analytics career track comes with an industry-aligned curriculum designed by the top 1% of the industry experts, weekly live classes, quick doubt resolution, placement support to help you land your dream job, and a 2-year alumni membership. You get all of this at a one-fourth price of any other online data analytics courses.", category: "general", order: 10 },
  { question: "Why should I choose SkilloVilla's Data Science career track over other online data science certification?", answer: "Our Data Science career track comes with an industry-aligned curriculum designed by the top 1% of the industry experts, weekly live classes, quick doubt resolution, placement support to help you land your dream job, and a 2-year alumni membership. You get all of this at a one-fourth price of any other online data science certification course.", category: "general", order: 11 },
  { question: "How do I know if this track is right for me?", answer: "Book a free masterclass with our experts. In the masterclass, you will solve a real-life case study, interact with mentors and understand the learning approach. Our academic counsellors will also help you pick the right track based on your background and goals.", category: "tracks", order: 1 },
  { question: "How much time do I need to dedicate every day?", answer: "Most tracks need 2 hours a day. The learning journey combines short conceptual videos, reading materials, quizzes and weekly live classes so you can learn consistently even with a busy schedule.", category: "tracks", order: 2 },
  { question: "Can I preview a class before enrolling?", answer: "Yes! Try a free masterclass to experience how we teach. You will solve a case study live with experts and get a feel of the SkilloVilla way of learning before you enroll.", category: "tracks", order: 3 },
  { question: "Are the courses self-paced?", answer: "Yes. All individual courses are self-paced with lifetime access. Career tracks add weekly live classes and mentorship on top of self-paced content.", category: "courses", order: 1 },
  { question: "Do I get a certificate for individual courses?", answer: "Yes. Every course grants an individual certificate on completion. Completing all courses in a track grants a specialization certificate recognized across the industry.", category: "courses", order: 2 },
  { question: "How does the placement assistance work?", answer: "Once you complete the courses in a track, our placement program kicks in: resume building with a career coach, multiple mock interviews with industry experts, and interview invites from 300+ partner companies until you land your dream job.", category: "placement", order: 1 },
  { question: "What salary can I expect after the program?", answer: "Our alumni have secured packages from 9 to 30 LPA with an average hike of 60%. Salaries depend on your background, interview performance and the role — but our placement stats speak for themselves: 92% placement rate and an 8 LPA average salary.", category: "placement", order: 2 },
  { question: "I still have questions. How can I talk to someone?", answer: "Request a callback and our academic counsellors will reach out within 24 hours. You can also write to support@skillovilla.com for student queries or admissions@skillovilla.com for admission information.", category: "contact", order: 1 },
  { question: "Where is SkilloVilla located?", answer: "You can find us at 4th Floor, Royaloak Furniture Building, Bannerghatta Road, Anthappa Layout, J.P. Nagar Phase 4, Bengaluru, Karnataka - 560078.", category: "contact", order: 2 },
];

const blogs = [
  {
    slug: "pay-after-placement-courses-how-they-work",
    title: "Pay After Placement Courses: How They Work and What They Really Cost",
    excerpt: "How pay after placement and income share agreements work in India, what the published schedules really cost, and the clauses that decide what you actually pay.",
    readTime: "7 min read",
    category: "Careers",
    cover: "1",
    content: "Pay after placement courses promise something every career switcher dreams about: learn now, pay after you are hired. It sounds perfect, but the details matter more than the promise.\n\nIn India, pay after placement usually comes in two flavours. The first is an Income Share Agreement, where you agree to pay a percentage of your salary for a fixed number of months once your salary crosses a threshold. The second is a deferred fee model, where the full fee becomes due after placement, often in instalments.\n\nThe published schedules look simple. A typical ISA asks for 15 to 17 percent of monthly income for 24 to 36 months, capped at a multiple of the course fee. Deferred fee plans usually total between one and one-and-a-half times the upfront price.\n\nWhat actually decides your cost is in the clauses. Look for the minimum salary threshold that triggers payment. Check what happens if you drop out, if you defer a batch, or if you do not accept the jobs shared with you. Some agreements count any job as placement, others require a role in your trained domain.\n\nThe math is simple to run. Take the median salary of the program's last three placed batches, multiply by the ISA percentage and months, and compare it to an upfront course of similar quality. If the ISA total is more than 1.5x the upfront fee, you are paying a heavy premium for cashflow comfort.\n\nPay after placement works best when you are confident about completing the program and the provider is transparent about outcomes. Ask for audited placement numbers, speak to alumni, and read the exit clauses before you sign. The promise is real, but only when the paperwork is fair.",
    daysAgo: 1,
  },
  {
    slug: "data-scientist-roadmap-india-stage-by-stage",
    title: "Data Scientist Roadmap for India: A Stage by Stage Plan",
    excerpt: "A data scientist roadmap for India with months, skills and one project per stage, the first roles that actually hire, and separate routes for freshers and working professionals.",
    readTime: "8 min read",
    category: "Data Science",
    cover: "2",
    content: "Everyone wants a data scientist roadmap that fits India's hiring reality, not a generic syllabus. Here is a stage by stage plan that works whether you are a fresher or a working professional.\n\nMonths 1 to 2: Python and spreadsheets. Learn Python fundamentals, Pandas and advanced Excel. Your project: analyse a public Indian dataset, like IPL matches or metro rail ridership, and publish a clean notebook.\n\nMonths 3 to 4: Statistics and SQL. Learn descriptive statistics, hypothesis testing and write SQL daily. Your project: build an analytics report on an e-commerce dataset with SQL and present five insights with charts.\n\nMonths 5 to 6: Machine learning foundations. Regression, classification, clustering and model evaluation with scikit-learn. Your project: predict customer churn for a telecom company and explain every feature in plain language.\n\nMonths 7 to 8: Specialisation and storytelling. Pick NLP, computer vision or forecasting. Learn Tableau or Power BI for storytelling. Your project: an end-to-end dashboard backed by a model, deployed so anyone can click it.\n\nMonths 9 to 10: Interview preparation. DSA basics for analysts, SQL interviews, case studies and ML theory. Build your resume around impact metrics, not course lists.\n\nFreshers should target data analyst, business analyst and data science intern roles first; they hire in volume and convert internally. Working professionals should target analytics roles inside their own domain first, where domain knowledge is the unfair advantage.\n\nThe roadmap is honest about one thing: skills compound only with projects. One project per stage, published publicly, beats ten certificates sitting in a drive.",
    daysAgo: 1,
  },
  {
    slug: "best-online-data-science-courses-working-professionals",
    title: "Best Online Data Science Courses for Working Professionals in India",
    excerpt: "Online data science courses in India compared on hours a week, live or recorded classes, weekend batches, capstone and fee, for people holding a full-time job.",
    readTime: "8 min read",
    category: "Courses",
    cover: "3",
    content: "Working professionals do not fail at data science because the courses are bad. They fail because the course assumed they had student hours to give. This guide compares online data science programs in India on the constraints that matter when you hold a full-time job.\n\nHours per week is the first filter. Honest programs ask for 10 to 15 hours a week. Anything promising mastery in 5 hours a week is selling a playlist, not a career change.\n\nLive versus recorded is the second. Recorded-only courses have 3 to 8 percent completion. Programs with weekly live classes and doubt solving consistently show 2 to 3 times better completion, because a schedule and a mentor beat motivation.\n\nWeekend batches matter for live classes if your weekdays are unpredictable. Look for programs that run live sessions on weekends and keep weekday commitments to reading and practice.\n\nA capstone with real data is non-negotiable. Ask to see three recent capstone projects. If they look like Kaggle tutorials, the placement stories will too.\n\nFee is the last filter, not the first. India's serious online programs range from ₹60,000 to ₹3,00,000. Cheaper is fine for upskilling; career switching needs placement support, which costs money to deliver.\n\nThe verdict: pick the program that fits your calendar first, your budget second, and the brochure last. A course you finish beats a course that looks perfect and dies in week three.",
    daysAgo: 1,
  },
  {
    slug: "data-analytics-training-hyderabad-2026",
    title: "Data Analytics Training in Hyderabad (2026): Institutes, Fees and Hiring Reality",
    excerpt: "Data analytics training in Hyderabad for 2026: Ameerpet and Kukatpally institutes, real fee ranges, HITEC City hiring, and when online is the better buy.",
    readTime: "7 min read",
    category: "City Guides",
    cover: "4",
    content: "Hyderabad runs one of India's busiest analytics training markets. Ameerpet alone has hundreds of institutes, and HITEC City keeps the demand side strong. Here is the 2026 picture.\n\nWhere the institutes are: Ameerpet remains the volume hub for classroom analytics training, with fees between ₹15,000 and ₹45,000 for 3 to 5 month courses. Kukatpally and Gachibowli host newer institutes and premium programs, with fees from ₹40,000 to ₹1,20,000.\n\nWhat you actually get: most classroom programs cover Excel, SQL, Python and Power BI or Tableau. Quality varies wildly between batches at the same institute, because instructor assignment matters more than the brand on the board.\n\nHITEC City hiring: banks, product companies and GCCs in Madhapur, Gachibowli and the Financial District hire analysts steadily. Freshers with strong SQL and one solid dashboard project get interviews; everyone else gets screened out.\n\nWhen classroom works: if you need discipline, peer energy and local networking, and you live within commuting distance of Ameerpet or Gachibowli.\n\nWhen online wins: if you are working, online programs with live weekend classes give you better instructors than your nearest Ameerpet batch, plus placement support that is not limited to walk-in drives.\n\nThe honest comparison: Ameerpet's ₹25,000 course plus self-placed effort can absolutely land a job. But if you value structure, mentorship and placement pipelines, a serious online program is the better buy in 2026.",
    daysAgo: 11,
  },
  {
    slug: "skillovilla-vs-simplilearn-2026",
    title: "SkilloVilla vs Simplilearn (2026): Which Data Analytics Course Fits You",
    excerpt: "SkilloVilla vs Simplilearn compared fairly on fees, duration, admissions and certificates, so you can pick the right data analytics course in 2026.",
    readTime: "6 min read",
    category: "Comparisons",
    cover: "5",
    content: "Comparing SkilloVilla and Simplilearn for data analytics in 2026 comes down to what you are buying: a guided career switch or a broad catalog.\n\nFees and duration: SkilloVilla's career tracks are priced at roughly a fourth of Simplilearn's comparable data analytics programs, running 4 to 5 months with weekly live classes. Simplilearn's programs typically run 6 to 12 months with blended recorded and live formats.\n\nTeaching format: SkilloVilla runs small-batch live classes taught by practitioners, with doubt solving built into the week. Simplilearn's scale means recorded content does the heavy lifting, with live sessions scheduled at intervals.\n\nPlacement: both offer placement assistance. SkilloVilla's placement program is bundled with the track at no extra cost and includes resume building, mock interviews and introductions to 300+ partner companies. Simplilearn offers placement support through its JobAssist program on higher tiers.\n\nCertificates: Simplilearn carries partner branding (Purdue, IBM on some paths) which looks strong on paper. SkilloVilla grants NASSCOM-accredited certificates plus a specialization certificate on track completion.\n\nWho should pick what: if you want a focused, mentor-led, budget-friendly path to a first analytics job, SkilloVilla's track is the sharper tool. If you want brand-heavy certificates and a wide course library and have the budget for it, Simplilearn fits.\n\nRun the trial before you decide: attend a free masterclass from either side and judge the teaching quality yourself.",
    daysAgo: 11,
  },
  {
    slug: "best-data-analytics-courses-chennai-2026",
    title: "Best Data Analytics Courses in Chennai (2026): Fees, Branches and Reality Check",
    excerpt: "Picking a data analytics course in Chennai for 2026: local institutes by branch, honest fee ranges, and live online options that reach beyond the classroom.",
    readTime: "6 min read",
    category: "City Guides",
    cover: "1",
    content: "Chennai's data analytics training market splits between two worlds: legacy classroom institutes clustered around T. Nagar, Adyar and Velachery, and a growing set of online-first programs that Chennai learners increasingly pick.\n\nFees by format: classroom programs in Chennai run ₹20,000 to ₹60,000 for 3 to 5 month courses covering Excel, SQL, Python and BI tools. Premium classroom-plus-placement programs touch ₹1,00,000. Online programs with live classes sit between ₹40,000 and ₹1,50,000.\n\nWhat hiring looks like: Chennai's demand comes from BFSI (the city is a back-office and GCC hub), SaaS product companies along OMR, and analytics service firms. Recruiters consistently screen for SQL depth and one dashboard project over institute brands.\n\nThe classroom math: if you are a fresher living near a good batch, classroom training with peer pressure works. Ask to sit in a live class before paying, and ask which instructor takes your batch.\n\nThe online math: if you are working or the good institute is 90 minutes away, live-online programs give you better mentors and placement pipelines that interview you for Bangalore, Hyderabad and Chennai openings alike.\n\nThe verdict: Chennai learners should choose by instructor and placement evidence, not by pincode. Sit in a demo class, verify the last three batches' placement lists, and only then pay.",
    daysAgo: 11,
  },
  {
    slug: "data-science-course-pune-2026",
    title: "Data Science Course in Pune (2026): Fees, Format and the Honest Math",
    excerpt: "A data scientist course in Pune costs about ₹35,000 to ₹3,99,000. Verified fees for institutes in Deccan, Baner and Kharadi, plus online options.",
    readTime: "6 min read",
    category: "City Guides",
    cover: "2",
    content: "Pune asks a simple question every year: which data science course is worth it? The 2026 answer starts with verified fees, not brochures.\n\nThe fee map: classroom programs in Deccan and FC Road charge ₹35,000 to ₹80,000 for 5 to 6 month data science courses. Premium institutes in Baner and Kharadi, close to the IT parks, run ₹1,00,000 to ₹3,99,000 with placement add-ons. Online live programs sit between ₹60,000 and ₹2,00,000.\n\nWhat the fee buys: at the low end you get recorded lectures and a lab. Mid-range buys live classes and projects. The top of the range buys brand certificates, career services and interview pipelines.\n\nPune's hiring market: Kharadi, Hinjewadi and Magarpatta host product companies, banks and GCCs hiring data scientists and analysts. Freshers break in through analyst roles; career switchers with domain experience break in through analytics roles in their own industry.\n\nThe format decision: Kharadi's working crowd increasingly picks online live programs for weekday flexibility, while freshers still benefit from classroom discipline in Deccan batches.\n\nThe honest math: the course fee is the smallest number in the decision. Twelve months of your career is the big number. Pick the program with evidence of outcomes — audited placement lists, alumni you can call, and teaching you can trial for free.",
    daysAgo: 11,
  },
  {
    slug: "data-analyst-courses-near-me-how-to-pick",
    title: "Data Analyst Courses Near Me: How to Pick the Right One",
    excerpt: "Searching data analyst courses near me? What the map results hide, the six checks that matter, real local fee bands, and when online beats the nearest classroom.",
    readTime: "6 min read",
    category: "Careers",
    cover: "3",
    content: "\"Data analyst courses near me\" is the most common search in Indian upskilling, and the most misleading. Map results rank by advertising spend, not by outcomes. Here is how to actually pick.\n\nThe six checks that matter: one, who teaches the live classes — a named practitioner or a rotating substitute. Two, what the last three batches' placement lists look like, with companies and roles. Three, whether the syllabus includes SQL, Python, Excel and a dashboarding tool with projects on real data. Four, whether doubt solving is same-day or ticket-based. Five, whether the fee is transparent with no EMI ambush. Six, whether you can sit in a real class before paying.\n\nLocal fee bands: Indian metro classroom programs run ₹20,000 to ₹1,00,000 depending on depth and placement support. Anything above ₹1,50,000 needs extraordinary evidence.\n\nWhen nearby classroom wins: you are a fresher who needs structure, your locality has a genuinely good batch (verify by attending), and you value in-person networking.\n\nWhen online beats the nearest classroom: you are working, your commute is long, or the best mentor for your domain does not live in your city. A live-online class with a practitioner from a top company beats a mediocre batch you can walk to.\n\nThe search that actually works: filter for outcomes first and location second. The best 'near me' course is the one whose alumni have the job you want.",
    daysAgo: 11,
  },
  {
    slug: "skillovilla-vs-excelr-bangalore-2026",
    title: "SkilloVilla vs ExcelR: Classroom Data Analytics in Bangalore (2026)",
    excerpt: "SkilloVilla vs ExcelR compared for classroom data analytics in Bangalore: fees, centres, batch access, IIT add-on and placement support.",
    readTime: "7 min read",
    category: "Comparisons",
    cover: "4",
    content: "Bangalore learners comparing SkilloVilla and ExcelR for classroom data analytics are really comparing two models: focused cohort programs versus franchise-scale classroom networks.\n\nFees: ExcelR's classroom data analytics program in Bangalore sits around ₹35,000 to ₹50,000, with their IIT-certified add-on pushing the bundle higher. SkilloVilla's Data Analytics Classroom Program in Bangalore is priced in the same band with current discounts, and includes the full online track access.\n\nBatch access: ExcelR runs batches across multiple centres with recorded backup. SkilloVilla runs small cohorts taught personally by Deepak Kharol, an IIT Delhi alumnus with 10+ years at Mu Sigma, Swiggy, Cuemath and PayU — with lifetime access to recordings.\n\nCurriculum: both cover Excel, SQL, Python and Power BI. SkilloVilla adds structured case studies from real companies (Swiggy, Flipkart, Jio) and weekly doubt-solving built into the schedule.\n\nPlacement: ExcelR offers placement through its hiring network and tie-ups. SkilloVilla bundles its full placement program — resume building, mock interviews and 300+ partner introductions — with the classroom program at no extra cost.\n\nThe verdict: if you want a big-brand certificate and a centre near you, ExcelR works. If you want a founder-taught cohort with deep placement support at a similar price, SkilloVilla's classroom program is the stronger bet. Attend a free masterclass for both and decide with your own eyes.",
    daysAgo: 16,
  },
];

export async function runSeed(client: PrismaClient) {
  db = client;
  console.log("Clearing existing data...");
  await db.lead.deleteMany();
  await db.blogPost.deleteMany();
  await db.testimonial.deleteMany();
  await db.mentor.deleteMany();
  await db.course.deleteMany();
  await db.track.deleteMany();
  await db.faq.deleteMany();
  await db.placedStudent.deleteMany();
  await db.company.deleteMany();

  console.log("Seeding tracks...");
  for (const t of tracks) {
    const { order, ...data } = t as (typeof t) & { order: number };
    await db.track.create({
      data: {
        ...data,
        skills: JSON.stringify(t.skills),
        outcomes: JSON.stringify(t.outcomes),
        syllabus: JSON.stringify(t.syllabus),
        projectsList: JSON.stringify(t.projectsList),
        highlights: JSON.stringify(t.highlights),
        expertLogos: JSON.stringify(t.expertLogos),
        order,
      },
    });
  }

  console.log("Seeding courses...");
  for (const c of courses) {
    const { order, ...data } = c as (typeof c) & { order: number };
    await db.course.create({
      data: {
        ...data,
        skills: JSON.stringify(c.skills),
        highlights: JSON.stringify(c.highlights),
        chapters: JSON.stringify(c.chapters),
        order,
      },
    });
  }

  console.log("Seeding mentors...");
  for (const m of mentors) {
    const { order, ...data } = m;
    await db.mentor.create({ data: { ...data, order } });
  }

  console.log("Seeding testimonials...");
  for (const t of testimonials) {
    const { order, ...data } = t;
    await db.testimonial.create({ data: { ...data, order } });
  }

  console.log("Seeding blogs...");
  for (const b of blogs) {
    const { daysAgo, ...data } = b;
    await db.blogPost.create({
      data: {
        ...data,
        publishedAt: new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000),
      },
    });
  }

  console.log("Seeding faqs...");
  for (const f of faqs) {
    const { order, ...data } = f;
    await db.faq.create({ data: { ...data, order } });
  }

  console.log("Seeding placed students...");
  for (const p of placedStudents) {
    const { order, ...data } = p;
    await db.placedStudent.create({ data: { ...data, order } });
  }

  console.log("Seeding companies...");
  for (const c of companies) {
    const { order, ...data } = c;
    await db.company.create({ data: { ...data, order } });
  }

  console.log("Seed complete ✅");
}
