/* CLI: provisions RBAC roles + demo platform data against the local database.
 * Run: bun run db:seed:platform */
import { PrismaClient } from "@prisma/client";
import { resolvedDatabaseUrl } from "@/lib/db-url";
import { ensureRoles, ensurePlatformDemoData } from "@/db/seed-platform";
import { ensureCoreAccounts } from "@/db/core-accounts";

async function main() {
  const client = new PrismaClient({ datasourceUrl: resolvedDatabaseUrl });
  try {
    const roles = await ensureRoles(client);
    await ensureCoreAccounts(client);
    await ensurePlatformDemoData(client);
    console.log("roles seeded:", roles);
    const counts = {
      roles: await client.role.count(),
      users: await client.user.count(),
      orgs: await client.organization.count(),
      contacts: await client.contact.count(),
      deals: await client.deal.count(),
      activities: await client.activity.count(),
      modules: await client.module.count(),
      lessons: await client.lesson.count(),
      enrollments: await client.enrollment.count(),
      certificates: await client.certificate.count(),
      quizzes: await client.quiz.count(),
      notifications: await client.notification.count(),
    };
    console.log(JSON.stringify(counts));
  } finally {
    await client.$disconnect();
  }
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
