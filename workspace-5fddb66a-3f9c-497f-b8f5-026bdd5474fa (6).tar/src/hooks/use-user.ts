"use client";

import { useCallback, useEffect, useState } from "react";
import { canIn } from "@/lib/rbac";

export interface SessionUser {
  uid?: string;
  name: string;
  email: string;
  role?: string;
  roleLabel?: string;
  permissions?: string[];
}

const USER_CHANGED_EVENT = "sv:user-changed";

/** Dispatch after sign-in/sign-out so mounted useUser() hooks refetch. */
export function notifyUserChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(USER_CHANGED_EVENT));
  }
}

export function useUser() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      const data = await res.json();
      setUser(data.user ?? null);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const handler = () => refresh();
    window.addEventListener(USER_CHANGED_EVENT, handler);
    return () => window.removeEventListener(USER_CHANGED_EVENT, handler);
  }, [refresh]);

  const signOut = useCallback(async () => {
    await fetch("/api/auth/signout", { method: "POST" });
    setUser(null);
    notifyUserChanged();
  }, []);

  const can = useCallback((perm: string) => canIn(user?.permissions, perm), [user]);

  return { user, loading, refresh, signOut, can };
}
