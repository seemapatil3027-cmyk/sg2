import { redirect } from "next/navigation";
import { ShieldOff } from "lucide-react";
import { getSessionUser } from "@/lib/auth";
import { roleLabel } from "@/lib/rbac";
import { permissionsForRole } from "@/lib/rbac-server";
import { AppShell } from "@/components/platform/app-shell";
import { LogOutButton } from "@/components/platform/access-denied";

/** Platform layout — server-side auth gate for every CRM/LMS/Admin page. */
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await getSessionUser();

  if (!session) {
    redirect("/signin?next=/dashboard");
  }
  if (session.role === "STUDENT") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted/40 p-6">
        <div className="w-full max-w-md rounded-3xl border bg-card p-8 text-center shadow-lg">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
            <ShieldOff className="h-6 w-6" />
          </div>
          <h1 className="mt-4 text-lg font-bold">Student sign-in has been removed</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            The SkillGorila platform is now staff-only. Learners are managed internally by the CRM
            and LMS teams — contact your program advisor if you need help.
          </p>
          <div className="mt-6 flex justify-center">
            <LogOutButton />
          </div>
        </div>
      </div>
    );
  }

  const permissions = await permissionsForRole(session.role);

  return (
    <AppShell
      session={{
        ...session,
        roleLabel: roleLabel(session.role),
        permissions,
      }}
    >
      {children}
    </AppShell>
  );
}
