import { getSessionUser } from "@/lib/auth";
import { roleLabel } from "@/lib/rbac";
import { SettingsClient } from "@/components/platform/settings-client";

export const metadata = { title: "Settings", robots: { index: false } };

export default async function SettingsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  return (
    <SettingsClient
      name={session.name}
      email={session.email}
      role={session.role}
      roleLabel={roleLabel(session.role)}
    />
  );
}
