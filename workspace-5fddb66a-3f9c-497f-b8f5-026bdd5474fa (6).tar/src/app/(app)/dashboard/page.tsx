import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { DashboardClient } from "@/components/platform/dashboard-client";

export const metadata = { title: "Dashboard", robots: { index: false } };

export default async function DashboardPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "dashboard.view"))) {
    return <AccessDenied permission="dashboard.view" />;
  }
  return <DashboardClient role={session.role} name={session.name} />;
}
