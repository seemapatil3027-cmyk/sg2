import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { UsersClient } from "@/components/admin/users-client";

export const metadata = { title: "Users", robots: { index: false } };

export default async function AdminUsersPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "admin.users.view"))) {
    return <AccessDenied permission="admin.users.view" />;
  }
  return <UsersClient sessionUid={session.uid} />;
}
