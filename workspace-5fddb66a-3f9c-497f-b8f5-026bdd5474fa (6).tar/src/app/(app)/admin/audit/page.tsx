import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { AuditClient } from "@/components/admin/audit-client";

export const metadata = { title: "Audit Log", robots: { index: false } };

export default async function AdminAuditPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "admin.audit.view"))) {
    return <AccessDenied permission="admin.audit.view" />;
  }
  return <AuditClient />;
}
