import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { RolesClient } from "@/components/admin/roles-client";

export const metadata = { title: "Roles & Permissions", robots: { index: false } };

export default async function AdminRolesPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "admin.roles.view"))) {
    return <AccessDenied permission="admin.roles.view" />;
  }
  return <RolesClient />;
}
