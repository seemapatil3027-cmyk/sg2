import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { ProgressClient } from "@/components/lms/progress-client";

export const metadata = { title: "Learning Progress | LMS", robots: { index: false } };

export default async function LmsProgressPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.progress.view"))) {
    return <AccessDenied permission="lms.progress.view" />;
  }
  return <ProgressClient />;
}
