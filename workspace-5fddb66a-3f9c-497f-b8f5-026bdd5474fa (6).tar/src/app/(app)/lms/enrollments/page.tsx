import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { EnrollmentsClient } from "@/components/lms/enrollments-client";

export const metadata = { title: "Enrollments | LMS", robots: { index: false } };

export default async function LmsEnrollmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ courseId?: string }>;
}) {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.enrollments.view"))) {
    return <AccessDenied permission="lms.enrollments.view" />;
  }
  const { courseId } = await searchParams;
  const canManage = await can(session.role, "lms.enrollments.manage");
  return <EnrollmentsClient canManage={canManage} initialCourseId={courseId ?? "ALL"} />;
}
