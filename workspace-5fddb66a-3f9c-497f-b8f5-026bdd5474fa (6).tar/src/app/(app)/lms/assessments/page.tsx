import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { AssessmentsClient } from "@/components/lms/assessments-client";

export const metadata = { title: "Assessments | LMS", robots: { index: false } };

export default async function LmsAssessmentsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.assessments.view"))) {
    return <AccessDenied permission="lms.assessments.view" />;
  }
  const canManage = await can(session.role, "lms.assessments.manage");
  return <AssessmentsClient canManage={canManage} />;
}
