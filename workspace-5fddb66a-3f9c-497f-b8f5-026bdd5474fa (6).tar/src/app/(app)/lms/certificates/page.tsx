import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { CertificatesClient } from "@/components/lms/certificates-client";

export const metadata = { title: "Certificates | LMS", robots: { index: false } };

export default async function LmsCertificatesPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.certificates.view"))) {
    return <AccessDenied permission="lms.certificates.view" />;
  }
  const canIssue = await can(session.role, "lms.certificates.issue");
  return <CertificatesClient canIssue={canIssue} />;
}
