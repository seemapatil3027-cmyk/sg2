import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { ReportsClient } from "@/components/lms/reports-client";

export const metadata = { title: "LMS Reports", robots: { index: false } };

export default async function LmsReportsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.reports.view"))) {
    return <AccessDenied permission="lms.reports.view" />;
  }
  return <ReportsClient />;
}
