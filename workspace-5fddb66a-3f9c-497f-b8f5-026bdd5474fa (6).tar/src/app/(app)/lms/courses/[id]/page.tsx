import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { CourseBuilderClient } from "@/components/lms/course-builder-client";

export const metadata = { title: "Course Builder | LMS", robots: { index: false } };

export default async function CourseBuilderPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.courses.view"))) {
    return <AccessDenied permission="lms.courses.view" />;
  }
  const { id } = await params;
  const canManage = await can(session.role, "lms.courses.manage");
  return <CourseBuilderClient courseId={id} canManage={canManage} />;
}
