import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { CoursesClient } from "@/components/lms/courses-client";

export const metadata = { title: "Courses | LMS", robots: { index: false } };

export default async function LmsCoursesPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "lms.courses.view"))) {
    return <AccessDenied permission="lms.courses.view" />;
  }
  const canManage = await can(session.role, "lms.courses.manage");
  return <CoursesClient canManage={canManage} />;
}
