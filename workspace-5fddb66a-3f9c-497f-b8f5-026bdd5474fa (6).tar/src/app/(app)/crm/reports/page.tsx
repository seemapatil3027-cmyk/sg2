import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { ReportsClient } from "@/components/crm/reports-client";

export const metadata = { title: "Sales Reports · CRM", robots: { index: false } };

export default async function ReportsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.reports.view"))) {
    return <AccessDenied permission="crm.reports.view" />;
  }
  return <ReportsClient />;
}
