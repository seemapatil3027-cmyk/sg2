import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { PipelineClient } from "@/components/crm/pipeline-client";

export const metadata = { title: "Pipeline · CRM", robots: { index: false } };

export default async function PipelinePage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.deals.view"))) {
    return <AccessDenied permission="crm.deals.view" />;
  }
  return <PipelineClient />;
}
