import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { ContactsClient } from "@/components/crm/contacts-client";

export const metadata = { title: "Contacts · CRM", robots: { index: false } };

export default async function ContactsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.contacts.view"))) {
    return <AccessDenied permission="crm.contacts.view" />;
  }
  return <ContactsClient />;
}
