import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { OrganizationsClient } from "@/components/crm/organizations-client";

export const metadata = { title: "Organizations · CRM", robots: { index: false } };

export default async function OrganizationsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.organizations.view"))) {
    return <AccessDenied permission="crm.organizations.view" />;
  }
  return <OrganizationsClient />;
}
