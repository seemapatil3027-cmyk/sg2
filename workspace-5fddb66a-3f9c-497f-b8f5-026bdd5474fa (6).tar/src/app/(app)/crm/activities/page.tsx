import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { ActivitiesClient } from "@/components/crm/activities-client";

export const metadata = { title: "Activities & Tasks · CRM", robots: { index: false } };

export default async function ActivitiesPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.activities.view"))) {
    return <AccessDenied permission="crm.activities.view" />;
  }
  return <ActivitiesClient />;
}
