import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { DealsClient } from "@/components/crm/deals-client";

export const metadata = { title: "Deals · CRM", robots: { index: false } };

export default async function DealsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.deals.view"))) {
    return <AccessDenied permission="crm.deals.view" />;
  }
  return <DealsClient />;
}
