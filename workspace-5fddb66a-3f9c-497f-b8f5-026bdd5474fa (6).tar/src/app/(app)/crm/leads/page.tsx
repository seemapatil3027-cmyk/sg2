import { getSessionUser } from "@/lib/auth";
import { can } from "@/lib/rbac-server";
import { AccessDenied } from "@/components/platform/access-denied";
import { LeadsClient } from "@/components/crm/leads-client";

export const metadata = { title: "Leads · CRM", robots: { index: false } };

export default async function LeadsPage() {
  const session = await getSessionUser();
  if (!session) return null;
  if (!(await can(session.role, "crm.leads.view"))) {
    return <AccessDenied permission="crm.leads.view" />;
  }
  return <LeadsClient />;
}
