import type { MetadataRoute } from "next";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

const BASE = process.env.NEXT_PUBLIC_SITE_URL || "https://www.skillgorila.com";

const STATIC_ROUTES = [
  "",
  "/about-us",
  "/blogs",
  "/contact-us",
  "/courses",
  "/hire-from-us",
  "/how-it-works",
  "/internships",
  "/placement-assistance",
  "/placement-stats",
  "/signin",
  "/success-stories",
  "/tracks",
];

type Sluggable = { slug: string };

async function safeMany(fn: () => Promise<Sluggable[]>): Promise<Sluggable[]> {
  try {
    return await fn();
  } catch {
    return [];
  }
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  const entries: MetadataRoute.Sitemap = STATIC_ROUTES.map((path) => ({
    url: `${BASE}${path}`,
    lastModified: now,
    changeFrequency: path === "" ? "daily" : "weekly",
    priority: path === "" ? 1 : 0.7,
  }));

  const [tracks, courses, blogs] = await Promise.all([
    safeMany(() => db.track.findMany({ select: { slug: true } })),
    safeMany(() => db.course.findMany({ select: { slug: true } })),
    safeMany(() => db.blogPost.findMany({ select: { slug: true } })),
  ]);

  for (const t of tracks) {
    entries.push({ url: `${BASE}/tracks/${t.slug}`, lastModified: now, changeFrequency: "weekly", priority: 0.9 });
  }
  for (const c of courses) {
    entries.push({ url: `${BASE}/courses/${c.slug}`, lastModified: now, changeFrequency: "weekly", priority: 0.9 });
  }
  for (const b of blogs) {
    entries.push({ url: `${BASE}/blogs/${b.slug}`, lastModified: now, changeFrequency: "monthly", priority: 0.6 });
  }

  return entries;
}
