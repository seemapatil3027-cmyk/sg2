import type { Metadata } from "next";
import { Poppins, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/platform/theme-provider";

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.skillgorila.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "SkillGorila — IT Skill Courses & SAP Courses with Placement",
    template: "%s | SkillGorila",
  },
  description:
    "SkillGorila is the Career Operating System: job-ready IT skill courses and SAP courses with placement assistance — learn, practice, prove, connect and get hired, all in one platform.",
  keywords: [
    "SkillGorila",
    "IT skill courses",
    "SAP courses with placement",
    "data analytics course",
    "career tracks",
    "placement assistance",
    "online learning India",
  ],
  openGraph: {
    title: "SkillGorila — The Career Operating System",
    description:
      "Industry-led IT skill courses and SAP courses with placement. Learn → Practice → Prove → Connect → Get Hired.",
    url: SITE_URL,
    siteName: "SkillGorila",
    locale: "en_IN",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${poppins.variable} ${geistMono.variable} antialiased bg-background text-foreground font-sans`}
      >
        <ThemeProvider>{children}</ThemeProvider>
        <Toaster />
      </body>
    </html>
  );
}
