"use client";

import { useEffect } from "react";
import Link from "next/link";
import { TriangleAlert, RefreshCcw, Home, LifeBuoy } from "lucide-react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Surface the real error in the server/browser console for debugging
    console.error("[app-error]", error);
  }, [error]);

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-brand-soft px-4 py-16">
      {/* soft decorative blobs */}
      <div aria-hidden className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-brand-light/40 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-gold/10 blur-3xl" />

      <section className="relative w-full max-w-lg rounded-[2rem] border border-brand/10 bg-white p-8 text-center shadow-elevate sm:p-10">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-gradient text-white shadow-card">
          <TriangleAlert className="h-8 w-8" aria-hidden />
        </div>

        <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
          Something went wrong
        </h1>
        <p className="mx-auto mt-3 max-w-md leading-7 text-ink-soft">
          We hit an unexpected snag loading this page. It&apos;s usually momentary —
          try again, and if it persists our team is on it.
        </p>

        {error?.digest ? (
          <p className="mx-auto mt-4 inline-block rounded-full bg-muted px-4 py-1.5 font-mono text-xs text-ink-soft">
            Error ID: {error.digest}
          </p>
        ) : null}

        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <button
            type="button"
            onClick={reset}
            className="inline-flex h-11 min-w-44 items-center justify-center gap-2 rounded-full bg-brand-gradient px-6 font-semibold text-white shadow-card transition-transform hover:-translate-y-0.5 hover:shadow-elevate focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
          >
            <RefreshCcw className="h-4 w-4" aria-hidden />
            Try again
          </button>
          <Link
            href="/"
            className="inline-flex h-11 min-w-44 items-center justify-center gap-2 rounded-full border border-brand/20 bg-white px-6 font-semibold text-brand transition-colors hover:bg-brand-light/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
          >
            <Home className="h-4 w-4" aria-hidden />
            Back to home
          </Link>
        </div>

        <p className="mt-8 flex items-center justify-center gap-2 text-sm text-ink-soft">
          <LifeBuoy className="h-4 w-4 text-gold" aria-hidden />
          Need help?{" "}
          <Link href="/contact-us" className="font-semibold text-brand underline-offset-4 hover:underline">
            Contact support
          </Link>
        </p>
      </section>
    </main>
  );
}
