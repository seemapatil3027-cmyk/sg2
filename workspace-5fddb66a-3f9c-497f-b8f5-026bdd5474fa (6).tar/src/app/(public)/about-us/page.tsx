import type { Metadata } from "next";
import Link from "next/link";
import {
  Zap,
  DoorOpen,
  Compass,
  UserSearch,
  IndianRupee,
  BookOpenCheck,
  BriefcaseBusiness,
  Handshake,
} from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "About SkilloVilla | Online Upskilling & Placement Platform",
};

const LEARNER_PROBLEMS = [
  {
    icon: Zap,
    term: "Skill",
    text: "Their skills are not relevant to what the fast-paced industry needs",
  },
  {
    icon: DoorOpen,
    term: "Exposure",
    text: "Fresh graduates struggle to find a job since they don't have access to companies",
  },
  {
    icon: Compass,
    term: "Guidance",
    text: "No mentorship from experts that can accelerate student's learning",
  },
];

const COMPANY_PROBLEMS = [
  {
    icon: UserSearch,
    term: "Finding talent",
    text: "Difficult to find candidates with a relevant skill set that matches their needs",
  },
  {
    icon: IndianRupee,
    term: "Training",
    text: "High expenditure to train new employees, companies spend over 50k to do it",
  },
];

const SOLUTIONS = [
  {
    icon: BookOpenCheck,
    title: "Upskill",
    text: "Teaching fresh graduates all the skills that are relevant to the industries",
    tile: "bg-brand-soft text-brand",
  },
  {
    icon: BriefcaseBusiness,
    title: "Careers",
    text: "Helping students to start their careers with end-to-end preparations",
    tile: "bg-accento-soft text-accento",
  },
  {
    icon: Handshake,
    title: "Connect",
    text: "Connecting companies and students with relevant skills that matches their needs",
    tile: "bg-[#EAF8F0] text-[#16A34A]",
  },
];

const TEAM = [
  { name: "Ronak Agrawal", role: "Co-Founder and CEO", education: "IIT Delhi" },
  { name: "Rajat Agrawal", role: "Co-Founder and CTO", education: "IIIT Hyderabad" },
  { name: "Deepak Kharol", role: "Co-Founder and COO", education: "IIT Delhi" },
];

const INVESTORS = [{ name: "Miten Sampat", descriptor: "Building CRED, Upsparks" }];

export default function AboutUsPage() {
  return (
    <>
      {/* HERO */}
      <section className="bg-[#EFE9F7]">
        <div className="container-sv py-16 sm:py-24">
          <SectionHeading
            align="center"
            title="Transform your learnings into earnings"
            sub="We train individuals to unlock their skills and transform it into big earnings."
          />
        </div>
      </section>

      {/* CAUSES WE CARE ABOUT */}
      <Section>
        <SectionHeading
          align="center"
          label="CAUSES WE CARE ABOUT"
          title="We aim to close the gap between what industry needs and what talents can offer"
        />
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {/* Learner's problem */}
          <div className="rounded-3xl bg-accento-soft p-8">
            <h3 className="text-lg font-bold text-ink">Learner&apos;s problem</h3>
            <div className="mt-6 flex flex-col gap-5">
              {LEARNER_PROBLEMS.map((p) => (
                <div key={p.term} className="flex items-start gap-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm">
                    <p.icon className="h-5 w-5 text-accento" aria-hidden="true" />
                  </span>
                  <p className="text-[14.5px] leading-6 text-ink-soft">
                    <span className="font-bold text-ink">{p.term} — </span>
                    {p.text}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Company's problem */}
          <div className="rounded-3xl bg-brand-soft p-8">
            <h3 className="text-lg font-bold text-ink">Company&apos;s problem</h3>
            <div className="mt-6 flex flex-col gap-5">
              {COMPANY_PROBLEMS.map((p) => (
                <div key={p.term} className="flex items-start gap-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm">
                    <p.icon className="h-5 w-5 text-brand" aria-hidden="true" />
                  </span>
                  <p className="text-[14.5px] leading-6 text-ink-soft">
                    <span className="font-bold text-ink">{p.term} — </span>
                    {p.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* THE SOLUTIONS WE OFFER */}
      <Section>
        <SectionHeading
          align="center"
          label="THE SOLUTIONS WE OFFER"
          title="Training the next generation of talent and connecting them with top companies"
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SOLUTIONS.map((s) => (
            <div
              key={s.title}
              className="flex flex-col items-center rounded-3xl border border-border bg-white p-8 text-center shadow-[0_10px_36px_rgba(28,15,66,0.06)]"
            >
              <span className={cn("flex h-14 w-14 items-center justify-center rounded-2xl", s.tile)}>
                <s.icon className="h-7 w-7" aria-hidden="true" />
              </span>
              <h3 className="mt-5 text-lg font-bold text-ink">{s.title}</h3>
              <p className="mt-2 text-[14.5px] leading-6 text-ink-soft">{s.text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* LEARN TO EARN CTA BAND */}
      <Section>
        <div className="bg-brand-gradient rounded-3xl px-6 py-12 text-center sm:px-12 sm:py-16">
          <h2 className="text-[26px] font-bold leading-tight text-white sm:text-[32px]">From learning to earning</h2>
          <p className="mt-3 text-[15px] text-white/80">Improve your skill, invest in yourself.</p>
          <p className="mt-6 text-[14px] font-medium text-white/70">Learn more about our career tracks &amp; courses</p>
          <div className="mt-4 flex flex-col justify-center gap-3 sm:flex-row">
            <Link
              href="/how-it-works"
              className="inline-flex h-12 items-center justify-center rounded-xl border border-white px-8 text-[15px] font-semibold text-white transition hover:bg-white/10"
            >
              How it Works
            </Link>
            <Link
              href="/tracks"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-white px-8 text-[15px] font-semibold text-primary transition hover:bg-white/90"
            >
              Explore Tracks
            </Link>
          </div>
        </div>
      </Section>

      {/* TEAM */}
      <Section>
        <SectionHeading
          align="center"
          label="PEOPLE BEHIND SKILLOVILLA"
          title="Get to know the people behind the scene who aim to help students & connect them to top companies"
        />
        <div className="mx-auto mt-12 grid max-w-4xl gap-6 sm:grid-cols-3">
          {TEAM.map((m) => (
            <div
              key={m.name}
              className="flex flex-col items-center rounded-3xl border border-border bg-white p-8 text-center shadow-[0_10px_36px_rgba(28,15,66,0.06)]"
            >
              <InitialAvatar name={m.name} className="h-24 w-24 text-2xl" />
              <p className="mt-5 font-bold text-ink">{m.name}</p>
              <p className="mt-1 text-[14px] font-medium text-ink">{m.role}</p>
              <p className="mt-0.5 text-[13px] text-ink-soft">{m.education}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CAREERS CTA */}
      <Section>
        <div className="rounded-3xl border border-border bg-brand-soft p-8 text-center sm:p-10">
          <h3 className="text-xl font-bold text-ink sm:text-2xl">Want to be part of our amazing journey? Apply now!</h3>
          <p className="mt-3 text-[15px] text-ink-soft">
            Mail us at:{" "}
            <a
              href="mailto:careers@skillovilla.com"
              className="font-bold text-brand underline-offset-4 transition hover:underline"
            >
              careers@skillovilla.com
            </a>
          </p>
        </div>
      </Section>

      {/* INVESTORS */}
      <Section>
        <SectionHeading
          align="center"
          label="PEOPLE WHO INVEST IN US"
          title="Get to know the people who believe in our mission and have supported us"
        />
        <div className="mt-12 flex flex-wrap justify-center gap-6">
          {INVESTORS.map((i) => (
            <div
              key={i.name}
              className="flex w-full max-w-sm items-center gap-4 rounded-2xl border border-border bg-white p-6 shadow-[0_10px_36px_rgba(28,15,66,0.06)]"
            >
              <InitialAvatar name={i.name} className="h-14 w-14 text-lg" />
              <div>
                <p className="font-bold text-ink">{i.name}</p>
                <p className="text-[13.5px] text-ink-soft">{i.descriptor}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <CallbackBanner />
    </>
  );
}
