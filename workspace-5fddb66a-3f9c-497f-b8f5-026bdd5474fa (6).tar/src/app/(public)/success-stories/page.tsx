import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { Download, Trophy, BookOpen, UserRoundPen, BriefcaseBusiness } from "lucide-react";
import { getPlacedStudents } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { StudentBadge } from "@/components/placement/student-badge";

export const metadata: Metadata = {
  title: "SkilloVilla Success Stories | Achievements that Inspire",
  description:
    "Inspiring stories of SkilloVilla alumni who made their mark — discover the journey from learning to earning at 300+ partner companies.",
};

const JOURNEY_STEPS: { n: string; title: string; text: string; icon: ReactNode }[] = [
  {
    n: "1",
    title: "Learning",
    text: "Get conceptual and practical learning experience",
    icon: <BookOpen className="h-5 w-5 text-brand" />,
  },
  {
    n: "2",
    title: "Profile Building",
    text: "Resume building and linkedin workshop",
    icon: <UserRoundPen className="h-5 w-5 text-brand" />,
  },
  {
    n: "3",
    title: "Secure Dream Job",
    text: "Job interviews with our partner companies",
    icon: <BriefcaseBusiness className="h-5 w-5 text-brand" />,
  },
];

export default async function SuccessStoriesPage() {
  const students = await getPlacedStudents();

  return (
    <main>
      {/* 1. HERO */}
      <section className="bg-[#EFE9F7] py-14 text-center sm:py-20">
        <div className="container-sv flex flex-col items-center">
          <p className="section-label mb-3">SUCCESS STORIES</p>
          <h1 className="max-w-3xl text-3xl font-bold leading-tight text-ink sm:text-[44px]">
            Discover the Journey to Success
          </h1>
          <p className="mt-4 max-w-2xl text-[15px] text-ink-soft sm:text-lg">
            Inspiring Stories of SkilloVilla Alumni Who Made Their Mark !
          </p>
          <p className="mt-2 text-[15px] font-medium italic text-gold">
            Celebrating Success, One Story at a Time!
          </p>
          <Link
            href="/tracks"
            className="mt-8 inline-flex h-12 items-center justify-center rounded-xl bg-primary px-7 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
          >
            Explore Programs
          </Link>
        </div>
      </section>

      {/* 2. ALUMNI WITNESS (masonry stories) */}
      <Section>
        <SectionHeading
          align="center"
          label="ALUMNI"
          title="Witness Our Alumni's Remarkable Careers!"
        />
        <div className="mt-10 columns-1 gap-5 sm:columns-2 lg:columns-3">
          {students.map((s) => (
            <div
              key={s.id}
              className="mb-5 break-inside-avoid rounded-2xl border border-border bg-white p-6 transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]"
            >
              <div className="flex items-start gap-3">
                <InitialAvatar name={s.name} className="h-12 w-12 text-base" />
                <div className="min-w-0">
                  <p className="truncate font-bold text-ink">{s.name}</p>
                  <p className="truncate text-sm font-semibold text-brand">{s.role}</p>
                  <p className="truncate text-sm text-ink-soft">@ {s.company}</p>
                </div>
              </div>
              {s.story && (
                <p className="mt-4 text-[14px] leading-6 text-ink-soft">&ldquo;{s.story}&rdquo;</p>
              )}
              {(s.status === "Fresher" || s.hike) && (
                <div className="mt-4">
                  <StudentBadge status={s.status} hike={s.hike} />
                </div>
              )}
            </div>
          ))}
        </div>
      </Section>

      {/* 3. REPORT CTA */}
      <Section className="pt-0 sm:pt-0">
        <SectionHeading
          align="center"
          title="Explore Our Exceptional Placement Opportunities"
          sub="Learn how we help our students land their dream job"
        />
        <div className="mt-7 text-center">
          <a
            href="/api/brochure?track=data-analytics-and-ai"
            download
            className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-primary px-7 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
          >
            <Download className="h-4 w-4" />
            Download Report
          </a>
        </div>
      </Section>

      {/* 4. YOUR JOURNEY */}
      <Section className="bg-[#FAF8FD]">
        <SectionHeading align="center" label="YOUR JOURNEY" title="From Learning to Earning" />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {JOURNEY_STEPS.map((step) => (
            <JourneyCard key={step.n} {...step} />
          ))}
          {/* 4th celebratory card */}
          <div className="rounded-2xl border border-[#E9DFF8] bg-brand-soft p-6 transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-white">
              <Trophy className="h-5 w-5" />
            </span>
            <h3 className="mt-5 font-bold text-ink">Celebrate 🎉</h3>
            <p className="mt-2 text-[14px] leading-6 text-ink-soft">Join the 6K+ alumni network</p>
          </div>
        </div>
      </Section>

      {/* 5. CALLBACK */}
      <CallbackBanner />
    </main>
  );
}

function JourneyCard({
  n,
  title,
  text,
  icon,
}: {
  n: string;
  title: string;
  text: string;
  icon: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-border bg-white p-6 transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]">
      <div className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-lg font-bold text-white">
          {n}
        </span>
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft">
          {icon}
        </span>
      </div>
      <h3 className="mt-5 font-bold text-ink">{title}</h3>
      <p className="mt-2 text-[14px] leading-6 text-ink-soft">{text}</p>
    </div>
  );
}
