import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";

export const metadata = { robots: { index: false, follow: false }, title: "Instructor" };

/** Legacy /instructor URL → unified platform (LMS courses). */
export default async function LegacyInstructorPage() {
  const session = await getSessionUser();
  if (!session) redirect("/signin?next=/lms/courses");
  redirect("/lms/courses");
}
