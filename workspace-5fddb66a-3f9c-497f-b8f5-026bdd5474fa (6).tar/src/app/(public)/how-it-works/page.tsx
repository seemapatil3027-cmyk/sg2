import type { Metadata } from "next";
import Link from "next/link";
import { Section, SectionHeading } from "@/components/shared/section";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { TrackCard } from "@/components/shared/track-card";
import { LearnEarnTabs } from "@/components/info/learn-earn-tabs";
import { getFaqs, getTracks } from "@/lib/data";

export const metadata: Metadata = {
  title: "How it works | Learn from the best",
};

export default async function HowItWorksPage() {
  const [faqs, tracks] = await Promise.all([getFaqs(), getTracks()]);

  return (
    <>
      {/* HERO */}
      <section className="bg-[#EFE9F7]">
        <div className="container-sv flex flex-col items-center py-16 text-center sm:py-20">
          <SectionHeading
            align="center"
            label="HOW IT WORKS"
            title="From learning to earning"
            sub="Learn skills that matter, get shortlisted easily"
          />
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <LeadDialogButton
              label="Contact Us"
              source="contact"
              buttonVariant="outline"
              dialogTitle="Contact us"
              dialogText="We'll get back to you in the next 24 hours."
            />
            <Link
              href="/tracks"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-primary px-8 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
            >
              Explore Tracks
            </Link>
          </div>
        </div>
      </section>

      {/* LEARNING / EARNING JOURNEY TABS */}
      <Section>
        <LearnEarnTabs />
      </Section>

      {/* CAREER TRACKS */}
      <Section>
        <SectionHeading label="CAREER TRACKS" title="Explore career tracks" />
        <div className="mt-12 grid gap-x-8 gap-y-12 pt-6 lg:grid-cols-2">
          {tracks.slice(0, 4).map((track) => (
            <TrackCard key={track.id} track={track} />
          ))}
        </div>
      </Section>

      <FaqSection items={faqs} />
      <CallbackBanner />
    </>
  );
}
