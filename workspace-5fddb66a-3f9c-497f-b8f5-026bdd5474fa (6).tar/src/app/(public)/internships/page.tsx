import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { BookOpen, Hammer, Award, FileUp } from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { getFaqs } from "@/lib/data";

export const metadata: Metadata = {
  title: "2-month Internship Programs with NASSCOM accredited certificates",
};

const STEPS = [
  {
    n: 1,
    icon: BookOpen,
    title: "Learn Skills",
    desc: "Learn the skills from curriculum created by top 1% industry experts.",
  },
  {
    n: 2,
    icon: Hammer,
    title: "Build Projects",
    desc: "Apply the concepts by building real world projects.",
  },
  {
    n: 3,
    icon: Award,
    title: "Get Certified",
    desc: "Get a 2 Month - Internship Certificate from SkilloVilla.",
  },
  {
    n: 4,
    icon: FileUp,
    title: "Boost Resume",
    desc: "Boost your resume with the newly gained skills and Certificate.",
  },
];

export default async function InternshipsPage() {
  const faqs = await getFaqs();

  return (
    <>
      {/* HERO */}
      <section className="bg-[#EFE9F7]">
        <div className="container-sv grid items-center gap-10 py-14 sm:py-20 lg:grid-cols-2">
          <div>
            <SectionHeading
              label="INDUSTRY RELEVANT SKILLS"
              title="Transform your future, one data point at a time"
            />
            <Link
              href="/tracks"
              className="mt-8 inline-flex h-12 items-center justify-center rounded-xl bg-primary px-8 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
            >
              Explore internships
            </Link>
          </div>
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl shadow-[0_20px_50px_rgba(34,28,51,0.14)]">
            <Image
              src="/images/classroom.png"
              alt="Students learning together in a SkilloVilla internship program"
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
              priority
            />
          </div>
        </div>
      </section>

      {/* FOUR STEPS */}
      <Section>
        <SectionHeading
          align="center"
          label="FROM LEARNING TO LAUNCH"
          title="A Four-Step Journey to Elevate Your Expertise"
        />
        <div className="mt-14 grid gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s) => (
            <div key={s.n} className="relative flex flex-col items-center text-center">
              {/* dashed connector between numbered circles (desktop 4-col row only) */}
              {s.n < STEPS.length && (
                <span
                  aria-hidden="true"
                  className="absolute left-[calc(50%+2rem)] top-7 hidden w-[calc(100%-1.4rem)] border-t-2 border-dashed border-brand/30 lg:block"
                />
              )}
              <div className="relative z-10 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-lg font-bold text-white shadow-[0_8px_20px_rgba(93,24,190,0.35)]">
                {s.n}
              </div>
              <span className="mt-5 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-soft">
                <s.icon className="h-6 w-6 text-brand" aria-hidden="true" />
              </span>
              <h3 className="mt-4 text-lg font-bold text-ink">{s.title}</h3>
              <p className="mt-2 max-w-[260px] text-[14px] leading-6 text-ink-soft">{s.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA BAND */}
      <Section>
        <div className="bg-brand-gradient rounded-3xl px-6 py-12 text-center sm:px-12 sm:py-16">
          <h2 className="text-[26px] font-bold leading-tight text-white sm:text-[32px]">
            Ready to launch your career?
          </h2>
          <p className="mt-3 text-[15px] text-white/80">
            Join an internship program and work on real industry projects.
          </p>
          <div className="mt-8">
            <Link
              href="/tracks"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-white px-8 text-[15px] font-semibold text-primary transition hover:bg-white/90"
            >
              Explore Tracks
            </Link>
          </div>
        </div>
      </Section>

      <FaqSection items={faqs} />
      <CallbackBanner />
    </>
  );
}
