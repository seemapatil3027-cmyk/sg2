import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";

export const metadata = { robots: { index: false, follow: false }, title: "Admin" };

/** Legacy /-admin URL → unified platform (CRM workspace). */
export default async function LegacyAdminPage() {
  const session = await getSessionUser();
  if (!session) redirect("/signin?next=/crm/leads");
  redirect("/crm/leads");
}
