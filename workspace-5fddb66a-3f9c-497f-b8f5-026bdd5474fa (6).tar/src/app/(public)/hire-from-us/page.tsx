import type { Metadata } from "next";
import { BadgeCheck, BriefcaseBusiness, Zap } from "lucide-react";
import { getPlacedStudents } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { LeadForm } from "@/components/shared/lead-form";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { CandidatesMarquee } from "@/components/placement/candidates-marquee";

export const metadata: Metadata = {
  title: "Hire Data Analysts & Data Scientists",
  description:
    "Hire pre-vetted, industry-ready data analysts, data scientists and SDEs from SkilloVilla — 2K+ certified candidates trusted by 350+ companies.",
};

const BENEFITS = [
  {
    icon: BadgeCheck,
    title: "Pre-vetted talent",
    text: "Every candidate is trained on real industry projects and case studies",
  },
  {
    icon: BriefcaseBusiness,
    title: "Domain ready",
    text: "Analysts, data scientists and SDEs ready from day one",
  },
  {
    icon: Zap,
    title: "Zero effort hiring",
    text: "Share your requirement, we shortlist the best fits for you",
  },
];

export default async function HireFromUsPage() {
  const candidates = await getPlacedStudents();

  return (
    <main>
      {/* 1. HERO */}
      <section className="bg-[#EFE9F7] py-14 sm:py-20">
        <div className="container-sv grid items-center gap-10 lg:grid-cols-2">
          <div className="text-center lg:text-left">
            <h1 className="mx-auto max-w-xl text-3xl font-bold leading-tight text-ink sm:text-[44px] lg:mx-0">
              Hire from India&apos;s <span className="text-accento">top</span> talent pool
            </h1>
            <p className="mt-4 text-[15px] text-ink-soft sm:text-lg">
              We make hiring seem like a breeze
            </p>
            <div className="mt-8 flex justify-center lg:justify-start">
              <LeadDialogButton
                label="Explore Talent"
                source="hire"
                dialogTitle="Explore our talent"
                dialogText="Share your details and our team will reach out with candidate profiles."
              />
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-[0_16px_40px_rgba(34,28,51,0.12)]">
              <div className="grid grid-cols-2 divide-x divide-border text-center">
                <div className="px-2">
                  <p className="text-3xl font-bold text-ink">2K+</p>
                  <p className="mt-1 text-sm text-ink-soft">Certified Candidates</p>
                </div>
                <div className="px-2">
                  <p className="text-3xl font-bold text-ink">350+</p>
                  <p className="mt-1 text-sm text-ink-soft">Companies trust us</p>
                </div>
              </div>
              <div className="mt-5 flex justify-center">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-[#DCF2E4] px-3 py-1 text-xs font-bold text-[#15803D]">
                  <BadgeCheck className="h-3.5 w-3.5" />
                  Placed Student
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CANDIDATES MARQUEE (client comp) */}
      <Section>
        <CandidatesMarquee candidates={candidates} />
      </Section>

      {/* 3. WHY HIRE FROM US */}
      <Section className="bg-[#FAF8FD]">
        <SectionHeading align="center" label="BENEFITS" title="Why hire from SkilloVilla" />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {BENEFITS.map((b) => (
            <div
              key={b.title}
              className="rounded-2xl border border-border bg-white p-6 transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-soft">
                <b.icon className="h-5 w-5 text-brand" />
              </span>
              <h3 className="mt-5 text-lg font-bold text-ink">{b.title}</h3>
              <p className="mt-2 text-[14px] leading-6 text-ink-soft">{b.text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* 4. HIRE FORM */}
      <Section>
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <SectionHeading
            title="Hire only the best talents"
            sub="We provide fresh talents who are industry ready, the one you're looking for. Contact us to learn more about SkilloVilla graduates."
          />
          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_8px_24px_rgba(34,28,51,0.06)] sm:p-8">
            <LeadForm
              source="hire"
              submitLabel="Submit"
              successText="Thanks! Our hiring team will reach out shortly."
            />
          </div>
        </div>
      </Section>

      {/* 5. CALLBACK */}
      <CallbackBanner />
    </main>
  );
}
