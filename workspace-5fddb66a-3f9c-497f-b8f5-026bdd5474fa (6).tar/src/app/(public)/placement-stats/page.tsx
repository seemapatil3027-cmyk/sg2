import type { Metadata } from "next";
import Link from "next/link";
import { getPlacedStudents, getCompanies } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { PartnerTabs } from "@/components/placement/partner-tabs";

export const metadata: Metadata = {
  title: "Placement Stats — Empowering Your Career Transformation",
  description:
    "Discover SkilloVilla placement stats: 92% placement rate, 8 LPA average salary, 60% average hike and alumni working at 300+ companies.",
};

const BAND_STATS = [
  { value: "92%", label: "Placement Rate" },
  { value: "8LPA", label: "Average Salary" },
  { value: "60%", label: "Average Hike" },
  { value: "32LPA", label: "Highest Salary" },
];

export default async function PlacementStatsPage() {
  const [students, mnc, unicorn, startup] = await Promise.all([
    getPlacedStudents(),
    getCompanies("mnc"),
    getCompanies("unicorn"),
    getCompanies("startup"),
  ]);

  return (
    <main>
      {/* 1. HERO */}
      <section className="bg-[#EFE9F7] py-14 text-center sm:py-20">
        <div className="container-sv flex flex-col items-center">
          <p className="section-label mb-3">FROM LEARNING TO EARNING</p>
          <h1 className="max-w-3xl text-3xl font-bold leading-tight text-ink sm:text-[44px]">
            Discover success stories that could mirror your own journey at SkilloVilla
          </h1>
          <p className="mt-4 max-w-2xl text-[15px] text-ink-soft sm:text-lg">
            Witness the transformative outcome of the upskilling journey at SkilloVilla.
          </p>
          <Link
            href="/tracks"
            className="mt-8 inline-flex h-12 items-center justify-center rounded-xl bg-primary px-7 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
          >
            Explore Programs
          </Link>
        </div>
      </section>

      {/* 2. STUDENT GRID */}
      <Section>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {students.map((s) => {
            const [first, ...rest] = s.name.split(" ");
            return (
              <div
                key={s.id}
                className="rounded-2xl border border-border bg-white p-5 text-center transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]"
              >
                <InitialAvatar name={s.name} className="mx-auto h-14 w-14 text-lg" />
                <p className="mt-3 font-bold leading-tight text-ink">
                  {first}
                  {rest.length > 0 && (
                    <>
                      <br />
                      {rest.join(" ")}
                    </>
                  )}
                </p>
                <p className="mt-1.5 text-sm font-semibold text-brand">{s.role}</p>
                {s.hike && (
                  <span className="mt-3 inline-block rounded-full bg-[#DCF2E4] px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-[#15803D]">
                    {s.hike.toUpperCase()}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </Section>

      {/* 3. STATS BAND */}
      <section className="pb-4">
        <div className="container-sv">
          <div className="grid grid-cols-2 gap-x-6 gap-y-8 rounded-3xl bg-brand-gradient p-8 text-center sm:p-10 lg:grid-cols-4">
            {BAND_STATS.map((s) => (
              <div key={s.label}>
                <p className="text-3xl font-bold text-white sm:text-4xl">{s.value}</p>
                <p className="mt-1 text-sm text-white/70">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. HIRING PARTNERS (client tabs) */}
      <Section>
        <PartnerTabs companies={{ mnc, unicorn, startup }} />
      </Section>

      {/* 5. CTA */}
      <Section className="pt-0 sm:pt-0">
        <SectionHeading
          align="center"
          title="Explore our exceptional Placement Opportunities"
          sub="Learn how we help our students land their dream job"
        />
        <div className="mt-7 text-center">
          <Link
            href="/tracks"
            className="inline-flex h-12 items-center justify-center rounded-xl bg-primary px-7 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
          >
            Explore Programs
          </Link>
        </div>
      </Section>

      {/* 6. CALLBACK */}
      <CallbackBanner />
    </main>
  );
}
