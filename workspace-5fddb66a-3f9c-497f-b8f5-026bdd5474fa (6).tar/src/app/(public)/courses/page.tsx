import type { Metadata } from "next";
import Link from "next/link";
import { BookOpen, CheckCircle2, Rocket } from "lucide-react";
import { getCourses, getFaqs } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { CourseCard } from "@/components/shared/course-card";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";

export const metadata: Metadata = {
  title: "SQL, Python, Excel & Data Analytics Courses",
  description:
    "Invest in yourself with SkilloVilla courses in SQL, Python, Excel, Power BI and Data Analytics. Learn industry relevant skills at your own pace, designed by top 1% industry experts.",
};

const COURSE_BULLETS = ["Designed by top 1% industry experts", "Learn at your own pace"];

const TRACK_BULLETS = [
  "Designed by top 1% industry experts",
  "Ask your doubts directly to mentors",
  "Get a glimpse of our career tracks in a masterclass",
];

export default async function CoursesPage() {
  const [courses, courseFaqs] = await Promise.all([getCourses(), getFaqs("courses")]);

  return (
    <>
      {/* 1. Hero (centered) */}
      <section className="bg-[#EFE9F7] py-14 sm:py-16">
        <div className="container-sv text-center">
          <SectionHeading
            align="center"
            title="Invest in yourself. Level up your skills."
            titleClassName="!text-[30px] sm:!text-[42px]"
            sub="Learn industry relevant skills at your own pace!"
          />
          <p className="mt-6 text-[15px] text-ink-soft">
            Want to advance your career?{" "}
            <Link
              href="/tracks"
              className="font-semibold text-brand underline-offset-2 hover:underline"
            >
              Switch to career tracks.
            </Link>
          </p>
        </div>
      </section>

      {/* 2. Courses */}
      <Section>
        <SectionHeading label="Designed by experts from" title={`Courses (${courses.length})`} />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((c) => (
            <CourseCard key={c.id} course={c} />
          ))}
        </div>
      </Section>

      {/* 3. Compare */}
      <Section className="pt-0">
        <SectionHeading
          align="center"
          title="Compare to make a career switch"
          sub="Explore our career tracks in our masterclass. See it for yourself!"
        />
        <div className="mt-12 grid gap-8 md:grid-cols-2">
          {/* Courses card */}
          <div className="rounded-3xl border border-border bg-white p-8">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-soft">
              <BookOpen className="h-7 w-7 text-brand" aria-hidden />
            </div>
            <h3 className="mt-5 text-xl font-bold text-ink">Courses</h3>
            <ul className="mt-5 flex flex-col gap-3.5">
              {COURSE_BULLETS.map((b) => (
                <li key={b} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-600" aria-hidden />
                  <span className="text-[15px] leading-6 text-ink">{b}</span>
                </li>
              ))}
            </ul>
          </div>
          {/* Career tracks card */}
          <div className="relative rounded-3xl border-2 border-brand bg-white p-8 shadow-[0_16px_40px_rgba(93,24,190,0.12)]">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary">
              <Rocket className="h-7 w-7 text-white" aria-hidden />
            </div>
            <h3 className="mt-5 text-xl font-bold text-ink">Career Tracks</h3>
            <ul className="mt-5 flex flex-col gap-3.5">
              {TRACK_BULLETS.map((b) => (
                <li key={b} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-600" aria-hidden />
                  <span className="text-[15px] leading-6 text-ink">{b}</span>
                </li>
              ))}
            </ul>
            <Link
              href="/tracks"
              className="mt-7 inline-flex h-12 w-full items-center justify-center rounded-xl bg-primary text-[15px] font-semibold text-white transition hover:bg-brand-dark"
            >
              <span className="mr-2 text-lg leading-none">»</span> Explore career tracks
            </Link>
          </div>
        </div>
      </Section>

      {/* 4. FAQs + callback */}
      <FaqSection items={courseFaqs} />
      <CallbackBanner />
    </>
  );
}
