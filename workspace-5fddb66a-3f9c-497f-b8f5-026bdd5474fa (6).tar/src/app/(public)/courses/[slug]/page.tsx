import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import {
  BadgeCheck,
  Calendar,
  CheckCircle2,
  Clock,
  FileSearch,
  GraduationCap,
  Laptop,
  Users,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { getCourse, getFaqs } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { ChaptersAccordion } from "@/components/courses/chapters-accordion";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const course = await getCourse(slug);
  return {
    title: course?.title ?? "Course",
    description: course?.description,
  };
}

const ADVANTAGES: { icon: LucideIcon; title: string; sub: string }[] = [
  {
    icon: GraduationCap,
    title: "World class curriculum",
    sub: "designed by experts",
  },
  {
    icon: FileSearch,
    title: "Learn with case studies",
    sub: "from the industry",
  },
  {
    icon: BadgeCheck,
    title: "Showcase your skills",
    sub: "with industry recognized certificate",
  },
];

export default async function CourseDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const course = await getCourse(slug);
  if (!course) notFound();

  const courseFaqs = await getFaqs("courses");

  const stats: { icon: LucideIcon; value: string; label: string }[] = [
    { icon: Calendar, value: `${course.weeks}`, label: "Weeks" },
    { icon: Clock, value: `${course.hrsPerDay}`, label: "hrs/day" },
    { icon: Users, value: `${course.learners}`, label: "Students" },
  ];

  return (
    <>
      {/* 1. Hero */}
      <section className="bg-[#EFE9F7] py-14">
        <div className="container-sv grid items-center gap-12 lg:grid-cols-[1.4fr_1fr] lg:gap-14">
          <div>
            <h1 className="text-[30px] font-bold leading-tight text-ink sm:text-[40px]">
              {course.title}
            </h1>
            <div className="mt-4 h-1.5 w-14 rounded bg-primary" aria-hidden />
            <p className="mt-5 max-w-xl text-[15px] leading-7 text-ink-soft">
              {course.description}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <LeadDialogButton
                label="Contact us"
                source="contact"
                dialogTitle="Contact us"
                dialogText="We'll get back to you in the next 24 hours."
                buttonVariant="outline"
                buttonClassName="sm:flex-1"
              />
              <LeadDialogButton
                label="Enroll Now"
                source="enroll"
                itemSlug={course.slug}
                dialogTitle={`Enroll in ${course.title}`}
                dialogText="Leave your details — our admissions team will call you within 24 hours."
                buttonClassName="sm:flex-1"
              />
            </div>
          </div>
          {/* stat chips column */}
          <div className="flex w-full max-w-sm flex-col gap-4 lg:justify-self-end">
            {stats.map(({ icon: Icon, value, label }) => (
              <div
                key={label}
                className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow-[0_10px_30px_rgba(34,28,51,0.1)]"
              >
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-soft">
                  <Icon className="h-5 w-5 text-brand" aria-hidden />
                </span>
                <div>
                  <p className="text-[22px] font-bold leading-none text-ink">{value}</p>
                  <p className="mt-1.5 text-[12.5px] font-medium text-ink-soft">{label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. Course overview */}
      <Section>
        <SectionHeading label="COURSE OVERVIEW" title="Master these skills" />
        <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="rounded-3xl border border-border bg-white p-7">
            <h3 className="text-lg font-bold text-ink">Skills covered</h3>
            <div className="mt-5 flex flex-wrap gap-2.5">
              {course.skills.map((s) => (
                <span
                  key={s}
                  className="rounded-full border border-border px-4 py-2 text-sm font-medium text-ink transition hover:border-brand hover:bg-brand-soft hover:text-brand"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-border bg-white p-7">
            <h3 className="text-lg font-bold text-ink">Level &amp; pre-requisites</h3>
            <div className="mt-5 flex flex-col gap-4">
              <div className="flex items-center gap-4 rounded-2xl bg-brand-soft p-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white">
                  <GraduationCap className="h-5 w-5 text-brand" aria-hidden />
                </span>
                <div>
                  <p className="text-[12px] font-medium uppercase tracking-wide text-ink-soft">
                    Level
                  </p>
                  <p className="mt-0.5 text-[15px] font-semibold text-ink">{course.level}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-2xl bg-brand-soft p-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white">
                  <Laptop className="h-5 w-5 text-brand" aria-hidden />
                </span>
                <div>
                  <p className="text-[12px] font-medium uppercase tracking-wide text-ink-soft">
                    Pre-requisites
                  </p>
                  <p className="mt-0.5 text-[15px] font-semibold text-ink">
                    {course.prerequisite}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* 3. Course highlight */}
      <Section className="pt-0">
        <SectionHeading
          label="COURSE HIGHLIGHT"
          title="Benefit of mastering this course"
        />
        <div className="mt-10 rounded-3xl border border-border bg-white p-8 sm:p-10">
          <ul className="grid gap-x-10 gap-y-4 sm:grid-cols-2">
            {course.highlights.map((h) => (
              <li key={h} className="flex items-start gap-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-600" aria-hidden />
                <span className="text-[14.5px] leading-6 text-ink">{h}</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* 4. The advantages */}
      <Section className="pt-0">
        <SectionHeading
          label="THE ADVANTAGES"
          title="Why take SkilloVilla's courses"
        />
        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_400px]">
          <div className="flex flex-col gap-4">
            {ADVANTAGES.map(({ icon: Icon, title, sub }) => (
              <div
                key={title}
                className="flex items-start gap-5 rounded-2xl border border-border bg-white p-6"
              >
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-brand-soft">
                  <Icon className="h-6 w-6 text-brand" aria-hidden />
                </span>
                <div>
                  <h3 className="text-[16.5px] font-bold text-ink">{title}</h3>
                  <p className="mt-1 text-[14px] leading-6 text-ink-soft">{sub}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="relative">
            <Image
              src="/images/classroom.png"
              alt="SkilloVilla courses designed by industry experts"
              width={1344}
              height={768}
              className="aspect-[4/3] w-full rounded-3xl object-cover shadow-[0_16px_40px_rgba(34,28,51,0.14)]"
            />
            <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-white/95 p-4 shadow-lg backdrop-blur sm:right-auto sm:min-w-[240px]">
              <p className="text-[15px] font-bold text-ink">Courses designed by experts</p>
              <p className="mt-0.5 text-[12.5px] text-ink-soft">Top 1% industry mentors</p>
            </div>
          </div>
        </div>
      </Section>

      {/* 5. Syllabus */}
      <Section className="pt-0">
        <SectionHeading label="SYLLABUS" title="SkilloVilla's world-class curriculum" />
        <ChaptersAccordion items={course.chapters} className="mt-10" />
      </Section>

      {/* 6. CTA band */}
      <section className="bg-brand-gradient py-12">
        <div className="container-sv flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
          <div>
            <h2 className="text-2xl font-bold text-white sm:text-[28px]">
              Ready to master {course.title}?
            </h2>
            <p className="mt-2 text-[15px] text-white/80">
              Learn live with the top 1% industry experts and boost your career.
            </p>
          </div>
          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
            <LeadDialogButton
              label="Enroll Now"
              source="enroll"
              itemSlug={course.slug}
              dialogTitle={`Enroll in ${course.title}`}
              dialogText="Leave your details — our admissions team will call you within 24 hours."
              buttonClassName="bg-white text-brand hover:bg-white/90 w-full sm:w-auto"
            />
            <LeadDialogButton
              label="Try Masterclass"
              source="masterclass"
              itemSlug={course.slug}
              dialogTitle="Try a free masterclass"
              dialogText="Solve a real-life case study, live with the experts."
              icon={<Zap className="mr-2 h-4 w-4" />}
              buttonVariant="outline"
              buttonClassName="border-white/70 bg-transparent text-white hover:bg-white/10 hover:text-white w-full sm:w-auto"
            />
          </div>
        </div>
      </section>

      {/* 7. FAQs + callback */}
      <FaqSection items={courseFaqs} />
      <CallbackBanner />
    </>
  );
}
