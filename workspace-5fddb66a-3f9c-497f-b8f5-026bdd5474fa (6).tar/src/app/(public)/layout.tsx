import { Toaster } from "@/components/ui/toaster";
import { NotifyBar } from "@/components/layout/notify-bar";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { FloatingCall } from "@/components/layout/floating-call";

/** Marketing site chrome — wraps every public page of SkillGorila. */
export default function PublicLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className="flex min-h-screen flex-col">
      <NotifyBar />
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
      <FloatingCall />
    </div>
  );
}
