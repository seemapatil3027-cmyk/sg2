import type { Metadata } from "next";
import {
  getCompanies,
  getFaqs,
  getMentors,
  getPlacedStudents,
  getTestimonials,
  getTracks,
} from "@/lib/data";
import type { TrackFull } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { CompanyMarquee } from "@/components/shared/company-marquee";
import { TestimonialCarousel } from "@/components/shared/testimonial-carousel";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { Hero } from "@/components/home/hero";
import { CareerAssessment } from "@/components/home/career-assessment";
import { TrustStrip } from "@/components/home/trust-strip";
import { CareerPathCard } from "@/components/home/career-path-card";
import { WhyDifferent } from "@/components/home/why-different";
import { LmsPreview } from "@/components/home/lms-preview";
import { ProjectsShowcase } from "@/components/home/projects-showcase";
import { MentorsSectionV2 } from "@/components/home/mentors-section-v2";
import { SuccessSection } from "@/components/home/success-section";
import { PlacementEngine } from "@/components/home/placement-engine";
import { CareerResources } from "@/components/home/career-resources";
import { Zap, Target, ShieldCheck } from "lucide-react";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.skillgorila.com";

export const metadata: Metadata = {
  title: {
    absolute: "SkillGorila | IT Skill Courses & SAP Courses with Placement",
  },
  description:
    "Learn → Practice → Prove → Connect → Get Hired. Industry-led IT skill courses and SAP courses with placement — real projects, expert mentorship and a personal learning dashboard.",
  keywords: [
    "IT skill courses",
    "SAP courses with placement",
    "data analytics career track",
    "AI courses India",
    "career assessment",
    "placement assistance",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    title: "SkillGorila — Build Skills That Move Your Career Forward",
    description:
      "Industry-led programs, real projects, expert mentorship and a structured path from learning to employment.",
    url: "/",
    siteName: "SkillGorila",
    locale: "en_IN",
    type: "website",
  },
};

/* Domain grouping for the Career Paths section */
const DATA_GROUP = new Set(["data-analytics-and-ai", "data-analytics-offline", "data-analytics-python"]);
const AI_GROUP = new Set([
  "ai-mastery-program",
  "data-science-and-ai",
  "data-science-machine-learning",
  "software-development",
]);
const BUSINESS_KEYWORDS = ["business", "digital-marketing", "digital"];

function monthsOf(track: TrackFull): number {
  return Math.max(1, Math.round((track.weeks ?? 20) / 4));
}

const ASSESSMENT_PERKS = [
  { icon: Zap, text: "Instant result — no sign-up needed" },
  { icon: Target, text: "A learning path mapped to your goal" },
  { icon: ShieldCheck, text: "Skill-gap & readiness report" },
];

export default async function HomePage() {
  const [tracks, testimonials, generalFaqs, mentors, placedStudents, hiringCompanies] =
    await Promise.all([
      getTracks(),
      getTestimonials(),
      getFaqs("general"),
      getMentors(),
      getPlacedStudents(),
      getCompanies("hiring"),
    ]);

  const dataTracks = tracks.filter((t) => DATA_GROUP.has(t.slug));
  const aiTracks = tracks.filter((t) => AI_GROUP.has(t.slug));
  const sapTracks = tracks.filter((t) => t.slug.startsWith("sap"));
  const businessTracks = tracks.filter((t) =>
    BUSINESS_KEYWORDS.some((k) => t.slug.includes(k))
  );

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${SITE_URL}/#organization`,
        name: "SkillGorila",
        url: SITE_URL,
        logo: `${SITE_URL}/logo.svg`,
        sameAs: [
          "https://facebook.com",
          "https://instagram.com",
          "https://youtube.com",
          "https://twitter.com",
          "https://linkedin.com",
        ],
      },
      {
        "@type": "WebSite",
        "@id": `${SITE_URL}/#website`,
        name: "SkillGorila",
        url: SITE_URL,
        publisher: { "@id": `${SITE_URL}/#organization` },
      },
      {
        "@type": "FAQPage",
        mainEntity: generalFaqs.map((f) => ({
          "@type": "Question",
          name: f.question,
          acceptedAnswer: { "@type": "Answer", text: f.answer },
        })),
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* 1. HERO */}
      <Hero />

      {/* 2. CAREER ASSESSMENT */}
      <section
        id="assessment"
        className="scroll-mt-20 border-y border-border bg-brand-soft/40 py-14 sm:py-18"
      >
        <div className="container-sv grid items-center gap-10 lg:grid-cols-[0.8fr_1.2fr]">
          <div>
            <SectionHeading
              label="CAREER ASSESSMENT"
              title="Not sure what to learn?"
              sub="Take our 3-minute career assessment."
            />
            <ul className="mt-6 flex flex-col gap-3">
              {ASSESSMENT_PERKS.map((perk) => (
                <li key={perk.text} className="flex items-center gap-3 text-[14px] font-medium text-ink">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white shadow-soft">
                    <perk.icon className="h-4 w-4 text-brand" aria-hidden />
                  </span>
                  {perk.text}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl border border-border bg-white p-5 shadow-card sm:p-7">
            <CareerAssessment />
          </div>
        </div>
      </section>

      {/* 3. TRUST STRIP */}
      <TrustStrip />

      {/* 4. CAREER PATHS */}
      <Section>
        <SectionHeading
          align="center"
          label="CAREER PATHS"
          title="What do you want to become?"
          sub="Structured, placement-focused programs — pick a destination and we build the road."
        />

        {/* Data & Analytics */}
        {dataTracks.length > 0 && (
          <div className="mt-10">
            <div className="flex items-center gap-2.5">
              <span className="h-2.5 w-2.5 rounded-full bg-brand" aria-hidden />
              <h3 className="text-[17px] font-bold text-ink">Data & Analytics</h3>
            </div>
            <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {dataTracks.map((t) => (
                <CareerPathCard
                  key={t.id}
                  title={t.title}
                  href={`/tracks/${t.slug}`}
                  months={monthsOf(t)}
                  projects={t.projects}
                  liveSessions={t.liveClasses}
                />
              ))}
            </div>
          </div>
        )}

        {/* AI & Technology */}
        {aiTracks.length > 0 && (
          <div className="mt-10">
            <div className="flex items-center gap-2.5">
              <span className="h-2.5 w-2.5 rounded-full bg-gold" aria-hidden />
              <h3 className="text-[17px] font-bold text-ink">AI & Technology</h3>
            </div>
            <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
              {aiTracks.map((t) => (
                <CareerPathCard
                  key={t.id}
                  title={t.title}
                  href={`/tracks/${t.slug}`}
                  months={monthsOf(t)}
                  projects={t.projects}
                  liveSessions={t.liveClasses}
                />
              ))}
            </div>
          </div>
        )}

        {/* SAP — render from DB when present, otherwise elegant "cohorts forming" cards */}
        <div className="mt-10">
          <div className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-accento" aria-hidden />
            <h3 className="text-[17px] font-bold text-ink">SAP</h3>
          </div>
          {sapTracks.length > 0 ? (
            <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {sapTracks.map((t) => (
                <CareerPathCard
                  key={t.id}
                  title={t.title}
                  href={`/tracks/${t.slug}`}
                  months={monthsOf(t)}
                  projects={t.projects}
                  liveSessions={t.liveClasses}
                />
              ))}
            </div>
          ) : (
            <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {["SAP FICO", "SAP MM", "SAP SD"].map((title) => (
                <CareerPathCard
                  key={title}
                  title={title}
                  href="/contact-us"
                  chip="New cohorts forming"
                  chipTone="gold"
                  note="Live-cohort curriculum with SAP mentors. Placement support from day one."
                  ctaLabel="Register Interest"
                />
              ))}
            </div>
          )}
        </div>

        {/* Business & Digital — only when data exists */}
        {businessTracks.length > 0 && (
          <div className="mt-10">
            <div className="flex items-center gap-2.5">
              <span className="h-2.5 w-2.5 rounded-full bg-green-600" aria-hidden />
              <h3 className="text-[17px] font-bold text-ink">Business & Digital</h3>
            </div>
            <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {businessTracks.map((t) => (
                <CareerPathCard
                  key={t.id}
                  title={t.title}
                  href={`/tracks/${t.slug}`}
                  months={monthsOf(t)}
                  projects={t.projects}
                  liveSessions={t.liveClasses}
                />
              ))}
            </div>
          </div>
        )}

        <div className="mt-10 flex justify-center">
          <a
            href="/tracks"
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-brand px-6 text-[14px] font-semibold text-brand transition hover:bg-brand-soft"
          >
            View all career paths
            <span aria-hidden>→</span>
          </a>
        </div>
      </Section>

      {/* 5. WHY SKILLGORILA */}
      <WhyDifferent />

      {/* 6. LMS PREVIEW */}
      <LmsPreview />

      {/* 7. REAL PROJECTS */}
      <ProjectsShowcase />

      {/* 8. MENTORS */}
      <MentorsSectionV2 mentors={mentors} />

      {/* 9. STUDENT SUCCESS */}
      <SuccessSection students={placedStudents} />

      {/* 10. TESTIMONIALS */}
      <TestimonialCarousel testimonials={testimonials} />

      {/* 11. PLACEMENT ENGINE */}
      <PlacementEngine />

      {/* 12. HIRING PARTNERS */}
      <Section className="pt-4">
        <CompanyMarquee
          companies={hiringCompanies.map((c) => ({ id: c.id, name: c.name }))}
          title="SkillGorila talent is hired by 300+ companies"
        />
      </Section>

      {/* 13. CAREER RESOURCES */}
      <CareerResources />

      {/* 14. FAQ */}
      <div id="faq" className="scroll-mt-24">
        <FaqSection
          items={generalFaqs.map((f) => ({ id: f.id, question: f.question, answer: f.answer }))}
        />
      </div>

      {/* 15. FINAL CTA */}
      <CallbackBanner />
    </>
  );
}
