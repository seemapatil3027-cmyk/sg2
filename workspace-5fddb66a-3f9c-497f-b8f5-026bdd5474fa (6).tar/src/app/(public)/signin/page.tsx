"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Loader2, LockKeyhole, ShieldCheck, Zap, Users, GraduationCap, Eye, EyeOff } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { notifyUserChanged, useUser } from "@/hooks/use-user";

/** Unified staff sign-in — students no longer log in to the platform. */
export default function SignInPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, loading, signOut } = useUser();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [signingOut, setSigningOut] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        user?: { role?: string; roleLabel?: string };
      };
      if (!res.ok) {
        setError(data.error ?? "Something went wrong. Please try again.");
        return;
      }
      toast({
        title: "Welcome back! 👋",
        description: `Signed in as ${data.user?.roleLabel ?? "team member"}.`,
      });
      notifyUserChanged();
      const nextParam =
        typeof window !== "undefined"
          ? new URLSearchParams(window.location.search).get("next")
          : null;
      router.push(nextParam || "/dashboard");
      router.refresh();
    } catch {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSignOut() {
    setSigningOut(true);
    try {
      await signOut();
      toast({ title: "Signed out", description: "See you soon! 👋" });
      router.refresh();
    } finally {
      setSigningOut(false);
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center py-10">
        <Loader2 className="h-8 w-8 animate-spin text-brand" aria-label="Loading" />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:py-16">
      <div className="overflow-hidden rounded-3xl border bg-card shadow-xl lg:grid lg:grid-cols-2">
        {/* Visual panel */}
        <div className="relative hidden overflow-hidden bg-gradient-to-br from-[#4a0e9e] via-[#5d18be] to-[#7a1fd8] p-10 text-white lg:flex lg:flex-col lg:justify-between">
          <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" aria-hidden="true" />
          <div className="pointer-events-none absolute -bottom-24 -left-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" aria-hidden="true" />
          <div className="relative">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-white/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-widest backdrop-blur">
              <Zap className="h-3 w-3" /> One connected platform
            </span>
            <h2 className="mt-5 max-w-md text-3xl font-extrabold leading-tight">
              CRM &amp; LMS, finally on the same page.
            </h2>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-white/80">
              Capture leads, run the pipeline, enroll customers and track learning to certificates —
              one team, one workspace, one journey.
            </p>
          </div>

          {/* Product mock — pipeline + learning, hand-built */}
          <div className="relative mt-8 rounded-2xl border border-white/20 bg-white/10 p-3 backdrop-blur" aria-hidden="true">
            <div className="rounded-xl bg-white p-3 shadow-2xl">
              <div className="flex items-center gap-1.5 px-1 pb-2.5">
                <span className="h-2 w-2 rounded-full bg-rose-400" />
                <span className="h-2 w-2 rounded-full bg-amber-400" />
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                <span className="ml-2 h-2.5 w-28 rounded-full bg-muted" />
              </div>
              <div className="flex gap-2.5">
                {/* mini sidebar */}
                <div className="hidden w-14 shrink-0 flex-col gap-1.5 rounded-lg bg-muted/70 p-2 sm:flex">
                  <span className="h-5 w-5 rounded-md bg-brand" />
                  <span className="h-1.5 w-full rounded-full bg-brand/25" />
                  <span className="h-1.5 w-4/5 rounded-full bg-border" />
                  <span className="h-1.5 w-full rounded-full bg-border" />
                  <span className="mt-auto h-5 w-5 rounded-full bg-brand-soft" />
                </div>
                {/* kanban */}
                <div className="grid flex-1 grid-cols-3 gap-2">
                  {[
                    { tone: "bg-slate-300", bars: ["w-4/5", "w-3/5"] },
                    { tone: "bg-sky-400", bars: ["w-3/4", "w-1/2"] },
                    { tone: "bg-emerald-400", bars: ["w-4/6", "w-2/3"] },
                  ].map((col, ci) => (
                    <div key={ci} className="space-y-1.5 rounded-lg bg-muted/60 p-1.5">
                      <span className={`block h-1.5 w-8 rounded-full ${col.tone}`} />
                      {col.bars.map((w, bi) => (
                        <div key={bi} className="rounded-md bg-white p-1.5 shadow-sm">
                          <span className={`block h-1.5 rounded-full bg-border ${w}`} />
                          <span className="mt-1 block h-1.5 w-1/3 rounded-full bg-brand/30" />
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
                {/* learning card */}
                <div className="hidden w-24 shrink-0 flex-col justify-between rounded-lg bg-brand p-2 md:flex">
                  <div className="space-y-1.5">
                    <span className="block h-1.5 w-4/5 rounded-full bg-white/70" />
                    <span className="block h-1.5 w-3/5 rounded-full bg-white/40" />
                  </div>
                  <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full bg-amber-300/90">
                    <GraduationCap className="h-4.5 w-4.5 text-brand-dark" />
                  </div>
                  <div className="h-1 w-full rounded-full bg-white/25">
                    <div className="h-full w-2/3 rounded-full bg-amber-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <ul className="relative mt-8 grid grid-cols-3 gap-3 text-center">
            {[
              { icon: Users, label: "Sales pipeline" },
              { icon: GraduationCap, label: "Learning tracks" },
              { icon: ShieldCheck, label: "Role-based access" },
            ].map((f) => (
              <li key={f.label} className="rounded-2xl border border-white/20 bg-white/10 px-2 py-3 backdrop-blur">
                <f.icon className="mx-auto h-4.5 w-4.5" aria-hidden="true" />
                <p className="mt-1.5 text-[11px] font-semibold leading-tight">{f.label}</p>
              </li>
            ))}
          </ul>
        </div>

        {/* Form panel */}
        <div className="p-6 sm:p-10">
          {user ? (
            <div className="flex h-full min-h-[420px] flex-col items-center justify-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300">
                <ShieldCheck className="h-6 w-6" />
              </span>
              <h1 className="mt-5 text-2xl font-bold">You&apos;re signed in as {user.name} 👋</h1>
              <p className="mt-1 text-sm text-muted-foreground">{user.email}</p>
              <div className="mt-8 flex w-full max-w-xs flex-col gap-3">
                <Link
                  href="/dashboard"
                  className="inline-flex h-12 items-center justify-center rounded-xl bg-primary px-6 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
                >
                  Go to Dashboard
                </Link>
                <button
                  type="button"
                  onClick={handleSignOut}
                  disabled={signingOut}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-border px-6 text-[15px] font-semibold text-ink transition hover:border-brand hover:text-brand disabled:opacity-60 dark:text-foreground"
                >
                  {signingOut && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                  Sign out
                </button>
              </div>
            </div>
          ) : (
            <div className="mx-auto flex max-w-sm flex-col">
              <div className="lg:hidden">
                <div className="flex justify-center">
                  <Logo />
                </div>
              </div>
              <span className="mt-8 hidden h-11 w-11 items-center justify-center rounded-2xl bg-brand-soft text-brand lg:flex dark:bg-brand/15 dark:text-violet-300">
                <LockKeyhole className="h-5 w-5" />
              </span>
              <h1 className="mt-5 text-[26px] font-bold leading-tight text-ink dark:text-foreground">
                Staff sign-in
              </h1>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-soft dark:text-muted-foreground">
                One account for CRM, LMS and administration. Your role decides what you see —
                learner records are managed internally by the team.
              </p>

              <form onSubmit={handleSubmit} className="mt-7 flex flex-col gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email" className="text-[13px] font-semibold">Work email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@skillgorila.com"
                    autoComplete="email"
                    required
                    className="h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password" className="text-[13px] font-semibold">Password</Label>
                  </div>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      autoComplete="current-password"
                      required
                      minLength={6}
                      className="h-12 rounded-xl pr-11"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition hover:text-foreground"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
                    </button>
                  </div>
                </div>

                {error && (
                  <p role="alert" className="rounded-xl bg-rose-50 px-3.5 py-2.5 text-[13px] font-medium leading-snug text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-primary text-[15px] font-semibold text-white transition hover:bg-brand-dark disabled:opacity-60"
                >
                  {submitting && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                  {submitting ? "Signing in…" : "Sign in"}
                </button>
              </form>

              <p className="mt-6 text-center text-xs leading-5 text-ink-soft dark:text-muted-foreground">
                Need an account? Contact your Super Admin — access is provisioned by role.
              </p>
              <div className="mt-4 text-center">
                <Link href="/" className="text-sm font-semibold text-brand transition hover:text-brand-dark">
                  ← Back to website
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
