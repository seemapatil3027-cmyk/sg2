import type { Metadata } from "next";
import { Mail, MapPin, BriefcaseBusiness } from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";
import { LeadForm } from "@/components/shared/lead-form";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { getFaqs } from "@/lib/data";

export const metadata: Metadata = {
  title: "Contact Us",
};

export default async function ContactUsPage() {
  const faqs = await getFaqs("contact");

  return (
    <>
      {/* HERO */}
      <section className="bg-[#EFE9F7]">
        <div className="container-sv py-16 sm:py-20">
          <SectionHeading
            align="center"
            title="Let's get you that dream job!"
            sub="SkilloVilla is always ready to help you. Get in touch with us if you want to learn more."
          />
        </div>
      </section>

      {/* CONTACT GRID */}
      <Section>
        <div className="grid items-start gap-8 lg:grid-cols-2">
          {/* LEFT — lead form card */}
          <div className="rounded-3xl border border-border bg-white p-8 shadow-sm">
            <h3 className="text-xl font-bold text-ink">Contact us</h3>
            <p className="mt-1.5 text-[14.5px] text-ink-soft">We&apos;ll get back to you in the next 24 hours.</p>
            <LeadForm source="contact" className="mt-7" />
          </div>

          {/* RIGHT — info cards stack */}
          <div className="flex flex-col gap-6">
            {/* Contact info */}
            <div className="rounded-3xl border border-border bg-white p-8 shadow-sm">
              <div className="flex flex-col gap-5">
                <div className="flex items-center gap-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft">
                    <Mail className="h-5 w-5 text-brand" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-[13px] text-ink-soft">Student query</p>
                    <a
                      href="mailto:support@skillovilla.com"
                      className="text-[15px] font-semibold text-ink transition hover:text-brand"
                    >
                      support@skillovilla.com
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft">
                    <Mail className="h-5 w-5 text-brand" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-[13px] text-ink-soft">Admission info</p>
                    <a
                      href="mailto:admissions@skillovilla.com"
                      className="text-[15px] font-semibold text-ink transition hover:text-brand"
                    >
                      admissions@skillovilla.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Hire talent */}
            <div className="rounded-3xl border border-border bg-white p-8 shadow-sm">
              <div className="flex items-start gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-accento-soft">
                  <BriefcaseBusiness className="h-5 w-5 text-accento" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-lg font-bold text-ink">Hire only the best talents</h3>
                  <p className="mt-2 text-[14.5px] leading-6 text-ink-soft">
                    We provide fresh talents who are industry ready, the one you&apos;re looking for. Contact us to
                    learn more about SkilloVilla graduates.
                  </p>
                </div>
              </div>
              <div className="mt-6">
                <LeadDialogButton
                  label="Hire Talent"
                  source="hire"
                  dialogTitle="Hire talent"
                  dialogText="Tell us your requirement and our team will reach out."
                />
              </div>
            </div>

            {/* Reach us */}
            <div className="rounded-3xl border border-border bg-white p-8 shadow-sm">
              <h3 className="text-lg font-bold text-ink">Reach Us</h3>
              <div className="mt-4 flex items-start gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft">
                  <MapPin className="h-5 w-5 text-brand" aria-hidden="true" />
                </span>
                <div>
                  <p className="font-semibold text-ink">Our location</p>
                  <p className="mt-1 text-[14.5px] leading-6 text-ink-soft">
                    Find us at 4th Floor, Royaloak Furniture Building, Bannerghatta Road, Anthappa Layout, J.P. Nagar
                    Phase 4, Bengaluru, Karnataka - 560078
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Section>

      <FaqSection items={faqs} title="Any Questions?" />
      <CallbackBanner />
    </>
  );
}
