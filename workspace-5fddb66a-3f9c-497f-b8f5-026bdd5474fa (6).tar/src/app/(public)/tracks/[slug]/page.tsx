import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import {
  BadgeCheck,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  Download,
  FileUser,
  FolderKanban,
  IndianRupee,
  Laptop,
  MapPin,
  MessagesSquare,
  PenTool,
  Target,
  Trophy,
  Users,
  Wrench,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { getCompanies, getFaqs, getMentors, getTrack } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { MasterclassSection } from "@/components/shared/masterclass-section";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { LeadForm } from "@/components/shared/lead-form";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { Logo } from "@/components/layout/logo";
import { SyllabusAccordion } from "@/components/tracks/syllabus-accordion";
import { ProjectsMarquee } from "@/components/tracks/projects-marquee";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const track = await getTrack(slug);
  return {
    title: track?.title ?? "Career Track",
    description: track?.description,
  };
}

const GROWTH_FEATURES: { icon: LucideIcon; title: string }[] = [
  { icon: PenTool, title: "Created by experts" },
  { icon: Wrench, title: "Learn practical skills" },
  { icon: FolderKanban, title: "Hands on projects" },
  { icon: Target, title: "Strategize career move" },
];

const PLACEMENT_STEPS: { icon: LucideIcon; title: string; desc: string }[] = [
  {
    icon: FileUser,
    title: "Create a flawless profile",
    desc: "Build strong resume and social profiles that stand out",
  },
  {
    icon: MessagesSquare,
    title: "Interview preparation",
    desc: "Ace interviews with ease, practice with experts in our mock interviews",
  },
  {
    icon: Trophy,
    title: "Get your dream job",
    desc: "Master the skill and become a pro in your field. The rest is history!",
  },
];

const CERT_POINTS = [
  "Certification recognized in 300+ companies",
  "Prove that your skills are certified to employers",
  "Be a recruiter-magnet in LinkedIn with your certifications",
];

export default async function TrackDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const track = await getTrack(slug);
  if (!track) notFound();

  const [generalFaqs, mentors, hiringCompanies] = await Promise.all([
    getFaqs("general"),
    getMentors(),
    getCompanies("hiring"),
  ]);

  // Data holds e.g. "4K+" and "8L" — normalise so labels never double up ("4K++", "8LL")
  const learnersLabel = track.learners ? `${track.learners.replace(/\+$/, "")}+` : "";
  const pkgLabel = track.packageUpto
    ? track.packageUpto.endsWith("L")
      ? track.packageUpto
      : `${track.packageUpto}L`
    : "";
  const isClassroom = track.mode === "classroom";

  const journey = track.highlights.slice(0, 4);
  const effortCards: { icon: LucideIcon; text: string }[] = [
    { icon: Calendar, text: `${track.weeks} weeks / program` },
    { icon: Clock, text: `${track.hrsPerDay} hrs/day` },
    isClassroom
      ? { icon: MapPin, text: "In-classroom in Bangalore" }
      : { icon: Laptop, text: "No coding experience required" },
  ];

  return (
    <>
      {/* 1. Hero */}
      <section className="bg-[#EFE9F7] py-14">
        <div className="container-sv grid items-center gap-12 lg:grid-cols-2 lg:gap-14">
          <div>
            <h1 className="text-[30px] font-bold leading-tight text-ink sm:text-[40px]">
              {track.title}
            </h1>
            <div className="mt-4 h-1.5 w-14 rounded bg-primary" aria-hidden />
            <p className="mt-5 max-w-xl text-[15px] leading-7 text-ink-soft">{track.description}</p>
            {track.badge && (
              <div className="mt-5 inline-flex items-center rounded-lg bg-white px-4 py-2 shadow-[0_6px_20px_rgba(34,28,51,0.1)]">
                <span className="text-[13.5px] font-semibold text-accento">{track.badge}</span>
              </div>
            )}
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <LeadDialogButton
                label="Enroll Now"
                source="enroll"
                itemSlug={track.slug}
                dialogTitle={`Enroll in ${track.title}`}
                dialogText="Leave your details — our admissions team will call you within 24 hours."
                buttonVariant="outline"
                buttonClassName="sm:flex-1"
              />
              <LeadDialogButton
                label="Try Masterclass"
                source="masterclass"
                itemSlug={track.slug}
                dialogTitle="Try a free masterclass"
                dialogText="Solve a real-life case study, live with the experts."
                icon={<Zap className="mr-2 h-4 w-4" />}
                buttonClassName="sm:flex-1"
              />
            </div>
          </div>
          <div className="relative">
            <Image
              src="/images/track-hero.png"
              alt={`Students mastering ${track.title} at SkilloVilla`}
              width={1024}
              height={1024}
              priority
              className="aspect-[5/4] w-full rounded-3xl object-cover shadow-[0_24px_60px_rgba(34,28,51,0.18)]"
            />
            {/* floating stat chips */}
            <div className="absolute -left-3 top-8 flex animate-float items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-[0_10px_30px_rgba(34,28,51,0.18)] sm:-left-6">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-soft">
                <Users className="h-5 w-5 text-brand" aria-hidden />
              </span>
              <div>
                <p className="text-[18px] font-bold leading-none text-ink">{learnersLabel}</p>
                <p className="mt-1 text-[12px] font-medium text-ink-soft">learners</p>
              </div>
            </div>
            <div className="absolute -right-3 bottom-8 flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-[0_10px_30px_rgba(34,28,51,0.18)] sm:-right-6">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accento-soft">
                <IndianRupee className="h-5 w-5 text-accento" aria-hidden />
              </span>
              <div>
                <p className="text-[18px] font-bold leading-none text-ink">{pkgLabel}</p>
                <p className="mt-1 text-[12px] font-medium text-ink-soft">packages upto</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Stats band */}
      <div className="container-sv relative z-10 -mt-8">
        <div className="rounded-2xl bg-white p-6 shadow-[0_14px_40px_rgba(34,28,51,0.12)] sm:p-7">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-x-10 gap-y-3">
              <p className="flex items-center gap-2 text-[17px] font-bold text-ink">
                <span className="text-2xl" aria-hidden>
                  🔥
                </span>
                <span className="text-brand">{track.jobs}</span> Jobs
              </p>
              <p className="text-[17px] font-bold text-ink">
                <span className="text-brand">{track.companies ?? "300+"}</span> Companies
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-x-7 gap-y-2">
              {hiringCompanies.slice(0, 6).map((c) => (
                <span
                  key={c.id}
                  className="select-none whitespace-nowrap text-[15px] font-semibold text-gray-400"
                >
                  {c.name}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 3. Track overview */}
      <Section>
        <SectionHeading
          label="TRACK OVERVIEW"
          title="Experience the new way of learning"
          sub="Learn in live classes, solve real-life case studies, get mentored by the top 1% experts. Be the talent every recruiter in the industry is looking for!"
        />
        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <div className="rounded-3xl border border-border bg-white p-7">
            <h3 className="text-lg font-bold text-ink">Skills covered</h3>
            <div className="mt-5 flex flex-wrap gap-2.5">
              {track.skills.map((s) => (
                <span
                  key={s}
                  className="rounded-full border border-border px-4 py-2 text-sm font-medium text-ink transition hover:border-brand hover:bg-brand-soft hover:text-brand"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-border bg-white p-7">
            <h3 className="text-lg font-bold text-ink">Outcomes</h3>
            <ul className="mt-5 grid gap-x-6 gap-y-3.5 sm:grid-cols-2">
              {track.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-600" aria-hidden />
                  <span className="text-[14px] leading-6 text-ink">{o}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        {/* Learning effort */}
        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          {effortCards.map(({ icon: Icon, text }) => (
            <div
              key={text}
              className="flex items-center gap-4 rounded-2xl border border-border bg-white p-5"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-soft">
                <Icon className="h-5 w-5 text-brand" aria-hidden />
              </span>
              <p className="text-[15px] font-bold leading-snug text-ink">{text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* 4. Masterclass */}
      <MasterclassSection itemSlug={track.slug} />

      {/* 5. Career growth (purple) */}
      <section className="bg-brand-gradient py-14 sm:py-18">
        <div className="container-sv">
          <p className="section-label mb-6">CAREER GROWTH</p>
          <div className="rounded-3xl bg-white p-7 sm:p-10">
            <h2 className="text-lg font-bold text-ink sm:text-xl">Industry Insights</h2>
            <p className="mt-3 text-[15px] leading-7 text-ink-soft">{track.industryInsight}</p>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {GROWTH_FEATURES.map(({ icon: Icon, title }) => (
              <div
                key={title}
                className="rounded-2xl bg-white/10 p-5 ring-1 ring-white/15 backdrop-blur-sm"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-white">
                  <Icon className="h-5 w-5 text-brand" aria-hidden />
                </span>
                <p className="mt-4 text-[14.5px] font-semibold text-white">{title}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl bg-white/10 p-6 text-center ring-1 ring-white/15">
              <p className="text-[26px] font-bold leading-none text-white">{track.openings}</p>
              <p className="mt-2 text-[13.5px] font-medium text-white/70">Job Openings</p>
            </div>
            <div className="rounded-xl bg-white/10 p-6 text-center ring-1 ring-white/15">
              <p className="text-[26px] font-bold leading-none text-white">{track.avgCtc}</p>
              <p className="mt-2 text-[13.5px] font-medium text-white/70">Average CTC</p>
            </div>
            <div className="rounded-xl bg-white/10 p-6 text-center ring-1 ring-white/15">
              <p className="text-[26px] font-bold leading-none text-white">{track.avgHike}</p>
              <p className="mt-2 text-[13.5px] font-medium text-white/70">Avg YoY hike</p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Learning journey */}
      <Section>
        <SectionHeading
          label="LEARNING JOURNEY"
          title="Learning journey at SkilloVilla"
          sub="Master the skills with short conceptual videos, reading materials and quizzes. Then work on industry projects to build your resume. Undergo mock interviews and land your dream job."
        />
        <div className="relative mt-12 grid gap-10 md:grid-cols-4 md:gap-6">
          <div
            aria-hidden
            className="absolute left-[10%] right-[10%] top-7 hidden border-t-2 border-dashed border-brand/30 md:block"
          />
          {journey.map((h, i) => (
            <div
              key={`${h}-${i}`}
              className="relative flex flex-col items-start gap-4 md:items-center md:text-center"
            >
              <span className="z-10 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-xl font-bold text-white shadow-[0_8px_20px_rgba(93,24,190,0.35)]">
                {i + 1}
              </span>
              <p className="max-w-[250px] text-[14.5px] font-medium leading-6 text-ink">{h}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* 7. Syllabus */}
      <Section id="syllabus">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <SectionHeading label="SYLLABUS" title="SkilloVilla&apos;s world-class curriculum" />
          <a
            href={`/api/brochure?track=${encodeURIComponent(track.slug)}`}
            className="inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-xl border border-brand px-6 text-[15px] font-semibold text-brand transition hover:bg-brand-soft"
          >
            <Download className="h-4 w-4" aria-hidden /> Download syllabus
          </a>
        </div>
        <SyllabusAccordion items={track.syllabus} className="mt-10" />
      </Section>

      {/* 8. Placement assistance */}
      <Section>
        <SectionHeading
          title="SkilloVilla&apos;s placement assistance"
          sub="Our career counselors are ready to help you whenever you need them"
        />
        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_380px]">
          <div className="flex flex-col gap-5">
            {PLACEMENT_STEPS.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="flex items-start gap-5 rounded-2xl border border-border bg-white p-6"
              >
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-brand-soft">
                  <Icon className="h-6 w-6 text-brand" aria-hidden />
                </span>
                <div>
                  <h3 className="text-[16.5px] font-bold text-ink">{title}</h3>
                  <p className="mt-1.5 text-[14px] leading-6 text-ink-soft">{desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="rounded-3xl border border-border bg-white p-7 shadow-[0_14px_40px_rgba(34,28,51,0.08)]">
            <h3 className="text-lg font-bold text-ink">Speak to career counselors</h3>
            <p className="mt-1.5 text-[13.5px] text-ink-soft">Book a session, ask your doubts away</p>
            <LeadForm source="callback" itemSlug={track.slug} submitLabel="Submit" className="mt-6" />
          </div>
        </div>
      </Section>

      {/* 9. Projects & case studies */}
      <Section>
        <SectionHeading
          label="SYLLABUS"
          title="Projects and Case studies"
          sub="Work on industry projects that make your resume stand out."
        />
        <div className="mt-10">
          <ProjectsMarquee projects={track.projectsList} />
        </div>
        <div className="mt-10 text-center">
          <p className="text-xl font-bold text-ink sm:text-2xl">
            {track.projectsList.length * 10}+ Industry relevant Projects
          </p>
          <p className="mt-1 text-[15px] text-ink-soft">Experience to work on best projects.</p>
        </div>
      </Section>

      {/* 10. Certification (purple) */}
      <section className="bg-brand-gradient py-14 sm:py-18">
        <div className="container-sv grid items-center gap-12 lg:grid-cols-2 lg:gap-14">
          <div>
            <SectionHeading dark label="CERTIFICATION" title="Get certified to become a pro!" />
            <ul className="mt-7 flex flex-col gap-4">
              {CERT_POINTS.map((p) => (
                <li key={p} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/15">
                    <ChevronRight className="h-4 w-4 text-gold" aria-hidden />
                  </span>
                  <span className="text-[15px] leading-6 text-white">{p}</span>
                </li>
              ))}
            </ul>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <LeadDialogButton
                label="Contact Us"
                source="contact"
                dialogTitle="Contact us"
                dialogText="We'll get back to you in the next 24 hours."
                buttonVariant="outline"
                buttonClassName="border-white/70 bg-transparent text-white hover:bg-white/10 hover:text-white"
              />
              <LeadDialogButton
                label="Try Masterclass"
                source="masterclass"
                itemSlug={track.slug}
                dialogTitle="Try a free masterclass"
                dialogText="Solve a real-life case study, live with the experts."
                buttonClassName="bg-white text-brand hover:bg-white/90"
              />
            </div>
          </div>
          {/* certificate mockup */}
          <div className="relative mx-auto w-full max-w-md lg:max-w-none">
            <div className="absolute -top-5 right-4 z-10 flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-[0_8px_24px_rgba(0,0,0,0.25)]">
              <BadgeCheck className="h-4 w-4 text-[#F5820D]" aria-hidden />
              <span className="text-[12.5px] font-bold text-ink">NASSCOM Accredited</span>
            </div>
            <div className="rounded-3xl bg-white p-8 shadow-[0_24px_60px_rgba(0,0,0,0.28)] sm:p-10">
              <div className="flex items-center justify-between border-b border-dashed border-border pb-6">
                <Logo />
                <BadgeCheck className="h-9 w-9 text-gold" aria-hidden />
              </div>
              <div className="mt-8 text-center">
                <p className="section-label">Certificate of Completion</p>
                <h3 className="mt-3 text-xl font-bold leading-snug text-ink sm:text-2xl">
                  {track.title}
                </h3>
                <p className="mt-7 text-[12.5px] text-ink-soft">This certifies that</p>
                <p className="mt-2 border-b border-ink/20 pb-2 text-lg font-semibold text-ink-soft">
                  Your Name Here
                </p>
                <p className="mt-1.5 text-[12px] text-ink-soft">
                  has successfully completed the program
                </p>
              </div>
              <div className="mt-9 flex items-end justify-between gap-6 border-t border-dashed border-border pt-6">
                <div>
                  <p className="w-28 border-b border-ink/25 pb-1 text-sm font-semibold italic text-ink">
                    SkilloVilla
                  </p>
                  <p className="mt-1.5 text-[11px] text-ink-soft">Authorized Signature</p>
                </div>
                <div className="text-right">
                  <p className="text-[13px] font-semibold text-ink">www.skillovilla.com</p>
                  <p className="mt-1.5 text-[11px] text-ink-soft">Verify at skillovilla.com/verify</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 11. Mentors */}
      <Section>
        <SectionHeading
          label="MENTORS"
          title={`Learn ${track.title.toLowerCase()} only from the best!`}
          sub="100+ best mentors to solve your doubts"
        />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {mentors.slice(0, 8).map((m) => (
            <div
              key={m.id}
              className="rounded-2xl border border-border bg-white p-6 text-center transition hover:shadow-[0_10px_28px_rgba(34,28,51,0.08)]"
            >
              <InitialAvatar name={m.name} className="mx-auto h-16 w-16 text-lg" />
              <h3 className="mt-4 text-[15.5px] font-bold text-ink">{m.name}</h3>
              <p className="mt-1 text-[13px] font-semibold text-ink">
                {m.role} @ {m.company}
              </p>
              {(m.ex || m.education) && (
                <p className="mt-2 text-[12px] leading-5 text-ink-soft">
                  {[m.ex, m.education].filter(Boolean).join(" · ")}
                </p>
              )}
            </div>
          ))}
        </div>
      </Section>

      {/* 12. FAQs + callback */}
      <FaqSection items={generalFaqs} />
      <CallbackBanner />
    </>
  );
}
