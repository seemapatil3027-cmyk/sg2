import type { Metadata } from "next";
import Image from "next/image";
import { BookOpen, Briefcase, MessagesSquare, Radio } from "lucide-react";
import { getFaqs, getTracks } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { ChevronList, MasterclassSection } from "@/components/shared/masterclass-section";
import { TrackCard } from "@/components/shared/track-card";
import { FaqSection } from "@/components/shared/faq";
import { CallbackBanner } from "@/components/shared/callback-banner";

export const metadata: Metadata = {
  title: "Data Analytics & Data Science Career Tracks",
  description:
    "Explore SkilloVilla career tracks in Data Analytics, Data Science, AI and Software Development. Learn core concepts from experts in live classes, solve real-life case studies and get placed.",
};

const HERO_POINTS = [
  "Learn core concepts from experts in live classes",
  "Get a headstart and kickoff your career",
  "Solve real-life case studies live with experts",
  "Interact with experts and ask your doubts away",
];

const HERO_CHIPS = [
  { icon: BookOpen, label: "Learn" },
  { icon: Radio, label: "Live classes" },
  { icon: MessagesSquare, label: "Interview prep" },
  { icon: Briefcase, label: "Secure a job" },
];

export default async function TracksPage() {
  const [tracks, tracksFaqs] = await Promise.all([getTracks(), getFaqs("tracks")]);

  return (
    <>
      {/* 1. Hero */}
      <section className="bg-[#EFE9F7] py-14">
        <div className="container-sv grid items-center gap-12 lg:grid-cols-2 lg:gap-14">
          <div>
            <SectionHeading
              title="Start your career with SkilloVilla"
              titleClassName="!text-[30px] sm:!text-[40px]"
            />
            <ChevronList items={HERO_POINTS} className="mt-7" />
            <div className="mt-8 flex flex-wrap gap-3">
              {HERO_CHIPS.map(({ icon: Icon, label }) => (
                <span
                  key={label}
                  className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-[13.5px] font-semibold text-ink shadow-[0_4px_14px_rgba(34,28,51,0.08)]"
                >
                  <Icon className="h-4 w-4 text-brand" aria-hidden /> {label}
                </span>
              ))}
            </div>
          </div>
          <div className="relative">
            <Image
              src="/images/classroom.png"
              alt="Students learning together in a live SkilloVilla class"
              width={1344}
              height={768}
              priority
              className="w-full rounded-3xl object-cover shadow-[0_20px_50px_rgba(34,28,51,0.15)]"
            />
            {/* floating chips */}
            <div className="absolute -left-3 top-6 flex animate-float items-center gap-2.5 rounded-2xl bg-white px-4 py-3 shadow-[0_10px_30px_rgba(34,28,51,0.18)] sm:-left-6">
              <span className="relative flex h-2.5 w-2.5" aria-hidden>
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-500" />
              </span>
              <span className="text-[13px] font-bold text-ink">Live classes</span>
            </div>
            <div className="absolute -right-3 bottom-6 flex items-center gap-2.5 rounded-2xl bg-white px-4 py-3 shadow-[0_10px_30px_rgba(34,28,51,0.18)] sm:-right-6">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-soft">
                <MessagesSquare className="h-4 w-4 text-brand" aria-hidden />
              </span>
              <span className="text-[13px] font-bold text-ink">Interview prep</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Career tracks (purple) */}
      <section className="bg-brand-gradient py-14 sm:py-18">
        <div className="container-sv">
          <SectionHeading dark label="CAREER TRACKS" title="Build your career 👔" />
          <div className="mt-12 grid gap-x-8 gap-y-12 lg:grid-cols-2">
            {tracks.map((t) => (
              <TrackCard key={t.id} track={t} />
            ))}
          </div>
        </div>
      </section>

      {/* 3. Masterclass */}
      <MasterclassSection />

      {/* 4. FAQs */}
      <FaqSection
        items={tracksFaqs}
        label="FREQUENTLY ASKED QUESTIONS"
        title="Any further questions?"
      />

      {/* 5. Callback banner */}
      <CallbackBanner />
    </>
  );
}
