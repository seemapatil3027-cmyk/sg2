import type { Metadata } from "next";
import Link from "next/link";
import {
  Target,
  IndianRupee,
  Building2,
  BriefcaseBusiness,
  FileUser,
  MessagesSquare,
  Trophy,
} from "lucide-react";
import { getPlacedStudents, getFaqs } from "@/lib/data";
import { Section, SectionHeading } from "@/components/shared/section";
import { FaqSection } from "@/components/shared/faq";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { StudentBadge } from "@/components/placement/student-badge";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Job Placements At 300+ Partner Hiring Companies",
  description:
    "Upskill, connect and get placed with SkilloVilla's placement assistance program — 95% placement rate, 9 to 30 LPA average salary and 300+ hiring partners.",
};

const STATS = [
  { icon: Target, value: "95%", label: "Placement" },
  { icon: IndianRupee, value: "9 to 30 LPA", label: "Average salary" },
  { icon: Building2, value: "300+", label: "Hiring partners" },
  { icon: BriefcaseBusiness, value: "1150+", label: "Jobs" },
];

const STEPS = [
  {
    icon: FileUser,
    title: "Create a flawless profile",
    text: "Build strong resume and social profiles that stand out",
  },
  {
    icon: MessagesSquare,
    title: "Interview preparation",
    text: "Ace interviews with ease, practice with experts in our mock interviews",
  },
  {
    icon: Trophy,
    title: "Get your dream job",
    text: "Master the skill and become a pro in your field. The rest is history!",
  },
];

export default async function PlacementAssistancePage() {
  const [students, placementFaqs] = await Promise.all([
    getPlacedStudents(),
    getFaqs("placement"),
  ]);

  return (
    <main>
      {/* 1. HERO */}
      <section className="bg-[#EFE9F7] pb-28 pt-14 text-center sm:pb-32 sm:pt-20">
        <div className="container-sv flex flex-col items-center">
          <p className="section-label mb-3">PLACEMENTS</p>
          <h1 className="max-w-3xl text-3xl font-bold leading-tight text-ink sm:text-[44px]">
            Upskill. Connect. Get placed.
          </h1>
          <p className="mt-4 max-w-xl text-[15px] text-ink-soft sm:text-lg">
            Get placed with the help of SkilloVilla&apos;s placement assistance program
          </p>
          <LeadDialogButton
            label="Book a consultation"
            source="callback"
            dialogTitle="Book a consultation"
            dialogText="Our career counsellors will reach out within 24 hours."
            buttonClassName="mt-8"
          />
        </div>
      </section>

      {/* 2. STATS BAND (overlaps hero) */}
      <div className="relative z-10 -mt-16">
        <div className="container-sv">
          <div className="grid grid-cols-2 overflow-hidden rounded-2xl bg-white shadow-[0_16px_40px_rgba(34,28,51,0.12)] lg:grid-cols-4">
            {STATS.map((s, i) => (
              <div
                key={s.label}
                className={cn(
                  "flex flex-col items-center gap-1.5 px-4 py-7 text-center sm:py-9",
                  i % 2 === 1 && "border-l border-border",
                  i >= 2 && "border-t border-border lg:border-t-0",
                  i > 0 && "lg:border-l"
                )}
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft">
                  <s.icon className="h-5 w-5 text-brand" />
                </span>
                <p className="text-2xl font-bold text-ink sm:text-[28px]">{s.value}</p>
                <p className="text-sm text-ink-soft">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 3. STUDENTS SUCCESS */}
      <Section>
        <SectionHeading
          align="center"
          label="STUDENTS SUCCESS"
          title="Our alumni work at their dream companies"
        />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {students.map((s) => (
            <div
              key={s.id}
              className="rounded-2xl border border-border bg-white p-6 transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]"
            >
              <div className="flex items-start gap-4">
                <InitialAvatar name={s.name} className="h-12 w-12 text-base" />
                <div className="min-w-0">
                  <p className="truncate font-bold text-ink">{s.name}</p>
                  <p className="mt-0.5 truncate text-sm font-semibold text-brand">{s.role}</p>
                  <p className="mt-0.5 truncate text-sm text-ink-soft">@ {s.company}</p>
                </div>
                <div className="ml-auto pl-2">
                  <StudentBadge status={s.status} hike={s.hike} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* 4. HOW WE GET YOU PLACED */}
      <Section className="bg-[#FAF8FD]">
        <SectionHeading align="center" label="PLACEMENT PROGRAM" title="How we get you placed" />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {STEPS.map((step, i) => (
            <div
              key={step.title}
              className="rounded-2xl border border-border bg-white p-6 transition-shadow hover:shadow-[0_8px_24px_rgba(34,28,51,0.07)]"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-lg font-bold text-white">
                  {i + 1}
                </span>
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft">
                  <step.icon className="h-5 w-5 text-brand" />
                </span>
              </div>
              <h3 className="mt-5 text-lg font-bold text-ink">{step.title}</h3>
              <p className="mt-2 text-[14px] leading-6 text-ink-soft">{step.text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* 5. CTA BAND */}
      <Section>
        <div className="rounded-3xl bg-brand-gradient px-6 py-12 text-center sm:px-12">
          <h2 className="text-2xl font-bold text-white sm:text-3xl">Ready to get placed? 🚀</h2>
          <p className="mx-auto mt-3 max-w-xl text-[15px] text-[#E7D9FA]">
            Join a career track and unlock the placement program.
          </p>
          <Link
            href="/tracks"
            className="mt-7 inline-flex h-12 items-center justify-center rounded-xl bg-white px-7 text-[15px] font-semibold text-brand shadow-sm transition hover:bg-white/90"
          >
            Explore Tracks
          </Link>
        </div>
      </Section>

      {/* 6. FAQ + CALLBACK */}
      <FaqSection items={placementFaqs} />
      <CallbackBanner />
    </main>
  );
}
