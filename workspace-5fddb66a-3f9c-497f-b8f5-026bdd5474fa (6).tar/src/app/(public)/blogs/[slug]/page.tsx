import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Clock } from "lucide-react";
import { getBlog, formatDate } from "@/lib/data";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { CallbackBanner } from "@/components/shared/callback-banner";

interface BlogDetailProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: BlogDetailProps): Promise<Metadata> {
  const { slug } = await params;
  const blog = await getBlog(slug);
  if (!blog) return { title: "Blog not found — SkilloVilla" };
  return { title: blog.title, description: blog.excerpt };
}

export default async function BlogDetailPage({ params }: BlogDetailProps) {
  const { slug } = await params;
  const blog = await getBlog(slug);
  if (!blog) notFound();

  const paragraphs = blog.content.split("\n\n").filter(Boolean);
  const [firstParagraph, ...restParagraphs] = paragraphs;

  return (
    <>
      <article className="mx-auto w-full max-w-3xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-center gap-3">
          <span className="rounded-full bg-brand-soft px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-brand">
            {blog.category}
          </span>
          <span className="inline-flex items-center gap-1 text-xs text-ink-soft">
            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
            {blog.readTime}
          </span>
        </div>

        <h1 className="mt-4 text-[28px] font-bold leading-tight text-ink sm:text-[34px]">{blog.title}</h1>

        <div className="mt-5 flex items-center gap-3">
          <InitialAvatar name={blog.author} className="h-10 w-10 text-sm" />
          <div>
            <p className="text-sm font-bold text-ink">{blog.author}</p>
            <p className="text-xs text-ink-soft">
              {formatDate(blog.publishedAt)} · {blog.readTime}
            </p>
          </div>
        </div>

        <Image
          src={`/images/blog-cover-${blog.cover}.png`}
          alt={blog.title}
          width={1200}
          height={675}
          priority
          className="mt-6 aspect-[16/9] w-full rounded-2xl object-cover"
        />

        {/* First paragraph rendered larger, outside .blog-prose so utilities win */}
        {firstParagraph && (
          <p className="mt-8 text-[17px] font-medium leading-8 text-ink">{firstParagraph}</p>
        )}
        {restParagraphs.length > 0 && (
          <div className="blog-prose mt-5">
            {restParagraphs.map((paragraph, i) => (
              <p key={i}>{paragraph}</p>
            ))}
          </div>
        )}

        <hr className="my-10 border-border" />

        <div className="flex items-start gap-4 rounded-2xl border bg-white p-6">
          <InitialAvatar name={blog.author} className="h-12 w-12 text-base" />
          <div>
            <p className="font-bold text-ink">Written by {blog.author}</p>
            <p className="mt-1 text-sm leading-6 text-ink-soft">
              Data careers, taught live. We train young graduates and working professionals to land
              their dream jobs in data.
            </p>
          </div>
        </div>

        <div className="bg-brand-gradient mt-10 rounded-2xl p-6 text-center sm:p-10">
          <h2 className="text-xl font-bold text-white sm:text-2xl">Ready to start your data career?</h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-white/80">
            Join live classes, build real projects and get placement support from the SkilloVilla team.
          </p>
          <Link
            href="/tracks"
            className="mt-5 inline-flex h-12 items-center justify-center rounded-lg bg-white px-7 text-[15px] font-semibold text-brand transition hover:bg-brand-soft"
          >
            Explore Tracks
          </Link>
        </div>

        <div className="mt-8">
          <Link
            href="/blogs"
            className="text-sm font-semibold text-brand transition hover:text-brand-dark"
          >
            ← Back to Blogs
          </Link>
        </div>
      </article>

      <CallbackBanner />
    </>
  );
}
