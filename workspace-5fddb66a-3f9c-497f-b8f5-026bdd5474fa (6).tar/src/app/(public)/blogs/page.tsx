import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Clock } from "lucide-react";
import { getBlogs, formatDate, type BlogSummary } from "@/lib/data";
import { SectionHeading } from "@/components/shared/section";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { CallbackBanner } from "@/components/shared/callback-banner";
import { BlogsPagination } from "@/components/blogs/pagination";

export const metadata: Metadata = {
  title: "Blogs — Data careers, taught live",
  description:
    "Guides, comparisons and honest advice on building a career in data — written by the SkilloVilla team.",
};

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

function parsePage(raw: string | string[] | undefined): number {
  const value = Array.isArray(raw) ? raw[0] : raw;
  const parsed = parseInt(value ?? "1", 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
}

export default async function BlogsPage({ searchParams }: { searchParams: SearchParams }) {
  const { page } = await searchParams;
  const currentPage = parsePage(page);
  const { items, totalPages } = await getBlogs(currentPage, 9);

  return (
    <>
      {/* Hero band */}
      <section className="bg-[#EFE9F7]">
        <div className="container-sv py-14 text-center sm:py-16">
          <SectionHeading
            align="center"
            label="Blogs"
            title="Data careers, taught live"
            sub="Guides, comparisons and honest advice on building a career in data — written by the SkilloVilla team."
          />
        </div>
      </section>

      {/* Blog grid */}
      <section className="py-12 sm:py-14">
        <div className="container-sv">
          {items.length === 0 ? (
            <p className="py-16 text-center text-[15px] text-ink-soft">
              No blog posts published yet. Check back soon! ✍️
            </p>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {items.map((blog) => (
                <BlogCard key={blog.slug} blog={blog} />
              ))}
            </div>
          )}

          {totalPages > 1 && (
            <div className="mt-10">
              <BlogsPagination currentPage={currentPage} totalPages={totalPages} />
            </div>
          )}
        </div>
      </section>

      <CallbackBanner />
    </>
  );
}

function BlogCard({ blog }: { blog: BlogSummary }) {
  return (
    <Link
      href={`/blogs/${blog.slug}`}
      className="group flex flex-col overflow-hidden rounded-2xl border bg-white transition hover:shadow-lg"
    >
      <Image
        src={`/images/blog-cover-${blog.cover}.png`}
        alt={blog.title}
        width={640}
        height={360}
        className="aspect-[16/9] w-full object-cover"
      />
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-brand-soft px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-brand">
            {blog.category}
          </span>
          <span className="inline-flex items-center gap-1 text-xs text-ink-soft">
            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
            {blog.readTime}
          </span>
        </div>
        <h3 className="clamp-2 mt-3 text-[17px] font-bold leading-snug text-ink transition group-hover:text-brand">
          {blog.title}
        </h3>
        <p className="clamp-3 mb-4 mt-2 text-sm leading-6 text-ink-soft">{blog.excerpt}</p>
        <div className="mt-auto flex items-center gap-2.5 border-t border-border pt-4">
          <InitialAvatar name={blog.author} className="h-7 w-7 text-[11px]" />
          <p className="min-w-0 truncate text-[13px] font-semibold text-ink">{blog.author}</p>
          <span className="ml-auto shrink-0 text-xs text-ink-soft">{formatDate(blog.publishedAt)}</span>
        </div>
      </div>
    </Link>
  );
}
