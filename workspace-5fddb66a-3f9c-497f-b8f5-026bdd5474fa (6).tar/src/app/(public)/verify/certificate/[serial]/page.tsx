import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/lib/db";
import { BadgeCheck, CircleX, GraduationCap } from "lucide-react";

export const metadata: Metadata = {
  title: "Verify certificate",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

/** Public certificate verification — employers can confirm authenticity. */
export default async function VerifyCertificatePage({
  params,
}: {
  params: Promise<{ serial: string }>;
}) {
  const { serial: raw } = await params;
  const serial = decodeURIComponent(raw).trim().toUpperCase();

  let cert: {
    serial: string;
    learnerName: string;
    courseTitle: string;
    grade: string | null;
    issuedAt: Date;
  } | null = null;
  try {
    cert = await db.certificate.findUnique({
      where: { serial },
      select: { serial: true, learnerName: true, courseTitle: true, grade: true, issuedAt: true },
    });
  } catch {
    cert = null;
  }

  return (
    <div className="mx-auto flex min-h-[70vh] w-full max-w-xl flex-col items-center justify-center px-4 py-12">
      {cert ? (
        <div className="w-full overflow-hidden rounded-3xl border-2 border-emerald-200 bg-card shadow-xl dark:border-emerald-500/30">
          <div className="bg-gradient-to-br from-[#4a0e9e] via-[#5d18be] to-[#7a1fd8] px-8 py-6 text-center text-white">
            <GraduationCap className="mx-auto h-9 w-9" aria-hidden="true" />
            <h1 className="mt-2 text-lg font-extrabold tracking-tight">
              Skill<span className="text-amber-300">Gorila</span>
            </h1>
            <p className="text-xs font-medium uppercase tracking-widest text-white/70">
              Certificate of Completion
            </p>
          </div>
          <div className="px-8 py-8 text-center">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
              <BadgeCheck className="h-4 w-4" aria-hidden="true" /> Authentic certificate
            </span>
            <p className="mt-6 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Awarded to
            </p>
            <p className="mt-1 text-2xl font-extrabold tracking-tight text-ink dark:text-foreground">
              {cert.learnerName}
            </p>
            <p className="mt-5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              For successfully completing
            </p>
            <p className="mt-1 text-lg font-bold text-brand">{cert.courseTitle}</p>
            {cert.grade ? (
              <p className="mt-2 inline-flex items-center gap-1 rounded-lg bg-brand-soft px-2.5 py-1 text-xs font-bold text-brand dark:bg-brand/15 dark:text-violet-300">
                Grade {cert.grade}
              </p>
            ) : null}
            <dl className="mx-auto mt-7 grid max-w-sm grid-cols-2 gap-3 text-left text-xs">
              <div className="rounded-xl bg-muted/60 px-3 py-2.5">
                <dt className="font-medium text-muted-foreground">Serial</dt>
                <dd className="mt-0.5 font-mono font-semibold">{cert.serial}</dd>
              </div>
              <div className="rounded-xl bg-muted/60 px-3 py-2.5">
                <dt className="font-medium text-muted-foreground">Issued on</dt>
                <dd className="mt-0.5 font-semibold">
                  {new Date(cert.issuedAt).toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </dd>
              </div>
            </dl>
          </div>
        </div>
      ) : (
        <div className="w-full rounded-3xl border bg-card p-10 text-center shadow-lg">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
            <CircleX className="h-6 w-6" aria-hidden="true" />
          </div>
          <h1 className="mt-4 text-xl font-bold">Certificate not found</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            No certificate exists with serial{" "}
            <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{serial}</code>. Check
            the serial and try again — valid serials look like{" "}
            <span className="font-mono text-xs">SG-CERT-2026-000001</span>.
          </p>
        </div>
      )}
      <Link href="/" className="mt-8 text-sm font-semibold text-brand transition hover:text-brand-dark">
        ← Back to skillgorila.com
      </Link>
    </div>
  );
}
