import Link from "next/link";
import { TriangleAlert } from "lucide-react";
import { Section } from "@/components/shared/section";

export default function NotFound() {
  return (
    <Section>
      <div className="mt-10 flex flex-col items-center py-10 text-center">
        {/* Big 404 graphic */}
        <div className="relative" aria-hidden="true">
          <span className="select-none bg-gradient-to-r from-brand via-brand-light to-accento bg-clip-text text-[120px] font-black leading-none tracking-tight text-transparent">
            404
          </span>
          <TriangleAlert
            className="absolute -right-9 -top-1 h-14 w-14 rotate-12 text-accento drop-shadow-sm"
            strokeWidth={2.2}
          />
        </div>

        <p className="mt-8 text-lg font-bold text-brand">404</p>
        <h1 className="mt-2 max-w-xl text-xl font-semibold leading-relaxed text-ink sm:text-2xl">
          Looks like our team needs to take a class on finding our own pages
        </h1>

        <Link
          href="/"
          className="mt-8 inline-flex h-12 items-center justify-center rounded-lg bg-primary px-8 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
        >
          Back to home
        </Link>
      </div>
    </Section>
  );
}
