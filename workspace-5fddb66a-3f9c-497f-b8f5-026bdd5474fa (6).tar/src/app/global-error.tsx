"use client";

import { useEffect } from "react";
import "@/app/globals.css";
import { TriangleAlert, RefreshCcw } from "lucide-react";

/**
 * Root-level error boundary — catches failures thrown by the root layout
 * itself. It renders its own <html>/<body>, so it must be fully self-contained.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[global-error]", error);
  }, [error]);

  return (
    <html lang="en">
      <body className="bg-brand-soft">
        <main className="flex min-h-screen items-center justify-center px-4">
          <section className="w-full max-w-lg rounded-[2rem] border border-brand/10 bg-white p-8 text-center shadow-elevate">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-gradient text-white shadow-card">
              <TriangleAlert className="h-8 w-8" aria-hidden />
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight text-ink">
              Application error
            </h1>
            <p className="mt-3 leading-7 text-ink-soft">
              A server-side issue interrupted the application. Please try again.
            </p>
            {error?.digest ? (
              <p className="mt-4 inline-block rounded-full bg-muted px-4 py-1.5 font-mono text-xs text-ink-soft">
                Error ID: {error.digest}
              </p>
            ) : null}
            <div className="mt-8">
              <button
                type="button"
                onClick={reset}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-brand-gradient px-6 font-semibold text-white shadow-card transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
              >
                <RefreshCcw className="h-4 w-4" aria-hidden />
                Try again
              </button>
            </div>
          </section>
        </main>
      </body>
    </html>
  );
}
