import { NextResponse } from "next/server";
import { getMentors } from "@/lib/data";

export async function GET() {
  const mentors = await getMentors();
  return NextResponse.json({ mentors });
}
