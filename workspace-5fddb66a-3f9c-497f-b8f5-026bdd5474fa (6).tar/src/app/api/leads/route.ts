import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeLeadScore } from "@/lib/assessment";

const ALLOWED_SOURCES = ["contact", "callback", "brochure", "masterclass", "enroll", "hire", "newsletter", "assessment"];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = (body.name || "").toString().trim();
    const phone = (body.phone || "").toString().trim();
    const email = (body.email || "").toString().trim();
    const source = (body.source || "contact").toString();
    const note = (body.note || "").toString() || null;
    const itemSlug = (body.itemSlug || "").toString() || null;

    if (!name || name.length < 2) {
      return NextResponse.json({ error: "Please enter your name" }, { status: 400 });
    }
    if (!/^[+]?[\d\s-]{8,15}$/.test(phone)) {
      return NextResponse.json({ error: "Please enter a valid mobile number" }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Please enter a valid email ID" }, { status: 400 });
    }
    if (!ALLOWED_SOURCES.includes(source)) {
      return NextResponse.json({ error: "Invalid source" }, { status: 400 });
    }

    // Assessment leads: embed structured CRM data (recomputed lead score + recommended
    // track) INSIDE the existing note string — never in dedicated DB columns.
    let finalNote = note;
    if (source === "assessment") {
      const leadScore = computeLeadScore({ name, phone, email, source, itemSlug, note });
      const parts = [`leadScore:${leadScore}`];
      if (itemSlug && !(note || "").includes(`recommended:${itemSlug}`)) {
        parts.push(`recommended:${itemSlug}`);
      }
      finalNote = [...parts, ...(note ? [note] : [])].join(" | ");
    }

    const lead = await db.lead.create({
      data: { name, phone, email, source, note: finalNote, itemSlug },
    });

    return NextResponse.json({
      ok: true,
      id: lead.id,
      message:
        source === "callback"
          ? "Request received! Our academic counsellors will call you back within 24 hours."
          : source === "assessment"
            ? "Assessment complete! Your personalised career path is ready."
            : "Thank you! Our experts will get back to you within 24 hrs.",
      // Lets the assessment widget link the user onward to the recommended track.
      ...(itemSlug ? { recommended: itemSlug } : {}),
    });
  } catch (e) {
    console.error("Lead create failed", e);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}
