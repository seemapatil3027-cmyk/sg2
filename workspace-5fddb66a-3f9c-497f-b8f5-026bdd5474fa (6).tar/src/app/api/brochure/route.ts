import { NextRequest, NextResponse } from "next/server";
import { getTrack } from "@/lib/data";
import { buildTrackBrochure } from "@/lib/pdf";

export async function GET(req: NextRequest) {
  const slug = req.nextUrl.searchParams.get("track");
  if (!slug) {
    return NextResponse.json({ error: "track query param required" }, { status: 400 });
  }
  const track = await getTrack(slug);
  if (!track) {
    return NextResponse.json({ error: "Track not found" }, { status: 404 });
  }
  const pdf = buildTrackBrochure({
    title: track.title,
    description: track.description,
    weeks: track.weeks,
    liveClasses: track.liveClasses,
    projects: track.projects,
    hrPerWeek: track.hrPerWeek,
    skills: track.skills,
    syllabus: track.syllabus,
    outcomes: track.outcomes,
  });
  return new NextResponse(new Uint8Array(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="SkilloVilla-${track.slug}-brochure.pdf"`,
    },
  });
}
