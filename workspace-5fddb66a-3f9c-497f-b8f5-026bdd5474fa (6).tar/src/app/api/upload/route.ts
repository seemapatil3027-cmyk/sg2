import { NextRequest } from "next/server";
import { auth, ok, fail, unauthorized } from "@/lib/api-helpers";
import fs from "fs";
import path from "path";
import crypto from "crypto";

const ALLOWED: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/svg+xml": "svg",
  "application/pdf": "pdf",
};
const MAX_BYTES = 5 * 1024 * 1024; // 5 MB

/** File upload — course thumbnails, lesson documents, submission attachments. */
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return unauthorized();

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) return fail("Attach a file in the 'file' field.", 422);

  const ext = ALLOWED[file.type];
  if (!ext) return fail("Unsupported file type. Allowed: PNG, JPEG, WebP, SVG, PDF.", 422);
  if (file.size > MAX_BYTES) return fail("File too large — 5 MB maximum.", 422);

  const now = new Date();
  const folder = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const dir = path.join(process.cwd(), "public", "uploads", folder);
  fs.mkdirSync(dir, { recursive: true });

  const name = `${crypto.randomUUID()}.${ext}`;
  const bytes = Buffer.from(await file.arrayBuffer());
  fs.writeFileSync(path.join(dir, name), bytes);

  return ok({ url: `/uploads/${folder}/${name}`, size: file.size, type: file.type });
}
