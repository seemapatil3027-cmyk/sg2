import { NextResponse } from "next/server";
import { getPlacedStudents } from "@/lib/data";

export async function GET() {
  const students = await getPlacedStudents();
  return NextResponse.json({ students });
}
