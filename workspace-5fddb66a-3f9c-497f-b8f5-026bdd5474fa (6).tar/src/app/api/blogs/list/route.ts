import { NextRequest, NextResponse } from "next/server";
import { getBlogs } from "@/lib/data";

export async function GET(req: NextRequest) {
  const page = parseInt(req.nextUrl.searchParams.get("page") || "1", 10) || 1;
  const pageSize = parseInt(req.nextUrl.searchParams.get("pageSize") || "8", 10) || 8;
  const data = await getBlogs(page, pageSize);
  return NextResponse.json(data);
}
