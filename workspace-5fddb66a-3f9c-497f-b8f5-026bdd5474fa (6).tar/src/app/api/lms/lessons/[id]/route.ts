import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().trim().min(1).max(160).optional(),
  type: z.enum(["VIDEO", "DOCUMENT", "QUIZ", "ASSIGNMENT"]).optional(),
  url: z.string().trim().max(500).nullable().optional(),
  body: z.string().max(8000).nullable().optional(),
  durationMin: z.coerce.number().int().min(0).max(600).optional(),
  isPreview: z.boolean().optional(),
  order: z.coerce.number().int().min(0).optional(),
});

async function lessonWithCourse(id: string) {
  const lesson = await db.lesson.findUnique({ where: { id } });
  if (!lesson) return null;
  const mod = await db.module.findUnique({
    where: { id: lesson.moduleId },
    select: { courseId: true },
  });
  if (!mod) return null;
  return { lesson, courseId: mod.courseId };
}

/** PATCH /api/lms/lessons/:id — edit lesson fields. */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const found = await lessonWithCourse(id);
  if (!found) return fail("Lesson not found.", 404);
  if (!(await ownsCourse(g.guard.session, found.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const lesson = await db.lesson.update({
    where: { id },
    data: {
      ...(d.title !== undefined ? { title: d.title } : {}),
      ...(d.type !== undefined ? { type: d.type } : {}),
      ...(d.url !== undefined ? { url: d.url || null } : {}),
      ...(d.body !== undefined ? { body: d.body || null } : {}),
      ...(d.durationMin !== undefined ? { durationMin: d.durationMin } : {}),
      ...(d.isPreview !== undefined ? { isPreview: d.isPreview } : {}),
      ...(d.order !== undefined ? { order: d.order } : {}),
    },
  });
  return ok(lesson);
}

/** DELETE /api/lms/lessons/:id — removes the lesson, its quiz/assignment, progress rows. */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const found = await lessonWithCourse(id);
  if (!found) return fail("Lesson not found.", 404);
  if (!(await ownsCourse(g.guard.session, found.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const quizzes = await db.quiz.findMany({ where: { lessonId: id }, select: { id: true } });
  const quizIds = quizzes.map((q) => q.id);
  const assignments = await db.assignment.findMany({ where: { lessonId: id }, select: { id: true } });
  const assignmentIds = assignments.map((a) => a.id);

  await db.$transaction([
    db.quizQuestion.deleteMany({ where: { quizId: { in: quizIds } } }),
    db.quizAttempt.deleteMany({ where: { quizId: { in: quizIds } } }),
    db.quiz.deleteMany({ where: { lessonId: id } }),
    db.assignmentSubmission.deleteMany({ where: { assignmentId: { in: assignmentIds } } }),
    db.assignment.deleteMany({ where: { lessonId: id } }),
    db.lessonProgress.deleteMany({ where: { lessonId: id } }),
    db.lesson.delete({ where: { id } }),
  ]);

  return ok({ deleted: true });
}
