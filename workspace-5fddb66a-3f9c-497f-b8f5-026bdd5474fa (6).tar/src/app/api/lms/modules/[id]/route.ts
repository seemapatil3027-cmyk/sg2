import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().trim().min(1).max(120).optional(),
  description: z.string().trim().max(500).nullable().optional(),
  order: z.coerce.number().int().min(0).optional(),
});

async function moduleWithCourse(id: string) {
  const mod = await db.module.findUnique({ where: { id } });
  if (!mod) return null;
  const course = await db.course.findUnique({
    where: { id: mod.courseId },
    select: { id: true, ownerId: true },
  });
  return mod && course ? { module: mod, course } : null;
}

/** PATCH /api/lms/modules/:id — rename / re-describe / reorder. */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const found = await moduleWithCourse(id);
  if (!found) return fail("Module not found.", 404);
  if (!(await ownsCourse(g.guard.session, found.course.id))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const mod = await db.module.update({
    where: { id },
    data: {
      ...(d.title !== undefined ? { title: d.title } : {}),
      ...(d.description !== undefined ? { description: d.description || null } : {}),
      ...(d.order !== undefined ? { order: d.order } : {}),
    },
  });
  return ok(mod);
}

/** DELETE /api/lms/modules/:id — cascades lessons + their quizzes/questions/assignments. */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const found = await moduleWithCourse(id);
  if (!found) return fail("Module not found.", 404);
  if (!(await ownsCourse(g.guard.session, found.course.id))) {
    return fail("You can only manage your own courses.", 403);
  }

  const lessons = await db.lesson.findMany({ where: { moduleId: id }, select: { id: true } });
  const lessonIds = lessons.map((l) => l.id);
  const assignments = lessonIds.length
    ? await db.assignment.findMany({ where: { lessonId: { in: lessonIds } }, select: { id: true } })
    : [];
  const assignmentIds = assignments.map((a) => a.id);
  const quizzes = lessonIds.length
    ? await db.quiz.findMany({ where: { lessonId: { in: lessonIds } }, select: { id: true } })
    : [];
  const quizIds = quizzes.map((q) => q.id);

  await db.$transaction([
    db.quizQuestion.deleteMany({ where: { quizId: { in: quizIds } } }),
    db.quizAttempt.deleteMany({ where: { quizId: { in: quizIds } } }),
    db.quiz.deleteMany({ where: { lessonId: { in: lessonIds } } }),
    db.assignmentSubmission.deleteMany({ where: { assignmentId: { in: assignmentIds } } }),
    db.assignment.deleteMany({ where: { lessonId: { in: lessonIds } } }),
    db.lessonProgress.deleteMany({ where: { lessonId: { in: lessonIds } } }),
    db.lesson.deleteMany({ where: { moduleId: id } }),
    db.module.delete({ where: { id } }),
  ]);

  return ok({ deleted: true });
}
