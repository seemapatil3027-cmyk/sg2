import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const createSchema = z.object({
  title: z.string().trim().min(1, "Lesson title is required").max(160),
  type: z.enum(["VIDEO", "DOCUMENT", "QUIZ", "ASSIGNMENT"]),
  url: z.string().trim().max(500).optional().nullable(),
  body: z.string().max(8000).optional().nullable(),
  durationMin: z.coerce.number().int().min(0).max(600).optional(),
  isPreview: z.boolean().optional(),
});

/** POST /api/lms/modules/:id/lessons — add a lesson (order = max + 1). */
export async function POST(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;

  const mod = await db.module.findUnique({ where: { id } });
  if (!mod) return fail("Module not found.", 404);
  if (!(await ownsCourse(g.guard.session, mod.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;

  const max = await db.lesson.aggregate({ where: { moduleId: id }, _max: { order: true } });
  const lesson = await db.lesson.create({
    data: {
      moduleId: id,
      title: parsed.data.title,
      type: parsed.data.type,
      url: parsed.data.url || null,
      body: parsed.data.body || null,
      durationMin: parsed.data.durationMin ?? 10,
      isPreview: parsed.data.isPreview ?? false,
      order: (max._max.order ?? 0) + 1,
    },
  });
  return ok(lesson, 201);
}
