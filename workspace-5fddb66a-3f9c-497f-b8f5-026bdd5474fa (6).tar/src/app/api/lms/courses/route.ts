import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit, guard, ok, paginated, pageParams, parseBody } from "@/lib/api-helpers";
import { courseScope, slugify, uniqueSlug } from "@/lib/lms-server";

const createSchema = z.object({
  title: z.string().trim().min(3, "Title must be at least 3 characters").max(120),
  description: z.string().trim().min(1, "Description is required").max(2000),
  level: z.string().trim().max(40).optional(),
  weeks: z.coerce.number().int().min(1).max(52).optional(),
  hrsPerDay: z.coerce.number().int().min(1).max(12).optional(),
  prerequisite: z.string().trim().max(200).optional().nullable(),
  icon: z.string().trim().max(40).optional(),
  categoryId: z.string().trim().optional().nullable(),
  thumbnail: z.string().trim().optional().nullable(),
  ownerId: z.string().trim().optional(),
});

/** GET /api/lms/courses — list (filters: q/status/categoryId) or ?basic=1 picker feed. */
export async function GET(req: NextRequest) {
  const g = await guard("lms.courses.view");
  if (g.response) return g.response;
  const p = pageParams(req, 100);
  const sp = p.searchParams;

  if (sp.get("basic")) {
    const courses = await db.course.findMany({
      where: courseScope(g.guard.session),
      select: { id: true, title: true, slug: true },
      orderBy: { title: "asc" },
    });
    return ok(courses);
  }

  const where: Record<string, unknown> = { ...courseScope(g.guard.session) };
  const status = sp.get("status");
  if (status && status !== "ALL") where.status = status;
  const categoryId = sp.get("categoryId");
  if (categoryId && categoryId !== "ALL") where.categoryId = categoryId;
  if (p.q) where.title = { contains: p.q };

  const [total, courses] = await Promise.all([
    db.course.count({ where }),
    db.course.findMany({ where, orderBy: { createdAt: "desc" }, skip: p.skip, take: p.pageSize }),
  ]);

  const ids = courses.map((c) => c.id);
  const modules = await db.module.findMany({ where: { courseId: { in: ids } }, select: { id: true, courseId: true } });
  const [lessons, enrollRows, ownerRows, categoryRows] = await Promise.all([
    modules.length
      ? db.lesson.findMany({
          where: { moduleId: { in: modules.map((m) => m.id) } },
          select: { moduleId: true },
        })
      : Promise.resolve([] as { moduleId: string }[]),
    ids.length
      ? db.enrollment.findMany({ where: { courseId: { in: ids } }, select: { courseId: true } })
      : Promise.resolve([] as { courseId: string | null }[]),
    db.user.findMany({
      where: { id: { in: courses.map((c) => c.ownerId).filter((v): v is string => Boolean(v)) } },
      select: { id: true, name: true },
    }),
    db.courseCategory.findMany({
      where: { id: { in: courses.map((c) => c.categoryId).filter((v): v is string => Boolean(v)) } },
      select: { id: true, name: true, color: true },
    }),
  ]);

  const lessonsByModule = new Map<string, number>();
  for (const l of lessons) lessonsByModule.set(l.moduleId, (lessonsByModule.get(l.moduleId) ?? 0) + 1);
  const moduleCount = new Map<string, number>();
  for (const m of modules) moduleCount.set(m.courseId, (moduleCount.get(m.courseId) ?? 0) + 1);
  const enrollmentCount = new Map<string, number>();
  for (const e of enrollRows) {
    if (e.courseId) enrollmentCount.set(e.courseId, (enrollmentCount.get(e.courseId) ?? 0) + 1);
  }
  const ownerName = new Map(ownerRows.map((u) => [u.id, u.name]));
  const categoryMap = new Map(categoryRows.map((c) => [c.id, c]));

  const items = courses.map((c) => ({
    id: c.id,
    slug: c.slug,
    title: c.title,
    description: c.description,
    status: c.status,
    level: c.level,
    weeks: c.weeks,
    hrsPerDay: c.hrsPerDay,
    icon: c.icon,
    thumbnail: c.thumbnail,
    prerequisite: c.prerequisite,
    ownerId: c.ownerId,
    categoryId: c.categoryId,
    createdAt: c.createdAt,
    updatedAt: c.updatedAt,
    ownerName: c.ownerId ? ownerName.get(c.ownerId) ?? null : null,
    categoryName: c.categoryId ? categoryMap.get(c.categoryId)?.name ?? null : null,
    categoryColor: c.categoryId ? categoryMap.get(c.categoryId)?.color ?? null : null,
    moduleCount: moduleCount.get(c.id) ?? 0,
    lessonCount: modules
      .filter((m) => m.courseId === c.id)
      .reduce((sum, m) => sum + (lessonsByModule.get(m.id) ?? 0), 0),
    enrollmentCount: enrollmentCount.get(c.id) ?? 0,
  }));

  return ok(paginated(items, total, p));
}

/** POST /api/lms/courses — create a course (defaults to DRAFT, owner = creator). */
export async function POST(req: NextRequest) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const slug = await uniqueSlug(slugify(d.title));
  const course = await db.course.create({
    data: {
      slug,
      title: d.title,
      description: d.description,
      level: d.level ?? "Beginner Level",
      weeks: d.weeks ?? 8,
      hrsPerDay: d.hrsPerDay ?? 2,
      prerequisite: d.prerequisite || "No prior experience required",
      icon: d.icon || "BookOpen",
      categoryId: d.categoryId || null,
      thumbnail: d.thumbnail || null,
      ownerId: d.ownerId || g.guard.session.uid,
      status: "DRAFT", // public site lists PUBLISHED only — new courses start hidden
      skills: "[]",
      highlights: "[]",
      chapters: "[]",
      learners: "0",
      rating: "New",
    },
  });

  await audit(g.guard.session, "course.create", "course", course.id, `Created course "${course.title}" (draft)`);
  return ok(course, 201);
}
