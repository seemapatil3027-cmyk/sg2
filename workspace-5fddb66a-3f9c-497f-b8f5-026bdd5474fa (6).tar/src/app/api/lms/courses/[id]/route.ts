import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit, fail, guard, notifyPermission, ok, parseBody } from "@/lib/api-helpers";
import { isInstructor, ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().trim().min(3).max(120).optional(),
  description: z.string().trim().min(1).max(2000).optional(),
  level: z.string().trim().max(40).optional(),
  weeks: z.coerce.number().int().min(1).max(52).optional(),
  hrsPerDay: z.coerce.number().int().min(1).max(12).optional(),
  prerequisite: z.string().trim().max(200).nullable().optional(),
  icon: z.string().trim().max(40).optional(),
  categoryId: z.string().trim().nullable().optional(),
  thumbnail: z.string().trim().nullable().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).optional(),
});

/** GET /api/lms/courses/:id — full course detail for the Course Builder. */
export async function GET(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.view");
  if (g.response) return g.response;
  const { id } = await ctx.params;

  const course = await db.course.findUnique({ where: { id } });
  if (!course) return fail("Course not found.", 404);
  if (isInstructor(g.guard.session) && course.ownerId !== g.guard.session.uid) {
    return fail("You can only view your own courses.", 403);
  }

  const [category, owner, modules, quizzes, assignments, enrollRows] = await Promise.all([
    course.categoryId
      ? db.courseCategory.findUnique({ where: { id: course.categoryId } })
      : Promise.resolve(null),
    course.ownerId
      ? db.user.findUnique({ where: { id: course.ownerId }, select: { id: true, name: true, email: true } })
      : Promise.resolve(null),
    db.module.findMany({ where: { courseId: id }, orderBy: { order: "asc" } }),
    db.quiz.findMany({ where: { courseId: id }, orderBy: { createdAt: "asc" } }),
    db.assignment.findMany({ where: { courseId: id }, orderBy: { createdAt: "asc" } }),
    db.enrollment.findMany({ where: { courseId: id }, select: { id: true, status: true, progress: true } }),
  ]);

  const moduleIds = modules.map((m) => m.id);
  const [lessons, questionCounts] = await Promise.all([
    moduleIds.length
      ? db.lesson.findMany({ where: { moduleId: { in: moduleIds } }, orderBy: { order: "asc" } })
      : Promise.resolve([]),
    quizzes.length
      ? db.quizQuestion.groupBy({ by: ["quizId"], where: { quizId: { in: quizzes.map((q) => q.id) } }, _count: true })
      : Promise.resolve([] as { quizId: string; _count: number }[]),
  ]);
  const qCount = new Map(questionCounts.map((r) => [r.quizId, r._count]));

  const avgProgress = enrollRows.length
    ? Math.round(enrollRows.reduce((s, e) => s + e.progress, 0) / enrollRows.length)
    : 0;
  const statusCounts: Record<string, number> = {};
  for (const e of enrollRows) statusCounts[e.status] = (statusCounts[e.status] ?? 0) + 1;

  const quizByLesson = new Map(quizzes.filter((q) => q.lessonId).map((q) => [q.lessonId as string, q]));
  const assignmentByLesson = new Map(
    assignments.filter((a) => a.lessonId).map((a) => [a.lessonId as string, a])
  );

  return ok({
    course,
    category,
    owner,
    modules: modules.map((m) => ({
      ...m,
      lessons: lessons
        .filter((l) => l.moduleId === m.id)
        .map((l) => {
          const q = quizByLesson.get(l.id);
          const a = assignmentByLesson.get(l.id);
          return {
            ...l,
            quiz: q ? { id: q.id, title: q.title, questionCount: qCount.get(q.id) ?? 0 } : null,
            assignment: a ? { id: a.id, title: a.title, maxPoints: a.maxPoints } : null,
          };
        }),
    })),
    quizzes: quizzes.map((q) => ({ ...q, questionCount: qCount.get(q.id) ?? 0 })),
    assignments,
    stats: {
      enrollments: enrollRows.length,
      active: statusCounts["ACTIVE"] ?? 0,
      completed: statusCounts["COMPLETED"] ?? 0,
      dropped: statusCounts["DROPPED"] ?? 0,
      paused: statusCounts["PAUSED"] ?? 0,
      avgProgress,
      lessonCount: lessons.length,
    },
  });
}

/** PATCH /api/lms/courses/:id — edit fields incl. publish/unpublish/archive. */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  if (!(await ownsCourse(g.guard.session, id))) return fail("You can only edit your own courses.", 403);

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const existing = await db.course.findUnique({ where: { id } });
  if (!existing) return fail("Course not found.", 404);

  const course = await db.course.update({
    where: { id },
    data: {
      ...(d.title !== undefined ? { title: d.title } : {}),
      ...(d.description !== undefined ? { description: d.description } : {}),
      ...(d.level !== undefined ? { level: d.level } : {}),
      ...(d.weeks !== undefined ? { weeks: d.weeks } : {}),
      ...(d.hrsPerDay !== undefined ? { hrsPerDay: d.hrsPerDay } : {}),
      ...(d.prerequisite !== undefined ? { prerequisite: d.prerequisite || "" } : {}),
      ...(d.icon !== undefined ? { icon: d.icon } : {}),
      ...(d.categoryId !== undefined ? { categoryId: d.categoryId || null } : {}),
      ...(d.thumbnail !== undefined ? { thumbnail: d.thumbnail || null } : {}),
      ...(d.status !== undefined ? { status: d.status } : {}),
    },
  });

  const statusChanged = d.status !== undefined && d.status !== existing.status;
  await audit(
    g.guard.session,
    statusChanged ? `course.${d.status!.toLowerCase()}` : "course.update",
    "course",
    id,
    statusChanged ? `Course "${course.title}" → ${d.status}` : `Updated course "${course.title}"`
  );
  if (d.status === "PUBLISHED" && existing.status !== "PUBLISHED") {
    await notifyPermission("lms.courses.view", "Course published", {
      body: `"${course.title}" is now live on the website.`,
      type: "SUCCESS",
      link: `/lms/courses/${id}`,
    });
  }
  return ok(course);
}

/** DELETE /api/lms/courses/:id — only when the course has no enrollments. */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  if (!(await ownsCourse(g.guard.session, id))) return fail("You can only delete your own courses.", 403);

  const existing = await db.course.findUnique({ where: { id } });
  if (!existing) return fail("Course not found.", 404);

  const enrollments = await db.enrollment.count({ where: { courseId: id } });
  if (enrollments > 0) {
    return fail("This course has enrollments and cannot be deleted. Archive it instead.", 409);
  }

  const modules = await db.module.findMany({ where: { courseId: id }, select: { id: true } });
  const moduleIds = modules.map((m) => m.id);
  const quizzes = await db.quiz.findMany({ where: { courseId: id }, select: { id: true } });
  const quizIds = quizzes.map((q) => q.id);

  await db.$transaction([
    db.quizQuestion.deleteMany({ where: { quizId: { in: quizIds } } }),
    db.quiz.deleteMany({ where: { courseId: id } }),
    db.assignment.deleteMany({ where: { courseId: id } }),
    db.lesson.deleteMany({ where: { moduleId: { in: moduleIds } } }),
    db.module.deleteMany({ where: { courseId: id } }),
    db.course.delete({ where: { id } }),
  ]);

  await audit(g.guard.session, "course.delete", "course", id, `Deleted course "${existing.title}"`);
  return ok({ deleted: true });
}
