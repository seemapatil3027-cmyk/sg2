import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const createSchema = z.object({
  title: z.string().trim().min(1, "Module title is required").max(120),
  description: z.string().trim().max(500).optional(),
});

/** POST /api/lms/courses/:id/modules — add a module (order = max + 1). */
export async function POST(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  if (!(await ownsCourse(g.guard.session, id))) return fail("You can only manage your own courses.", 403);

  const course = await db.course.findUnique({ where: { id }, select: { id: true } });
  if (!course) return fail("Course not found.", 404);

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;

  const max = await db.module.aggregate({ where: { courseId: id }, _max: { order: true } });
  const mod = await db.module.create({
    data: {
      courseId: id,
      title: parsed.data.title,
      description: parsed.data.description || null,
      order: (max._max.order ?? 0) + 1,
    },
  });
  return ok(module, 201);
}
