import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

/** GET /api/lms/assignments/:id — assignment detail for the builder dialog. */
export async function GET(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.view");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const assignment = await db.assignment.findUnique({ where: { id } });
  if (!assignment) return fail("Assignment not found.", 404);
  if (!(await ownsCourse(g.guard.session, assignment.courseId))) {
    return fail("You can only view assignments of your own courses.", 403);
  }
  return ok(assignment);
}

const patchSchema = z.object({
  title: z.string().trim().min(1).max(160).optional(),
  instructions: z.string().trim().max(5000).nullable().optional(),
  maxPoints: z.coerce.number().int().min(1).max(1000).optional(),
  dueInDays: z.coerce.number().int().min(0).max(365).nullable().optional(),
});

/** PATCH /api/lms/assignments/:id */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const assignment = await db.assignment.findUnique({ where: { id } });
  if (!assignment) return fail("Assignment not found.", 404);
  if (!(await ownsCourse(g.guard.session, assignment.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const updated = await db.assignment.update({
    where: { id },
    data: {
      ...(d.title !== undefined ? { title: d.title } : {}),
      ...(d.instructions !== undefined ? { instructions: d.instructions || null } : {}),
      ...(d.maxPoints !== undefined ? { maxPoints: d.maxPoints } : {}),
      ...(d.dueInDays !== undefined ? { dueInDays: d.dueInDays ?? null } : {}),
    },
  });
  return ok(updated);
}

/** DELETE /api/lms/assignments/:id — cascades submissions. */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const assignment = await db.assignment.findUnique({ where: { id } });
  if (!assignment) return fail("Assignment not found.", 404);
  if (!(await ownsCourse(g.guard.session, assignment.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  await db.$transaction([
    db.assignmentSubmission.deleteMany({ where: { assignmentId: id } }),
    db.assignment.delete({ where: { id } }),
  ]);
  return ok({ deleted: true });
}
