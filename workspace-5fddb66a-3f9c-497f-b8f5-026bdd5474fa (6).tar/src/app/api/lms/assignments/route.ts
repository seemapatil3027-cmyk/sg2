import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

const createSchema = z.object({
  courseId: z.string().trim().min(1, "courseId is required"),
  lessonId: z.string().trim().optional().nullable(),
  title: z.string().trim().min(1, "Assignment title is required").max(160),
  instructions: z.string().trim().max(5000).optional().nullable(),
  maxPoints: z.coerce.number().int().min(1).max(1000).optional(),
  dueInDays: z.coerce.number().int().min(0).max(365).optional().nullable(),
});

/** POST /api/lms/assignments — create an assignment (optionally on a lesson). */
export async function POST(req: NextRequest) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  if (!(await ownsCourse(g.guard.session, d.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }
  const course = await db.course.findUnique({ where: { id: d.courseId }, select: { id: true } });
  if (!course) return fail("Course not found.", 404);

  if (d.lessonId) {
    const lesson = await db.lesson.findUnique({
      where: { id: d.lessonId },
      select: { id: true, moduleId: true },
    });
    if (!lesson) return fail("Lesson not found.", 404);
    const mod = await db.module.findUnique({ where: { id: lesson.moduleId }, select: { courseId: true } });
    if (mod?.courseId !== d.courseId) {
      return fail("The lesson does not belong to this course.", 422);
    }
  }

  const assignment = await db.assignment.create({
    data: {
      courseId: d.courseId,
      lessonId: d.lessonId || null,
      title: d.title,
      instructions: d.instructions || null,
      maxPoints: d.maxPoints ?? 100,
      dueInDays: d.dueInDays ?? null,
    },
  });
  return ok(assignment, 201);
}
