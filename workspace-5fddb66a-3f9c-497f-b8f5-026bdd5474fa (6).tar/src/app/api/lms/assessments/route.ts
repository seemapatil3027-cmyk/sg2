import { db } from "@/lib/db";
import { guard, ok } from "@/lib/api-helpers";
import { isInstructor } from "@/lib/lms-server";

/** GET /api/lms/assessments — quizzes + submission summary (instructor-scoped). */
export async function GET() {
  const g = await guard("lms.assessments.view");
  if (g.response) return g.response;

  const courses = await db.course.findMany({
    where: isInstructor(g.guard.session) ? { ownerId: g.guard.session.uid } : {},
    select: { id: true, title: true },
  });
  const courseIds = courses.map((c) => c.id);
  const courseTitle = new Map(courses.map((c) => [c.id, c.title]));
  if (courseIds.length === 0) return ok({ quizzes: [], submissions: [] });

  const quizzes = await db.quiz.findMany({
    where: { courseId: { in: courseIds } },
    orderBy: { createdAt: "asc" },
  });
  const assignments = await db.assignment.findMany({
    where: { courseId: { in: courseIds } },
    orderBy: { createdAt: "asc" },
  });
  const quizIds = quizzes.map((q) => q.id);
  const assignmentIds = assignments.map((a) => a.id);

  const [questions, attempts, submissions] = await Promise.all([
    quizIds.length
      ? db.quizQuestion.groupBy({ by: ["quizId"], where: { quizId: { in: quizIds } }, _count: true })
      : Promise.resolve([] as { quizId: string; _count: number }[]),
    quizIds.length
      ? db.quizAttempt.findMany({
          where: { quizId: { in: quizIds } },
          select: { quizId: true, score: true, maxScore: true, passed: true },
        })
      : Promise.resolve([]),
    assignmentIds.length
      ? db.assignmentSubmission.findMany({
          where: { assignmentId: { in: assignmentIds } },
          orderBy: { submittedAt: "desc" },
        })
      : Promise.resolve([]),
  ]);

  const qCount = new Map(questions.map((r) => [r.quizId, r._count]));

  const quizOut = quizzes.map((q) => {
    const at = attempts.filter((a) => a.quizId === q.id);
    const percents = at.map((a) => (a.maxScore > 0 ? (a.score / a.maxScore) * 100 : 0));
    return {
      id: q.id,
      courseId: q.courseId,
      courseTitle: courseTitle.get(q.courseId) ?? "—",
      lessonId: q.lessonId,
      title: q.title,
      passScore: q.passScore,
      questionCount: qCount.get(q.id) ?? 0,
      attemptCount: at.length,
      avgScore: percents.length ? Math.round(percents.reduce((s, p) => s + p, 0) / percents.length) : null,
      passRate: at.length ? Math.round((at.filter((a) => a.passed).length / at.length) * 100) : null,
    };
  });

  const enrollmentIds = [...new Set(submissions.map((s) => s.enrollmentId))];
  const enrollments = enrollmentIds.length
    ? await db.enrollment.findMany({
        where: { id: { in: enrollmentIds } },
        select: { id: true, learnerName: true, contactId: true, batchName: true },
      })
    : [];
  const enrMap = new Map(enrollments.map((e) => [e.id, e]));
  const contactIds = enrollments.map((e) => e.contactId).filter((v): v is string => Boolean(v));
  const contacts = contactIds.length
    ? await db.contact.findMany({ where: { id: { in: contactIds } }, select: { id: true, name: true } })
    : [];
  const contactMap = new Map(contacts.map((c) => [c.id, c.name]));
  const assignmentMap = new Map(assignments.map((a) => [a.id, a]));

  const submissionOut = submissions.map((s) => {
    const a = assignmentMap.get(s.assignmentId);
    const e = enrMap.get(s.enrollmentId);
    return {
      id: s.id,
      assignmentId: s.assignmentId,
      assignmentTitle: a?.title ?? "Assignment",
      maxPoints: a?.maxPoints ?? 100,
      courseId: a?.courseId ?? null,
      courseTitle: a ? courseTitle.get(a.courseId) ?? "—" : "—",
      enrollmentId: s.enrollmentId,
      learnerName:
        (e?.contactId ? contactMap.get(e.contactId) : undefined) ?? e?.learnerName ?? "Learner",
      batchName: e?.batchName ?? null,
      status: s.status,
      grade: s.grade,
      feedback: s.feedback,
      gradedBy: s.gradedBy,
      contentText: s.contentText,
      fileUrl: s.fileUrl,
      submittedAt: s.submittedAt,
      gradedAt: s.gradedAt,
    };
  });

  return ok({ quizzes: quizOut, submissions: submissionOut });
}
