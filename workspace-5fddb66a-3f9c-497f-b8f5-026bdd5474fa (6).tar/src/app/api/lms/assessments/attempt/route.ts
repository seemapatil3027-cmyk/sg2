import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { jsonNumbers, ownsCourse, sameSet } from "@/lib/lms-server";

const postSchema = z.object({
  quizId: z.string().trim().min(1),
  enrollmentId: z.string().trim().min(1),
  answers: z.array(z.array(z.coerce.number().int().min(0)).max(10)).max(50),
});

/** POST /api/lms/assessments/attempt — record + auto-grade a quiz attempt. */
export async function POST(req: NextRequest) {
  const g = await guard("lms.assessments.manage");
  if (g.response) return g.response;
  const parsed = await parseBody(req, postSchema);
  if (parsed.response) return parsed.response;
  const { quizId, enrollmentId, answers } = parsed.data;

  const quiz = await db.quiz.findUnique({ where: { id: quizId } });
  if (!quiz) return fail("Quiz not found.", 404);
  if (!(await ownsCourse(g.guard.session, quiz.courseId))) {
    return fail("You can only manage quizzes of your own courses.", 403);
  }
  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId } });
  if (!enrollment) return fail("Enrollment not found.", 404);
  if (enrollment.courseId !== quiz.courseId) {
    return fail("The learner is not enrolled in this quiz's course.", 422);
  }

  const questions = await db.quizQuestion.findMany({
    where: { quizId },
    orderBy: { order: "asc" },
  });
  if (questions.length === 0) {
    return fail("This quiz has no questions yet — add questions first.", 422);
  }

  let score = 0;
  let maxScore = 0;
  const perQuestion: { correct: boolean; points: number }[] = [];
  questions.forEach((q, i) => {
    const correctIdx = jsonNumbers(q.correct);
    const points = q.points;
    maxScore += points;
    const given = answers[i] ?? [];
    const isCorrect =
      correctIdx.length > 0 && sameSet(given.filter((idx) => idx >= 0), correctIdx);
    if (isCorrect) score += points;
    perQuestion.push({ correct: isCorrect, points });
  });

  const percent = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
  const passed = percent >= quiz.passScore;

  const attempt = await db.quizAttempt.create({
    data: {
      quizId,
      enrollmentId,
      answers: JSON.stringify(answers),
      score,
      maxScore,
      passed,
    },
  });

  return ok(
    {
      id: attempt.id,
      score,
      maxScore,
      percent,
      passed,
      passScore: quiz.passScore,
      perQuestion,
      submittedAt: attempt.submittedAt,
    },
    201
  );
}
