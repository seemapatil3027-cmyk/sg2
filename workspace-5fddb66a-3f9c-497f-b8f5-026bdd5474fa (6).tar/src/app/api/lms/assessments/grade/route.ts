import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit, fail, guard, notifyPermission, ok, parseBody } from "@/lib/api-helpers";

const patchSchema = z.object({
  submissionId: z.string().trim().min(1),
  grade: z.coerce.number().int().min(0).max(1000),
  feedback: z.string().trim().max(2000).optional().nullable(),
});

/** PATCH /api/lms/assessments/grade — grade an assignment submission. */
export async function PATCH(req: NextRequest) {
  const g = await guard("lms.assessments.manage");
  if (g.response) return g.response;
  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const { submissionId, grade, feedback } = parsed.data;

  const submission = await db.assignmentSubmission.findUnique({
    where: { id: submissionId },
  });
  if (!submission) return fail("Submission not found.", 404);
  const assignment = await db.assignment.findUnique({
    where: { id: submission.assignmentId },
    select: { id: true, title: true, maxPoints: true },
  });
  if (!assignment) return fail("Assignment not found.", 404);
  if (grade > assignment.maxPoints) {
    return fail(`Grade cannot exceed the assignment maximum of ${assignment.maxPoints} points.`, 422);
  }

  const enrollment = await db.enrollment.findUnique({
    where: { id: submission.enrollmentId },
    select: { learnerName: true },
  });

  const updated = await db.assignmentSubmission.update({
    where: { id: submissionId },
    data: {
      status: "GRADED",
      grade,
      feedback: feedback || null,
      gradedBy: g.guard.session.email,
      gradedAt: new Date(),
    },
  });

  await notifyPermission("lms.assessments.view", "Submission graded", {
    body: `${enrollment?.learnerName ?? "A learner"} scored ${grade}/${assignment.maxPoints} on "${assignment.title}".`,
    type: "LMS",
    link: "/lms/assessments",
  });
  await audit(
    g.guard.session,
    "submission.grade",
    "assignmentSubmission",
    submissionId,
    `Graded "${assignment.title}" — ${grade}/${assignment.maxPoints}`
  );

  return ok(updated);
}
