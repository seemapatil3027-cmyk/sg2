import { db } from "@/lib/db";
import { guard, ok } from "@/lib/api-helpers";
import { isInstructor } from "@/lib/lms-server";

const DAY = 24 * 60 * 60 * 1000;

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(k: string): string {
  const [y, m] = k.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("en-IN", { month: "short" });
}

/** GET /api/lms/reports — LMS analytics (instructor-scoped). */
export async function GET() {
  const g = await guard("lms.reports.view");
  if (g.response) return g.response;

  const courses = await db.course.findMany({
    where: isInstructor(g.guard.session) ? { ownerId: g.guard.session.uid } : {},
    select: { id: true, title: true },
    orderBy: { createdAt: "asc" },
  });
  const courseIds = courses.map((c) => c.id);
  const courseTitle = new Map(courses.map((c) => [c.id, c.title]));

  if (courseIds.length === 0) {
    return ok({
      kpis: { totalEnrollments: 0, activeEnrollments: 0, completionRate: 0, avgProgress: 0, certificatesIssued: 0 },
      enrollmentsTrend: [],
      coursePerformance: [],
      assessmentStats: { attempts: 0, passRate: 0, avgScore: 0, pendingGrading: 0, passed: 0, failed: 0 },
      certificatesByMonth: [],
    });
  }

  const quizRows = await db.quiz.findMany({
    where: { courseId: { in: courseIds } },
    select: { id: true },
  });
  const quizIdSet = quizRows.map((q) => q.id);
  const [enrollments, attempts, submissions, certificates] = await Promise.all([
    db.enrollment.findMany({
      where: { courseId: { in: courseIds } },
      select: { id: true, courseId: true, status: true, progress: true, enrolledAt: true },
    }),
    quizIdSet.length
      ? db.quizAttempt.findMany({
          where: { quizId: { in: quizIdSet } },
          select: { quizId: true, score: true, maxScore: true, passed: true },
        })
      : Promise.resolve([]),
    db.assignment.findMany({ where: { courseId: { in: courseIds } }, select: { id: true } }).then((rows) =>
      rows.length
        ? db.assignmentSubmission.findMany({
            where: { assignmentId: { in: rows.map((r) => r.id) } },
            select: { status: true },
          })
        : Promise.resolve([])
    ),
    db.certificate.findMany({
      where: { courseId: { in: courseIds } },
      select: { issuedAt: true },
    }),
  ]);

  const total = enrollments.length;
  const completed = enrollments.filter((e) => e.status === "COMPLETED").length;
  const active = enrollments.filter((e) => e.status === "ACTIVE").length;
  const avgProgress = total ? Math.round(enrollments.reduce((s, e) => s + e.progress, 0) / total) : 0;

  // 6-month enrollments trend
  const trendMap = new Map<string, number>();
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - i);
    trendMap.set(monthKey(d), 0);
  }
  for (const e of enrollments) {
    const k = monthKey(new Date(e.enrolledAt));
    if (trendMap.has(k)) trendMap.set(k, (trendMap.get(k) ?? 0) + 1);
  }
  const enrollmentsTrend = [...trendMap.entries()].map(([k, value]) => ({
    month: monthLabel(k),
    value,
  }));

  // course performance (top 8 by enrollments)
  const coursePerformance = courses
    .map((c) => {
      const list = enrollments.filter((e) => e.courseId === c.id);
      const done = list.filter((e) => e.status === "COMPLETED").length;
      return {
        course: c.title.length > 22 ? `${c.title.slice(0, 22)}…` : c.title,
        enrollments: list.length,
        avgProgress: list.length
          ? Math.round(list.reduce((s, e) => s + e.progress, 0) / list.length)
          : 0,
        completionRate: list.length ? Math.round((done / list.length) * 100) : 0,
      };
    })
    .sort((a, b) => b.enrollments - a.enrollments)
    .slice(0, 8);

  // assessment stats
  const percents = attempts.map((a) => (a.maxScore > 0 ? (a.score / a.maxScore) * 100 : 0));
  const passedCount = attempts.filter((a) => a.passed).length;
  const assessmentStats = {
    attempts: attempts.length,
    passRate: attempts.length ? Math.round((passedCount / attempts.length) * 100) : 0,
    avgScore: percents.length ? Math.round(percents.reduce((s, p) => s + p, 0) / percents.length) : 0,
    pendingGrading: submissions.filter((s) => s.status === "SUBMITTED").length,
    passed: passedCount,
    failed: attempts.length - passedCount,
  };

  // certificates by month (6mo)
  const certMap = new Map<string, number>();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(Date.now() - i * 31 * DAY);
    d.setDate(1);
    certMap.set(monthKey(d), 0);
  }
  for (const c of certificates) {
    const k = monthKey(new Date(c.issuedAt));
    if (certMap.has(k)) certMap.set(k, (certMap.get(k) ?? 0) + 1);
  }
  const certificatesByMonth = [...certMap.entries()].map(([k, value]) => ({
    month: monthLabel(k),
    value,
  }));

  return ok({
    kpis: {
      totalEnrollments: total,
      activeEnrollments: active,
      completionRate: total ? Math.round((completed / total) * 100) : 0,
      avgProgress,
      certificatesIssued: certificates.length,
    },
    enrollmentsTrend,
    coursePerformance,
    assessmentStats,
    certificatesByMonth,
  });
}
