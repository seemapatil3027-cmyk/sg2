import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit, fail, guard, notifyPermission, ok, parseBody, nextSerial } from "@/lib/api-helpers";

/** GET /api/lms/certificates — issued certificates w/ enrollment status. */
export async function GET() {
  const g = await guard("lms.certificates.view");
  if (g.response) return g.response;

  const certs = await db.certificate.findMany({ orderBy: { issuedAt: "desc" } });
  const enrollmentIds = [...new Set(certs.map((c) => c.enrollmentId))];
  const enrollments = enrollmentIds.length
    ? await db.enrollment.findMany({
        where: { id: { in: enrollmentIds } },
        select: { id: true, status: true, progress: true, batchName: true, contactId: true },
      })
    : [];
  const enrMap = new Map(enrollments.map((e) => [e.id, e]));
  const issuerEmails = [...new Set(certs.map((c) => c.issuedBy).filter((v): v is string => Boolean(v)))];
  const issuers = issuerEmails.length
    ? await db.user.findMany({ where: { email: { in: issuerEmails } }, select: { email: true, name: true } })
    : [];
  const issuerMap = new Map(issuers.map((u) => [u.email, u.name]));

  const items = certs.map((c) => {
    const e = enrMap.get(c.enrollmentId);
    return {
      id: c.id,
      serial: c.serial,
      enrollmentId: c.enrollmentId,
      learnerName: c.learnerName,
      courseId: c.courseId,
      courseTitle: c.courseTitle,
      grade: c.grade,
      issuedBy: c.issuedBy,
      issuerName: c.issuedBy ? issuerMap.get(c.issuedBy) ?? c.issuedBy : null,
      issuedAt: c.issuedAt,
      enrollmentStatus: e?.status ?? null,
      enrollmentProgress: e?.progress ?? null,
      batchName: e?.batchName ?? null,
    };
  });

  return ok({ items });
}

const createSchema = z.object({
  enrollmentId: z.string().trim().min(1, "Select a completed enrollment"),
  grade: z.enum(["A", "B", "C"]).optional().nullable(),
});

/** POST /api/lms/certificates — issue a certificate for a 100%-complete enrollment. */
export async function POST(req: NextRequest) {
  const g = await guard("lms.certificates.issue");
  if (g.response) return g.response;
  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const { enrollmentId, grade } = parsed.data;

  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId } });
  if (!enrollment) return fail("Enrollment not found.", 404);
  if (enrollment.progress !== 100) {
    return fail("Learner must complete 100% before a certificate can be issued.", 422);
  }

  const existing = await db.certificate.findFirst({ where: { enrollmentId } });
  if (existing) {
    return fail("A certificate has already been issued for this enrollment.", 409);
  }

  const course = enrollment.courseId
    ? await db.course.findUnique({ where: { id: enrollment.courseId }, select: { title: true } })
    : null;

  const serial = await nextSerial("SG-CERT");
  const certificate = await db.certificate.create({
    data: {
      serial,
      enrollmentId,
      learnerName: enrollment.learnerName,
      courseId: enrollment.courseId ?? "",
      courseTitle: course?.title ?? enrollment.itemSlug,
      grade: grade ?? null,
      issuedBy: g.guard.session.email,
    },
  });

  await db.activity.create({
    data: {
      type: "CERTIFICATE",
      subject: `Certificate issued — ${certificate.courseTitle}`,
      detail: `Serial ${serial}${grade ? ` · Grade ${grade}` : ""}`,
      contactId: enrollment.contactId,
      createdBy: g.guard.session.email,
    },
  });
  await notifyPermission("lms.certificates.view", "Certificate issued", {
    body: `${certificate.learnerName} — ${certificate.courseTitle} (${serial})`,
    type: "SUCCESS",
    link: "/lms/certificates",
  });
  await audit(
    g.guard.session,
    "certificate.issue",
    "certificate",
    certificate.id,
    `Issued ${serial} to ${certificate.learnerName} for "${certificate.courseTitle}"`
  );

  return ok(certificate, 201);
}
