import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit, fail, guard, notifyPermission, ok, paginated, pageParams, parseBody } from "@/lib/api-helpers";
import { isInstructor } from "@/lib/lms-server";

/** GET /api/lms/enrollments — paginated list + status counts (instructor-scoped). */
export async function GET(req: NextRequest) {
  const g = await guard("lms.enrollments.view");
  if (g.response) return g.response;
  const p = pageParams(req, 100);
  const sp = p.searchParams;

  let scopeCourseIds: string[] | null = null;
  if (isInstructor(g.guard.session)) {
    const own = await db.course.findMany({
      where: { ownerId: g.guard.session.uid },
      select: { id: true },
    });
    scopeCourseIds = own.map((c) => c.id);
    if (scopeCourseIds.length === 0) {
      return ok({ ...paginated([], 0, p), counts: { total: 0, avgProgress: 0 } });
    }
  }

  const filterWhere: Record<string, unknown> = {
    courseId: scopeCourseIds ? { in: scopeCourseIds } : { not: null },
  };
  const courseId = sp.get("courseId");
  if (courseId && courseId !== "ALL") filterWhere.courseId = courseId;
  const batch = sp.get("batch");
  if (batch) filterWhere.batchName = { contains: batch };
  if (p.q) {
    const matching = await db.course.findMany({
      where: { title: { contains: p.q } },
      select: { id: true },
    });
    filterWhere.OR = [
      { learnerName: { contains: p.q } },
      { courseId: { in: matching.map((c) => c.id) } },
    ];
  }

  // status counts reflect every other filter (so tab badges stay accurate)
  const baseWhere = { ...filterWhere };
  const status = sp.get("status");
  if (status && status !== "ALL") baseWhere.status = status;

  const [total, rows, grouped] = await Promise.all([
    db.enrollment.count({ where: baseWhere }),
    db.enrollment.findMany({
      where: baseWhere,
      orderBy: { enrolledAt: "desc" },
      skip: p.skip,
      take: p.pageSize,
    }),
    db.enrollment.groupBy({ by: ["status"], where: filterWhere, _count: true }),
  ]);

  const contactIds = rows.map((r) => r.contactId).filter((v): v is string => Boolean(v));
  const userIds = rows.map((r) => r.userId).filter((v): v is string => Boolean(v));
  const courseIds = rows.map((r) => r.courseId).filter((v): v is string => Boolean(v));
  const [contacts, users, courses] = await Promise.all([
    contactIds.length
      ? db.contact.findMany({
          where: { id: { in: contactIds } },
          select: { id: true, name: true, email: true, phone: true },
        })
      : Promise.resolve([] as { id: string; name: string; email: string | null; phone: string | null }[]),
    userIds.length
      ? db.user.findMany({ where: { id: { in: userIds } }, select: { id: true, name: true } })
      : Promise.resolve([] as { id: string; name: string }[]),
    courseIds.length
      ? db.course.findMany({
          where: { id: { in: courseIds } },
          select: { id: true, title: true, slug: true, thumbnail: true },
        })
      : Promise.resolve([] as { id: string; title: string; slug: string; thumbnail: string | null }[]),
  ]);
  const contactMap = new Map(contacts.map((c) => [c.id, c]));
  const userMap = new Map(users.map((u) => [u.id, u.name]));
  const courseMap = new Map(courses.map((c) => [c.id, c]));

  const items = rows.map((r) => {
    const contact = r.contactId ? contactMap.get(r.contactId) : undefined;
    const course = r.courseId ? courseMap.get(r.courseId) : undefined;
    return {
      id: r.id,
      status: r.status,
      progress: r.progress,
      batchName: r.batchName,
      enrolledAt: r.enrolledAt,
      itemType: r.itemType,
      courseId: r.courseId,
      courseTitle: course?.title ?? r.itemSlug,
      courseSlug: course?.slug ?? null,
      contactId: r.contactId,
      userId: r.userId,
      learnerName: contact?.name ?? (r.userId ? userMap.get(r.userId) : undefined) ?? r.learnerName,
      email: contact?.email ?? null,
      phone: contact?.phone ?? null,
    };
  });

  const counts: Record<string, number> = {};
  for (const grp of grouped) counts[grp.status] = grp._count;
  const allRows = await db.enrollment.findMany({ where: filterWhere, select: { progress: true } });
  const avgProgress = allRows.length
    ? Math.round(allRows.reduce((s, r) => s + r.progress, 0) / allRows.length)
    : 0;
  return ok({
    ...paginated(items, total, p),
    counts: { total: allRows.length, avgProgress, ...counts },
  });
}

const createSchema = z.object({
  contactId: z.string().trim().min(1, "Select a learner"),
  courseId: z.string().trim().min(1, "Select a course"),
  batchName: z.string().trim().max(40).optional().nullable(),
  itemType: z.string().trim().max(20).optional(),
});

/** POST /api/lms/enrollments — enroll a contact in a course. */
export async function POST(req: NextRequest) {
  const g = await guard("lms.enrollments.manage");
  if (g.response) return g.response;
  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const contact = await db.contact.findUnique({ where: { id: d.contactId } });
  if (!contact) return fail("Contact not found.", 404);
  const course = await db.course.findUnique({ where: { id: d.courseId } });
  if (!course) return fail("Course not found.", 404);

  const duplicate = await db.enrollment.findFirst({
    where: { contactId: contact.id, courseId: course.id, status: { in: ["ACTIVE", "PAUSED"] } },
    select: { id: true },
  });
  if (duplicate) return fail("Already enrolled", 400);

  const enrollment = await db.enrollment.create({
    data: {
      userId: contact.userId ?? null,
      contactId: contact.id,
      learnerName: contact.name,
      courseId: course.id,
      itemSlug: course.slug,
      itemType: d.itemType || "course",
      batchName: d.batchName || null,
      status: "ACTIVE",
      progress: 0,
    },
  });

  await db.activity.create({
    data: {
      type: "ENROLLMENT",
      subject: `Enrolled in ${course.title}`,
      detail: d.batchName ? `Batch ${d.batchName}` : null,
      contactId: contact.id,
      createdBy: g.guard.session.email,
    },
  });
  await notifyPermission("lms.enrollments.view", "New enrollment", {
    body: `${contact.name} enrolled in ${course.title}${d.batchName ? ` (batch ${d.batchName})` : ""}.`,
    type: "LMS",
    link: "/lms/enrollments",
  });
  await audit(
    g.guard.session,
    "enrollment.create",
    "enrollment",
    enrollment.id,
    `Enrolled ${contact.name} in ${course.title}`
  );

  return ok(
    {
      ...enrollment,
      courseTitle: course.title,
      email: contact.email,
      phone: contact.phone,
    },
    201
  );
}
