import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { audit, fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { isInstructor, ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  status: z.enum(["ACTIVE", "PAUSED", "COMPLETED", "DROPPED"]).optional(),
  batchName: z.string().trim().max(40).nullable().optional(),
});

/** GET /api/lms/enrollments/:id — detail with lesson checklist, attempts, submissions. */
export async function GET(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.enrollments.view");
  if (g.response) return g.response;
  const { id } = await ctx.params;

  const enrollment = await db.enrollment.findUnique({ where: { id } });
  if (!enrollment) return fail("Enrollment not found.", 404);
  if (enrollment.courseId) {
    if (!(await ownsCourse(g.guard.session, enrollment.courseId))) {
      return fail("You can only view enrollments of your own courses.", 403);
    }
  } else if (isInstructor(g.guard.session)) {
    return fail("You can only view enrollments of your own courses.", 403);
  }

  const [contact, user, course, progressRows] = await Promise.all([
    enrollment.contactId
      ? db.contact.findUnique({
          where: { id: enrollment.contactId },
          select: { id: true, name: true, email: true, phone: true, city: true },
        })
      : Promise.resolve(null),
    enrollment.userId
      ? db.user.findUnique({ where: { id: enrollment.userId }, select: { id: true, name: true, email: true } })
      : Promise.resolve(null),
    enrollment.courseId ? db.course.findUnique({ where: { id: enrollment.courseId } }) : Promise.resolve(null),
    db.lessonProgress.findMany({ where: { enrollmentId: id } }),
  ]);

  let lessons: {
    id: string;
    moduleId: string;
    moduleTitle: string;
    title: string;
    type: string;
    durationMin: number;
    isPreview: boolean;
    order: number;
    completed: boolean;
    completedAt: Date | null;
  }[] = [];
  if (course) {
    const modules = await db.module.findMany({
      where: { courseId: course.id },
      orderBy: { order: "asc" },
    });
    const moduleIds = modules.map((m) => m.id);
    const allLessons = moduleIds.length
      ? await db.lesson.findMany({
          where: { moduleId: { in: moduleIds } },
          orderBy: { order: "asc" },
        })
      : [];
    const doneMap = new Map(progressRows.map((p) => [p.lessonId, p.completedAt]));
    lessons = allLessons.map((l) => {
      const mod = modules.find((m) => m.id === l.moduleId);
      return {
        id: l.id,
        moduleId: l.moduleId,
        moduleTitle: mod?.title ?? "Module",
        title: l.title,
        type: l.type,
        durationMin: l.durationMin,
        isPreview: l.isPreview,
        order: l.order,
        completed: doneMap.has(l.id),
        completedAt: doneMap.get(l.id) ?? null,
      };
    });
  }

  const attempts = await db.quizAttempt.findMany({
    where: { enrollmentId: id },
    orderBy: { submittedAt: "desc" },
  });
  const quizIds = [...new Set(attempts.map((a) => a.quizId))];
  const quizzes = quizIds.length
    ? await db.quiz.findMany({ where: { id: { in: quizIds } }, select: { id: true, title: true } })
    : [];
  const quizTitle = new Map(quizzes.map((q) => [q.id, q.title]));

  const submissions = await db.assignmentSubmission.findMany({
    where: { enrollmentId: id },
    orderBy: { submittedAt: "desc" },
  });
  const assignmentIds = [...new Set(submissions.map((s) => s.assignmentId))];
  const assignments = assignmentIds.length
    ? await db.assignment.findMany({
        where: { id: { in: assignmentIds } },
        select: { id: true, title: true, maxPoints: true },
      })
    : [];
  const assignmentMap = new Map(assignments.map((a) => [a.id, a]));

  return ok({
    enrollment,
    contact,
    user,
    course: course
      ? { id: course.id, title: course.title, slug: course.slug, thumbnail: course.thumbnail, status: course.status, level: course.level }
      : null,
    lessons,
    attempts: attempts.map((a) => ({
      id: a.id,
      quizTitle: quizTitle.get(a.quizId) ?? "Quiz",
      score: a.score,
      maxScore: a.maxScore,
      percent: a.maxScore > 0 ? Math.round((a.score / a.maxScore) * 100) : 0,
      passed: a.passed,
      submittedAt: a.submittedAt,
    })),
    submissions: submissions.map((s) => {
      const a = assignmentMap.get(s.assignmentId);
      return {
        id: s.id,
        assignmentId: s.assignmentId,
        assignmentTitle: a?.title ?? "Assignment",
        maxPoints: a?.maxPoints ?? 100,
        contentText: s.contentText,
        fileUrl: s.fileUrl,
        status: s.status,
        grade: s.grade,
        feedback: s.feedback,
        gradedBy: s.gradedBy,
        submittedAt: s.submittedAt,
        gradedAt: s.gradedAt,
      };
    }),
    certificate: await db.certificate.findFirst({ where: { enrollmentId: id } }),
  });
}

/** PATCH /api/lms/enrollments/:id — status / batch; COMPLETED pins progress to 100. */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.enrollments.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;

  const enrollment = await db.enrollment.findUnique({ where: { id } });
  if (!enrollment) return fail("Enrollment not found.", 404);
  if (enrollment.courseId && !(await ownsCourse(g.guard.session, enrollment.courseId))) {
    return fail("You can only manage enrollments of your own courses.", 403);
  }

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const willComplete = d.status === "COMPLETED" && enrollment.status !== "COMPLETED";
  const updated = await db.enrollment.update({
    where: { id },
    data: {
      ...(d.status !== undefined ? { status: d.status } : {}),
      ...(d.batchName !== undefined ? { batchName: d.batchName || null } : {}),
      ...(willComplete ? { progress: 100 } : {}),
      updatedAt: new Date(),
    },
  });

  await audit(
    g.guard.session,
    "enrollment.update",
    "enrollment",
    id,
    `Updated enrollment of ${enrollment.learnerName}${
      d.status && d.status !== enrollment.status ? ` → ${d.status}` : ""
    }`
  );
  return ok(updated);
}

/** DELETE /api/lms/enrollments/:id — cascades progress, attempts, submissions, certificates. */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.enrollments.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;

  const enrollment = await db.enrollment.findUnique({ where: { id } });
  if (!enrollment) return fail("Enrollment not found.", 404);
  if (enrollment.courseId && !(await ownsCourse(g.guard.session, enrollment.courseId))) {
    return fail("You can only manage enrollments of your own courses.", 403);
  }

  await db.$transaction([
    db.lessonProgress.deleteMany({ where: { enrollmentId: id } }),
    db.quizAttempt.deleteMany({ where: { enrollmentId: id } }),
    db.assignmentSubmission.deleteMany({ where: { enrollmentId: id } }),
    db.certificate.deleteMany({ where: { enrollmentId: id } }),
    db.enrollment.delete({ where: { id } }),
  ]);

  await audit(
    g.guard.session,
    "enrollment.delete",
    "enrollment",
    id,
    `Removed enrollment of ${enrollment.learnerName}`
  );
  return ok({ deleted: true });
}
