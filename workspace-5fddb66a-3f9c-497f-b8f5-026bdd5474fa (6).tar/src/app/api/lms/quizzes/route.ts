import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { isInstructor, jsonNumbers, jsonStrings, ownsCourse } from "@/lib/lms-server";

const createSchema = z.object({
  courseId: z.string().trim().min(1, "courseId is required"),
  lessonId: z.string().trim().optional().nullable(),
  title: z.string().trim().min(1, "Quiz title is required").max(160),
  description: z.string().trim().max(1000).optional().nullable(),
  passScore: z.coerce.number().int().min(1).max(100).optional(),
  timeLimitMin: z.coerce.number().int().min(1).max(300).optional().nullable(),
});

/** POST /api/lms/quizzes — create a quiz (optionally attached to a lesson). */
export async function POST(req: NextRequest) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  if (!(await ownsCourse(g.guard.session, d.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }
  const course = await db.course.findUnique({ where: { id: d.courseId }, select: { id: true } });
  if (!course) return fail("Course not found.", 404);

  if (d.lessonId) {
    const lesson = await db.lesson.findUnique({
      where: { id: d.lessonId },
      select: { id: true, moduleId: true },
    });
    if (!lesson) return fail("Lesson not found.", 404);
    const mod = await db.module.findUnique({ where: { id: lesson.moduleId }, select: { courseId: true } });
    if (mod?.courseId !== d.courseId) {
      return fail("The lesson does not belong to this course.", 422);
    }
  }

  const quiz = await db.quiz.create({
    data: {
      courseId: d.courseId,
      lessonId: d.lessonId || null,
      title: d.title,
      description: d.description || null,
      passScore: d.passScore ?? 60,
      timeLimitMin: d.timeLimitMin ?? null,
    },
  });
  return ok(quiz, 201);
}

/** GET /api/lms/quizzes?quizId= — quiz + questions + attempts (assessments view). */
export async function GET(req: NextRequest) {
  const g = await guard("lms.assessments.view");
  if (g.response) return g.response;
  const quizId = req.nextUrl.searchParams.get("quizId");
  if (!quizId) return fail("quizId query parameter is required.", 422);

  const quiz = await db.quiz.findUnique({ where: { id: quizId } });
  if (!quiz) return fail("Quiz not found.", 404);
  if (isInstructor(g.guard.session) && !(await ownsCourse(g.guard.session, quiz.courseId))) {
    return fail("You can only view quizzes of your own courses.", 403);
  }

  const [questions, attempts, course] = await Promise.all([
    db.quizQuestion.findMany({ where: { quizId }, orderBy: { order: "asc" } }),
    db.quizAttempt.findMany({ where: { quizId }, orderBy: { submittedAt: "desc" } }),
    db.course.findUnique({ where: { id: quiz.courseId }, select: { id: true, title: true } }),
  ]);

  const enrollmentIds = attempts.map((a) => a.enrollmentId);
  const enrollments = enrollmentIds.length
    ? await db.enrollment.findMany({
        where: { id: { in: enrollmentIds } },
        select: { id: true, learnerName: true, contactId: true, userId: true, batchName: true, status: true },
      })
    : [];
  const enrMap = new Map(enrollments.map((e) => [e.id, e]));
  const contactIds = enrollments.map((e) => e.contactId).filter((v): v is string => Boolean(v));
  const contacts = contactIds.length
    ? await db.contact.findMany({ where: { id: { in: contactIds } }, select: { id: true, name: true } })
    : [];
  const contactMap = new Map(contacts.map((c) => [c.id, c.name]));

  return ok({
    quiz,
    course,
    questions: questions.map((q) => ({
      id: q.id,
      text: q.text,
      type: q.type,
      options: jsonStrings(q.options),
      correct: jsonNumbers(q.correct),
      points: q.points,
      order: q.order,
    })),
    attempts: attempts.map((a) => {
      const e = enrMap.get(a.enrollmentId);
      return {
        id: a.id,
        enrollmentId: a.enrollmentId,
        learnerName:
          (e?.contactId ? contactMap.get(e.contactId) : undefined) ?? e?.learnerName ?? "Learner",
        batchName: e?.batchName ?? null,
        enrollmentStatus: e?.status ?? null,
        score: a.score,
        maxScore: a.maxScore,
        percent: a.maxScore > 0 ? Math.round((a.score / a.maxScore) * 100) : 0,
        passed: a.passed,
        submittedAt: a.submittedAt,
      };
    }),
  });
}
