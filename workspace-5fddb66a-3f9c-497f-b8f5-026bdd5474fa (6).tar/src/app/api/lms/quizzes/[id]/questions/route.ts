import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const createSchema = z
  .object({
    text: z.string().trim().min(1, "Question text is required").max(1000),
    type: z.enum(["SINGLE", "MULTI", "BOOLEAN"]),
    options: z.array(z.string().trim().min(1).max(200)).max(10).optional(),
    correct: z.array(z.coerce.number().int().min(0)).max(10),
    points: z.coerce.number().int().min(1).max(100).optional(),
  })
  .superRefine((val, ctx2) => {
    if (val.type !== "BOOLEAN") {
      if (!val.options || val.options.length < 2) {
        ctx2.addIssue({ code: "custom", message: "At least 2 options are required", path: ["options"] });
      }
    }
  });

/** POST /api/lms/quizzes/:id/questions — add a question (options/correct stored as JSON). */
export async function POST(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const quiz = await db.quiz.findUnique({ where: { id } });
  if (!quiz) return fail("Quiz not found.", 404);
  if (!(await ownsCourse(g.guard.session, quiz.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const options = d.type === "BOOLEAN" ? ["True", "False"] : d.options ?? [];
  const maxIndex = options.length - 1;
  const correct = [...new Set(d.correct)].filter((i) => i >= 0 && i <= maxIndex);
  if (correct.length === 0) {
    return fail("Select at least one correct option within the option list.", 422);
  }

  const max = await db.quizQuestion.aggregate({ where: { quizId: id }, _max: { order: true } });
  const question = await db.quizQuestion.create({
    data: {
      quizId: id,
      text: d.text,
      type: d.type,
      options: JSON.stringify(options),
      correct: JSON.stringify(correct),
      points: d.points ?? 1,
      order: (max._max.order ?? 0) + 1,
    },
  });
  return ok(question, 201);
}
