import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().trim().min(1).max(160).optional(),
  description: z.string().trim().max(1000).nullable().optional(),
  passScore: z.coerce.number().int().min(1).max(100).optional(),
  timeLimitMin: z.coerce.number().int().min(1).max(300).nullable().optional(),
});

/** PATCH /api/lms/quizzes/:id — edit quiz settings. */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const quiz = await db.quiz.findUnique({ where: { id } });
  if (!quiz) return fail("Quiz not found.", 404);
  if (!(await ownsCourse(g.guard.session, quiz.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const updated = await db.quiz.update({
    where: { id },
    data: {
      ...(d.title !== undefined ? { title: d.title } : {}),
      ...(d.description !== undefined ? { description: d.description || null } : {}),
      ...(d.passScore !== undefined ? { passScore: d.passScore } : {}),
      ...(d.timeLimitMin !== undefined ? { timeLimitMin: d.timeLimitMin || null } : {}),
    },
  });
  return ok(updated);
}

/** DELETE /api/lms/quizzes/:id — cascades questions + attempts. */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const quiz = await db.quiz.findUnique({ where: { id } });
  if (!quiz) return fail("Quiz not found.", 404);
  if (!(await ownsCourse(g.guard.session, quiz.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  await db.$transaction([
    db.quizQuestion.deleteMany({ where: { quizId: id } }),
    db.quizAttempt.deleteMany({ where: { quizId: id } }),
    db.quiz.delete({ where: { id } }),
  ]);
  return ok({ deleted: true });
}
