import { db } from "@/lib/db";
import { guard, ok } from "@/lib/api-helpers";

/** GET /api/lms/categories — course categories for pickers. */
export async function GET() {
  const g = await guard("lms.courses.view");
  if (g.response) return g.response;
  const categories = await db.courseCategory.findMany({ orderBy: { order: "asc" } });
  return ok(categories);
}
