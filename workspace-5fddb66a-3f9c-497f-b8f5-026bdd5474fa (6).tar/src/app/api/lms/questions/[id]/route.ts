import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { ownsCourse } from "@/lib/lms-server";

type RouteCtx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  text: z.string().trim().min(1).max(1000).optional(),
  type: z.enum(["SINGLE", "MULTI", "BOOLEAN"]).optional(),
  options: z.array(z.string().trim().min(1).max(200)).max(10).optional(),
  correct: z.array(z.coerce.number().int().min(0)).max(10).optional(),
  points: z.coerce.number().int().min(1).max(100).optional(),
  order: z.coerce.number().int().min(0).optional(),
});

async function questionWithCourse(id: string) {
  const question = await db.quizQuestion.findUnique({ where: { id } });
  if (!question) return null;
  const quiz = await db.quiz.findUnique({ where: { id: question.quizId }, select: { courseId: true } });
  if (!quiz) return null;
  return { question, courseId: quiz.courseId };
}

/** PATCH /api/lms/questions/:id — edit a quiz question. */
export async function PATCH(req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const found = await questionWithCourse(id);
  if (!found) return fail("Question not found.", 404);
  if (!(await ownsCourse(g.guard.session, found.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const d = parsed.data;

  const type = d.type ?? found.question.type;
  let options: string[] | undefined;
  if (d.options !== undefined) options = d.options;
  if (type === "BOOLEAN") options = ["True", "False"];
  const maxIndex = (options ?? JSON.parse(found.question.options) as string[]).length - 1;
  const correct =
    d.correct !== undefined
      ? [...new Set(d.correct)].filter((i) => i >= 0 && i <= maxIndex)
      : undefined;
  if (correct !== undefined && correct.length === 0) {
    return fail("Select at least one correct option within the option list.", 422);
  }

  const question = await db.quizQuestion.update({
    where: { id },
    data: {
      ...(d.text !== undefined ? { text: d.text } : {}),
      ...(d.type !== undefined ? { type: d.type } : {}),
      ...(options !== undefined ? { options: JSON.stringify(options) } : {}),
      ...(correct !== undefined ? { correct: JSON.stringify(correct) } : {}),
      ...(d.points !== undefined ? { points: d.points } : {}),
      ...(d.order !== undefined ? { order: d.order } : {}),
    },
  });
  return ok(question);
}

/** DELETE /api/lms/questions/:id */
export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const g = await guard("lms.courses.manage");
  if (g.response) return g.response;
  const { id } = await ctx.params;
  const found = await questionWithCourse(id);
  if (!found) return fail("Question not found.", 404);
  if (!(await ownsCourse(g.guard.session, found.courseId))) {
    return fail("You can only manage your own courses.", 403);
  }
  await db.quizQuestion.delete({ where: { id } });
  return ok({ deleted: true });
}
