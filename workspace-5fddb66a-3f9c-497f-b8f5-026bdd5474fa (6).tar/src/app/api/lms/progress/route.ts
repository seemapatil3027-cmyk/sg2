import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, guard, ok, parseBody } from "@/lib/api-helpers";
import { isInstructor, ownsCourse } from "@/lib/lms-server";

const postSchema = z.object({
  enrollmentId: z.string().trim().min(1),
  lessonId: z.string().trim().min(1),
  done: z.boolean(),
});

async function recomputeProgress(enrollmentId: string) {
  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId } });
  if (!enrollment || !enrollment.courseId) return null;

  const modules = await db.module.findMany({ where: { courseId: enrollment.courseId }, select: { id: true } });
  const moduleIds = modules.map((m) => m.id);
  const courseLessons = moduleIds.length
    ? await db.lesson.findMany({ where: { moduleId: { in: moduleIds } }, select: { id: true } })
    : [];
  const lessonIds = courseLessons.map((l) => l.id);
  const total = lessonIds.length;
  const completed = total
    ? await db.lessonProgress.count({
        where: { enrollmentId, lessonId: { in: lessonIds } },
      })
    : 0;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  let status = enrollment.status;
  if (progress === 100 && status !== "COMPLETED") status = "COMPLETED";
  else if (progress < 100 && status === "COMPLETED") status = "ACTIVE";

  await db.enrollment.update({
    where: { id: enrollmentId },
    data: { progress, status, updatedAt: new Date() },
  });
  return { progress, status, completed, total };
}

/** POST /api/lms/progress — toggle a lesson complete + recompute enrollment progress. */
export async function POST(req: NextRequest) {
  const g = await guard("lms.progress.view");
  if (g.response) return g.response;
  const parsed = await parseBody(req, postSchema);
  if (parsed.response) return parsed.response;
  const { enrollmentId, lessonId, done } = parsed.data;

  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId } });
  if (!enrollment) return fail("Enrollment not found.", 404);
  if (enrollment.courseId && !(await ownsCourse(g.guard.session, enrollment.courseId))) {
    return fail("You can only update progress of your own courses.", 403);
  }
  const lesson = await db.lesson.findUnique({ where: { id: lessonId }, select: { id: true } });
  if (!lesson) return fail("Lesson not found.", 404);

  if (done) {
    await db.lessonProgress.upsert({
      where: { enrollmentId_lessonId: { enrollmentId, lessonId } },
      create: { enrollmentId, lessonId },
      update: {},
    });
  } else {
    await db.lessonProgress.deleteMany({ where: { enrollmentId, lessonId } });
  }

  const result = await recomputeProgress(enrollmentId);
  if (!result) return fail("Enrollment has no linked course.", 422);
  return ok(result);
}

/** GET /api/lms/progress — per-course progress overview for staff. */
export async function GET() {
  const g = await guard("lms.progress.view");
  if (g.response) return g.response;

  const courses = await db.course.findMany({
    where: isInstructor(g.guard.session) ? { ownerId: g.guard.session.uid } : {},
    select: { id: true, title: true, status: true, thumbnail: true, icon: true },
    orderBy: { createdAt: "desc" },
  });
  const courseIds = courses.map((c) => c.id);
  if (courseIds.length === 0) return ok({ courses: [], stats: { learners: 0, avgProgress: 0, completed: 0 } });

  const [modules, enrollments] = await Promise.all([
    db.module.findMany({ where: { courseId: { in: courseIds } }, select: { id: true, courseId: true } }),
    db.enrollment.findMany({
      where: { courseId: { in: courseIds } },
      orderBy: { enrolledAt: "desc" },
    }),
  ]);

  const moduleIds = modules.map((m) => m.id);
  const [lessons, progressRows] = await Promise.all([
    moduleIds.length
      ? db.lesson.findMany({ where: { moduleId: { in: moduleIds } }, select: { id: true, moduleId: true } })
      : Promise.resolve([] as { id: string; moduleId: string }[]),
    enrollments.length
      ? db.lessonProgress.findMany({
          where: { enrollmentId: { in: enrollments.map((e) => e.id) } },
          select: { enrollmentId: true, lessonId: true, completedAt: true },
        })
      : Promise.resolve([]),
  ]);

  const lessonsByModule = new Map<string, string[]>();
  for (const l of lessons) {
    const arr = lessonsByModule.get(l.moduleId) ?? [];
    arr.push(l.id);
    lessonsByModule.set(l.moduleId, arr);
  }
  const lessonIdsByCourse = new Map<string, Set<string>>();
  for (const m of modules) {
    const set = lessonIdsByCourse.get(m.courseId) ?? new Set<string>();
    for (const id of lessonsByModule.get(m.id) ?? []) set.add(id);
    lessonIdsByCourse.set(m.courseId, set);
  }
  const moduleCourse = new Map(modules.map((m) => [m.id, m.courseId]));

  // per-enrollment done set + last activity
  const doneByEnrollment = new Map<string, Set<string>>();
  const lastActivity = new Map<string, Date>();
  for (const p of progressRows) {
    const set = doneByEnrollment.get(p.enrollmentId) ?? new Set<string>();
    set.add(p.lessonId);
    doneByEnrollment.set(p.enrollmentId, set);
    const prev = lastActivity.get(p.enrollmentId);
    if (!prev || p.completedAt > prev) lastActivity.set(p.enrollmentId, p.completedAt);
  }

  const lessonCourse = new Map<string, string | undefined>(
    lessons.map((l) => [l.id, moduleCourse.get(l.moduleId)])
  );

  const enrollmentOut = enrollments.map((e) => {
    const total = e.courseId ? lessonIdsByCourse.get(e.courseId)?.size ?? 0 : 0;
    const doneSet = doneByEnrollment.get(e.id);
    const lessonsDone = doneSet
      ? [...doneSet].filter((id) => lessonCourse.get(id) === e.courseId).length
      : 0;
    return {
      id: e.id,
      learnerName: e.learnerName,
      courseId: e.courseId,
      batchName: e.batchName,
      status: e.status,
      progress: e.progress,
      enrolledAt: e.enrolledAt,
      lessonsDone,
      lessonsTotal: total,
      lastActivityAt: lastActivity.get(e.id) ?? null,
    };
  });

  const out = courses
    .map((c) => {
      const list = enrollmentOut.filter((e) => e.courseId === c.id);
      const avgProgress = list.length
        ? Math.round(list.reduce((s, e) => s + e.progress, 0) / list.length)
        : 0;
      return {
        id: c.id,
        title: c.title,
        status: c.status,
        icon: c.icon,
        thumbnail: c.thumbnail,
        avgProgress,
        learners: list.length,
        completed: list.filter((e) => e.status === "COMPLETED").length,
        enrollments: list,
      };
    })
    .filter((c) => c.learners > 0);

  const all = enrollmentOut;
  return ok({
    courses: out,
    stats: {
      learners: all.length,
      avgProgress: all.length ? Math.round(all.reduce((s, e) => s + e.progress, 0) / all.length) : 0,
      completed: all.filter((e) => e.status === "COMPLETED").length,
    },
  });
}
