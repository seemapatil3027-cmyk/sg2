import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/password";
import { roleLabel, ROLE_KEYS } from "@/lib/rbac";
import {
  ok,
  fail,
  guard,
  parseBody,
  pageParams,
  paginated,
  audit,
  notify,
} from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/** GET /api/admin/users — paginated directory (admin.users.view).
 * Query: page, pageSize, q (name/email contains), role, sort=createdAt|name, dir. */
export async function GET(req: NextRequest) {
  const g = await guard("admin.users.view");
  if (g.response) return g.response;

  const p = pageParams(req, 20, 100);
  const role = req.nextUrl.searchParams.get("role")?.trim() || null;

  const where: Record<string, unknown> = {};
  if (p.q) {
    where.OR = [{ name: { contains: p.q } }, { email: { contains: p.q } }];
  }
  if (role) where.role = role;

  const orderBy =
    p.sort === "name" ? { name: p.dir } : p.sort === "email" ? { email: p.dir } : { createdAt: p.dir };

  const [rows, total] = await Promise.all([
    db.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        phone: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
      },
      orderBy,
      skip: p.skip,
      take: p.pageSize,
    }),
    db.user.count({ where }),
  ]);

  // Platform-wide stats for the KPI row.
  const [totalUsers, activeUsers, adminCount, superAdminCount, roleGroups] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { isActive: true } }),
    db.user.count({ where: { role: "ADMIN", isActive: true } }),
    db.user.count({ where: { role: "SUPER_ADMIN", isActive: true } }),
    db.user.groupBy({ by: ["role"], where: { isActive: true } }),
  ]);

  return ok({
    ...paginated(
      rows.map((u) => ({ ...u, roleLabel: roleLabel(u.role) })),
      total,
      p
    ),
    stats: {
      total: totalUsers,
      active: activeUsers,
      admins: adminCount + superAdminCount,
      roles: roleGroups.length,
    },
  });
}

const createSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email"),
  password: z.string().min(8, "Password must be at least 8 characters").max(128),
  role: z.enum(ROLE_KEYS),
  phone: z.string().trim().max(20).optional().nullable(),
});

/** POST /api/admin/users — create a staff account (admin.users.manage). */
export async function POST(req: NextRequest) {
  const g = await guard("admin.users.manage");
  if (g.response) return g.response;

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const { name, email, password, role, phone } = parsed.data;

  const existing = await db.user.findUnique({ where: { email }, select: { id: true } });
  if (existing) return fail("A user with this email already exists.", 409);

  const user = await db.user.create({
    data: {
      name,
      email,
      passwordHash: hashPassword(password),
      role,
      phone: phone || null,
      isActive: true,
    },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      phone: true,
      isActive: true,
      lastLoginAt: true,
      createdAt: true,
    },
  });

  await audit(
    g.guard.session,
    "user.create",
    "User",
    user.id,
    `Created ${roleLabel(role)} account for ${email}`,
    { role, email, name }
  );

  await notify(user.id, "Your SkillGorila account is ready", {
    body: `Welcome ${user.name}! Sign in with the password shared by your administrator.`,
    type: "SUCCESS",
    link: "/dashboard",
  });

  return ok({ ...user, roleLabel: roleLabel(user.role) }, 201);
}
