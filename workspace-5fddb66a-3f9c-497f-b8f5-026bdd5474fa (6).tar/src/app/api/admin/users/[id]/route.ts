import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { roleLabel } from "@/lib/rbac";
import { ok, fail, guard, parseBody, audit, notify } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z
  .object({
    name: z.string().trim().min(2, "Name must be at least 2 characters").max(80).optional(),
    phone: z.string().trim().max(20).optional().nullable(),
    role: z.enum(["SUPER_ADMIN", "ADMIN", "CRM_MANAGER", "CRM_EXECUTIVE", "LMS_MANAGER", "INSTRUCTOR", "EMPLOYEE"]).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, { message: "Nothing to update." });

/** PATCH /api/admin/users/:id — edit profile / role / active (admin.users.manage). */
export async function PATCH(req: NextRequest, ctx: Ctx) {
  const g = await guard("admin.users.manage");
  if (g.response) return g.response;

  const { id } = await ctx.params;
  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const data = parsed.data;

  const target = await db.user.findUnique({ where: { id } });
  if (!target) return fail("User not found.", 404);

  const isSelf = target.id === g.guard.session.uid;
  if (isSelf && (data.role !== undefined || data.isActive === false)) {
    return fail("You cannot change your own role or deactivate yourself.", 400);
  }

  if (target.role === "SUPER_ADMIN" && target.isActive && (data.role !== undefined || data.isActive === false)) {
    const activeSuperAdmins = await db.user.count({
      where: { role: "SUPER_ADMIN", isActive: true },
    });
    if (activeSuperAdmins <= 1) {
      return fail("There must be at least one active Super Admin.", 400);
    }
  }

  const user = await db.user.update({
    where: { id },
    data: {
      ...(data.name !== undefined ? { name: data.name } : {}),
      ...(data.phone !== undefined ? { phone: data.phone || null } : {}),
      ...(data.role !== undefined ? { role: data.role } : {}),
      ...(data.isActive !== undefined ? { isActive: data.isActive } : {}),
    },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      phone: true,
      isActive: true,
      lastLoginAt: true,
      createdAt: true,
    },
  });

  // Audit summary of changed fields ("role: ADMIN → CRM_MANAGER").
  const changes: string[] = [];
  if (data.name !== undefined && data.name !== target.name) changes.push(`name: ${target.name} → ${data.name}`);
  if (data.role !== undefined && data.role !== target.role)
    changes.push(`role: ${roleLabel(target.role)} → ${roleLabel(data.role)}`);
  if (data.isActive !== undefined && data.isActive !== target.isActive)
    changes.push(`active: ${target.isActive ? "Yes" : "No"} → ${data.isActive ? "Yes" : "No"}`);
  if (data.phone !== undefined && (data.phone || null) !== target.phone)
    changes.push(`phone: ${target.phone ?? "—"} → ${data.phone || "—"}`);

  await audit(
    g.guard.session,
    "user.update",
    "User",
    user.id,
    changes.length ? `Updated ${user.email} (${changes.join("; ")})` : `Updated ${user.email}`,
    { changes, ...(data.role ? { role: data.role } : {}) }
  );

  if (data.role !== undefined && data.role !== target.role) {
    await notify(user.id, "Your role was updated", {
      body: `Your SkillGorila role is now ${roleLabel(data.role)}. Sign out and back in to refresh your access.`,
      type: "INFO",
      link: "/dashboard",
    });
  }

  return ok({ ...user, roleLabel: roleLabel(user.role) });
}

/** DELETE /api/admin/users/:id — remove a staff account (admin.users.manage). */
export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const g = await guard("admin.users.manage");
  if (g.response) return g.response;

  const { id } = await ctx.params;
  const target = await db.user.findUnique({ where: { id } });
  if (!target) return fail("User not found.", 404);

  if (target.id === g.guard.session.uid) return fail("You cannot delete your own account.", 400);

  if (target.role === "SUPER_ADMIN" && target.isActive) {
    const activeSuperAdmins = await db.user.count({
      where: { role: "SUPER_ADMIN", isActive: true },
    });
    if (activeSuperAdmins <= 1) {
      return fail("There must be at least one active Super Admin.", 400);
    }
  }

  await db.user.delete({ where: { id } });

  await audit(
    g.guard.session,
    "user.delete",
    "User",
    id,
    `Deleted ${roleLabel(target.role)} account ${target.email}`,
    { role: target.role, email: target.email, name: target.name }
  );

  return ok({ id });
}
