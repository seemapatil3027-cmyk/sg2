import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, guard, pageParams, paginated, dateOrNull } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/** GET /api/admin/audit — paginated audit trail (admin.audit.view).
 * Query: page, pageSize, q (actor email contains), action (prefix, e.g. "lead."),
 * entity, from, to (ISO dates), sort ignored (newest first). */
export async function GET(req: NextRequest) {
  const g = await guard("admin.audit.view");
  if (g.response) return g.response;

  const p = pageParams(req, 20, 100);
  const sp = req.nextUrl.searchParams;
  const action = sp.get("action")?.trim() || null;
  const entity = sp.get("entity")?.trim() || null;
  const from = dateOrNull(sp.get("from"));
  const to = dateOrNull(sp.get("to"));

  const where: Record<string, unknown> = {};
  if (p.q) where.actorEmail = { contains: p.q };
  if (action) where.action = { startsWith: action };
  if (entity) where.entity = entity;
  if (from || to) {
    where.createdAt = {
      ...(from ? { gte: from } : {}),
      ...(to ? { lte: to } : {}),
    };
  }

  const [rows, total, actionRows] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: p.skip,
      take: p.pageSize,
    }),
    db.auditLog.count({ where }),
    db.auditLog.findMany({
      select: { action: true },
      distinct: ["action"],
      orderBy: { action: "asc" },
    }),
  ]);

  return ok({
    ...paginated(rows, total, p),
    actions: actionRows.map((r) => r.action).sort(),
  });
}
