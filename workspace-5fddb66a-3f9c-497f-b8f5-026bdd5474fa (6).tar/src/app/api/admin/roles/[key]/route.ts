import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ALL_PERMISSIONS, ALL_PERMISSION_KEYS } from "@/lib/rbac";
import { invalidateRoleCache } from "@/lib/rbac-server";
import { ok, fail, guard, parseBody, audit } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ key: string }> };

const putSchema = z.object({
  permissions: z.array(z.string().min(1)).max(64),
  name: z.string().trim().min(2).max(60).optional(),
  description: z.string().trim().max(200).optional(),
});

/** PUT /api/admin/roles/:key — update a role's permission matrix (admin.roles.manage). */
export async function PUT(req: NextRequest, ctx: Ctx) {
  const g = await guard("admin.roles.manage");
  if (g.response) return g.response;

  const { key } = await ctx.params;
  const parsed = await parseBody(req, putSchema);
  if (parsed.response) return parsed.response;
  const { permissions, name, description } = parsed.data;

  const role = await db.role.findUnique({ where: { key } });
  if (!role) return fail("Role not found.", 404);

  if (role.key === "SUPER_ADMIN") {
    return fail("Super Admin always keeps full wildcard access and cannot be edited.", 422);
  }

  const valid = new Set<string>([ALL_PERMISSIONS, ...ALL_PERMISSION_KEYS]);
  const invalid = permissions.filter((p) => !valid.has(p));
  if (invalid.length) {
    return fail(`Unknown permission key(s): ${invalid.slice(0, 4).join(", ")}`, 422);
  }

  // De-duplicate while preserving catalog order.
  const ordered = ALL_PERMISSION_KEYS.filter((k) => permissions.includes(k));

  const updated = await db.role.update({
    where: { key },
    data: {
      permissions: JSON.stringify(ordered),
      ...(name !== undefined ? { name } : {}),
      ...(description !== undefined ? { description } : {}),
    },
  });

  invalidateRoleCache();

  await audit(
    g.guard.session,
    "roles.update",
    "Role",
    role.id,
    `${ordered.length} permissions for ${updated.name}`,
    { role: role.key, permissions: ordered }
  );

  const holders = await db.user.findMany({
    where: { role: role.key, isActive: true },
    select: { id: true },
  });
  if (holders.length) {
    await db.notification.createMany({
      data: holders.map((u) => ({
        userId: u.id,
        title: "Your role's permissions were updated",
        body: `The ${updated.name} role was changed by ${g.guard.session.name}. Refresh to see your new access.`,
        type: "WARNING",
        link: "/dashboard",
      })),
    });
  }

  return ok({
    id: updated.id,
    key: updated.key,
    name: updated.name,
    description: updated.description,
    permissions: ordered,
    isSystem: updated.isSystem,
    order: updated.order,
  });
}
