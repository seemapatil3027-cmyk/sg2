import { db } from "@/lib/db";
import {
  PERMISSION_CATALOG,
  ALL_PERMISSION_KEYS,
  DEFAULT_ROLES,
  LEGACY_ROLE_MAP,
} from "@/lib/rbac";
import { ok, guard } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/** GET /api/admin/roles — full permission matrix (admin.roles.view).
 * Returns every role ordered by `order` with parsed permissions, per-role
 * user counts, the permission catalog and the full permission key list. */
export async function GET() {
  const g = await guard("admin.roles.view");
  if (g.response) return g.response;

  const [roles, users] = await Promise.all([
    db.role.findMany({ orderBy: { order: "asc" } }),
    db.user.groupBy({ by: ["role"], where: { isActive: true }, _count: { _all: true } }),
  ]);

  const countByRole = new Map(users.map((u) => [u.role, u._count._all]));
  const legacyCounts = users.filter((u) => LEGACY_ROLE_MAP[u.role]);
  for (const legacy of legacyCounts) {
    const canonical = LEGACY_ROLE_MAP[legacy.role];
    countByRole.set(canonical, (countByRole.get(canonical) ?? 0) + legacy._count._all);
  }

  const known = new Set(roles.map((r) => r.key));
  // Bootstrap safety: DEFAULT_ROLES cover roles missing from the DB.
  const fallback = DEFAULT_ROLES.filter((d) => !known.has(d.key)).map((d) => ({
    id: `default-${d.key}`,
    key: d.key,
    name: d.name,
    description: d.description,
    permissions: JSON.stringify(d.permissions),
    isSystem: true,
    order: d.order,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));

  const items = [...roles, ...fallback]
    .sort((a, b) => a.order - b.order)
    .map((r) => {
      let permissions: string[] = [];
      try {
        permissions = JSON.parse(r.permissions) as string[];
      } catch {
        permissions = [];
      }
      return {
        id: r.id,
        key: r.key,
        name: r.name,
        description: r.description,
        permissions,
        isSystem: r.isSystem,
        order: r.order,
        userCount: countByRole.get(r.key) ?? 0,
      };
    });

  return ok({ items, catalog: PERMISSION_CATALOG, allKeys: ALL_PERMISSION_KEYS });
}
