import { NextRequest, NextResponse } from "next/server";
import { getFaqs } from "@/lib/data";

export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get("category") || undefined;
  const faqs = await getFaqs(category);
  return NextResponse.json({ faqs });
}
