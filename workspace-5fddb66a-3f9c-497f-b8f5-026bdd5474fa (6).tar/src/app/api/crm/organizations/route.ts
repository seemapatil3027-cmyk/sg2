import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, guard, parseBody, pageParams, paginated, audit } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/organizations — paginated list + ?basic=1 picker feed ────
 * Query: q (name/domain/city), page, pageSize, basic=1.
 * Includes contacts count + open deals value per organization. */
export async function GET(req: NextRequest) {
  const g = await guard("crm.organizations.view");
  if (g.response) return g.response;

  const sp = req.nextUrl.searchParams;

  if (sp.get("basic")) {
    const orgs = await db.organization.findMany({
      select: { id: true, name: true },
      orderBy: { name: "asc" },
      take: 500,
    });
    return ok({ items: orgs });
  }

  const p = pageParams(req, 12, 500);
  const and: Record<string, unknown>[] = [];
  if (p.q) {
    and.push({
      OR: [
        { name: { contains: p.q } },
        { domain: { contains: p.q } },
        { city: { contains: p.q } },
        { industry: { contains: p.q } },
      ],
    });
  }
  const where: Record<string, unknown> = and.length ? { AND: and } : {};

  const [rows, total, contactGroups, dealGroups, owners] = await Promise.all([
    db.organization.findMany({ where, orderBy: { name: "asc" }, skip: p.skip, take: p.pageSize }),
    db.organization.count({ where }),
    db.contact.groupBy({ by: ["organizationId"], where: { organizationId: { not: null } }, _count: { _all: true } }),
    db.deal.groupBy({
      by: ["organizationId"],
      where: { status: "OPEN", organizationId: { not: null } },
      _count: { _all: true },
      _sum: { value: true },
    }),
    db.user.findMany({ select: { id: true, name: true } }),
  ]);

  const contactCounts = new Map(contactGroups.map((c) => [c.organizationId ?? "", c._count._all]));
  const openDealsValue = new Map(dealGroups.map((d) => [d.organizationId ?? "", d._sum.value ?? 0]));
  const openDealsCount = new Map(dealGroups.map((d) => [d.organizationId ?? "", d._count._all]));
  const userNames = new Map(owners.map((u) => [u.id, u.name]));

  return ok({
    ...paginated(
      rows.map((o) => ({
        ...o,
        ownerName: o.ownerId ? userNames.get(o.ownerId) ?? null : null,
        contactsCount: contactCounts.get(o.id) ?? 0,
        openDealsValue: openDealsValue.get(o.id) ?? 0,
        openDealsCount: openDealsCount.get(o.id) ?? 0,
      })),
      total,
      p
    ),
  });
}

/* ── POST /api/crm/organizations — create (crm.organizations.manage) ─────── */
const createSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(120),
  domain: z.string().trim().max(120).optional().nullable(),
  industry: z.string().trim().max(80).optional().nullable(),
  size: z.enum(["1-10", "11-50", "51-200", "201-1000", "1000+"]).optional().nullable(),
  city: z.string().trim().max(60).optional().nullable(),
  phone: z.string().trim().max(20).optional().nullable(),
  website: z.string().trim().max(200).optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
  ownerId: z.string().trim().optional().nullable(),
});

export async function POST(req: NextRequest) {
  const g = await guard("crm.organizations.manage");
  if (g.response) return g.response;
  const { session } = g.guard;

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  let ownerId: string | null = null;
  if (b.ownerId) {
    const owner = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true } });
    if (!owner) return fail("Selected owner does not exist.", 422);
    ownerId = owner.id;
  }

  const org = await db.organization.create({
    data: {
      name: b.name,
      domain: b.domain || null,
      industry: b.industry || null,
      size: b.size ?? null,
      city: b.city || null,
      phone: b.phone || null,
      website: b.website || null,
      notes: b.notes || null,
      ownerId,
    },
  });

  await audit(session, "organization.create", "Organization", org.id, `Created organization ${org.name}`);
  return ok(org, 201);
}
