import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, guard, parseBody, audit } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/organizations/[id] — org + contacts + deals + timeline ─── */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.organizations.view");
  if (g.response) return g.response;
  const { id } = await params;

  const organization = await db.organization.findUnique({ where: { id } });
  if (!organization) return fail("Organization not found.", 404);

  const [contacts, deals, activities, owner] = await Promise.all([
    db.contact.findMany({
      where: { organizationId: id },
      select: { id: true, name: true, email: true, phone: true, title: true, lifecycle: true },
      orderBy: { name: "asc" },
    }),
    db.deal.findMany({ where: { organizationId: id }, orderBy: { createdAt: "desc" } }),
    db.activity.findMany({ where: { organizationId: id }, orderBy: { createdAt: "desc" }, take: 100 }),
    organization.ownerId
      ? db.user.findUnique({
          where: { id: organization.ownerId },
          select: { id: true, name: true, email: true },
        })
      : Promise.resolve(null),
  ]);

  const contactIds = contacts.map((c) => c.id);
  const contactNames = new Map(contacts.map((c) => [c.id, c.name]));

  const openValue = deals
    .filter((d) => d.status === "OPEN")
    .reduce((sum, d) => sum + d.value, 0);
  const wonValue = deals
    .filter((d) => d.status === "WON")
    .reduce((sum, d) => sum + d.value, 0);

  return ok({
    organization,
    owner,
    contacts,
    deals: deals.map((d) => ({
      id: d.id,
      title: d.title,
      value: d.value,
      stage: d.stage,
      status: d.status,
      contactId: d.contactId,
      contactName: d.contactId ? contactNames.get(d.contactId) ?? null : null,
      expectedCloseAt: d.expectedCloseAt,
    })),
    activities,
    stats: {
      contactsCount: contacts.length,
      openDealsValue: openValue,
      wonDealsValue: wonValue,
      totalDeals: deals.length,
      /** contactIds exposed so the UI can link / filter where needed */
      contactIds,
    },
  });
}

/* ── PATCH /api/crm/organizations/[id] — edit (crm.organizations.manage) ─── */
const patchSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  domain: z.string().trim().max(120).optional().nullable(),
  industry: z.string().trim().max(80).optional().nullable(),
  size: z.enum(["1-10", "11-50", "51-200", "201-1000", "1000+"]).optional().nullable(),
  city: z.string().trim().max(60).optional().nullable(),
  phone: z.string().trim().max(20).optional().nullable(),
  website: z.string().trim().max(200).optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
  ownerId: z.string().trim().optional().nullable(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.organizations.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  const organization = await db.organization.findUnique({ where: { id } });
  if (!organization) return fail("Organization not found.", 404);

  const data: Record<string, unknown> = {};
  for (const field of ["name", "industry", "city", "phone", "website"] as const) {
    if (b[field] !== undefined) data[field] = b[field];
  }
  for (const field of ["domain", "notes"] as const) {
    if (b[field] !== undefined) data[field] = b[field] || null;
  }
  if (b.size !== undefined) data.size = b.size ?? null;
  if (b.ownerId !== undefined) {
    if (!b.ownerId) data.ownerId = null;
    else {
      const user = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true } });
      if (!user) return fail("Selected owner does not exist.", 422);
      data.ownerId = user.id;
    }
  }

  if (Object.keys(data).length === 0) return ok(organization);

  const updated = await db.organization.update({ where: { id }, data });
  await audit(session, "organization.update", "Organization", id, `Updated organization ${updated.name}`, {
    fields: Object.keys(data),
  });
  return ok(updated);
}

/* ── DELETE /api/crm/organizations/[id] (crm.organizations.manage) ───────── */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.organizations.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const organization = await db.organization.findUnique({ where: { id } });
  if (!organization) return fail("Organization not found.", 404);

  const [contacts, deals] = await Promise.all([
    db.contact.count({ where: { organizationId: id } }),
    db.deal.count({ where: { organizationId: id } }),
  ]);
  if (contacts > 0 || deals > 0) {
    return fail(
      `This organization still has ${contacts} contact(s) and ${deals} deal(s). Reassign or remove them first.`,
      409
    );
  }

  await db.$transaction([
    db.activity.deleteMany({ where: { organizationId: id } }),
    db.organization.delete({ where: { id } }),
  ]);

  await audit(session, "organization.delete", "Organization", id, `Deleted organization ${organization.name}`);
  return ok({ deleted: true });
}
