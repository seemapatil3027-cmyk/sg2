import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Activity types that can be logged manually via this endpoint. */
const ACTIVITY_TYPES = [
  "note",
  "call",
  "whatsapp",
  "email",
  "followup",
  "demo",
  "counselling",
  "brochure",
  "payment_link",
] as const;

type ActivityBody = {
  type?: unknown;
  title?: unknown;
  detail?: unknown;
  nextFollowUpAt?: unknown;
};

/**
 * POST /api/crm/leads/[id]/activities
 * Body: { type: note|call|whatsapp|email|followup|demo|counselling|brochure|payment_link,
 *         title: string, detail?: string, nextFollowUpAt?: ISO string|null }
 *
 * Auth: same as PATCH /api/crm/leads/[id] — ADMIN any lead, COUNSELLOR own or
 * unassigned leads. Creates a LeadActivity (createdBy = session email).
 * For followup activities an optional nextFollowUpAt also updates the lead.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (user.role !== "ADMIN" && user.role !== "COUNSELLOR") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }

    const body = (await req.json().catch(() => null)) as ActivityBody | null;
    if (!body || typeof body !== "object") {
      return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
    }

    const lead = await db.lead.findUnique({ where: { id } });
    if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

    if (user.role === "COUNSELLOR" && lead.assignedTo !== user.email && lead.assignedTo !== null) {
      return NextResponse.json({ error: "This lead is assigned to another counsellor" }, { status: 403 });
    }

    const type = typeof body.type === "string" ? body.type.trim() : "";
    if (!(ACTIVITY_TYPES as readonly string[]).includes(type)) {
      return NextResponse.json(
        { error: `Invalid activity type. Must be one of: ${ACTIVITY_TYPES.join(", ")}` },
        { status: 400 }
      );
    }

    const title = typeof body.title === "string" ? body.title.trim() : "";
    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }
    const detail =
      typeof body.detail === "string" && body.detail.trim().length > 0 ? body.detail.trim() : null;

    /* ---- optional follow-up scheduling alongside a followup activity ---- */
    let nextFollowUpUpdate: { nextFollowUpAt: Date | null } | null = null;
    if (type === "followup" && body.nextFollowUpAt !== undefined) {
      if (body.nextFollowUpAt === null || body.nextFollowUpAt === "") {
        nextFollowUpUpdate = { nextFollowUpAt: null };
      } else if (typeof body.nextFollowUpAt === "string") {
        const date = new Date(body.nextFollowUpAt);
        if (Number.isNaN(date.getTime())) {
          return NextResponse.json({ error: "nextFollowUpAt must be a valid ISO date string or null" }, { status: 400 });
        }
        nextFollowUpUpdate = { nextFollowUpAt: date };
      } else {
        return NextResponse.json({ error: "nextFollowUpAt must be an ISO date string or null" }, { status: 400 });
      }
    }

    const activity = await db.leadActivity.create({
      data: {
        leadId: lead.id,
        type,
        title,
        detail,
        createdBy: user.email,
      },
    });

    if (nextFollowUpUpdate) {
      await db.lead.update({ where: { id: lead.id }, data: nextFollowUpUpdate });
    }

    return NextResponse.json({ ok: true, activity });
  } catch (err) {
    console.error("POST /api/crm/leads/[id]/activities failed", err);
    return NextResponse.json({ error: "Failed to log activity. Please try again." }, { status: 500 });
  }
}
