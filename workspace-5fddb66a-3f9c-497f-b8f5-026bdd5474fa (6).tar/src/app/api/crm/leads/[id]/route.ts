import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  ok,
  fail,
  forbidden,
  guard,
  parseBody,
  audit,
  notify,
  dateOrNull,
} from "@/lib/api-helpers";
import { LEAD_STATUS_LABELS, isCrmWideRole, normalizeLeadStatus } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/** Visibility rule: managers see everything; executives see their own leads
 * plus unassigned ones (claimable). */
function canSeeLead(
  role: string,
  uid: string,
  lead: { ownerId: string | null }
): boolean {
  if (isCrmWideRole(role)) return true;
  return lead.ownerId === null || lead.ownerId === uid;
}

/* ── GET /api/crm/leads/[id] — lead + owner + activity timeline ──────────── */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.leads.view");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const lead = await db.lead.findUnique({ where: { id } });
  if (!lead) return fail("Lead not found.", 404);
  if (!canSeeLead(session.role, session.uid, lead)) return forbidden("crm.leads.view");

  const [owner, activities, contact] = await Promise.all([
    lead.ownerId
      ? db.user.findUnique({
          where: { id: lead.ownerId },
          select: { id: true, name: true, email: true },
        })
      : Promise.resolve(null),
    db.activity.findMany({ where: { leadId: id }, orderBy: { createdAt: "desc" }, take: 100 }),
    lead.contactId
      ? db.contact.findUnique({
          where: { id: lead.contactId },
          select: { id: true, name: true, email: true, lifecycle: true },
        })
      : Promise.resolve(null),
  ]);

  return ok({ lead, owner, contact, activities });
}

/* ── PATCH /api/crm/leads/[id] — edit, assign, stage moves (crm.leads.manage) */
const patchSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  email: z.string().trim().toLowerCase().email().optional(),
  phone: z.string().trim().min(5).max(20).optional(),
  source: z.string().trim().min(2).max(40).optional(),
  note: z.string().trim().max(2000).optional().nullable(),
  city: z.string().trim().max(60).optional().nullable(),
  education: z.string().trim().max(120).optional().nullable(),
  experience: z.string().trim().max(60).optional().nullable(),
  program: z.string().trim().max(160).optional().nullable(),
  mode: z.enum(["online", "classroom", "hybrid"]).optional().nullable(),
  score: z.number().int().min(0).max(100).optional(),
  status: z.string().trim().optional(),
  ownerId: z.string().trim().optional().nullable(),
  nextFollowUpAt: z.string().optional().nullable(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.leads.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  const lead = await db.lead.findUnique({ where: { id } });
  if (!lead) return fail("Lead not found.", 404);
  if (!canSeeLead(session.role, session.uid, lead)) return forbidden("crm.leads.manage");

  const data: Record<string, unknown> = {};
  for (const field of ["name", "email", "phone", "source", "city", "education", "experience", "program"] as const) {
    if (b[field] !== undefined) data[field] = b[field];
  }
  for (const field of ["note"] as const) {
    if (b[field] !== undefined) data[field] = b[field] || null;
  }
  if (b.mode !== undefined) data.mode = b.mode ?? null;
  if (b.score !== undefined) data.score = b.score;

  /* nextFollowUpAt — ISO string or null to clear */
  if (b.nextFollowUpAt !== undefined) {
    if (b.nextFollowUpAt === null || b.nextFollowUpAt === "") data.nextFollowUpAt = null;
    else {
      const d = dateOrNull(b.nextFollowUpAt);
      if (!d) return fail("nextFollowUpAt must be a valid date string or null.", 422);
      data.nextFollowUpAt = d;
    }
  }

  /* status — normalized; stage change is logged on the timeline */
  let newStatus: string | null = null;
  if (b.status !== undefined) {
    newStatus = normalizeLeadStatus(b.status);
    if (newStatus !== normalizeLeadStatus(lead.status)) data.status = newStatus;
  }

  /* ownerId — reassignment is logged + the new owner is notified */
  let newOwner: { id: string; name: string } | null | undefined;
  if (b.ownerId !== undefined) {
    if (b.ownerId === null || b.ownerId === "") {
      if (lead.ownerId) {
        data.ownerId = null;
        newOwner = null;
      }
    } else {
      const user = await db.user.findUnique({
        where: { id: b.ownerId },
        select: { id: true, name: true },
      });
      if (!user) return fail("Selected owner does not exist.", 422);
      if (user.id !== lead.ownerId) {
        data.ownerId = user.id;
        newOwner = user;
      }
    }
  }

  if (Object.keys(data).length === 0) {
    return ok({ lead });
  }

  const updated = await db.$transaction(async (tx) => {
    const saved = await tx.lead.update({ where: { id }, data });

    if (newStatus) {
      await tx.activity.create({
        data: {
          type: "STAGE_CHANGE",
          subject: `Stage: ${LEAD_STATUS_LABELS[normalizeLeadStatus(lead.status)]} → ${LEAD_STATUS_LABELS[normalizeLeadStatus(newStatus)]}`,
          status: "COMPLETED",
          completedAt: new Date(),
          leadId: id,
          ownerId: saved.ownerId,
          createdBy: session.email,
        },
      });
    }
    if (newOwner !== undefined) {
      await tx.activity.create({
        data: {
          type: "NOTE",
          subject: newOwner ? `Assigned to ${newOwner.name}` : "Owner unassigned",
          status: "COMPLETED",
          completedAt: new Date(),
          leadId: id,
          ownerId: saved.ownerId,
          createdBy: session.email,
        },
      });
    }
    return saved;
  });

  if (newStatus) {
    await audit(session, "lead.stage", "Lead", id, `Lead ${updated.name}: stage → ${newStatus}`);
  }
  if (newOwner !== undefined) {
    await audit(
      session,
      "lead.assign",
      "Lead",
      id,
      `Lead ${updated.name}: owner → ${newOwner ? newOwner.name : "unassigned"}`
    );
    if (newOwner && newOwner.id !== session.uid) {
      await notify(newOwner.id, "A lead was assigned to you", {
        body: `${updated.name} (${updated.email}).`,
        type: "LEAD",
        link: "/crm/leads",
      });
    }
  }
  await audit(session, "lead.update", "Lead", id, `Updated lead ${updated.name}`, {
    fields: Object.keys(data),
  });

  return ok(updated);
}

/* ── DELETE /api/crm/leads/[id] — only pre-conversion leads ──────────────── */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.leads.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const lead = await db.lead.findUnique({ where: { id } });
  if (!lead) return fail("Lead not found.", 404);
  if (!canSeeLead(session.role, session.uid, lead)) return forbidden("crm.leads.manage");
  if (lead.contactId) {
    return fail("This lead was already converted to a customer and cannot be deleted.", 409);
  }

  await db.$transaction([
    db.activity.deleteMany({ where: { leadId: id } }),
    db.lead.delete({ where: { id } }),
  ]);

  await audit(session, "lead.delete", "Lead", id, `Deleted lead ${lead.name} (${lead.email})`);
  return ok({ deleted: true });
}
