import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  ok,
  fail,
  forbidden,
  guard,
  parseBody,
  audit,
  notifyPermission,
  dateOrNull,
  inr,
} from "@/lib/api-helpers";
import { isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/**
 * POST /api/crm/leads/[id]/convert (crm.leads.manage)
 * Body: { createDeal?: { title?, value?, expectedCloseAt? },
 *         enrollCourseId?: string, batchName?: string, paymentAmount?: number }
 *
 * In ONE transaction: creates the Customer Contact from the lead, flips the
 * lead to CONVERTED, writes CONVERTED activities on lead + contact, and
 * optionally opens a Deal (stage PROPOSAL) and/or creates the LMS Enrollment
 * (+ PAID Payment). Returns { contactId, dealId?, enrollmentId? }.
 */
const convertSchema = z.object({
  createDeal: z
    .object({
      title: z.string().trim().min(2).max(140).optional(),
      value: z.number().int().min(0).max(1_000_000_000).optional(),
      expectedCloseAt: z.string().optional().nullable(),
    })
    .optional(),
  enrollCourseId: z.string().trim().min(1).optional(),
  batchName: z.string().trim().min(1).max(60).optional(),
  paymentAmount: z.number().int().min(1).max(1_000_000_000).optional(),
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.leads.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const parsed = await parseBody(req, convertSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  const lead = await db.lead.findUnique({ where: { id } });
  if (!lead) return fail("Lead not found.", 404);
  if (!isCrmWideRole(session.role) && lead.ownerId !== null && lead.ownerId !== session.uid) {
    return forbidden("crm.leads.manage");
  }
  if (lead.contactId || lead.status === "CONVERTED" || lead.status === "Enrolled") {
    return fail("This lead has already been converted to a customer.", 409);
  }
  if (b.paymentAmount && !b.enrollCourseId) {
    return fail("paymentAmount requires enrollCourseId — record it against the new enrollment.", 422);
  }

  // Validate external references up front for clean 4xx responses.
  let course: { id: string; title: string; slug: string } | null = null;
  if (b.enrollCourseId) {
    course = await db.course.findUnique({
      where: { id: b.enrollCourseId },
      select: { id: true, title: true, slug: true },
    });
    if (!course) return fail("Selected course does not exist.", 422);
  }

  const now = new Date();
  const dealTitle =
    b.createDeal?.title?.trim() || `${lead.name}${lead.program ? ` — ${lead.program}` : " — New opportunity"}`;

  const result = await db.$transaction(async (tx) => {
    /* 1. Contact created from the lead (lifecycle CUSTOMER). */
    const contact = await tx.contact.create({
      data: {
        name: lead.name,
        email: lead.email,
        phone: lead.phone,
        source: lead.source,
        city: lead.city,
        notes: lead.note,
        ownerId: lead.ownerId,
        leadId: lead.id,
        status: "ACTIVE",
        lifecycle: "CUSTOMER",
      },
    });

    /* 2. Flip the lead. */
    await tx.lead.update({
      where: { id: lead.id },
      data: { status: "CONVERTED", contactId: contact.id, convertedAt: now },
    });

    /* 3. Optional deal (stage PROPOSAL, status OPEN). */
    let dealId: string | null = null;
    if (b.createDeal) {
      const deal = await tx.deal.create({
        data: {
          title: dealTitle,
          value: b.createDeal.value ?? 0,
          stage: "PROPOSAL",
          status: "OPEN",
          probability: 50,
          expectedCloseAt: dateOrNull(b.createDeal.expectedCloseAt),
          ownerId: lead.ownerId ?? session.uid,
          contactId: contact.id,
          leadId: lead.id,
        },
      });
      dealId = deal.id;
      await tx.activity.create({
        data: {
          type: "CONVERTED",
          subject: `Deal created from lead: ${deal.title}`,
          detail: `Value ${inr(deal.value)} · stage Proposal`,
          status: "COMPLETED",
          completedAt: now,
          dealId: deal.id,
          contactId: contact.id,
          ownerId: deal.ownerId,
          createdBy: session.email,
        },
      });
    }

    /* 4. Optional LMS enrollment (+ PAID payment). */
    let enrollmentId: string | null = null;
    if (course) {
      const enrollment = await tx.enrollment.create({
        data: {
          contactId: contact.id,
          learnerName: contact.name,
          courseId: course.id,
          itemSlug: course.slug,
          itemType: "course",
          batchName: b.batchName || null,
          status: "ACTIVE",
          progress: 0,
          sourceLeadId: lead.id,
        },
      });
      enrollmentId = enrollment.id;
      if (b.paymentAmount) {
        await tx.payment.create({
          data: {
            userId: session.uid,
            enrollmentId: enrollment.id,
            amount: b.paymentAmount,
            plan: "full",
            status: "PAID",
            method: "link",
            note: `Course fee — ${course.title} (converted from lead)`,
          },
        });
      }
      await tx.activity.create({
        data: {
          type: "ENROLLMENT",
          subject: `Enrolled in ${course.title}`,
          detail: b.batchName ? `Batch ${b.batchName}` : null,
          status: "COMPLETED",
          completedAt: now,
          contactId: contact.id,
          ownerId: lead.ownerId,
          createdBy: session.email,
        },
      });
    }

    /* 5. CONVERTED activities on the lead + contact timelines. */
    const detailBits = [
      dealId ? "Deal opened" : null,
      enrollmentId ? "LMS enrollment created" : null,
    ].filter(Boolean);
    await tx.activity.create({
      data: {
        type: "CONVERTED",
        subject: "Converted to customer",
        detail: detailBits.length ? detailBits.join(" · ") : null,
        status: "COMPLETED",
        completedAt: now,
        leadId: lead.id,
        ownerId: lead.ownerId,
        createdBy: session.email,
      },
    });
    await tx.activity.create({
      data: {
        type: "CONVERTED",
        subject: "Customer created from lead",
        detail: `Lead: ${lead.name} (${lead.source})`,
        status: "COMPLETED",
        completedAt: now,
        contactId: contact.id,
        ownerId: lead.ownerId,
        createdBy: session.email,
      },
    });

    return { contactId: contact.id, dealId, enrollmentId };
  });

  await audit(
    session,
    "lead.convert",
    "Lead",
    lead.id,
    `Converted lead ${lead.name} to customer`,
    { contactId: result.contactId, dealId: result.dealId, enrollmentId: result.enrollmentId }
  );
  await notifyPermission("crm.reports.view", "Lead converted to customer", {
    body: `${lead.name} (${lead.email}) is now a customer${result.dealId ? " — deal opened" : ""}${result.enrollmentId ? " — enrolled in LMS" : ""}.`,
    type: "SUCCESS",
    link: "/crm/contacts",
    excludeUserId: session.uid,
  });

  return ok(result, 201);
}
