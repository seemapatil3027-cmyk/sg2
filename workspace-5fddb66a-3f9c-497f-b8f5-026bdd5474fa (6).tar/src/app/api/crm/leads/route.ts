import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  ok,
  fail,
  guard,
  parseBody,
  pageParams,
  paginated,
  audit,
  notify,
  dateOrNull,
} from "@/lib/api-helpers";
import {
  LEAD_STATUSES,
  isCrmWideRole,
  normalizeLeadStatus,
  rawStatusesFor,
} from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/leads — paginated, filterable lead list ──────────────────
 * Query: q (name/email/phone contains), status (repeatable or comma list:
 * NEW|CONTACTED|QUALIFIED|CONVERTED|LOST|OPEN|MINE), owner (userId|"me"|
 * "unassigned"), page, pageSize, sort (createdAt|score|name), dir.
 * CRM_EXECUTIVE scope: own leads + unassigned. */
export async function GET(req: NextRequest) {
  const g = await guard("crm.leads.view");
  if (g.response) return g.response;
  const { session } = g.guard;

  const p = pageParams(req, 20, 500);
  const sp = p.searchParams;
  const wide = isCrmWideRole(session.role);

  /* status param: supports ?status=NEW&status=OPEN and ?status=NEW,OPEN */
  const statusParam = sp.getAll("status").flatMap((s) => s.split(","));
  const statusList = statusParam.map((s) => s.trim().toUpperCase()).filter(Boolean);
  const ownerParam = sp.get("owner")?.trim() || null;

  const baseAnd: Record<string, unknown>[] = [];
  if (!wide) baseAnd.push({ OR: [{ ownerId: session.uid }, { ownerId: null }] });
  if (p.q) {
    baseAnd.push({
      OR: [
        { name: { contains: p.q } },
        { email: { contains: p.q } },
        { phone: { contains: p.q } },
      ],
    });
  }
  if (ownerParam === "unassigned") baseAnd.push({ ownerId: null });
  else if (ownerParam === "me") baseAnd.push({ ownerId: session.uid });
  else if (ownerParam) baseAnd.push({ ownerId: ownerParam });

  const statusIn = new Set<string>();
  const statusNotIn = new Set<string>();
  const and = [...baseAnd];
  for (const s of statusList) {
    if (s === "MINE") {
      and.push({ ownerId: session.uid });
    } else if (s === "OPEN") {
      for (const raw of [...rawStatusesFor("CONVERTED"), ...rawStatusesFor("LOST")]) {
        statusNotIn.add(raw);
      }
    } else if (s) {
      for (const raw of rawStatusesFor(normalizeLeadStatus(s))) statusIn.add(raw);
    }
  }
  if (statusIn.size > 0 && statusNotIn.size > 0) {
    and.push({
      OR: [{ status: { in: [...statusIn] } }, { status: { notIn: [...statusNotIn] } }],
    });
  } else if (statusIn.size > 0) {
    and.push({ status: { in: [...statusIn] } });
  } else if (statusNotIn.size > 0) {
    and.push({ status: { notIn: [...statusNotIn] } });
  }

  const where: Record<string, unknown> = and.length ? { AND: and } : {};
  // Tab counts ignore the status filter (scope + q + owner still applied).
  const countWhere: Record<string, unknown> = baseAnd.length ? { AND: baseAnd } : {};

  const orderBy =
    p.sort === "score"
      ? { score: p.dir }
      : p.sort === "name"
        ? { name: p.dir }
        : { createdAt: p.dir };

  const [rows, total, statusGroups, newThisWeek] = await Promise.all([
    db.lead.findMany({ where, orderBy, skip: p.skip, take: p.pageSize }),
    db.lead.count({ where }),
    db.lead.groupBy({ by: ["status"], where: countWhere, _count: { _all: true } }),
    db.lead.count({
      where: { ...countWhere, createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
    }),
  ]);

  // Normalized status counts (legacy values roll up).
  const counts: Record<string, number> = { ALL: 0 };
  for (const s of LEAD_STATUSES) counts[s] = 0;
  for (const grp of statusGroups) {
    const key = normalizeLeadStatus(grp.status);
    counts[key] += grp._count._all;
    counts.ALL += grp._count._all;
  }

  const ownerIds = [...new Set(rows.map((r) => r.ownerId).filter(Boolean))] as string[];
  const users = ownerIds.length
    ? await db.user.findMany({ where: { id: { in: ownerIds } }, select: { id: true, name: true } })
    : [];
  const ownerNames: Record<string, string> = {};
  for (const u of users) ownerNames[u.id] = u.name;

  const converted = counts.CONVERTED ?? 0;
  return ok({
    ...paginated(
      rows.map((r) => ({ ...r, ownerName: r.ownerId ? ownerNames[r.ownerId] ?? null : null })),
      total,
      p
    ),
    counts,
    stats: {
      total: counts.ALL,
      newThisWeek,
      qualified: counts.QUALIFIED ?? 0,
      converted,
      lost: counts.LOST ?? 0,
      conversionRate: counts.ALL > 0 ? Math.round((converted / counts.ALL) * 100) : 0,
    },
    ownerNames,
  });
}

/* ── POST /api/crm/leads — create a lead (crm.leads.manage) ──────────────── */
const createSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email"),
  phone: z.string().trim().min(5, "Phone must be at least 5 characters").max(20),
  source: z.string().trim().min(2, "Source is required").max(40),
  note: z.string().trim().max(2000).optional().nullable(),
  city: z.string().trim().max(60).optional().nullable(),
  education: z.string().trim().max(120).optional().nullable(),
  experience: z.string().trim().max(60).optional().nullable(),
  program: z.string().trim().max(160).optional().nullable(),
  mode: z.enum(["online", "classroom", "hybrid"]).optional().nullable(),
  score: z.number().int().min(0).max(100).optional(),
  status: z.string().trim().optional(),
  ownerId: z.string().trim().optional().nullable(),
  nextFollowUpAt: z.string().optional().nullable(),
});

export async function POST(req: NextRequest) {
  const g = await guard("crm.leads.manage");
  if (g.response) return g.response;
  const { session } = g.guard;

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  let ownerId: string | null = null;
  if (b.ownerId) {
    const owner = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true } });
    if (!owner) return fail("Selected owner does not exist.", 422);
    ownerId = owner.id;
  }

  const status = b.status ? normalizeLeadStatus(b.status) : "NEW";

  const lead = await db.lead.create({
    data: {
      name: b.name,
      email: b.email,
      phone: b.phone,
      source: b.source,
      note: b.note || null,
      city: b.city || null,
      education: b.education || null,
      experience: b.experience || null,
      program: b.program || null,
      mode: b.mode ?? null,
      score: b.score ?? 0,
      status,
      ownerId,
      nextFollowUpAt: dateOrNull(b.nextFollowUpAt),
    },
  });

  await db.activity.create({
    data: {
      type: "NOTE",
      subject: "Lead created",
      detail: `Source: ${b.source}${b.program ? ` · Program: ${b.program}` : ""}`,
      status: "COMPLETED",
      completedAt: new Date(),
      leadId: lead.id,
      ownerId,
      createdBy: session.email,
    },
  });

  await audit(session, "lead.create", "Lead", lead.id, `Created lead ${lead.name} (${lead.email})`, {
    source: b.source,
    ownerId,
  });

  if (ownerId && ownerId !== session.uid) {
    await notify(ownerId, "New lead assigned to you", {
      body: `${lead.name} (${lead.email}) — source ${b.source}.`,
      type: "LEAD",
      link: "/crm/leads",
    });
  }

  return ok(lead, 201);
}
