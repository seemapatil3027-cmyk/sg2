import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, forbidden, guard, parseBody, audit, notify, notifyPermission, dateOrNull, inr } from "@/lib/api-helpers";
import { DEAL_STAGES, DEAL_STAGE_LABELS, isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/deals/[id] — deal + joined names + timeline ────────────── */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.deals.view");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const deal = await db.deal.findUnique({ where: { id } });
  if (!deal) return fail("Deal not found.", 404);
  if (!isCrmWideRole(session.role) && deal.ownerId !== session.uid) {
    return forbidden("crm.deals.view");
  }

  const [owner, contact, organization, activities] = await Promise.all([
    deal.ownerId
      ? db.user.findUnique({ where: { id: deal.ownerId }, select: { id: true, name: true, email: true } })
      : Promise.resolve(null),
    deal.contactId
      ? db.contact.findUnique({ where: { id: deal.contactId }, select: { id: true, name: true, email: true } })
      : Promise.resolve(null),
    deal.organizationId
      ? db.organization.findUnique({ where: { id: deal.organizationId }, select: { id: true, name: true } })
      : Promise.resolve(null),
    db.activity.findMany({ where: { dealId: id }, orderBy: { createdAt: "desc" }, take: 100 }),
  ]);

  return ok({ deal, owner, contact, organization, activities });
}

/* ── PATCH /api/crm/deals/[id] — edit + stage moves (crm.deals.manage) ───── */
const patchSchema = z.object({
  title: z.string().trim().min(2).max(140).optional(),
  value: z.number().int().min(0).max(1_000_000_000).optional(),
  stage: z.enum(DEAL_STAGES).optional(),
  probability: z.number().int().min(0).max(100).optional(),
  expectedCloseAt: z.string().optional().nullable(),
  lostReason: z.string().trim().max(500).optional().nullable(),
  ownerId: z.string().trim().optional().nullable(),
  contactId: z.string().trim().optional().nullable(),
  organizationId: z.string().trim().optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.deals.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  const deal = await db.deal.findUnique({ where: { id } });
  if (!deal) return fail("Deal not found.", 404);
  if (!isCrmWideRole(session.role) && deal.ownerId !== session.uid) {
    return forbidden("crm.deals.manage");
  }

  const data: Record<string, unknown> = {};
  for (const field of ["title", "probability"] as const) {
    if (b[field] !== undefined) data[field] = b[field];
  }
  if (b.value !== undefined) data.value = b.value;
  for (const field of ["notes", "lostReason"] as const) {
    if (b[field] !== undefined) data[field] = b[field] || null;
  }
  if (b.expectedCloseAt !== undefined) data.expectedCloseAt = dateOrNull(b.expectedCloseAt);
  if (b.contactId !== undefined) data.contactId = b.contactId || null;
  if (b.organizationId !== undefined) data.organizationId = b.organizationId || null;

  /* Stage moves drive status: WON/LOST close the deal, everything else
   * (re)opens it. Logged as STAGE_CHANGE on the deal timeline. */
  let stageChangedTo: string | null = null;
  if (b.stage && b.stage !== deal.stage) {
    stageChangedTo = b.stage;
    data.stage = b.stage;
    if (b.stage === "WON") {
      data.status = "WON";
      data.closedAt = new Date();
      data.probability = 100;
    } else if (b.stage === "LOST") {
      data.status = "LOST";
      data.closedAt = new Date();
      data.probability = 0;
    } else {
      data.status = "OPEN";
      data.closedAt = null;
    }
  }

  let newOwner: { id: string; name: string } | null | undefined;
  if (b.ownerId !== undefined) {
    if (!b.ownerId) {
      if (deal.ownerId) {
        data.ownerId = null;
        newOwner = null;
      }
    } else {
      const user = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true, name: true } });
      if (!user) return fail("Selected owner does not exist.", 422);
      if (user.id !== deal.ownerId) {
        data.ownerId = user.id;
        newOwner = user;
      }
    }
  }

  if (Object.keys(data).length === 0) return ok(deal);

  const updated = await db.$transaction(async (tx) => {
    const saved = await tx.deal.update({ where: { id }, data });
    if (stageChangedTo) {
      await tx.activity.create({
        data: {
          type: "STAGE_CHANGE",
          subject: `Stage: ${DEAL_STAGE_LABELS[deal.stage as keyof typeof DEAL_STAGE_LABELS] ?? deal.stage} → ${DEAL_STAGE_LABELS[stageChangedTo as keyof typeof DEAL_STAGE_LABELS] ?? stageChangedTo}`,
          detail: stageChangedTo === "WON" ? "Deal won 🎉" : stageChangedTo === "LOST" ? deal.lostReason ?? "Deal lost" : null,
          status: "COMPLETED",
          completedAt: new Date(),
          dealId: id,
          contactId: saved.contactId,
          organizationId: saved.organizationId,
          ownerId: saved.ownerId,
          createdBy: session.email,
        },
      });
    }
    return saved;
  });

  if (stageChangedTo) {
    await audit(session, "deal.stage", "Deal", id, `Deal ${updated.title}: stage → ${stageChangedTo}`, {
      from: deal.stage,
      to: stageChangedTo,
    });
    if (stageChangedTo === "WON") {
      await notifyPermission("crm.reports.view", `Deal won: ${updated.title}`, {
        body: `${updated.title} closed at ${inr(updated.value)}.`,
        type: "SUCCESS",
        link: "/crm/deals",
        excludeUserId: session.uid,
      });
    }
  }
  if (newOwner && newOwner.id !== session.uid) {
    await notify(newOwner.id, "A deal was assigned to you", {
      body: `${updated.title} — ${inr(updated.value)}.`,
      type: "DEAL",
      link: "/crm/deals",
    });
  }
  await audit(session, "deal.update", "Deal", id, `Updated deal ${updated.title}`, {
    fields: Object.keys(data),
  });

  return ok(updated);
}

/* ── DELETE /api/crm/deals/[id] (crm.deals.manage) ───────────────────────── */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.deals.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const deal = await db.deal.findUnique({ where: { id } });
  if (!deal) return fail("Deal not found.", 404);
  if (!isCrmWideRole(session.role) && deal.ownerId !== session.uid) {
    return forbidden("crm.deals.manage");
  }

  await db.$transaction([
    db.activity.deleteMany({ where: { dealId: id } }),
    db.deal.delete({ where: { id } }),
  ]);

  await audit(session, "deal.delete", "Deal", id, `Deleted deal ${deal.title}`);
  return ok({ deleted: true });
}
