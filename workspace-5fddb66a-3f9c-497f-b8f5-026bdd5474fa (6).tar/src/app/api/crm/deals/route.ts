import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  ok,
  fail,
  guard,
  parseBody,
  pageParams,
  paginated,
  audit,
  notify,
  dateOrNull,
} from "@/lib/api-helpers";
import { DEAL_STAGES, DEAL_STAGE_LABELS, isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/deals — paginated list + stage counts + pipeline value ───
 * Query: q (title/notes), stage, status, owner (userId|"me"|"unassigned"),
 * page, pageSize, sort (createdAt|value|expectedCloseAt|title), dir.
 * CRM_EXECUTIVE scope: own deals only. */
export async function GET(req: NextRequest) {
  const g = await guard("crm.deals.view");
  if (g.response) return g.response;
  const { session } = g.guard;

  const p = pageParams(req, 20, 500);
  const wide = isCrmWideRole(session.role);
  const ownerParam = p.searchParams.get("owner")?.trim() || null;

  const and: Record<string, unknown>[] = [];
  if (!wide) and.push({ ownerId: session.uid });
  if (p.q) {
    and.push({ OR: [{ title: { contains: p.q } }, { notes: { contains: p.q } }] });
  }
  const stage = p.searchParams.get("stage")?.trim().toUpperCase() || null;
  if (stage) and.push({ stage });
  const status = p.searchParams.get("status")?.trim().toUpperCase() || null;
  if (status) and.push({ status });
  if (ownerParam === "unassigned") and.push({ ownerId: null });
  else if (ownerParam === "me") and.push({ ownerId: session.uid });
  else if (ownerParam) and.push({ ownerId: ownerParam });

  const where: Record<string, unknown> = and.length ? { AND: and } : {};

  const orderBy =
    p.sort === "value"
      ? { value: p.dir }
      : p.sort === "expectedCloseAt"
        ? { expectedCloseAt: p.dir }
        : p.sort === "title"
          ? { title: p.dir }
          : { createdAt: p.dir };

  const [rows, total, stageGroups, owners, contacts, orgs] = await Promise.all([
    db.deal.findMany({ where, orderBy, skip: p.skip, take: p.pageSize }),
    db.deal.count({ where }),
    db.deal.groupBy({ by: ["stage"], where, _count: { _all: true }, _sum: { value: true } }),
    db.user.findMany({ select: { id: true, name: true } }),
    db.contact.findMany({ select: { id: true, name: true } }),
    db.organization.findMany({ select: { id: true, name: true } }),
  ]);

  const userNames = new Map(owners.map((u) => [u.id, u.name]));
  const contactNames = new Map(contacts.map((c) => [c.id, c.name]));
  const orgNames = new Map(orgs.map((o) => [o.id, o.name]));

  const stageCounts: Record<string, { count: number; value: number }> = {};
  for (const s of DEAL_STAGES) stageCounts[s] = { count: 0, value: 0 };
  let totalPipelineValue = 0;
  let openCount = 0;
  for (const grp of stageGroups) {
    const key = grp.stage;
    if (stageCounts[key]) {
      stageCounts[key] = { count: grp._count._all, value: grp._sum.value ?? 0 };
    }
    if (key !== "WON" && key !== "LOST") {
      totalPipelineValue += grp._sum.value ?? 0;
      openCount += grp._count._all;
    }
  }

  return ok({
    ...paginated(
      rows.map((d) => ({
        ...d,
        contactName: d.contactId ? contactNames.get(d.contactId) ?? null : null,
        organizationName: d.organizationId ? orgNames.get(d.organizationId) ?? null : null,
        ownerName: d.ownerId ? userNames.get(d.ownerId) ?? null : null,
      })),
      total,
      p
    ),
    stageCounts,
    stats: { totalPipelineValue, openCount },
  });
}

/* ── POST /api/crm/deals — create a deal (crm.deals.manage) ──────────────── */
const createSchema = z.object({
  title: z.string().trim().min(2, "Title must be at least 2 characters").max(140),
  value: z.number().int().min(0).max(1_000_000_000),
  contactId: z.string().trim().optional().nullable(),
  organizationId: z.string().trim().optional().nullable(),
  expectedCloseAt: z.string().optional().nullable(),
  stage: z.enum(DEAL_STAGES).optional(),
  probability: z.number().int().min(0).max(100).optional(),
  ownerId: z.string().trim().optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
});

export async function POST(req: NextRequest) {
  const g = await guard("crm.deals.manage");
  if (g.response) return g.response;
  const { session } = g.guard;

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  if (b.contactId) {
    const contact = await db.contact.findUnique({ where: { id: b.contactId }, select: { id: true } });
    if (!contact) return fail("Selected contact does not exist.", 422);
  }
  if (b.organizationId) {
    const org = await db.organization.findUnique({
      where: { id: b.organizationId },
      select: { id: true },
    });
    if (!org) return fail("Selected organization does not exist.", 422);
  }
  let ownerId: string | null = null;
  if (b.ownerId) {
    const owner = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true } });
    if (!owner) return fail("Selected owner does not exist.", 422);
    ownerId = owner.id;
  }

  const stage = b.stage ?? "NEW";
  const deal = await db.deal.create({
    data: {
      title: b.title,
      value: b.value,
      stage,
      status: stage === "WON" ? "WON" : stage === "LOST" ? "LOST" : "OPEN",
      probability: b.probability ?? (stage === "WON" ? 100 : stage === "LOST" ? 0 : 10),
      expectedCloseAt: dateOrNull(b.expectedCloseAt),
      closedAt: stage === "WON" || stage === "LOST" ? new Date() : null,
      ownerId,
      contactId: b.contactId || null,
      organizationId: b.organizationId || null,
      notes: b.notes || null,
    },
  });

  await db.activity.create({
    data: {
      type: "NOTE",
      subject: "Deal created",
      detail: `Value ₹${deal.value.toLocaleString("en-IN")} · stage ${DEAL_STAGE_LABELS[stage]}`,
      status: "COMPLETED",
      completedAt: new Date(),
      dealId: deal.id,
      contactId: deal.contactId,
      organizationId: deal.organizationId,
      ownerId: deal.ownerId,
      createdBy: session.email,
    },
  });

  await audit(session, "deal.create", "Deal", deal.id, `Created deal ${deal.title}`, {
    value: deal.value,
    stage,
  });
  if (ownerId && ownerId !== session.uid) {
    await notify(ownerId, "A deal was assigned to you", {
      body: `${deal.title} — ${deal.value.toLocaleString("en-IN")} ₹.`,
      type: "DEAL",
      link: "/crm/deals",
    });
  }

  return ok(deal, 201);
}
