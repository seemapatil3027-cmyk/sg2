import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, forbidden, guard, parseBody, audit, notify } from "@/lib/api-helpers";
import { isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/contacts/[id] — 360° view incl. LMS data ─────────────────
 * Contact + organization + owner + enrollments (course title, progress) +
 * certificates (via enrollments) + deals + activity timeline. */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.contacts.view");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const contact = await db.contact.findUnique({ where: { id } });
  if (!contact) return fail("Contact not found.", 404);
  if (!isCrmWideRole(session.role) && contact.ownerId !== session.uid) {
    return forbidden("crm.contacts.view");
  }

  const [organization, owner, enrollments, deals, activities] = await Promise.all([
    contact.organizationId
      ? db.organization.findUnique({
          where: { id: contact.organizationId },
          select: { id: true, name: true, domain: true, industry: true },
        })
      : Promise.resolve(null),
    contact.ownerId
      ? db.user.findUnique({
          where: { id: contact.ownerId },
          select: { id: true, name: true, email: true },
        })
      : Promise.resolve(null),
    db.enrollment.findMany({ where: { contactId: id }, orderBy: { enrolledAt: "desc" } }),
    db.deal.findMany({ where: { contactId: id }, orderBy: { createdAt: "desc" } }),
    db.activity.findMany({ where: { contactId: id }, orderBy: { createdAt: "desc" }, take: 100 }),
  ]);

  /* Join course titles for enrollments + certificates. */
  const courseIds = [...new Set(enrollments.map((e) => e.courseId).filter(Boolean))] as string[];
  const courses = courseIds.length
    ? await db.course.findMany({
        where: { id: { in: courseIds } },
        select: { id: true, title: true },
      })
    : [];
  const courseTitles = new Map(courses.map((c) => [c.id, c.title]));

  const enrollmentIds = enrollments.map((e) => e.id);
  const certificates = enrollmentIds.length
    ? await db.certificate.findMany({
        where: { enrollmentId: { in: enrollmentIds } },
        orderBy: { issuedAt: "desc" },
      })
    : [];

  return ok({
    contact,
    organization,
    owner,
    enrollments: enrollments.map((e) => ({
      id: e.id,
      courseId: e.courseId,
      courseTitle: e.courseId ? courseTitles.get(e.courseId) ?? e.itemSlug : e.itemSlug,
      batchName: e.batchName,
      status: e.status,
      progress: e.progress,
      enrolledAt: e.enrolledAt,
    })),
    certificates: certificates.map((c) => ({
      id: c.id,
      serial: c.serial,
      courseTitle: c.courseTitle,
      grade: c.grade,
      issuedAt: c.issuedAt,
    })),
    deals: deals.map((d) => ({ id: d.id, title: d.title, value: d.value, stage: d.stage, status: d.status })),
    activities,
  });
}

/* ── PATCH /api/crm/contacts/[id] — edit (crm.contacts.manage) ───────────── */
const patchSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  email: z.string().trim().toLowerCase().email().optional().nullable(),
  phone: z.string().trim().max(20).optional().nullable(),
  title: z.string().trim().max(80).optional().nullable(),
  organizationId: z.string().trim().optional().nullable(),
  ownerId: z.string().trim().optional().nullable(),
  source: z.string().trim().max(40).optional().nullable(),
  status: z.enum(["ACTIVE", "INACTIVE", "CHURNED"]).optional(),
  lifecycle: z.enum(["CONTACT", "CUSTOMER", "CHURNED"]).optional(),
  city: z.string().trim().max(60).optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.contacts.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  const contact = await db.contact.findUnique({ where: { id } });
  if (!contact) return fail("Contact not found.", 404);
  if (!isCrmWideRole(session.role) && contact.ownerId !== session.uid) {
    return forbidden("crm.contacts.manage");
  }

  const data: Record<string, unknown> = {};
  for (const field of ["name", "title", "source", "city"] as const) {
    if (b[field] !== undefined) data[field] = b[field];
  }
  for (const field of ["email", "phone", "notes"] as const) {
    if (b[field] !== undefined) data[field] = b[field] || null;
  }
  if (b.organizationId !== undefined) {
    if (b.organizationId) {
      const org = await db.organization.findUnique({
        where: { id: b.organizationId },
        select: { id: true },
      });
      if (!org) return fail("Selected organization does not exist.", 422);
      data.organizationId = org.id;
    } else {
      data.organizationId = null;
    }
  }
  if (b.status) data.status = b.status;
  if (b.lifecycle) data.lifecycle = b.lifecycle;

  let newOwner: { id: string; name: string } | null | undefined;
  if (b.ownerId !== undefined) {
    if (!b.ownerId) {
      if (contact.ownerId) {
        data.ownerId = null;
        newOwner = null;
      }
    } else {
      const user = await db.user.findUnique({
        where: { id: b.ownerId },
        select: { id: true, name: true },
      });
      if (!user) return fail("Selected owner does not exist.", 422);
      if (user.id !== contact.ownerId) {
        data.ownerId = user.id;
        newOwner = user;
      }
    }
  }

  if (Object.keys(data).length === 0) return ok(contact);

  const updated = await db.$transaction(async (tx) => {
    const saved = await tx.contact.update({ where: { id }, data });
    await tx.activity.create({
      data: {
        type: "NOTE",
        subject: "Contact updated",
        detail: `Edited: ${Object.keys(data).join(", ")}`,
        status: "COMPLETED",
        completedAt: new Date(),
        contactId: id,
        ownerId: saved.ownerId,
        createdBy: session.email,
      },
    });
    return saved;
  });

  await audit(session, "contact.update", "Contact", id, `Updated contact ${updated.name}`, {
    fields: Object.keys(data),
  });
  if (newOwner && newOwner.id !== session.uid) {
    await notify(newOwner.id, "A contact was assigned to you", {
      body: `${updated.name} is now in your book of business.`,
      type: "INFO",
      link: "/crm/contacts",
    });
  }

  return ok(updated);
}

/* ── DELETE /api/crm/contacts/[id] (crm.contacts.manage) ─────────────────── */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.contacts.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const contact = await db.contact.findUnique({ where: { id } });
  if (!contact) return fail("Contact not found.", 404);
  if (!isCrmWideRole(session.role) && contact.ownerId !== session.uid) {
    return forbidden("crm.contacts.manage");
  }

  const enrollments = await db.enrollment.count({ where: { contactId: id } });
  if (enrollments > 0) {
    return fail(
      "This contact has LMS enrollments. Remove them in the LMS module before deleting the contact.",
      409
    );
  }

  await db.$transaction([
    db.deal.updateMany({ where: { contactId: id }, data: { contactId: null } }),
    db.activity.deleteMany({ where: { contactId: id } }),
    db.contact.delete({ where: { id } }),
  ]);

  await audit(session, "contact.delete", "Contact", id, `Deleted contact ${contact.name}`);
  return ok({ deleted: true });
}
