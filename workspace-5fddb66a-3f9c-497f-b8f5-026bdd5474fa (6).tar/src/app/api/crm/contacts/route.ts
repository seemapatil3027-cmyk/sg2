import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  ok,
  fail,
  guard,
  parseBody,
  pageParams,
  paginated,
  audit,
  notify,
} from "@/lib/api-helpers";
import { isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/contacts — paginated list + ?basic=1 picker feed ─────────
 * Query: q (name/email/phone), status, lifecycle, org (organizationId),
 * owner (userId|"me"|"unassigned"), page, pageSize, basic=1.
 * CRM_EXECUTIVE scope: own contacts only. */
export async function GET(req: NextRequest) {
  const g = await guard("crm.contacts.view");
  if (g.response) return g.response;
  const { session } = g.guard;

  const sp = req.nextUrl.searchParams;

  if (sp.get("basic")) {
    const base: Record<string, unknown> = {};
    if (!isCrmWideRole(session.role)) base.ownerId = session.uid;
    const contacts = await db.contact.findMany({
      where: base,
      select: { id: true, name: true, email: true },
      orderBy: { name: "asc" },
      take: 500,
    });
    return ok({ items: contacts });
  }

  const p = pageParams(req, 20, 500);
  const wide = isCrmWideRole(session.role);
  const ownerParam = sp.get("owner")?.trim() || null;

  const and: Record<string, unknown>[] = [];
  if (!wide) and.push({ ownerId: session.uid });
  if (p.q) {
    and.push({
      OR: [
        { name: { contains: p.q } },
        { email: { contains: p.q } },
        { phone: { contains: p.q } },
      ],
    });
  }
  const status = sp.get("status")?.trim().toUpperCase() || null;
  if (status) and.push({ status });
  const lifecycle = sp.get("lifecycle")?.trim().toUpperCase() || null;
  if (lifecycle) and.push({ lifecycle });
  const org = sp.get("org")?.trim() || null;
  if (org) and.push({ organizationId: org });
  if (ownerParam === "unassigned") and.push({ ownerId: null });
  else if (ownerParam === "me") and.push({ ownerId: session.uid });
  else if (ownerParam) and.push({ ownerId: ownerParam });

  const where: Record<string, unknown> = and.length ? { AND: and } : {};

  const [rows, total, orgs, owners, enrollGroups] = await Promise.all([
    db.contact.findMany({ where, orderBy: { createdAt: p.dir }, skip: p.skip, take: p.pageSize }),
    db.contact.count({ where }),
    db.organization.findMany({ select: { id: true, name: true } }),
    db.user.findMany({ select: { id: true, name: true } }),
    db.enrollment.groupBy({
      by: ["contactId"],
      where: { contactId: { not: null } },
      _count: { _all: true },
    }),
  ]);

  const orgNames = new Map(orgs.map((o) => [o.id, o.name]));
  const userNames = new Map(owners.map((u) => [u.id, u.name]));
  const enrollCounts = new Map(enrollGroups.map((e) => [e.contactId ?? "", e._count._all]));

  return ok({
    ...paginated(
      rows.map((c) => ({
        ...c,
        organizationName: c.organizationId ? orgNames.get(c.organizationId) ?? null : null,
        ownerName: c.ownerId ? userNames.get(c.ownerId) ?? null : null,
        enrollmentCount: enrollCounts.get(c.id) ?? 0,
      })),
      total,
      p
    ),
  });
}

/* ── POST /api/crm/contacts — create a contact (crm.contacts.manage) ─────── */
const createSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email").optional().nullable(),
  phone: z.string().trim().max(20).optional().nullable(),
  title: z.string().trim().max(80).optional().nullable(),
  organizationId: z.string().trim().optional().nullable(),
  ownerId: z.string().trim().optional().nullable(),
  source: z.string().trim().max(40).optional().nullable(),
  status: z.enum(["ACTIVE", "INACTIVE", "CHURNED"]).optional(),
  lifecycle: z.enum(["CONTACT", "CUSTOMER", "CHURNED"]).optional(),
  city: z.string().trim().max(60).optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
});

export async function POST(req: NextRequest) {
  const g = await guard("crm.contacts.manage");
  if (g.response) return g.response;
  const { session } = g.guard;

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  if (b.organizationId) {
    const org = await db.organization.findUnique({
      where: { id: b.organizationId },
      select: { id: true },
    });
    if (!org) return fail("Selected organization does not exist.", 422);
  }
  let ownerId: string | null = null;
  if (b.ownerId) {
    const owner = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true } });
    if (!owner) return fail("Selected owner does not exist.", 422);
    ownerId = owner.id;
  }

  const contact = await db.contact.create({
    data: {
      name: b.name,
      email: b.email || null,
      phone: b.phone || null,
      title: b.title || null,
      organizationId: b.organizationId || null,
      ownerId,
      source: b.source || null,
      status: b.status ?? "ACTIVE",
      lifecycle: b.lifecycle ?? "CONTACT",
      city: b.city || null,
      notes: b.notes || null,
    },
  });

  await db.activity.create({
    data: {
      type: "NOTE",
      subject: "Contact created",
      detail: b.source ? `Source: ${b.source}` : null,
      status: "COMPLETED",
      completedAt: new Date(),
      contactId: contact.id,
      ownerId,
      createdBy: session.email,
    },
  });

  await audit(session, "contact.create", "Contact", contact.id, `Created contact ${contact.name}`);

  if (ownerId && ownerId !== session.uid) {
    await notify(ownerId, "A contact was assigned to you", {
      body: `${contact.name} was added to your book of business.`,
      type: "INFO",
      link: "/crm/contacts",
    });
  }

  return ok(contact, 201);
}
