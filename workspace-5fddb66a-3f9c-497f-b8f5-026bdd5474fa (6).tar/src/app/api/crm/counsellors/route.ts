import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * GET /api/crm/counsellors — ADMIN only.
 * Returns the counsellor directory used by the assignment controls:
 * { ok: true, counsellors: [{ email, name }] }
 */
export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (user.role !== "ADMIN") {
      return NextResponse.json({ error: "Only admins can list counsellors" }, { status: 403 });
    }

    const rows = await db.user.findMany({
      where: { role: "COUNSELLOR" },
      orderBy: { name: "asc" },
      select: { email: true, name: true },
    });

    return NextResponse.json({ ok: true, counsellors: rows });
  } catch (err) {
    console.error("GET /api/crm/counsellors failed", err);
    return NextResponse.json({ error: "Failed to load counsellors" }, { status: 500 });
  }
}
