import { db } from "@/lib/db";
import { ok, guard } from "@/lib/api-helpers";
import {
  DEAL_STAGES,
  DEAL_STAGE_LABELS,
  LEAD_STATUSES,
  LEAD_STATUS_LABELS,
  isCrmWideRole,
  normalizeLeadStatus,
} from "@/lib/crm-status";

export const dynamic = "force-dynamic";

const DAY = 24 * 60 * 60 * 1000;

/* ── GET /api/crm/reports — funnel, sources, pipeline, revenue, team ────────
 * CRM_EXECUTIVE scope: every metric limited to records they own. */
export async function GET() {
  const g = await guard("crm.reports.view");
  if (g.response) return g.response;
  const { session } = g.guard;
  const wide = isCrmWideRole(session.role);
  const leadScope = wide ? {} : { OR: [{ ownerId: session.uid }, { ownerId: null }] };
  const dealScope = wide ? {} : { ownerId: session.uid };
  const activityScope = wide ? {} : { OR: [{ ownerId: session.uid }, { ownerId: null }] };

  const [leadGroups, sourceGroups, dealGroups, wonDeals, activities, users, followUps] =
    await Promise.all([
      db.lead.groupBy({ by: ["status"], where: leadScope, _count: { _all: true } }),
      db.lead.groupBy({ by: ["source"], where: leadScope, _count: { _all: true } }),
      db.deal.groupBy({
        by: ["stage"],
        where: dealScope,
        _count: { _all: true },
        _sum: { value: true },
      }),
      db.deal.findMany({
        where: { ...dealScope, status: "WON", closedAt: { gte: new Date(Date.now() - 200 * DAY) } },
        select: { value: true, closedAt: true },
      }),
      db.activity.findMany({ where: activityScope, select: { ownerId: true } }),
      db.user.findMany({
        where: { isActive: true, role: { in: ["CRM_MANAGER", "CRM_EXECUTIVE", "ADMIN", "SUPER_ADMIN"] } },
        select: { id: true, name: true, role: true },
      }),
      db.activity.findMany({
        where: { ...activityScope, status: "OPEN", dueAt: { not: null } },
        orderBy: { dueAt: "asc" },
        take: 10,
      }),
    ]);

  /* Funnel — canonical statuses in pipeline order. */
  const funnelCounts: Record<string, number> = {};
  for (const s of LEAD_STATUSES) funnelCounts[s] = 0;
  for (const grp of leadGroups) funnelCounts[normalizeLeadStatus(grp.status)] += grp._count._all;
  const funnel = LEAD_STATUSES.map((s) => ({
    key: s,
    label: LEAD_STATUS_LABELS[s],
    count: funnelCounts[s],
  }));
  const totalLeads = funnel.reduce((sum, f) => sum + f.count, 0);

  /* Leads by source. */
  const leadsBySource = sourceGroups
    .map((grp) => ({ name: grp.source || "unknown", value: grp._count._all }))
    .sort((a, b) => b.value - a.value);

  /* Deals by stage (count + value). */
  const byStage: Record<string, { count: number; value: number }> = {};
  for (const s of DEAL_STAGES) byStage[s] = { count: 0, value: 0 };
  for (const grp of dealGroups) {
    if (byStage[grp.stage]) byStage[grp.stage] = { count: grp._count._all, value: grp._sum.value ?? 0 };
  }
  const dealsByStage = DEAL_STAGES.map((s) => ({
    stage: s,
    label: DEAL_STAGE_LABELS[s],
    count: byStage[s].count,
    value: byStage[s].value,
  }));

  /* Revenue trend — WON deals bucketed by close month, last 6 months. */
  const monthBuckets: { key: string; label: string }[] = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    monthBuckets.push({
      key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`,
      label: d.toLocaleDateString("en-IN", { month: "short" }),
    });
  }
  const revenueMap = new Map<string, number>(monthBuckets.map((m) => [m.key, 0]));
  for (const deal of wonDeals) {
    if (!deal.closedAt) continue;
    const d = new Date(deal.closedAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    if (revenueMap.has(key)) revenueMap.set(key, (revenueMap.get(key) ?? 0) + deal.value);
  }
  const revenueTrend = monthBuckets.map((m) => ({ month: m.label, value: revenueMap.get(m.key) ?? 0 }));
  const totalRevenue = revenueTrend.reduce((sum, m) => sum + m.value, 0);

  /* Owner performance — CRM staff + anyone owning CRM records. */
  const [leads, deals] = await Promise.all([
    db.lead.findMany({ where: leadScope, select: { ownerId: true, status: true } }),
    db.deal.findMany({ where: dealScope, select: { ownerId: true, status: true, value: true } }),
  ]);
  const perf = new Map<
    string,
    { name: string; role: string; leads: number; converted: number; dealsWon: number; revenue: number; activities: number }
  >();
  for (const u of users) {
    perf.set(u.id, { name: u.name, role: u.role, leads: 0, converted: 0, dealsWon: 0, revenue: 0, activities: 0 });
  }
  const ensure = (ownerId: string | null) => {
    if (!ownerId) return null;
    let entry = perf.get(ownerId);
    if (!entry) {
      entry = { name: "Other", role: "—", leads: 0, converted: 0, dealsWon: 0, revenue: 0, activities: 0 };
      perf.set(ownerId, entry);
    }
    return entry;
  };
  for (const l of leads) {
    const entry = ensure(l.ownerId);
    if (!entry) continue;
    entry.leads += 1;
    if (normalizeLeadStatus(l.status) === "CONVERTED") entry.converted += 1;
  }
  for (const d of deals) {
    const entry = ensure(d.ownerId);
    if (!entry) continue;
    if (d.status === "WON") {
      entry.dealsWon += 1;
      entry.revenue += d.value;
    }
  }
  for (const a of activities) {
    const entry = ensure(a.ownerId);
    if (entry) entry.activities += 1;
  }
  const ownerPerformance = [...perf.entries()]
    .filter(([, v]) => v.name !== "Other" || v.leads + v.dealsWon + v.activities > 0)
    .map(([id, v]) => ({ userId: id, ...v }))
    .sort((a, b) => b.revenue - a.revenue || b.leads - a.leads);

  /* Follow-ups due — next 10 open activities with a due date. */
  const [leadsForNames, contactsForNames, dealsForNames, usersForNames] = await Promise.all([
    db.lead.findMany({ select: { id: true, name: true } }),
    db.contact.findMany({ select: { id: true, name: true } }),
    db.deal.findMany({ select: { id: true, title: true } }),
    db.user.findMany({ select: { id: true, name: true } }),
  ]);
  const leadNames = new Map(leadsForNames.map((l) => [l.id, l.name]));
  const contactNames = new Map(contactsForNames.map((c) => [c.id, c.name]));
  const dealTitles = new Map(dealsForNames.map((d) => [d.id, d.title]));
  const userNames = new Map(usersForNames.map((u) => [u.id, u.name]));
  const followUpsDue = followUps.map((a) => ({
    id: a.id,
    type: a.type,
    subject: a.subject,
    priority: a.priority,
    dueAt: a.dueAt,
    leadId: a.leadId,
    leadName: a.leadId ? leadNames.get(a.leadId) ?? null : null,
    contactName: a.contactId ? contactNames.get(a.contactId) ?? null : null,
    dealTitle: a.dealId ? dealTitles.get(a.dealId) ?? null : null,
    ownerName: a.ownerId ? userNames.get(a.ownerId) ?? null : null,
  }));

  const converted = funnelCounts.CONVERTED;
  const pipelineValue = dealsByStage
    .filter((d) => d.stage !== "WON" && d.stage !== "LOST")
    .reduce((sum, d) => sum + d.value, 0);

  return ok({
    funnel,
    leadsBySource,
    dealsByStage,
    revenueTrend,
    ownerPerformance,
    followUpsDue,
    stats: {
      totalLeads,
      converted,
      conversionRate: totalLeads > 0 ? Math.round((converted / totalLeads) * 100) : 0,
      pipelineValue,
      totalRevenue,
      activities: activities.length,
    },
  });
}
