import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, forbidden, guard, parseBody, audit, notify, dateOrNull } from "@/lib/api-helpers";
import { ACTIVITY_PRIORITIES, ACTIVITY_TYPES, isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/** Executives may only manage activities they own or created. */
function canManage(role: string, uid: string, email: string, activity: { ownerId: string | null; createdBy: string | null }): boolean {
  if (isCrmWideRole(role)) return true;
  return activity.ownerId === uid || activity.createdBy === email;
}

/* ── PATCH /api/crm/activities/[id] — complete / reopen / edit ───────────── */
const patchSchema = z.object({
  type: z.enum(ACTIVITY_TYPES).optional(),
  subject: z.string().trim().min(2).max(160).optional(),
  detail: z.string().trim().max(2000).optional().nullable(),
  status: z.enum(["OPEN", "COMPLETED"]).optional(),
  priority: z.enum(ACTIVITY_PRIORITIES).optional(),
  dueAt: z.string().optional().nullable(),
  ownerId: z.string().trim().optional().nullable(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.activities.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const parsed = await parseBody(req, patchSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  const activity = await db.activity.findUnique({ where: { id } });
  if (!activity) return fail("Activity not found.", 404);
  if (!canManage(session.role, session.uid, session.email, activity)) {
    return forbidden("crm.activities.manage");
  }

  const data: Record<string, unknown> = {};
  if (b.type) data.type = b.type;
  if (b.subject !== undefined) data.subject = b.subject;
  if (b.detail !== undefined) data.detail = b.detail || null;
  if (b.priority) data.priority = b.priority;

  /* Complete / reopen — completedAt stamps the transition. */
  if (b.status && b.status !== activity.status) {
    data.status = b.status;
    data.completedAt = b.status === "COMPLETED" ? new Date() : null;
  }

  if (b.dueAt !== undefined) data.dueAt = dateOrNull(b.dueAt);

  let newOwner: { id: string; name: string } | null | undefined;
  if (b.ownerId !== undefined) {
    if (!b.ownerId) {
      if (activity.ownerId) {
        data.ownerId = null;
        newOwner = null;
      }
    } else {
      const user = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true, name: true } });
      if (!user) return fail("Selected owner does not exist.", 422);
      if (user.id !== activity.ownerId) {
        data.ownerId = user.id;
        newOwner = user;
      }
    }
  }

  if (Object.keys(data).length === 0) return ok(activity);

  const updated = await db.activity.update({ where: { id }, data });

  await audit(session, "activity.update", "Activity", id, `Updated activity "${updated.subject}"`, {
    fields: Object.keys(data),
  });
  if (newOwner && newOwner.id !== session.uid) {
    await notify(newOwner.id, "An activity was assigned to you", {
      body: updated.subject,
      type: "INFO",
      link: "/crm/activities",
    });
  }

  return ok(updated);
}

/* ── DELETE /api/crm/activities/[id] (crm.activities.manage) ─────────────── */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard("crm.activities.manage");
  if (g.response) return g.response;
  const { session } = g.guard;
  const { id } = await params;

  const activity = await db.activity.findUnique({ where: { id } });
  if (!activity) return fail("Activity not found.", 404);
  if (!canManage(session.role, session.uid, session.email, activity)) {
    return forbidden("crm.activities.manage");
  }

  await db.activity.delete({ where: { id } });
  await audit(session, "activity.delete", "Activity", id, `Deleted activity "${activity.subject}"`);
  return ok({ deleted: true });
}
