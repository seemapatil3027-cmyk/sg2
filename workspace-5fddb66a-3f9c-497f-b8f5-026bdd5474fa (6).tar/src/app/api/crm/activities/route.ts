import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  ok,
  fail,
  guard,
  parseBody,
  pageParams,
  paginated,
  audit,
  notify,
  dateOrNull,
} from "@/lib/api-helpers";
import { ACTIVITY_PRIORITIES, ACTIVITY_TYPES, isCrmWideRole } from "@/lib/crm-status";

export const dynamic = "force-dynamic";

/* ── GET /api/crm/activities — unified CRM timeline / task list ────────────
 * Query: type (repeatable or comma list), status (OPEN|COMPLETED, default all),
 * owner (userId|"me"|"unassigned"), due ("overdue"|"today"|"week"),
 * leadId / contactId / dealId / organizationId, q, sort (createdAt|dueAt|priority), dir.
 * CRM_EXECUTIVE scope: own activities (+ unowned system log entries). */
export async function GET(req: NextRequest) {
  const g = await guard("crm.activities.view");
  if (g.response) return g.response;
  const { session } = g.guard;

  const p = pageParams(req, 20, 500);
  const sp = p.searchParams;
  const wide = isCrmWideRole(session.role);
  const ownerParam = sp.get("owner")?.trim() || null;

  const and: Record<string, unknown>[] = [];
  if (!wide) and.push({ OR: [{ ownerId: session.uid }, { ownerId: null }] });

  const typeList = sp
    .getAll("type")
    .flatMap((t) => t.split(","))
    .map((t) => t.trim().toUpperCase())
    .filter(Boolean);
  if (typeList.length) and.push({ type: { in: typeList } });

  const status = sp.get("status")?.trim().toUpperCase() || null;
  if (status) and.push({ status });

  if (ownerParam === "unassigned") and.push({ ownerId: null });
  else if (ownerParam === "me") and.push({ ownerId: session.uid });
  else if (ownerParam) and.push({ ownerId: ownerParam });

  const due = sp.get("due")?.trim().toLowerCase() || null;
  const now = new Date();
  if (due === "overdue") {
    and.push({ dueAt: { lt: now }, status: "OPEN" });
  } else if (due === "today") {
    const end = new Date(now);
    end.setHours(23, 59, 59, 999);
    and.push({ dueAt: { gte: now, lte: end } });
  } else if (due === "week") {
    const end = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    and.push({ dueAt: { gte: now, lte: end } });
  }

  for (const [param, field] of [
    ["leadId", "leadId"],
    ["contactId", "contactId"],
    ["dealId", "dealId"],
    ["organizationId", "organizationId"],
  ] as const) {
    const value = sp.get(param)?.trim() || null;
    if (value) and.push({ [field]: value });
  }

  if (p.q) {
    and.push({ OR: [{ subject: { contains: p.q } }, { detail: { contains: p.q } }] });
  }

  const where: Record<string, unknown> = and.length ? { AND: and } : {};

  const orderBy =
    p.sort === "dueAt"
      ? { dueAt: p.dir }
      : p.sort === "priority"
        ? { priority: p.dir }
        : { createdAt: p.dir };

  const [rows, total, leads, contacts, deals, orgs, users] = await Promise.all([
    db.activity.findMany({ where, orderBy, skip: p.skip, take: p.pageSize }),
    db.activity.count({ where }),
    db.lead.findMany({ select: { id: true, name: true } }),
    db.contact.findMany({ select: { id: true, name: true } }),
    db.deal.findMany({ select: { id: true, title: true } }),
    db.organization.findMany({ select: { id: true, name: true } }),
    db.user.findMany({ select: { id: true, name: true } }),
  ]);

  const leadNames = new Map(leads.map((l) => [l.id, l.name]));
  const contactNames = new Map(contacts.map((c) => [c.id, c.name]));
  const dealTitles = new Map(deals.map((d) => [d.id, d.title]));
  const orgNames = new Map(orgs.map((o) => [o.id, o.name]));
  const userNames = new Map(users.map((u) => [u.id, u.name]));

  return ok({
    ...paginated(
      rows.map((a) => ({
        ...a,
        leadName: a.leadId ? leadNames.get(a.leadId) ?? null : null,
        contactName: a.contactId ? contactNames.get(a.contactId) ?? null : null,
        dealTitle: a.dealId ? dealTitles.get(a.dealId) ?? null : null,
        organizationName: a.organizationId ? orgNames.get(a.organizationId) ?? null : null,
        ownerName: a.ownerId ? userNames.get(a.ownerId) ?? null : null,
      })),
      total,
      p
    ),
  });
}

/* ── POST /api/crm/activities — log an activity (crm.activities.manage) ──── */
const createSchema = z.object({
  type: z.enum(ACTIVITY_TYPES),
  subject: z.string().trim().min(2, "Subject is required").max(160),
  detail: z.string().trim().max(2000).optional().nullable(),
  dueAt: z.string().optional().nullable(),
  priority: z.enum(ACTIVITY_PRIORITIES).optional(),
  ownerId: z.string().trim().optional().nullable(),
  leadId: z.string().trim().optional().nullable(),
  contactId: z.string().trim().optional().nullable(),
  dealId: z.string().trim().optional().nullable(),
  organizationId: z.string().trim().optional().nullable(),
});

export async function POST(req: NextRequest) {
  const g = await guard("crm.activities.manage");
  if (g.response) return g.response;
  const { session } = g.guard;

  const parsed = await parseBody(req, createSchema);
  if (parsed.response) return parsed.response;
  const b = parsed.data;

  /* Validate every linked record so chips never dangle. */
  if (b.leadId && !(await db.lead.findUnique({ where: { id: b.leadId }, select: { id: true } })))
    return fail("Linked lead does not exist.", 422);
  if (b.contactId && !(await db.contact.findUnique({ where: { id: b.contactId }, select: { id: true } })))
    return fail("Linked contact does not exist.", 422);
  if (b.dealId && !(await db.deal.findUnique({ where: { id: b.dealId }, select: { id: true } })))
    return fail("Linked deal does not exist.", 422);
  if (
    b.organizationId &&
    !(await db.organization.findUnique({ where: { id: b.organizationId }, select: { id: true } }))
  )
    return fail("Linked organization does not exist.", 422);

  let ownerId: string | null = null;
  if (b.ownerId) {
    const owner = await db.user.findUnique({ where: { id: b.ownerId }, select: { id: true } });
    if (!owner) return fail("Selected owner does not exist.", 422);
    ownerId = owner.id;
  }

  const activity = await db.activity.create({
    data: {
      type: b.type,
      subject: b.subject,
      detail: b.detail || null,
      status: "OPEN",
      priority: b.priority ?? "MEDIUM",
      dueAt: dateOrNull(b.dueAt),
      leadId: b.leadId || null,
      contactId: b.contactId || null,
      dealId: b.dealId || null,
      organizationId: b.organizationId || null,
      ownerId,
      createdBy: session.email,
    },
  });

  await audit(session, "activity.create", "Activity", activity.id, `Logged ${b.type}: ${b.subject}`);
  if (ownerId && ownerId !== session.uid) {
    await notify(ownerId, "New activity assigned to you", {
      body: `${b.type.replace("_", " ")} — ${b.subject}`,
      type: "INFO",
      link: "/crm/activities",
    });
  }

  return ok(activity, 201);
}
