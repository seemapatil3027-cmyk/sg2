import { db } from "@/lib/db";
import { auth, ok, unauthorized } from "@/lib/api-helpers";

/** Lightweight user list for assignment pickers (any signed-in staff). */
export async function GET() {
  const session = await auth();
  if (!session) return unauthorized();
  const users = await db.user.findMany({
    where: { isActive: true, role: { not: "STUDENT" } },
    select: { id: true, name: true, email: true, role: true },
    orderBy: { name: "asc" },
  });
  return ok({ items: users });
}
