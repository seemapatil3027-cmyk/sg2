import { db } from "@/lib/db";
import { auth, ok, unauthorized } from "@/lib/api-helpers";
import { can } from "@/lib/rbac-server";

const DAY = 24 * 60 * 60 * 1000;
function daysAgo(n: number): Date {
  return new Date(Date.now() - n * DAY);
}

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/** Role-aware analytics for the main dashboard. Every block is computed only
 * when the caller holds the matching permission; CRM_EXECUTIVE is scoped to
 * their own records. */
export async function GET() {
  const session = await auth();
  if (!session) return unauthorized();

  const isCrm = await can(session.role, "crm.leads.view");
  const isLms = await can(session.role, "lms.courses.view");
  const crmReports = await can(session.role, "crm.reports.view");
  const lmsReports = await can(session.role, "lms.reports.view");
  const scoped = session.role === "CRM_EXECUTIVE";
  const ownerScope = scoped ? { ownerId: session.uid } : {};
  const leadOwnerScope = scoped ? { ownerId: session.uid } : {};

  /* ── CRM metrics ── */
  let crm: Record<string, unknown> | null = null;
  if (isCrm) {
    const [totalLeads, newLeads7d, convertedLeads, lostLeads, avgScoreAgg, openTasks, followUpsDue] =
      await Promise.all([
        db.lead.count({ where: leadOwnerScope }),
        db.lead.count({ where: { ...leadOwnerScope, createdAt: { gte: daysAgo(7) } } }),
        db.lead.count({ where: { ...leadOwnerScope, status: "CONVERTED" } }),
        db.lead.count({ where: { ...leadOwnerScope, status: "LOST" } }),
        db.lead.aggregate({ _avg: { score: true }, where: leadOwnerScope }),
        db.activity.count({ where: { ...ownerScope, status: "OPEN" } }),
        db.activity.count({
          where: { ...ownerScope, status: "OPEN", dueAt: { not: null, lte: new Date(Date.now() + 7 * DAY) } },
        }),
      ]);

    const [activeDeals, wonDeals, lostDeals, pipelineAgg, wonAgg] = await Promise.all([
      db.deal.count({ where: { ...ownerScope, status: "OPEN" } }),
      db.deal.count({ where: { ...ownerScope, status: "WON" } }),
      db.deal.count({ where: { ...ownerScope, status: "LOST" } }),
      db.deal.aggregate({ _sum: { value: true }, where: { ...ownerScope, status: "OPEN" } }),
      db.deal.aggregate({ _sum: { value: true }, where: { ...ownerScope, status: "WON" } }),
    ]);

    // funnel + sources
    const leads = await db.lead.findMany({
      where: leadOwnerScope,
      select: { status: true, source: true, createdAt: true },
    });
    const FUNNEL: Record<string, string[]> = {
      NEW: ["NEW", "New"],
      CONTACTED: ["CONTACTED", "Contacted", "Assigned", "Counselling", "Demo"],
      QUALIFIED: ["QUALIFIED", "Qualified", "Interested", "Payment Pending"],
      CONVERTED: ["CONVERTED", "Enrolled"],
      LOST: ["LOST", "Lost"],
    };
    const funnel = Object.entries(FUNNEL).map(([stage, names]) => ({
      stage,
      count: leads.filter((l) => names.includes(l.status)).length,
    }));
    const sourceMap = new Map<string, number>();
    for (const l of leads) sourceMap.set(l.source || "unknown", (sourceMap.get(l.source || "unknown") ?? 0) + 1);
    const leadsBySource = [...sourceMap.entries()]
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);

    // deals by stage
    const deals = await db.deal.findMany({
      where: ownerScope,
      select: { stage: true, value: true },
    });
    const STAGES = ["NEW", "CONTACTED", "QUALIFIED", "PROPOSAL", "NEGOTIATION", "WON", "LOST"];
    const dealsByStage = STAGES.map((stage) => {
      const rows = deals.filter((d) => d.stage === stage);
      return { stage, count: rows.length, value: rows.reduce((s, d) => s + d.value, 0) };
    });

    // revenue trend — last 6 months of won deals
    const won = await db.deal.findMany({
      where: { ...ownerScope, status: "WON", closedAt: { gte: daysAgo(180) } },
      select: { value: true, closedAt: true },
    });
    const trendMap = new Map<string, number>();
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setDate(1);
      d.setMonth(d.getMonth() - i);
      trendMap.set(monthKey(d), 0);
    }
    for (const w of won) {
      if (!w.closedAt) continue;
      const k = monthKey(new Date(w.closedAt));
      if (trendMap.has(k)) trendMap.set(k, (trendMap.get(k) ?? 0) + w.value);
    }
    const revenueTrend = [...trendMap.entries()].map(([month, value]) => ({ month, value }));

    crm = {
      totalLeads,
      newLeads7d,
      convertedLeads,
      lostLeads,
      conversionRate: totalLeads > 0 ? Math.round((convertedLeads / totalLeads) * 100) : 0,
      avgLeadScore: Math.round(avgScoreAgg._avg.score ?? 0),
      openTasks,
      followUpsDue,
      activeDeals,
      wonDeals,
      lostDeals,
      pipelineValue: pipelineAgg._sum.value ?? 0,
      revenueWon: wonAgg._sum.value ?? 0,
      funnel,
      leadsBySource,
      dealsByStage,
      revenueTrend,
    };
  }

  /* ── LMS metrics ── */
  let lms: Record<string, unknown> | null = null;
  if (isLms) {
    const instructorScope = session.role === "INSTRUCTOR" ? { ownerId: session.uid } : {};
    const courses = await db.course.findMany({
      where: instructorScope,
      select: { id: true, title: true, status: true, slug: true },
    });
    const courseIds = courses.map((c) => c.id);
    const enrollments = await db.enrollment.findMany({
      where: courseIds.length ? { courseId: { in: courseIds } } : { id: { not: "" } },
      select: { id: true, status: true, progress: true, enrolledAt: true, courseId: true },
    });
    const completed = enrollments.filter((e) => e.status === "COMPLETED").length;
    const [certificates, pendingSubmissions, avgQuizAgg, attempts] = await Promise.all([
      db.certificate.count(),
      db.assignmentSubmission.count({ where: { status: "SUBMITTED" } }),
      db.quizAttempt.aggregate({ _avg: { score: true }, _count: true }),
      db.quizAttempt.findMany({ select: { passed: true } }),
    ]);

    // enrollments trend — last 6 months
    const trendMap = new Map<string, number>();
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setDate(1);
      d.setMonth(d.getMonth() - i);
      trendMap.set(monthKey(d), 0);
    }
    for (const e of enrollments) {
      const k = monthKey(new Date(e.enrolledAt));
      if (trendMap.has(k)) trendMap.set(k, (trendMap.get(k) ?? 0) + 1);
    }

    const coursePerformance = await Promise.all(
      courses.slice(0, 6).map(async (c) => {
        const rows = enrollments.filter((e) => e.courseId === c.id);
        const avg = rows.length
          ? Math.round(rows.reduce((s, r) => s + r.progress, 0) / rows.length)
          : 0;
        return {
          title: c.title.length > 24 ? `${c.title.slice(0, 24)}…` : c.title,
          enrollments: rows.length,
          avgProgress: avg,
        };
      })
    );

    lms = {
      totalCourses: courses.length,
      publishedCourses: courses.filter((c) => c.status === "PUBLISHED").length,
      totalEnrollments: enrollments.length,
      activeEnrollments: enrollments.filter((e) => e.status === "ACTIVE").length,
      completedEnrollments: completed,
      completionRate: enrollments.length ? Math.round((completed / enrollments.length) * 100) : 0,
      avgProgress: enrollments.length
        ? Math.round(enrollments.reduce((s, e) => s + e.progress, 0) / enrollments.length)
        : 0,
      certificatesIssued: certificates,
      pendingGrading: pendingSubmissions,
      quizAttempts: avgQuizAgg._count,
      avgQuizScore: Math.round(avgQuizAgg._avg.score ?? 0),
      quizPassRate: attempts.length
        ? Math.round((attempts.filter((a) => a.passed).length / attempts.length) * 100)
        : 0,
      enrollmentsTrend: [...trendMap.entries()].map(([month, value]) => ({ month, value })),
      coursePerformance,
    };
  }

  /* ── Shared: recent activity feed + my open tasks ── */
  const recentActivities = await db.activity.findMany({
    where: scoped ? { ownerId: session.uid } : {},
    orderBy: { updatedAt: "desc" },
    take: 8,
  });
  const ownerIds = [...new Set(recentActivities.map((a) => a.ownerId).filter(Boolean))] as string[];
  const owners = ownerIds.length
    ? await db.user.findMany({ where: { id: { in: ownerIds } }, select: { id: true, name: true } })
    : [];
  const ownerName = (id: string | null) => owners.find((o) => o.id === id)?.name ?? "Team";

  const myTasks = await db.activity.findMany({
    where: { ownerId: session.uid, status: "OPEN" },
    orderBy: [{ dueAt: "asc" }, { priority: "desc" }],
    take: 6,
  });

  return ok({
    role: session.role,
    crm,
    lms,
    recentActivities: recentActivities.map((a) => ({
      id: a.id,
      type: a.type,
      subject: a.subject,
      status: a.status,
      priority: a.priority,
      dueAt: a.dueAt,
      owner: ownerName(a.ownerId),
      createdAt: a.createdAt,
    })),
    myTasks,
  });
}
