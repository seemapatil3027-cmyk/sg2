import { db } from "@/lib/db";
import { auth, ok, unauthorized } from "@/lib/api-helpers";

/** Lightweight course list for pickers (any signed-in staff). */
export async function GET() {
  const session = await auth();
  if (!session) return unauthorized();
  const courses = await db.course.findMany({
    where: { status: { not: "DRAFT" } },
    select: { id: true, title: true, slug: true, status: true },
    orderBy: { title: "asc" },
  });
  return ok({ items: courses });
}
