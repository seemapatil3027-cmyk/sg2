import { NextResponse } from "next/server";
import fs from "fs";
import { db, resolvedDatabaseUrl, databaseUrlSource } from "@/lib/db";
import { databaseSearchedPaths } from "@/lib/db-url";
import { bootstrapDatabase } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

/**
 * Deployment diagnostic + self-healing endpoint.
 * GET /api/health → DB file existence + connectivity + env provenance.
 * Also (re)triggers database provisioning — if instrumentation didn't run for
 * any reason, hitting this endpoint creates missing schema + seed data.
 */
export async function GET() {
  // Belt-and-suspenders: ensure the DB is provisioned (single-flight, cached).
  let bootstrapStatus: "ok" | "failed" = "ok";
  try {
    const ok = await bootstrapDatabase();
    bootstrapStatus = ok ? "ok" : "failed";
  } catch {
    bootstrapStatus = "failed";
  }

  const url = resolvedDatabaseUrl;
  const filePath = url.startsWith("file:") ? url.slice("file:".length) : null;
  const fileExists = filePath ? fs.existsSync(filePath) : null;

  let connected = false;
  let dbError: string | null = null;
  const startedAt = Date.now();
  try {
    await db.$queryRaw`SELECT 1`;
    connected = true;
  } catch (error) {
    dbError = error instanceof Error ? error.message : String(error);
  }
  const queryMs = Date.now() - startedAt;

  const ok = connected;

  return NextResponse.json(
    {
      ok,
      service: "skillgorila",
      time: new Date().toISOString(),
      runtime: {
        node: process.version,
        env: process.env.NODE_ENV ?? "unknown",
        uptimeSec: Math.round(process.uptime()),
      },
      database: {
        connected,
        queryMs,
        bootstrap: bootstrapStatus,
        source: databaseUrlSource,
        url,
        file: filePath,
        fileExists,
        envVarSet: Boolean(process.env.DATABASE_URL?.trim()),
        authSecretSet: Boolean(process.env.AUTH_SECRET?.trim()),
        searchedPaths: databaseSearchedPaths,
        error: dbError,
      },
    },
    { status: ok ? 200 : 503 }
  );
}
