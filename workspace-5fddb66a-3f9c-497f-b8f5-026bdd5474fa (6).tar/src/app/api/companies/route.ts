import { NextRequest, NextResponse } from "next/server";
import { getCompanies } from "@/lib/data";

export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get("category") || undefined;
  const companies = await getCompanies(category);
  return NextResponse.json({ companies });
}
