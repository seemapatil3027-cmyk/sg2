import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createToken, setSessionCookie, verifyPassword, type UserRole } from "@/lib/auth";
import { roleLabel } from "@/lib/rbac";

/** Staff-only sign-in. Students no longer log in to the platform — learners
 * are managed internally by the CRM/LMS teams (requirement: remove student login). */
export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();
    const e = (email || "").toString().trim().toLowerCase();
    const p = (password || "").toString();

    if (!e || !p) return NextResponse.json({ error: "Email and password are required" }, { status: 400 });

    const user = await db.user.findUnique({ where: { email: e } });
    if (!user || !verifyPassword(p, user.passwordHash)) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
    }
    if (user.role === "STUDENT") {
      return NextResponse.json(
        {
          error:
            "Student sign-in has been disabled. Learning records are managed internally — contact your program advisor for assistance.",
        },
        { status: 403 }
      );
    }
    if (user.isActive === false) {
      return NextResponse.json(
        { error: "This account has been deactivated. Contact your administrator." },
        { status: 403 }
      );
    }

    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    const token = createToken({
      uid: user.id,
      name: user.name,
      email: user.email,
      role: (user.role || "EMPLOYEE") as UserRole,
    });
    await setSessionCookie(token);
    return NextResponse.json({
      ok: true,
      user: { name: user.name, email: user.email, role: user.role, roleLabel: roleLabel(user.role) },
    });
  } catch (err) {
    console.error("signin failed", err);
    return NextResponse.json({ error: "Sign in failed. Please try again." }, { status: 500 });
  }
}
