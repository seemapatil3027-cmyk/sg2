import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { roleLabel } from "@/lib/rbac";
import { permissionsForRole } from "@/lib/rbac-server";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ user: null });
  const permissions = await permissionsForRole(user.role);
  return NextResponse.json({
    user: { ...user, roleLabel: roleLabel(user.role), permissions },
  });
}
