import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { verifyPassword, hashPassword } from "@/lib/password";
import { auth, ok, fail, parseBody, audit } from "@/lib/api-helpers";

const schema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(8, "New password must be at least 8 characters"),
});

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return fail("You must be signed in.", 401);
  const parsed = await parseBody(req, schema);
  if (parsed.response) return parsed.response;

  const user = await db.user.findUnique({ where: { id: session.uid } });
  if (!user || !verifyPassword(parsed.data.currentPassword, user.passwordHash)) {
    return fail("Current password is incorrect.", 422);
  }
  await db.user.update({
    where: { id: user.id },
    data: { passwordHash: hashPassword(parsed.data.newPassword) },
  });
  await audit(session, "user.password", "User", user.id, "Changed own password");
  return ok({ changed: true });
}
