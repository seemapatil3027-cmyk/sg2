import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { auth, ok, fail, unauthorized } from "@/lib/api-helpers";

/** Notification center for the signed-in user. */
export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session) return unauthorized();
  const sp = req.nextUrl.searchParams;
  const unreadOnly = sp.get("unread") === "1";
  const limit = Math.min(50, Math.max(1, Number(sp.get("limit")) || 15));

  const items = await db.notification.findMany({
    where: { userId: session.uid, ...(unreadOnly ? { readAt: null } : {}) },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
  const unread = await db.notification.count({ where: { userId: session.uid, readAt: null } });
  return ok({ items, unread });
}

const schema = z.object({
  id: z.string().optional(),
  all: z.boolean().optional(),
});

/** Mark one (or all) notifications as read. */
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return unauthorized();
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return fail("Invalid request body.", 422);

  if (parsed.data.all) {
    await db.notification.updateMany({
      where: { userId: session.uid, readAt: null },
      data: { readAt: new Date() },
    });
    return ok({ updated: "all" });
  }
  if (parsed.data.id) {
    await db.notification.updateMany({
      where: { id: parsed.data.id, userId: session.uid },
      data: { readAt: new Date() },
    });
    return ok({ updated: parsed.data.id });
  }
  return fail("Provide a notification id or all=true.", 422);
}
