import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";

/** PUBLIC certificate verification — powers /verify/certificate/[serial]. */
export async function GET(req: NextRequest) {
  const serial = req.nextUrl.searchParams.get("serial")?.trim().toUpperCase() ?? "";
  if (!serial) return fail("Provide a certificate serial to verify.", 400);

  const cert = await db.certificate.findUnique({ where: { serial } });
  if (!cert) return ok({ valid: false });

  return ok({
    valid: true,
    serial: cert.serial,
    learnerName: cert.learnerName,
    courseTitle: cert.courseTitle,
    grade: cert.grade,
    issuedAt: cert.issuedAt,
    issuedBy: cert.issuedBy,
  });
}
