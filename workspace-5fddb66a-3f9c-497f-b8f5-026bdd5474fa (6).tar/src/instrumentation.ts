/**
 * Next.js instrumentation hook — runs once when the server instance boots
 * (before it serves requests), in every environment.
 *
 * It self-provisions the SQLite database on fresh deployments: if the DB file
 * is missing or has no tables, schema + seed data are applied automatically.
 * See src/db/bootstrap.ts.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  try {
    const { bootstrapDatabase } = await import("@/db/bootstrap");
    const ok = await bootstrapDatabase();
    if (!ok) {
      console.warn(
        "[instrumentation] database bootstrap did not complete — check [db-bootstrap] logs above"
      );
    }
  } catch (error) {
    console.error("[instrumentation] database bootstrap error:", error);
  }
}
