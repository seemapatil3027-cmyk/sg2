"use client";

import { BookOpen, HelpCircle, PlayCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import type { ChapterItem } from "@/lib/data";
import { cn } from "@/lib/utils";

function plural(n: number, word: string) {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

const META_CHIP =
  "inline-flex items-center gap-1.5 rounded-full border border-border bg-white px-3 py-1 text-[12px] font-medium text-ink-soft";

/** Course syllabus accordion — "Chapter n" header with mins + video/reading/quiz meta chips */
export function ChaptersAccordion({
  items,
  className,
}: {
  items: ChapterItem[];
  className?: string;
}) {
  if (!items.length) return null;
  return (
    <Accordion
      type="single"
      collapsible
      defaultValue="chapter-0"
      className={cn("flex flex-col gap-4", className)}
    >
      {items.map((ch, i) => (
        <AccordionItem
          key={`${ch.title}-${i}`}
          value={`chapter-${i}`}
          className="rounded-2xl border border-border bg-white px-5 transition-shadow data-[state=open]:shadow-[0_8px_24px_rgba(34,28,51,0.07)] sm:px-6"
        >
          <AccordionTrigger className="py-5 hover:no-underline">
            <span className="flex flex-1 flex-wrap items-center justify-between gap-x-4 gap-y-2 pr-2 text-left">
              <span className="min-w-0">
                <span className="block text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-soft">
                  Chapter {i + 1}
                </span>
                <span className="mt-1 block text-[16px] font-bold leading-snug text-ink sm:text-[17px]">
                  {ch.title}
                </span>
              </span>
              <span className="flex flex-wrap items-center gap-2">
                <span className="inline-flex shrink-0 items-center rounded-full bg-brand-soft px-3 py-1 text-[12px] font-semibold text-brand">
                  {ch.mins} mins
                </span>
                <span className={META_CHIP}>
                  <PlayCircle className="h-3.5 w-3.5 text-brand" aria-hidden />{" "}
                  {plural(ch.videos, "Video")}
                </span>
                <span className={META_CHIP}>
                  <BookOpen className="h-3.5 w-3.5 text-brand" aria-hidden />{" "}
                  {plural(ch.readings, "Reading")}
                </span>
                <span className={META_CHIP}>
                  <HelpCircle className="h-3.5 w-3.5 text-brand" aria-hidden />{" "}
                  {plural(ch.quizzes, "Quiz")}
                </span>
              </span>
            </span>
          </AccordionTrigger>
          <AccordionContent className="pb-6">
            <p className="text-[14px] leading-6 text-ink-soft">
              Master {ch.title} with {plural(ch.videos, "short conceptual video")},{" "}
              {plural(ch.readings, "reading material")} and {plural(ch.quizzes, "quiz")} to test
              yourself — around {ch.mins} mins of focused learning.
            </p>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
