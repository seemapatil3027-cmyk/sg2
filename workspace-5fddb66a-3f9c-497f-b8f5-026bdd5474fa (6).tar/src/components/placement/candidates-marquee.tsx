"use client";

import type { ReactNode } from "react";
import type { PlacedStudent } from "@prisma/client";
import { SectionHeading } from "@/components/shared/section";
import { InitialAvatar } from "@/components/shared/initial-avatar";

export function CandidatesMarquee({
  candidates,
  title = "Our candidates work at reputed companies",
  sub = "350+ companies trust SkilloVilla certified talent",
}: {
  candidates: PlacedStudent[];
  title?: ReactNode;
  sub?: string;
}) {
  // Double the array so the -50% marquee loop is seamless
  const doubled = [...candidates, ...candidates];

  return (
    <div>
      <SectionHeading align="center" title={title} sub={sub} />
      <div className="marquee-paused relative mt-10 overflow-hidden">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-background to-transparent" />
        <div className="flex w-max animate-marquee gap-5">
          {doubled.map((c, i) => (
            <div
              key={`${c.id}-${i}`}
              aria-hidden={i >= candidates.length}
              className="min-w-[240px] shrink-0 rounded-2xl border border-border bg-white p-5 transition-colors hover:border-brand/40"
            >
              <p className="truncate text-xs font-bold text-brand">{c.role}</p>
              <div className="mt-3 flex items-center gap-3">
                <InitialAvatar name={c.name} className="h-10 w-10 text-sm" />
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-ink">{c.name}</p>
                  <p className="truncate text-xs text-ink-soft">{c.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
