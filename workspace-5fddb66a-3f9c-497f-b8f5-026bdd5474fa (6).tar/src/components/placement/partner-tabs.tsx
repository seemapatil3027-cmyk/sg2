"use client";

import { useState } from "react";
import type { Company } from "@prisma/client";
import { SectionHeading } from "@/components/shared/section";
import { CompanyGrid } from "@/components/shared/company-marquee";
import { cn } from "@/lib/utils";

type PartnerCategory = "mnc" | "unicorn" | "startup";

const TABS: { key: PartnerCategory; label: string }[] = [
  { key: "mnc", label: "Global MNCs" },
  { key: "unicorn", label: "Unicorns" },
  { key: "startup", label: "Startups" },
];

export function PartnerTabs({
  companies,
}: {
  companies: Record<PartnerCategory, Company[]>;
}) {
  const [active, setActive] = useState<PartnerCategory>("mnc");
  const visible = companies[active] ?? [];

  return (
    <div>
      <SectionHeading
        align="center"
        label="HIRING PARTNERS"
        title="Companies where our alumni are working"
      />
      <div className="mt-8 flex flex-wrap justify-center gap-3" role="tablist" aria-label="Hiring partner categories">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            role="tab"
            aria-selected={active === t.key}
            onClick={() => setActive(t.key)}
            className={cn(
              "h-10 rounded-full px-6 text-sm font-semibold transition",
              active === t.key
                ? "bg-primary text-white shadow-md hover:bg-brand-dark"
                : "border border-border bg-white text-ink-soft hover:border-brand hover:text-brand"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="mt-10 rounded-3xl border border-border bg-white p-6 sm:p-10">
        {visible.length > 0 ? (
          <CompanyGrid companies={visible} />
        ) : (
          <p className="text-center text-sm text-ink-soft">Companies coming soon.</p>
        )}
      </div>
    </div>
  );
}
