/**
 * Small status/hike chip used on placed-student cards.
 * - status === "Fresher"  -> orange chip
 * - hike present          -> green chip with the hike text (e.g. "75% hike")
 * - otherwise             -> nothing
 * Safe to use in server components (no hooks).
 */
export function StudentBadge({ status, hike }: { status: string | null; hike: string | null }) {
  if (status === "Fresher") {
    return (
      <span className="inline-flex shrink-0 items-center rounded-full bg-accento-soft px-2.5 py-1 text-[11px] font-bold text-accento">
        🌱 Fresher
      </span>
    );
  }
  if (hike) {
    return (
      <span className="inline-flex shrink-0 items-center whitespace-nowrap rounded-full bg-[#DCF2E4] px-2.5 py-1 text-[11px] font-bold text-[#15803D]">
        ↑ {hike}
      </span>
    );
  }
  return null;
}
