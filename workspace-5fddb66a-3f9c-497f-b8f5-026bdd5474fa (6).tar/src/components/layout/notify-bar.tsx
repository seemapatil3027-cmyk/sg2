"use client";

import { useEffect, useState } from "react";
import { X, ArrowRight } from "lucide-react";

interface Announcement {
  id: string;
  text: React.ReactNode;
  bg: string;
}

const ANNOUNCEMENTS: Announcement[] = [
  {
    id: "meity",
    bg: "#6C0BB8",
    text: (
      <>
        Officially recognised by the{" "}
        <span className="font-bold">MEITY Startup Hub, Government of India</span>, for the contribution to India&apos;s tech
        ecosystem.
      </>
    ),
  },
  {
    id: "nasscom",
    bg: "#F5820D",
    text: (
      <>
        Proud to offer an <span className="font-bold">accredited curriculum</span> that builds{" "}
        <span className="font-bold">future-proof careers</span> for industry excellence.
      </>
    ),
  },
  {
    id: "forbes",
    bg: "#0E9F4F",
    text: (
      <>
        Honored to be recognized by <span className="font-bold">Forbes India</span> as one of the{" "}
        <span className="font-bold">DGEMS 200</span> companies with global business potential!
      </>
    ),
  },
];

export function NotifyBar() {
  const [index, setIndex] = useState(0);
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    if (closed) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % ANNOUNCEMENTS.length), 5000);
    return () => clearInterval(t);
  }, [closed]);

  if (closed) return null;
  const current = ANNOUNCEMENTS[index];

  return (
    <div
      className="relative z-[60] w-full text-white transition-colors duration-500"
      style={{ backgroundColor: current.bg }}
      role="region"
      aria-label="Announcements"
    >
      <div className="container-sv flex min-h-[46px] items-center justify-center gap-3 py-2 pr-10 text-center">
        <p className="text-[13px] leading-snug sm:text-[14px]">
          {current.text}
          {current.id === "forbes" && (
            <span className="ml-2 hidden cursor-pointer items-center gap-1 rounded-full bg-white/20 px-3 py-0.5 text-[12px] font-semibold sm:inline-flex">
              Know more <ArrowRight className="h-3 w-3" />
            </span>
          )}
        </p>
      </div>
      <button
        onClick={() => setClosed(true)}
        aria-label="Close announcement"
        className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 opacity-80 transition hover:opacity-100"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
