"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ChevronDown, LayoutGrid, LogOut, Menu, User2 } from "lucide-react";
import { Logo } from "./logo";
import { useUser } from "@/hooks/use-user";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const TRACK_LINKS = [
  { href: "/tracks/data-analytics-and-ai", label: "Data Analytics & Generative AI" },
  { href: "/tracks/data-analytics-offline", label: "Data Analytics Classroom Program" },
  { href: "/tracks/ai-mastery-program", label: "AI Mastery Program" },
  { href: "/tracks/data-analytics-python", label: "Data Analytics + Python" },
  { href: "/tracks/data-science-and-ai", label: "Data Science & AI" },
  { href: "/tracks/data-science-machine-learning", label: "Data Science & Machine Learning" },
  { href: "/tracks/software-development", label: "Software Development" },
];

const COURSE_LINKS = [
  { href: "/courses/python-for-data-science", label: "Python For Data Science" },
  { href: "/courses/data-analytics-and-statistics-using-python", label: "Data Analytics and Statistics Using Python" },
  { href: "/courses/machine-learning-using-python", label: "Machine Learning using Python" },
  { href: "/courses/excel-beginner-to-advanced", label: "Excel: Beginner to Advanced" },
  { href: "/courses/sql-beginner-to-advanced", label: "SQL: Beginner to Advanced" },
];

const PLACEMENT_LINKS = [
  { href: "/placement-assistance", label: "Placement Assistance", desc: "How we get you placed" },
  { href: "/placement-stats", label: "Placement Stats", desc: "92% placement rate, 8 LPA average" },
  { href: "/success-stories", label: "Success Stories", desc: "Alumni who made their mark" },
];

export function Navbar() {
  const { user, signOut } = useUser();
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 4);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  async function handleSignOut() {
    await signOut();
    router.push("/");
  }

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full bg-white/95 backdrop-blur transition-shadow",
        scrolled ? "shadow-[0_2px_16px_rgba(34,28,51,0.08)]" : "border-b border-transparent"
      )}
    >
      <nav className="container-sv flex h-[68px] items-center justify-between gap-4" aria-label="Main navigation">
        <Link href="/" aria-label="SkillGorila Homepage" className="shrink-0">
          <Logo />
        </Link>

        {/* Desktop nav */}
        <div className="hidden items-center gap-1 lg:flex">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-1 rounded-md px-3 py-2 text-[15px] font-medium text-ink transition hover:text-brand">
                Programs <ChevronDown className="h-4 w-4 opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-[280px] rounded-xl border-border p-2 shadow-xl">
              <DropdownMenuItem asChild>
                <Link href="/tracks" className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5">
                  <LayoutGrid className="h-4 w-4 text-brand" />
                  <span>
                    <span className="block text-sm font-semibold">Career Tracks</span>
                    <span className="block text-xs text-muted-foreground">Placement-focused programs</span>
                  </span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/courses" className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5">
                  <User2 className="h-4 w-4 text-brand" />
                  <span>
                    <span className="block text-sm font-semibold">Courses</span>
                    <span className="block text-xs text-muted-foreground">Upskill at your own pace</span>
                  </span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/how-it-works" className="cursor-pointer rounded-lg px-3 py-2 text-sm font-medium">
                  How it works
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/internships" className="cursor-pointer rounded-lg px-3 py-2 text-sm font-medium">
                  Internship Programs
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-1 rounded-md px-3 py-2 text-[15px] font-medium text-ink transition hover:text-brand">
                Placements <ChevronDown className="h-4 w-4 opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-[300px] rounded-xl border-border p-2 shadow-xl">
              {PLACEMENT_LINKS.map((l) => (
                <DropdownMenuItem key={l.href} asChild>
                  <Link href={l.href} className="flex cursor-pointer flex-col rounded-lg px-3 py-2.5">
                    <span className="text-sm font-semibold">{l.label}</span>
                    <span className="text-xs text-muted-foreground">{l.desc}</span>
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <NavLink href="/blogs" label="Blogs" active={pathname === "/blogs"} />
          <NavLink href="/hire-from-us" label="Hire From Us" active={pathname === "/hire-from-us"} />
        </div>

        <div className="flex items-center gap-2.5">
          <Link
            href="/tracks"
            className="hidden rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-dark sm:inline-flex"
          >
            Explore Programs
          </Link>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="hidden items-center gap-2 rounded-full border border-input bg-white py-1.5 pl-1.5 pr-3 text-sm font-medium transition hover:border-brand sm:inline-flex">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand text-xs font-bold text-white">
                    {user.name.charAt(0).toUpperCase()}
                  </span>
                  <span className="max-w-[90px] truncate">{user.name.split(" ")[0]}</span>
                  <ChevronDown className="h-3.5 w-3.5 opacity-60" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52 rounded-xl p-2">
                <div className="px-3 py-2">
                  <p className="truncate text-sm font-semibold">{user.name}</p>
                  <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/tracks" className="cursor-pointer rounded-lg px-3 py-2 text-sm">
                    Explore Programs
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleSignOut}
                  className="cursor-pointer rounded-lg px-3 py-2 text-sm text-red-600 focus:text-red-600"
                >
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link
              href="/signin"
              className="hidden rounded-lg border border-brand px-5 py-2 text-sm font-semibold text-brand transition hover:bg-brand-soft sm:inline-flex"
            >
              Sign in
            </Link>
          )}

          {/* Mobile menu */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-input lg:hidden" aria-label="Open menu">
                <Menu className="h-5 w-5" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[320px] overflow-y-auto p-0" onClick={() => setOpen(false)}>
              <SheetTitle className="sr-only">Navigation menu</SheetTitle>
              <div className="border-b border-border p-4">
                <Logo />
              </div>
              <div className="flex flex-col gap-1 p-4 text-[15px] font-medium">
                <p className="px-2 pb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">Programs</p>
                <Link href="/tracks" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Career Tracks</Link>
                <Link href="/courses" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Courses</Link>
                <Link href="/how-it-works" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">How it works</Link>
                <Link href="/internships" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Internship Programs</Link>
                <p className="px-2 pb-1 pt-3 text-xs font-bold uppercase tracking-wide text-muted-foreground">Placements</p>
                <Link href="/placement-assistance" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Placement Assistance</Link>
                <Link href="/placement-stats" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Placement Stats</Link>
                <Link href="/success-stories" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Success Stories</Link>
                <p className="px-2 pb-1 pt-3 text-xs font-bold uppercase tracking-wide text-muted-foreground">More</p>
                <Link href="/blogs" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Blogs</Link>
                <Link href="/hire-from-us" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Hire From Us</Link>
                <Link href="/about-us" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">About us</Link>
                <Link href="/contact-us" className="rounded-lg px-2 py-2 hover:bg-brand-soft hover:text-brand">Contact us</Link>
                <div className="mt-4 flex flex-col gap-2">
                  <Link href="/tracks" className="rounded-lg bg-primary px-4 py-2.5 text-center text-sm font-semibold text-white">
                    Explore Programs
                  </Link>
                  {user ? (
                    <button onClick={handleSignOut} className="rounded-lg border border-input px-4 py-2.5 text-center text-sm font-semibold">
                      Sign out ({user.name.split(" ")[0]})
                    </button>
                  ) : (
                    <Link href="/signin" className="rounded-lg bg-brand-soft px-4 py-2.5 text-center text-sm font-semibold text-brand">
                      Staff sign-in
                    </Link>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}

function NavLink({ href, label, active }: { href: string; label: string; active?: boolean }) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-1 rounded-md px-3 py-2 text-[15px] font-medium text-ink transition hover:text-brand",
        active && "text-brand"
      )}
    >
      {label}
    </Link>
  );
}
