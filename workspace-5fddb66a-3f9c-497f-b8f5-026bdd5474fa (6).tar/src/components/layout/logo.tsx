import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("h-8 w-8", className)} aria-hidden="true">
      {/* orange chevron top */}
      <path d="M20 3 L33 12 L27 16 L20 11 L13 16 L7 12 Z" fill="#F5A623" />
      {/* purple diamond body */}
      <path d="M8 15 L20 24 L32 15 L32 22 L20 31 L8 22 Z" fill="#5D18BE" />
      <path d="M14 26 L20 30.5 L26 26 L26 33 L20 37.5 L14 33 Z" fill="#7A3BE0" opacity="0.9" />
    </svg>
  );
}

export function Logo({ className, textClassName, markClassName }: { className?: string; textClassName?: string; markClassName?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <LogoMark className={markClassName} />
      <span className={cn("text-[22px] font-bold tracking-tight text-ink", textClassName)}>
        SkillGorila
      </span>
    </span>
  );
}
