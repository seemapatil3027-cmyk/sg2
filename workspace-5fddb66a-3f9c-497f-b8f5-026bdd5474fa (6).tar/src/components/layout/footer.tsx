import Link from "next/link";
import { Facebook, Instagram, Youtube, Twitter, Linkedin } from "lucide-react";
import { Logo } from "./logo";

const PROGRAMS = [
  { href: "/tracks", label: "Career Tracks" },
  { href: "/courses", label: "Courses" },
  { href: "/internships", label: "Internships" },
  { href: "/how-it-works", label: "How it works" },
];

const TOP_TRACKS = [
  { href: "/tracks/data-analytics-and-ai", label: "Data Analytics & Generative AI" },
  { href: "/tracks/data-analytics-offline", label: "Data Analytics Classroom Program" },
  { href: "/tracks/ai-mastery-program", label: "AI Mastery Program" },
  { href: "/tracks/data-analytics-python", label: "Data Analytics + Python" },
  { href: "/tracks/data-science-and-ai", label: "Data Science & AI" },
  { href: "/tracks/data-science-machine-learning", label: "Data Science & Machine Learning" },
  { href: "/tracks/software-development", label: "Software Development" },
];

const POPULAR_COURSES = [
  { href: "/courses/python-for-data-science", label: "Python For Data Science" },
  { href: "/courses/data-analytics-and-statistics-using-python", label: "Data Analytics and Statistics Using Python" },
  { href: "/courses/machine-learning-using-python", label: "Machine Learning using Python" },
  { href: "/courses/excel-beginner-to-advanced", label: "Excel: Beginner to Advanced" },
  { href: "/courses/sql-beginner-to-advanced", label: "SQL: Beginner to Advanced" },
];

const FOR_STUDENTS = [
  { href: "/placement-assistance", label: "Placement Assistance" },
  { href: "/success-stories", label: "Success Stories" },
  { href: "/tracks", label: "Career Tracks" },
  { href: "/courses", label: "Courses" },
];

const FOR_EMPLOYERS = [
  { href: "/hire-from-us", label: "Hire From Us" },
  { href: "/contact-us", label: "Contact us" },
];

const RESOURCES = [
  { href: "/blogs", label: "Blogs" },
  { href: "/placement-stats", label: "Placement Stats" },
  { href: "/#faq", label: "FAQs" },
  { href: "/about-us", label: "About us" },
];

const COMPANY = [
  { href: "/", label: "Home" },
  { href: "/contact-us", label: "Contact us" },
  { href: "/about-us", label: "About us" },
];

const SOCIALS = [
  { icon: Facebook, label: "Facebook", href: "https://facebook.com" },
  { icon: Instagram, label: "Instagram", href: "https://instagram.com" },
  { icon: Youtube, label: "YouTube", href: "https://youtube.com" },
  { icon: Twitter, label: "Twitter", href: "https://twitter.com" },
  { icon: Linkedin, label: "LinkedIn", href: "https://linkedin.com" },
];

const COLUMNS: { title: string; links: { href: string; label: string }[] }[] = [
  { title: "Programs", links: PROGRAMS },
  { title: "Top Tracks", links: TOP_TRACKS },
  { title: "Popular Courses", links: POPULAR_COURSES },
  { title: "Learners", links: FOR_STUDENTS },
  { title: "For Employers", links: FOR_EMPLOYERS },
  { title: "Resources", links: RESOURCES },
  { title: "Company", links: COMPANY },
];

function FooterCol({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <nav aria-label={title}>
      <h3 className="mb-4 text-[12.5px] font-bold uppercase tracking-[0.12em] text-gold">{title}</h3>
      <ul className="space-y-2.5">
        {links.map((l) => (
          <li key={l.href + l.label}>
            <Link href={l.href} className="text-[13.5px] leading-5 text-white/75 transition hover:text-white">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="mt-auto">
      {/* curved top edge */}
      <div className="h-10 w-full overflow-hidden">
        <svg viewBox="0 0 1440 60" preserveAspectRatio="none" className="block h-full w-full">
          <path d="M0,60 C360,0 1080,0 1440,60 L1440,60 L0,60 Z" fill="#2E1A47" />
        </svg>
      </div>
      <div className="bg-[#2E1A47] text-white">
        <div className="container-sv pb-10 pt-2">
          {/* brand block */}
          <div className="flex flex-col gap-6 border-b border-white/10 pb-8 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <Logo textClassName="text-white text-[24px]" />
              <p className="mt-3 max-w-[420px] text-[14px] leading-6 text-white/70">
                The Career Operating System — learn, practice, prove, connect and get hired, all in
                one place.
              </p>
            </div>
            <div className="flex gap-3">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={s.label}
                  className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/25"
                >
                  <s.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* link columns */}
          <div className="mt-9 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
            {COLUMNS.map((col) => (
              <FooterCol key={col.title} title={col.title} links={col.links} />
            ))}
          </div>
        </div>

        <div className="border-t border-white/10">
          <div className="container-sv flex flex-col items-center justify-between gap-3 py-5 text-[12.5px] text-white/60 sm:flex-row">
            <p>
              This site is protected by reCAPTCHA and the Google{" "}
              <a href="#" className="underline">Privacy Policy</a> and{" "}
              <a href="#" className="underline">Terms of Service</a> apply.
            </p>
            <div className="flex items-center gap-2">
              <Link href="#" className="transition hover:text-white">Terms of use</Link>
              <span className="text-[8px]">●</span>
              <Link href="#" className="transition hover:text-white">Refund Policy</Link>
              <span className="text-[8px]">●</span>
              <Link href="#" className="transition hover:text-white">Privacy Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
