"use client";

import { useState } from "react";
import { Phone } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LeadForm } from "@/components/shared/lead-form";
import { Logo } from "./logo";

export function FloatingCall() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Request a callback"
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-white shadow-[0_8px_24px_rgba(93,24,190,0.45)] transition hover:scale-105 hover:bg-brand-dark"
      >
        <Phone className="h-5 w-5" />
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md rounded-2xl p-0 overflow-hidden">
          <div className="flex items-center gap-2 bg-brand-soft px-6 py-4">
            <Logo markClassName="h-6 w-6" />
            <span className="text-sm font-semibold text-brand">Request a callback</span>
          </div>
          <div className="p-6">
            <DialogHeader className="mb-4 text-left">
              <DialogTitle className="text-xl font-bold">Still have questions?</DialogTitle>
              <DialogDescription className="text-sm text-muted-foreground">
                Request a callback to get in touch with our academic counsellors.
              </DialogDescription>
            </DialogHeader>
            <LeadForm source="callback" submitLabel="Request a Callback" onDone={() => setTimeout(() => setOpen(false), 1800)} />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
