"use client";

import { cn } from "@/lib/utils";
import {
  BarChart3,
  BookOpen,
  Briefcase,
  Calculator,
  Camera,
  ClipboardCheck,
  Code2,
  Cpu,
  Database,
  FileText,
  Globe,
  GraduationCap,
  Layers,
  LineChart,
  Megaphone,
  Monitor,
  Music,
  Palette,
  PenLine,
  PenTool,
  Server,
  Smartphone,
  Sparkles,
  Target,
  Terminal,
  Video,
  Wrench,
  type LucideIcon,
} from "lucide-react";

/* ── Lesson types ── */

export const LESSON_TYPES = ["VIDEO", "DOCUMENT", "QUIZ", "ASSIGNMENT"] as const;
export type LessonType = (typeof LESSON_TYPES)[number];

export const LESSON_TYPE_META: Record<string, { icon: LucideIcon; label: string; tone: string }> = {
  VIDEO: { icon: Video, label: "Video", tone: "bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300" },
  DOCUMENT: { icon: FileText, label: "Document", tone: "bg-orange-50 text-orange-600 dark:bg-orange-500/15 dark:text-orange-300" },
  QUIZ: { icon: ClipboardCheck, label: "Quiz", tone: "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300" },
  ASSIGNMENT: { icon: PenLine, label: "Assignment", tone: "bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300" },
};

export function LessonTypeIcon({ type, className }: { type: string; className?: string }) {
  const meta = LESSON_TYPE_META[type?.toUpperCase()] ?? LESSON_TYPE_META.DOCUMENT;
  const Icon = meta.icon;
  return (
    <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-lg", meta.tone, className)}>
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
    </span>
  );
}

/* ── Course icon picker data ── */

const COURSE_ICON_MAP: Record<string, LucideIcon> = {
  BookOpen,
  BarChart3,
  Briefcase,
  Calculator,
  Camera,
  Code2,
  Cpu,
  Database,
  FileText,
  Globe,
  GraduationCap,
  Layers,
  LineChart,
  Megaphone,
  Monitor,
  Music,
  Palette,
  PenTool,
  Server,
  Smartphone,
  Sparkles,
  Target,
  Terminal,
  Wrench,
};

export const COURSE_ICON_NAMES = Object.keys(COURSE_ICON_MAP);

export function CourseIcon({ name, className }: { name: string | null | undefined; className?: string }) {
  const Icon = (name && COURSE_ICON_MAP[name]) || BookOpen;
  return <Icon className={cn("h-5 w-5", className)} aria-hidden="true" />;
}

/* ── Tiny progress bar (avoids radix overhead in dense tables) ── */

export function ProgressBar({
  value,
  className,
  barClassName,
}: {
  value: number;
  className?: string;
  barClassName?: string;
}) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div
      className={cn("h-2 w-full overflow-hidden rounded-full bg-muted", className)}
      role="progressbar"
      aria-valuenow={v}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={cn(
          "h-full rounded-full transition-all",
          v >= 100 ? "bg-emerald-500" : v >= 50 ? "bg-brand" : "bg-amber-500",
          barClassName
        )}
        style={{ width: `${v}%` }}
      />
    </div>
  );
}

/* ── Normalizes basic picker responses (array or {items}) ── */

export function asList<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object" && Array.isArray((data as { items?: unknown }).items)) {
    return (data as { items: T[] }).items;
  }
  return [];
}

/* ── Shared row types ── */

export interface BasicCourse {
  id: string;
  title: string;
  slug: string;
}
