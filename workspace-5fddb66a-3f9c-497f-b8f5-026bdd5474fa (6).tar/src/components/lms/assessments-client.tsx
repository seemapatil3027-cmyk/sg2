"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { api, fmt, useApi } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { EmptyState, ErrorBlock, LoadingBlock } from "@/components/platform/states";
import { StatusBadge } from "@/components/platform/status-badge";
import { DataTable, type Column } from "@/components/platform/data-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Award,
  BookOpen,
  ClipboardCheck,
  Clock,
  HelpCircle,
  Layers,
  Loader2,
  PenLine,
  Plus,
  Target,
} from "lucide-react";

/* ── API shapes ── */

interface QuizSummary {
  id: string;
  courseId: string;
  courseTitle: string;
  lessonId: string | null;
  title: string;
  passScore: number;
  questionCount: number;
  attemptCount: number;
  avgScore: number | null;
  passRate: number | null;
}

interface SubmissionRow {
  id: string;
  assignmentId: string;
  assignmentTitle: string;
  maxPoints: number;
  courseId: string | null;
  courseTitle: string;
  enrollmentId: string;
  learnerName: string;
  batchName: string | null;
  status: string;
  grade: number | null;
  feedback: string | null;
  gradedBy: string | null;
  contentText: string | null;
  fileUrl: string | null;
  submittedAt: string;
  gradedAt: string | null;
}

interface AssessmentsData {
  quizzes: QuizSummary[];
  submissions: SubmissionRow[];
}

export function AssessmentsClient({ canManage }: { canManage: boolean }) {
  const { data, loading, error, refetch } = useApi<AssessmentsData>("/api/lms/assessments");
  const [tab, setTab] = useState("quizzes");
  const [quizSheetId, setQuizSheetId] = useState<string | null>(null);
  const [attemptQuiz, setAttemptQuiz] = useState<QuizSummary | null>(null);
  const [gradeSubmission, setGradeSubmission] = useState<SubmissionRow | null>(null);

  const quizzes = data?.quizzes ?? [];
  const submissions = data?.submissions ?? [];

  const totals = useMemo(() => {
    const attempts = quizzes.reduce((s, q) => s + q.attemptCount, 0);
    const passed = quizzes.reduce((s, q) => s + Math.round(((q.passRate ?? 0) / 100) * q.attemptCount), 0);
    const avg =
      quizzes.filter((q) => q.avgScore !== null).length > 0
        ? Math.round(
            quizzes.filter((q) => q.avgScore !== null).reduce((s, q) => s + (q.avgScore ?? 0), 0) /
              quizzes.filter((q) => q.avgScore !== null).length
          )
        : 0;
    return { attempts, passed, avg, pending: submissions.filter((s) => s.status === "SUBMITTED").length };
  }, [quizzes, submissions]);

  if (loading) return <LoadingBlock label="Loading assessments…" className="min-h-[50vh]" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Assessments"
        description="Quizzes and assignment submissions across the catalog — record attempts and grade work."
      />

      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard label="Quizzes" value={quizzes.length} icon={ClipboardCheck} />
        <StatCard label="Quiz attempts" value={totals.attempts} icon={Target} tone="orange" hint={`${totals.passed} passed`} />
        <StatCard label="Avg score" value={`${totals.avg}%`} icon={Award} tone="green" />
        <StatCard label="Pending grading" value={totals.pending} icon={PenLine} tone="amber" />
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="rounded-xl">
          <TabsTrigger value="quizzes" className="rounded-lg">
            <ClipboardCheck className="mr-1.5 h-3.5 w-3.5" /> Quizzes
          </TabsTrigger>
          <TabsTrigger value="submissions" className="rounded-lg">
            <PenLine className="mr-1.5 h-3.5 w-3.5" /> Assignment submissions
            {totals.pending > 0 ? (
              <span className="ml-1.5 rounded-full bg-amber-100 px-1.5 text-[10px] font-bold text-amber-700 dark:bg-amber-500/20 dark:text-amber-300">
                {totals.pending}
              </span>
            ) : null}
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {tab === "quizzes" ? (
        quizzes.length === 0 ? (
          <EmptyState
            icon={ClipboardCheck}
            title="No quizzes yet"
            hint="Create quizzes on QUIZ lessons inside the course builder."
            action={
              <Button variant="outline" asChild>
                <Link href="/lms/courses">
                  <BookOpen className="mr-2 h-4 w-4" /> Open courses
                </Link>
              </Button>
            }
          />
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {quizzes.map((q) => (
              <div key={q.id} className="flex flex-col rounded-2xl border bg-card p-4 shadow-sm transition hover:shadow-md">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                      {q.courseTitle}
                    </p>
                    <h3 className="mt-0.5 truncate text-sm font-semibold">{q.title}</h3>
                  </div>
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300">
                    <ClipboardCheck className="h-4 w-4" />
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-4 gap-2 rounded-xl bg-muted/40 px-2 py-2 text-center">
                  <div>
                    <p className="text-sm font-bold">{q.questionCount}</p>
                    <p className="text-[10px] text-muted-foreground">questions</p>
                  </div>
                  <div>
                    <p className="text-sm font-bold">{q.attemptCount}</p>
                    <p className="text-[10px] text-muted-foreground">attempts</p>
                  </div>
                  <div>
                    <p className="text-sm font-bold">{q.avgScore !== null ? `${q.avgScore}%` : "—"}</p>
                    <p className="text-[10px] text-muted-foreground">avg score</p>
                  </div>
                  <div>
                    <p className="text-sm font-bold">{q.passRate !== null ? `${q.passRate}%` : "—"}</p>
                    <p className="text-[10px] text-muted-foreground">pass rate</p>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2 border-t pt-3">
                  <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                    <Target className="h-3 w-3" /> Pass at {q.passScore}%
                  </span>
                  <div className="flex gap-1.5">
                    <Button variant="outline" size="sm" onClick={() => setQuizSheetId(q.id)}>
                      Attempts
                    </Button>
                    {canManage ? (
                      <Button size="sm" disabled={q.questionCount === 0} onClick={() => setAttemptQuiz(q)}>
                        <Plus className="mr-1 h-3.5 w-3.5" /> Attempt
                      </Button>
                    ) : null}
                  </div>
                </div>
                {q.questionCount === 0 ? (
                  <p className="mt-2 inline-flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400">
                    <HelpCircle className="h-3 w-3" /> No questions yet — add them in the builder.
                  </p>
                ) : null}
              </div>
            ))}
          </div>
        )
      ) : submissions.length === 0 ? (
        <EmptyState
          icon={PenLine}
          title="No submissions yet"
          hint="Learner submissions will appear here for grading."
        />
      ) : (
        <SubmissionsTable
          rows={submissions}
          canManage={canManage}
          onGrade={(s) => setGradeSubmission(s)}
        />
      )}

      {/* quiz attempts sheet */}
      <Sheet open={quizSheetId !== null} onOpenChange={(open) => !open && setQuizSheetId(null)}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-lg nice-scrollbar">
          <SheetTitle className="sr-only">Quiz attempts</SheetTitle>
          {quizSheetId ? (
            <QuizAttemptsPanel quizId={quizSheetId} onRecord={() => {
              const q = quizzes.find((x) => x.id === quizSheetId);
              if (q) setAttemptQuiz(q);
            }} />
          ) : null}
        </SheetContent>
      </Sheet>

      {/* record attempt dialog */}
      <RecordAttemptDialog
        open={attemptQuiz !== null}
        quiz={attemptQuiz}
        onClose={async (recorded) => {
          setAttemptQuiz(null);
          if (recorded) await refetch();
        }}
      />

      {/* grade dialog */}
      <GradeDialog
        open={gradeSubmission !== null}
        submission={gradeSubmission}
        onClose={async (saved) => {
          setGradeSubmission(null);
          if (saved) await refetch();
        }}
      />
    </div>
  );
}

/* ── Submissions table ── */

function SubmissionsTable({
  rows,
  canManage,
  onGrade,
}: {
  rows: SubmissionRow[];
  canManage: boolean;
  onGrade: (s: SubmissionRow) => void;
}) {
  const [selected, setSelected] = useState<SubmissionRow | null>(null);
  const columns: Column<SubmissionRow>[] = [
    {
      key: "assignmentTitle",
      header: "Assignment",
      sortable: true,
      render: (s) => (
        <div className="min-w-0">
          <p className="truncate font-semibold">{s.assignmentTitle}</p>
          <p className="truncate text-xs text-muted-foreground">{s.courseTitle}</p>
        </div>
      ),
    },
    { key: "learnerName", header: "Learner", sortable: true, render: (s) => <span className="font-medium">{s.learnerName}</span> },
    { key: "status", header: "Status", render: (s) => <StatusBadge value={s.status} /> },
    {
      key: "submittedAt",
      header: "Submitted",
      sortable: true,
      render: (s) => <span className="whitespace-nowrap text-muted-foreground">{fmt.date(s.submittedAt)}</span>,
    },
    {
      key: "grade",
      header: "Grade",
      sortable: true,
      render: (s) =>
        s.grade !== null ? (
          <span className="font-semibold">
            {s.grade}
            <span className="text-muted-foreground">/{s.maxPoints}</span>
          </span>
        ) : (
          <span className="text-xs text-amber-600 dark:text-amber-400">Pending</span>
        ),
    },
    {
      key: "actions",
      header: "",
      className: "w-28",
      render: (s) =>
        canManage ? (
          <Button
            size="sm"
            variant={s.status === "SUBMITTED" ? "default" : "outline"}
            onClick={(e) => {
              e.stopPropagation();
              onGrade(s);
            }}
          >
            {s.status === "SUBMITTED" ? "Grade" : "Re-grade"}
          </Button>
        ) : null,
    },
  ];

  return (
    <>
      <DataTable
        columns={columns}
        rows={rows}
        rowKey={(s) => s.id}
        onRowClick={(s) => setSelected(s)}
        pageSize={10}
        searchPlaceholder="Search submissions…"
        filterFn={(s, q) => `${s.assignmentTitle} ${s.learnerName} ${s.courseTitle}`.toLowerCase().includes(q)}
        emptyTitle="No submissions"
      />
      <Sheet open={selected !== null} onOpenChange={(open) => !open && setSelected(null)}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-md nice-scrollbar">
          <SheetTitle className="sr-only">Submission details</SheetTitle>
          {selected ? <SubmissionPanel submission={selected} /> : null}
        </SheetContent>
      </Sheet>
    </>
  );
}

function SubmissionPanel({ submission }: { submission: SubmissionRow }) {
  return (
    <div className="space-y-4">
      <SheetHeader>
        <SheetTitle className="flex items-center gap-2">
          {submission.assignmentTitle} <StatusBadge value={submission.status} />
        </SheetTitle>
        <SheetDescription>
          {submission.learnerName} · {submission.courseTitle} · {submission.maxPoints} points
        </SheetDescription>
      </SheetHeader>
      <div className="rounded-2xl border bg-muted/30 p-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Submitted {fmt.dateTime(submission.submittedAt)}</p>
        {submission.contentText ? (
          <p className="mt-2 whitespace-pre-wrap rounded-xl bg-card p-3 text-sm">{submission.contentText}</p>
        ) : (
          <p className="mt-2 text-xs text-muted-foreground">No text content.</p>
        )}
        {submission.fileUrl ? (
          <a
            href={submission.fileUrl}
            target="_blank"
            rel="noreferrer"
            className="mt-2 inline-block text-sm font-medium text-brand hover:underline"
          >
            View attached file →
          </a>
        ) : null}
      </div>
      {submission.grade !== null ? (
        <div className="rounded-2xl border p-3 text-sm">
          <p className="font-semibold">
            Grade: {submission.grade}/{submission.maxPoints}
          </p>
          {submission.feedback ? <p className="mt-1 text-muted-foreground">“{submission.feedback}”</p> : null}
          <p className="mt-2 text-[11px] text-muted-foreground">
            Graded by {submission.gradedBy ?? "—"} · {submission.gradedAt ? fmt.dateTime(submission.gradedAt) : "—"}
          </p>
        </div>
      ) : null}
    </div>
  );
}

/* ── Grade dialog ── */

function GradeDialog({
  open,
  submission,
  onClose,
}: {
  open: boolean;
  submission: SubmissionRow | null;
  onClose: (saved: boolean) => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [grade, setGrade] = useState("");
  const [feedback, setFeedback] = useState("");
  const [saving, setSaving] = useState(false);
  const [seed, setSeed] = useState("");

  if (open && submission && seed !== submission.id) {
    setSeed(submission.id);
    setGrade(submission.grade !== null ? String(submission.grade) : "");
    setFeedback(submission.feedback ?? "");
  }

  async function save() {
    if (!submission) return;
    const g = Number(grade);
    if (Number.isNaN(g) || g < 0) {
      toast({ title: "Enter a valid grade", variant: "destructive" });
      return;
    }
    if (g > submission.maxPoints) {
      toast({ title: `Grade cannot exceed ${submission.maxPoints} points`, variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.patch("/api/lms/assessments/grade", {
        submissionId: submission.id,
        grade: Math.round(g),
        feedback: feedback.trim() || null,
      });
      toast({
        title: "Submission graded",
        description: `${submission.learnerName} · ${Math.round(g)}/${submission.maxPoints} on "${submission.assignmentTitle}".`,
      });
      await onClose(true);
    } catch (e) {
      toast({ title: "Grading failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && void onClose(false)}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Grade submission</DialogTitle>
          <DialogDescription>
            {submission?.learnerName} · {submission?.assignmentTitle} (max {submission?.maxPoints})
          </DialogDescription>
        </DialogHeader>
        {submission?.contentText ? (
          <div className="max-h-32 overflow-y-auto rounded-xl border bg-muted/30 p-3 text-xs text-muted-foreground nice-scrollbar">
            <p className="whitespace-pre-wrap">{submission.contentText}</p>
          </div>
        ) : null}
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label htmlFor="grade-input">Grade (out of {submission?.maxPoints}) *</Label>
            <Input id="grade-input" type="number" min={0} max={submission?.maxPoints ?? 100} value={grade} onChange={(e) => setGrade(e.target.value)} />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="grade-feedback">Feedback</Label>
            <Textarea id="grade-feedback" rows={3} value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder="What was good, what to improve…" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => void onClose(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={() => void save()} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save grade
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Quiz attempts sheet ── */

function QuizAttemptsPanel({ quizId, onRecord }: { quizId: string; onRecord: () => void }) {
  const { data, loading, error } = useApi<{
    quiz: { id: string; title: string; passScore: number; courseId: string };
    course: { id: string; title: string } | null;
    attempts: { id: string; learnerName: string; score: number; maxScore: number; percent: number; passed: boolean; submittedAt: string }[];
  }>(`/api/lms/quizzes?quizId=${quizId}`);

  if (loading) return <LoadingBlock label="Loading quiz…" />;
  if (error) return <ErrorBlock message={error} />;
  if (!data) return null;

  return (
    <div className="space-y-4">
      <SheetHeader>
        <SheetTitle>{data.quiz.title}</SheetTitle>
        <SheetDescription>
          {data.course?.title} · pass at {data.quiz.passScore}% · {data.attempts.length} attempt
          {data.attempts.length === 1 ? "" : "s"}
        </SheetDescription>
      </SheetHeader>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" asChild>
          <Link href={`/lms/courses/${data.quiz.courseId}`}>
            <Layers className="mr-2 h-3.5 w-3.5" /> Edit in builder
          </Link>
        </Button>
        <Button size="sm" onClick={onRecord}>
          <Plus className="mr-2 h-3.5 w-3.5" /> Record attempt
        </Button>
      </div>
      {data.attempts.length === 0 ? (
        <p className="rounded-xl border border-dashed p-6 text-center text-xs text-muted-foreground">
          No attempts recorded yet.
        </p>
      ) : (
        <ul className="space-y-1.5">
          {data.attempts.map((a) => (
            <li key={a.id} className="flex items-center justify-between gap-2 rounded-xl border px-3 py-2.5">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{a.learnerName}</p>
                <p className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Clock className="h-3 w-3" /> {fmt.dateTime(a.submittedAt)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold">
                  {a.score}/{a.maxScore}
                  <span className="ml-1 text-xs font-medium text-muted-foreground">({a.percent}%)</span>
                </span>
                <StatusBadge value={a.passed ? "PASSED" : "FAILED"} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ── Record attempt dialog ── */

function RecordAttemptDialog({
  open,
  quiz,
  onClose,
}: {
  open: boolean;
  quiz: QuizSummary | null;
  onClose: (recorded: boolean) => void | Promise<void>;
}) {
  const { toast } = useToast();
  const { data: quizDetail, loading: questionsLoading } = useApi<{
    questions: { id: string; text: string; type: string; options: string[]; correct: number[]; points: number }[];
  }>(open && quiz ? `/api/lms/quizzes?quizId=${quiz.id}` : null);
  const { data: enrollmentList } = useApi<{ items: { id: string; learnerName: string; status: string }[] }>(
    open && quiz ? `/api/lms/enrollments?courseId=${quiz.courseId}&pageSize=100` : null
  );

  const [enrollmentId, setEnrollmentId] = useState("");
  const [marks, setMarks] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<{ score: number; maxScore: number; percent: number; passed: boolean } | null>(null);
  const [seed, setSeed] = useState("");

  if (open && quiz && seed !== quiz.id) {
    setSeed(quiz.id);
    setEnrollmentId("");
    setMarks({});
    setResult(null);
  }

  const questions = quizDetail?.questions ?? [];
  const learners = (enrollmentList?.items ?? []).filter((e) => e.status !== "DROPPED");

  function setMark(questionId: string, correct: boolean) {
    setMarks((m) => ({ ...m, [questionId]: correct }));
  }

  async function submit() {
    if (!quiz || !enrollmentId) {
      toast({ title: "Select the learner", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const answers = questions.map((q) => (marks[q.id] ? q.correct : []));
      const res = await api.post<{ score: number; maxScore: number; percent: number; passed: boolean }>(
        "/api/lms/assessments/attempt",
        { quizId: quiz.id, enrollmentId, answers }
      );
      setResult(res);
      toast({
        title: res.passed ? "Attempt recorded — passed 🎉" : "Attempt recorded — failed",
        description: `${res.score}/${res.maxScore} (${res.percent}%) · pass mark ${quiz.passScore}%`,
        variant: res.passed ? "default" : "destructive",
      });
      await onClose(true);
    } catch (e) {
      toast({ title: "Could not record attempt", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && void onClose(false)}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg nice-scrollbar">
        <DialogHeader>
          <DialogTitle>Record quiz attempt</DialogTitle>
          <DialogDescription>
            {quiz?.title} · {quiz?.courseTitle}. Tick each question the learner answered correctly — the score is
            auto-computed.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label>Learner *</Label>
            <Select value={enrollmentId} onValueChange={setEnrollmentId}>
              <SelectTrigger aria-label="Select learner">
                <SelectValue placeholder="Select enrollment" />
              </SelectTrigger>
              <SelectContent className="max-h-56">
                {learners.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.learnerName} ({e.status.toLowerCase()})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {questionsLoading ? (
            <p className="text-xs text-muted-foreground">Loading questions…</p>
          ) : questions.length === 0 ? (
            <p className="rounded-xl border border-dashed p-4 text-center text-xs text-muted-foreground">
              This quiz has no questions — add them in the builder first.
            </p>
          ) : (
            <div className="space-y-1.5">
              <Label>Questions — learner answered correctly?</Label>
              {questions.map((q, i) => (
                <label
                  key={q.id}
                  className={cn(
                    "flex cursor-pointer items-start gap-2.5 rounded-xl border p-2.5 text-sm transition hover:bg-muted/50",
                    marks[q.id] && "border-emerald-300 bg-emerald-50/60 dark:border-emerald-500/40 dark:bg-emerald-500/10"
                  )}
                >
                  <Checkbox
                    checked={Boolean(marks[q.id])}
                    onCheckedChange={(checked) => setMark(q.id, checked === true)}
                    className="mt-0.5"
                    aria-label={`Question ${i + 1} answered correctly`}
                  />
                  <span className="min-w-0">
                    <span className="block font-medium">
                      {i + 1}. {q.text}
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      {q.type === "BOOLEAN" ? "True/False" : q.type === "MULTI" ? "Multiple answers" : "Single choice"} ·{" "}
                      {q.points} pt{q.points === 1 ? "" : "s"}
                    </span>
                  </span>
                </label>
              ))}
            </div>
          )}
          {result ? (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm dark:border-emerald-500/40 dark:bg-emerald-500/10">
              Last result: {result.score}/{result.maxScore} ({result.percent}%) — {result.passed ? "passed" : "failed"}
            </div>
          ) : null}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => void onClose(false)} disabled={saving}>
            Done
          </Button>
          <Button onClick={() => void submit()} disabled={saving || !enrollmentId || questions.length === 0}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ClipboardCheck className="mr-2 h-4 w-4" />}
            Record & auto-grade
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
