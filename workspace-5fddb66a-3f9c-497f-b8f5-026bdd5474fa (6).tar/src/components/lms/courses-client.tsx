"use client";

import { useMemo, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { api, useApi } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { CreateButton, EmptyState, ErrorBlock, LoadingBlock } from "@/components/platform/states";
import { StatusBadge } from "@/components/platform/status-badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Archive,
  BookOpen,
  CalendarDays,
  Clock,
  Edit3,
  Eye,
  GraduationCap,
  Layers,
  ListVideo,
  Loader2,
  MoreVertical,
  Plus,
  Rocket,
  RotateCcw,
  Trash2,
  Upload,
  Users,
} from "lucide-react";
import { asList, CourseIcon, COURSE_ICON_NAMES } from "@/components/lms/shared";

interface CourseRow {
  id: string;
  slug: string;
  title: string;
  description: string;
  status: string;
  level: string;
  weeks: number;
  hrsPerDay: number;
  icon: string;
  thumbnail: string | null;
  prerequisite: string;
  categoryId: string | null;
  categoryName: string | null;
  categoryColor: string | null;
  ownerName: string | null;
  moduleCount: number;
  lessonCount: number;
  enrollmentCount: number;
}

interface Category {
  id: string;
  name: string;
  color: string;
}

const LEVELS = ["Beginner Level", "Intermediate Level", "Advanced Level"];

interface CourseForm {
  title: string;
  description: string;
  level: string;
  weeks: string;
  hrsPerDay: string;
  prerequisite: string;
  icon: string;
  categoryId: string;
  thumbnail: string;
}

const EMPTY_FORM: CourseForm = {
  title: "",
  description: "",
  level: "Beginner Level",
  weeks: "8",
  hrsPerDay: "2",
  prerequisite: "",
  icon: "BookOpen",
  categoryId: "",
  thumbnail: "",
};

export function CoursesClient({ canManage }: { canManage: boolean }) {
  const { toast } = useToast();
  const listUrl = "/api/lms/courses?pageSize=100";
  const { data, loading, error, refetch } = useApi<{ items: CourseRow[]; total: number }>(listUrl);
  const { data: categories } = useApi<Category[]>("/api/lms/categories");

  const [statusTab, setStatusTab] = useState("ALL");
  const [createOpen, setCreateOpen] = useState(false);
  const [editing, setEditing] = useState<CourseRow | null>(null);
  const [deleting, setDeleting] = useState<CourseRow | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const courses = useMemo(() => data?.items ?? [], [data]);
  const filtered = useMemo(
    () => (statusTab === "ALL" ? courses : courses.filter((c) => c.status === statusTab)),
    [courses, statusTab]
  );

  const counts = useMemo(() => {
    const total = courses.length;
    const published = courses.filter((c) => c.status === "PUBLISHED").length;
    const drafts = courses.filter((c) => c.status === "DRAFT").length;
    const enrollments = courses.reduce((s, c) => s + c.enrollmentCount, 0);
    return { total, published, drafts, enrollments };
  }, [courses]);

  const tabCount = (t: string) => (t === "ALL" ? courses.length : courses.filter((c) => c.status === t).length);

  async function changeStatus(course: CourseRow, status: string) {
    setBusyId(course.id);
    try {
      await api.patch(`/api/lms/courses/${course.id}`, { status });
      toast({
        title: status === "PUBLISHED" ? "Course published" : status === "DRAFT" ? "Moved to draft" : "Course archived",
        description:
          status === "PUBLISHED"
            ? `"${course.title}" is now visible on the public website.`
            : `"${course.title}" is now ${status.toLowerCase()}.`,
      });
      await refetch();
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  }

  async function confirmDelete() {
    if (!deleting) return;
    setBusyId(deleting.id);
    try {
      await api.delete(`/api/lms/courses/${deleting.id}`);
      toast({ title: "Course deleted", description: `"${deleting.title}" was removed.` });
      setDeleting(null);
      await refetch();
    } catch (e) {
      toast({ title: "Delete failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Courses"
        description="Build the catalog — create courses, publish them to the website and manage content."
        actions={
          canManage ? (
            <CreateButton label="New course" onClick={() => setCreateOpen(true)} />
          ) : undefined
        }
      />

      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard label="Total courses" value={counts.total} icon={BookOpen} />
        <StatCard label="Published" value={counts.published} icon={Rocket} tone="green" hint="Live on the website" />
        <StatCard label="Drafts" value={counts.drafts} icon={Edit3} tone="amber" hint="Hidden from the website" />
        <StatCard label="Enrollments" value={counts.enrollments} icon={Users} tone="orange" hint="Across all courses" />
      </div>

      {/* Status tabs */}
      <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Filter by status">
        {["ALL", "DRAFT", "PUBLISHED", "ARCHIVED"].map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={statusTab === t}
            onClick={() => setStatusTab(t)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition",
              statusTab === t
                ? "border-brand bg-brand text-white"
                : "border-border bg-card text-muted-foreground hover:text-foreground"
            )}
          >
            {t === "ALL" ? "All" : t.charAt(0) + t.slice(1).toLowerCase()} ({tabCount(t)})
          </button>
        ))}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="rounded-2xl border bg-card p-0 shadow-sm">
              <Skeleton className="h-36 w-full rounded-b-none rounded-t-2xl" />
              <div className="space-y-3 p-4">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <ErrorBlock message={error} onRetry={refetch} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={statusTab === "ALL" ? BookOpen : Eye}
          title={statusTab === "ALL" ? "No courses yet" : `No ${statusTab.toLowerCase()} courses`}
          hint={
            statusTab === "ALL"
              ? "Create your first course, add modules & lessons, then publish it to the website."
              : "Try a different status filter."
          }
          action={
            canManage && statusTab === "ALL" ? (
              <CreateButton label="Create your first course" onClick={() => setCreateOpen(true)} />
            ) : undefined
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((course) => (
            <div key={course.id} className="group flex flex-col overflow-hidden rounded-2xl border bg-card shadow-sm transition hover:shadow-md">
              <Link href={`/lms/courses/${course.id}`} className="relative block h-36 overflow-hidden bg-gradient-to-br from-brand to-[#9b5cf0]">
                {course.thumbnail ? (
                  <Image
                    src={course.thumbnail}
                    alt=""
                    width={640}
                    height={288}
                    className="h-36 w-full object-cover transition group-hover:scale-[1.02]"
                  />
                ) : (
                  <div className="flex h-36 items-center justify-center text-white/90">
                    <CourseIcon name={course.icon} className="h-10 w-10" />
                  </div>
                )}
                <span className="absolute left-3 top-3">
                  <StatusBadge value={course.status} className="bg-background/90" />
                </span>
              </Link>
              <div className="flex flex-1 flex-col gap-3 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <Link
                      href={`/lms/courses/${course.id}`}
                      className="line-clamp-2 text-[15px] font-semibold leading-snug text-foreground hover:text-brand"
                    >
                      {course.title}
                    </Link>
                    <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{course.description}</p>
                  </div>
                  {canManage ? (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 rounded-lg" aria-label={`Actions for ${course.title}`}>
                          {busyId === course.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <MoreVertical className="h-4 w-4" />}
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-52">
                        <DropdownMenuItem asChild>
                          <Link href={`/lms/courses/${course.id}`}>
                            <Layers className="mr-2 h-4 w-4" /> Open builder
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setEditing(course)}>
                          <Edit3 className="mr-2 h-4 w-4" /> Edit details
                        </DropdownMenuItem>
                        {course.status !== "PUBLISHED" ? (
                          <DropdownMenuItem onClick={() => void changeStatus(course, "PUBLISHED")}>
                            <Rocket className="mr-2 h-4 w-4" /> Publish
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={() => void changeStatus(course, "DRAFT")}>
                            <RotateCcw className="mr-2 h-4 w-4" /> Unpublish (draft)
                          </DropdownMenuItem>
                        )}
                        {course.status !== "ARCHIVED" ? (
                          <DropdownMenuItem onClick={() => void changeStatus(course, "ARCHIVED")}>
                            <Archive className="mr-2 h-4 w-4" /> Archive
                          </DropdownMenuItem>
                        ) : null}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => setDeleting(course)}
                        >
                          <Trash2 className="mr-2 h-4 w-4" /> Delete…
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : null}
                </div>
                <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                  {course.categoryName ? (
                    <span
                      className="rounded-full border px-2 py-0.5 font-medium"
                      style={{
                        borderColor: `${course.categoryColor ?? "#5d18be"}55`,
                        color: course.categoryColor ?? "#5d18be",
                        background: `${course.categoryColor ?? "#5d18be"}11`,
                      }}
                    >
                      {course.categoryName}
                    </span>
                  ) : null}
                  <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                    <GraduationCap className="h-3 w-3" /> {course.level}
                  </span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                    <CalendarDays className="h-3 w-3" /> {course.weeks}w
                  </span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                    <Clock className="h-3 w-3" /> {course.hrsPerDay}h/day
                  </span>
                </div>
                <div className="mt-auto flex items-center justify-between border-t pt-3 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-3">
                    <span className="inline-flex items-center gap-1" title="Modules">
                      <Layers className="h-3.5 w-3.5" /> {course.moduleCount}
                    </span>
                    <span className="inline-flex items-center gap-1" title="Lessons">
                      <ListVideo className="h-3.5 w-3.5" /> {course.lessonCount}
                    </span>
                    <span className="inline-flex items-center gap-1" title="Enrollments">
                      <Users className="h-3.5 w-3.5" /> {course.enrollmentCount}
                    </span>
                  </span>
                  <span className="max-w-[45%] truncate">{course.ownerName ?? "Unassigned"}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <CourseFormDialog
        open={createOpen || editing !== null}
        onOpenChange={(open) => {
          if (!open) {
            setCreateOpen(false);
            setEditing(null);
          }
        }}
        categories={categories ?? []}
        course={editing}
        onSaved={async () => {
          setCreateOpen(false);
          setEditing(null);
          await refetch();
        }}
      />

      <AlertDialog open={deleting !== null} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete “{deleting?.title}”?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the course with all its modules, lessons, quizzes and assignments. Courses with
              enrollments cannot be deleted — archive them instead.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault();
                void confirmDelete();
              }}
            >
              {busyId && deleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Delete course
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ── Create/Edit dialog shared by list + builder ── */

export function CourseFormDialog({
  open,
  onOpenChange,
  categories,
  course,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categories: Category[];
  course: CourseRow | null; // null = create
  onSaved: () => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [form, setForm] = useState<CourseForm>(EMPTY_FORM);
  const [seed, setSeed] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const isEdit = course !== null;
  const seedKey = course?.id ?? "new";

  // re-seed the form each time the dialog target changes
  if (open && seed !== seedKey) {
    setSeed(seedKey);
    setForm(
      course
        ? {
            title: course.title,
            description: course.description,
            level: course.level || "Beginner Level",
            weeks: String(course.weeks ?? 8),
            hrsPerDay: String(course.hrsPerDay ?? 2),
            prerequisite: course.prerequisite ?? "",
            icon: course.icon || "BookOpen",
            categoryId: course.categoryId ?? "",
            thumbnail: course.thumbnail ?? "",
          }
        : EMPTY_FORM
    );
  }

  function set<K extends keyof CourseForm>(key: K, value: CourseForm[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleUpload(file: File) {
    setUploading(true);
    try {
      const { url } = await api.upload(file);
      set("thumbnail", url);
      toast({ title: "Thumbnail uploaded" });
    } catch (e) {
      toast({ title: "Upload failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    if (form.title.trim().length < 3) {
      toast({ title: "Title too short", description: "Use at least 3 characters.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim(),
        level: form.level,
        weeks: Number(form.weeks) || 8,
        hrsPerDay: Number(form.hrsPerDay) || 2,
        prerequisite: form.prerequisite.trim() || null,
        icon: form.icon,
        categoryId: form.categoryId || null,
        thumbnail: form.thumbnail || null,
      };
      if (isEdit && course) {
        await api.patch(`/api/lms/courses/${course.id}`, payload);
        toast({ title: "Course updated", description: `"${payload.title}" was saved.` });
      } else {
        await api.post("/api/lms/courses", payload);
        toast({ title: "Course created", description: `"${payload.title}" was created as a draft.` });
      }
      await onSaved();
    } catch (e) {
      toast({ title: isEdit ? "Update failed" : "Create failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit course" : "Create course"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Update catalog details. Publishing is a separate action."
              : "New courses start as drafts — publish when the content is ready."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label htmlFor="course-title">Title *</Label>
            <Input
              id="course-title"
              value={form.title}
              onChange={(e) => set("title", e.target.value)}
              placeholder="e.g. Full-Stack Data Analytics"
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="course-desc">Short description *</Label>
            <Textarea
              id="course-desc"
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              placeholder="One or two sentences shown on cards and the website."
              rows={2}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label>Category</Label>
              <Select value={form.categoryId || "none"} onValueChange={(v) => set("categoryId", v === "none" ? "" : v)}>
                <SelectTrigger aria-label="Category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No category</SelectItem>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label>Level</Label>
              <Select value={form.level} onValueChange={(v) => set("level", v)}>
                <SelectTrigger aria-label="Level">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LEVELS.map((l) => (
                    <SelectItem key={l} value={l}>
                      {l}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="course-weeks">Duration (weeks)</Label>
              <Input
                id="course-weeks"
                type="number"
                min={1}
                max={52}
                value={form.weeks}
                onChange={(e) => set("weeks", e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="course-hrs">Hours / day</Label>
              <Input
                id="course-hrs"
                type="number"
                min={1}
                max={12}
                value={form.hrsPerDay}
                onChange={(e) => set("hrsPerDay", e.target.value)}
              />
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="course-prereq">Prerequisite</Label>
            <Input
              id="course-prereq"
              value={form.prerequisite}
              onChange={(e) => set("prerequisite", e.target.value)}
              placeholder="e.g. No coding experience required"
            />
          </div>
          <div className="grid gap-1.5">
            <Label>Card icon</Label>
            <Select value={form.icon} onValueChange={(v) => set("icon", v)}>
              <SelectTrigger aria-label="Card icon">
                <span className="flex items-center gap-2">
                  <CourseIcon name={form.icon} className="h-4 w-4" />
                  {form.icon}
                </span>
              </SelectTrigger>
              <SelectContent className="max-h-64">
                {COURSE_ICON_NAMES.map((name) => (
                  <SelectItem key={name} value={name}>
                    <span className="flex items-center gap-2">
                      <CourseIcon name={name} className="h-4 w-4" />
                      {name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label>Thumbnail</Label>
            <div className="flex items-center gap-3">
              {form.thumbnail ? (
                <Image src={form.thumbnail} alt="Thumbnail preview" width={72} height={48} className="h-12 w-18 rounded-lg border object-cover" />
              ) : (
                <div className="flex h-12 w-18 items-center justify-center rounded-lg border bg-muted text-muted-foreground">
                  <CourseIcon name={form.icon} className="h-4 w-4" />
                </div>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void handleUpload(f);
                  e.target.value = "";
                }}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
              >
                {uploading ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <Upload className="mr-2 h-3.5 w-3.5" />}
                {uploading ? "Uploading…" : form.thumbnail ? "Replace image" : "Upload image"}
              </Button>
              {form.thumbnail ? (
                <Button type="button" variant="ghost" size="sm" onClick={() => set("thumbnail", "")}>
                  Remove
                </Button>
              ) : null}
            </div>
            <p className="text-[11px] text-muted-foreground">PNG, JPEG, WebP or SVG · max 5 MB.</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={() => void save()} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
            {isEdit ? "Save changes" : "Create course"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
