"use client";

import { BookOpen, ClipboardCheck, GraduationCap, Trophy } from "lucide-react";
import { useApi } from "@/lib/api-client";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { LoadingBlock, ErrorBlock } from "@/components/platform/states";
import { AreaTrend, BarsChart, DonutChart } from "@/components/platform/charts";
import { FlowDiagram } from "@/components/platform/flow";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ProgressBar } from "@/components/lms/shared";

interface ReportsData {
  kpis: {
    totalEnrollments: number;
    activeEnrollments: number;
    completionRate: number;
    avgProgress: number;
    certificatesIssued: number;
  };
  enrollmentsTrend: { month: string; value: number }[];
  coursePerformance: { course: string; enrollments: number; avgProgress: number; completionRate: number }[];
  assessmentStats: { attempts: number; passRate: number; avgScore: number; pendingGrading: number; passed: number; failed: number };
  certificatesByMonth: { month: string; value: number }[];
}

export function ReportsClient() {
  const { data, loading, error, refetch } = useApi<ReportsData>("/api/lms/reports");

  if (loading) return <LoadingBlock label="Crunching learning analytics…" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;
  if (!data) return null;

  return (
    <div className="space-y-6">
      <PageHeader
        title="LMS Reports"
        description="Enrollment, progress and assessment analytics across your courses."
      />

      <Card className="rounded-2xl">
        <CardContent className="pt-4">
          <FlowDiagram
            steps={[
              { icon: BookOpen, label: "Course", tone: "brand" },
              { icon: GraduationCap, label: "Module", tone: "brand" },
              { icon: BookOpen, label: "Lesson", tone: "brand" },
              { icon: ClipboardCheck, label: "Assessment", tone: "amber" },
              { icon: GraduationCap, label: "Completion", tone: "green" },
              { icon: Trophy, label: "Certificate", tone: "green" },
            ]}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard label="Total enrollments" value={data.kpis.totalEnrollments} hint={`${data.kpis.activeEnrollments} active now`} icon={GraduationCap} tone="brand" />
        <StatCard label="Completion rate" value={`${data.kpis.completionRate}%`} hint={`avg progress ${data.kpis.avgProgress}%`} icon={BookOpen} tone="green" />
        <StatCard label="Certificates issued" value={data.kpis.certificatesIssued} icon={Trophy} tone="amber" hint="All time" />
        <StatCard label="Pending grading" value={data.assessmentStats.pendingGrading} icon={ClipboardCheck} tone="orange" hint="Submissions awaiting review" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="rounded-2xl lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-bold">Enrollments trend</CardTitle>
            <p className="text-xs text-muted-foreground">Last 6 months</p>
          </CardHeader>
          <CardContent>
            {data.enrollmentsTrend.length ? (
              <AreaTrend data={data.enrollmentsTrend} xKey="month" yKey="value" height={230} />
            ) : (
              <p className="py-16 text-center text-xs text-muted-foreground">No enrollment activity yet</p>
            )}
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-bold">Quiz outcomes</CardTitle>
            <p className="text-xs text-muted-foreground">{data.assessmentStats.attempts} attempts · avg {data.assessmentStats.avgScore}%</p>
          </CardHeader>
          <CardContent>
            {data.assessmentStats.attempts > 0 ? (
              <DonutChart
                data={[
                  { name: "Passed", value: data.assessmentStats.passed },
                  { name: "Failed", value: data.assessmentStats.failed },
                ]}
                height={230}
              />
            ) : (
              <p className="py-16 text-center text-xs text-muted-foreground">No quiz attempts yet</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-bold">Course performance</CardTitle>
          <p className="text-xs text-muted-foreground">Enrollments and average progress per course</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {data.coursePerformance.length === 0 ? (
            <p className="py-10 text-center text-xs text-muted-foreground">No course data yet</p>
          ) : (
            <>
              <BarsChart data={data.coursePerformance} xKey="course" bars={[{ key: "enrollments", name: "Enrollments" }]} height={220} />
              <div className="space-y-3">
                {data.coursePerformance.slice(0, 6).map((c) => (
                  <div key={c.course}>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="font-semibold">{c.course}</span>
                      <span className="text-muted-foreground">{c.completionRate}% completed</span>
                    </div>
                    <ProgressBar value={c.completionRate} />
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
