"use client";

import { useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { EmptyState, ErrorBlock, LoadingBlock } from "@/components/platform/states";
import { StatusBadge } from "@/components/platform/status-badge";
import { FlowDiagram } from "@/components/platform/flow";
import { BarsChart } from "@/components/platform/charts";
import { LessonTypeIcon, ProgressBar } from "@/components/lms/shared";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Award,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  GraduationCap,
  LineChart,
  Loader2,
  Users,
} from "lucide-react";

interface ProgressEnrollment {
  id: string;
  learnerName: string;
  batchName: string | null;
  status: string;
  progress: number;
  enrolledAt: string;
  lessonsDone: number;
  lessonsTotal: number;
  lastActivityAt: string | null;
}

interface ProgressCourse {
  id: string;
  title: string;
  status: string;
  icon: string | null;
  avgProgress: number;
  learners: number;
  completed: number;
  enrollments: ProgressEnrollment[];
}

interface ProgressOverview {
  courses: ProgressCourse[];
  stats: { learners: number; avgProgress: number; completed: number };
}

interface DetailLesson {
  id: string;
  title: string;
  type: string;
  moduleTitle: string;
  durationMin: number;
  completed: boolean;
}

export function ProgressClient() {
  const { data, loading, error, refetch } = useApi<ProgressOverview>("/api/lms/progress");

  if (loading) return <LoadingBlock label="Loading progress overview…" className="min-h-[50vh]" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;

  const courses = data?.courses ?? [];
  const stats = data?.stats ?? { learners: 0, avgProgress: 0, completed: 0 };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Learning Progress"
        description="Per-course learner progress — toggle lessons to keep progress bars honest."
      />

      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <StatCard label="Active learners" value={stats.learners} icon={Users} />
        <StatCard label="Avg progress" value={`${stats.avgProgress}%`} icon={LineChart} tone="amber" />
        <StatCard label="Completed courses" value={stats.completed} icon={Award} tone="green" />
      </div>

      <div className="rounded-2xl border bg-card px-4 py-3 shadow-sm">
        <FlowDiagram
          steps={[
            { icon: GraduationCap, label: "Lesson", sub: "Watch / read", tone: "brand" },
            { icon: ClipboardCheck, label: "Quiz / Assignment", sub: "Prove skill", tone: "amber" },
            { icon: LineChart, label: "100%", sub: "All lessons done", tone: "green" },
            { icon: Award, label: "Certificate", sub: "Issued by staff", tone: "orange" },
          ]}
        />
      </div>

      {courses.length === 0 ? (
        <EmptyState
          icon={LineChart}
          title="No progress to show yet"
          hint="Progress appears here once learners are enrolled in courses with lessons."
        />
      ) : (
        <div className="space-y-5">
          {courses.map((course) => {
            const chartData = course.enrollments.slice(0, 10).map((e) => ({
              name: e.learnerName.split(" ")[0],
              progress: e.progress,
            }));
            return (
              <Card key={course.id} className="overflow-hidden">
                <CardHeader className="flex-row flex-wrap items-center justify-between gap-2 border-b bg-muted/30 py-3">
                  <CardTitle className="flex flex-wrap items-center gap-2 text-base">
                    {course.title}
                    <StatusBadge value={course.status} />
                  </CardTitle>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <Users className="h-3.5 w-3.5" /> {course.learners} learners
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Award className="h-3.5 w-3.5" /> {course.completed} completed
                    </span>
                    <span className="inline-flex items-center gap-1 font-semibold text-foreground">
                      avg {course.avgProgress}%
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 p-4">
                  {chartData.length > 1 ? (
                    <div className="rounded-2xl border bg-muted/20 p-3">
                      <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Progress by learner
                      </p>
                      <BarsChart data={chartData} xKey="name" bars={[{ key: "progress", name: "Progress %" }]} height={170} />
                    </div>
                  ) : null}

                  {/* learners table */}
                  <div className="overflow-hidden rounded-2xl border">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                          <th className="px-3 py-2 font-semibold">Learner</th>
                          <th className="hidden px-3 py-2 font-semibold sm:table-cell">Batch</th>
                          <th className="px-3 py-2 font-semibold">Lessons</th>
                          <th className="px-3 py-2 font-semibold">Progress</th>
                          <th className="hidden px-3 py-2 font-semibold md:table-cell">Status</th>
                          <th className="hidden px-3 py-2 font-semibold lg:table-cell">Last activity</th>
                          <th className="w-8 px-2 py-2" />
                        </tr>
                      </thead>
                      <tbody>
                        {course.enrollments.map((e) => (
                          <ExpandableRow key={e.id} enrollment={e} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ExpandableRow({ enrollment }: { enrollment: ProgressEnrollment }) {
  const [open, setOpen] = useState(false);
  const e = enrollment;
  return (
    <>
      <tr className="border-b transition hover:bg-muted/40">
        <td className="px-3 py-2.5 font-medium">{e.learnerName}</td>
        <td className="hidden px-3 py-2.5 sm:table-cell">
          {e.batchName ? (
            <span className="rounded-md bg-muted px-2 py-0.5 text-xs">{e.batchName}</span>
          ) : (
            <span className="text-muted-foreground">—</span>
          )}
        </td>
        <td className="px-3 py-2.5 text-xs">
          {e.lessonsDone}/{e.lessonsTotal}
        </td>
        <td className="px-3 py-2.5">
          <div className="flex w-28 items-center gap-2">
            <ProgressBar value={e.progress} className="h-1.5 flex-1" />
            <span className="w-8 text-right text-xs font-semibold">{e.progress}%</span>
          </div>
        </td>
        <td className="hidden px-3 py-2.5 md:table-cell">
          <StatusBadge value={e.status} />
        </td>
        <td className="hidden px-3 py-2.5 text-xs text-muted-foreground lg:table-cell">
          {e.lastActivityAt ? fmt.relative(e.lastActivityAt) : "—"}
        </td>
        <td className="px-2 py-2.5">
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-label={`${open ? "Hide" : "Show"} lessons for ${e.learnerName}`}
            className="flex h-7 w-7 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-muted hover:text-foreground"
          >
            {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
        </td>
      </tr>
      {open ? (
        <tr>
          <td colSpan={7} className="bg-muted/20 p-3">
            <LessonChecklist enrollmentId={e.id} learner={e.learnerName} />
          </td>
        </tr>
      ) : null}
    </>
  );
}

function LessonChecklist({ enrollmentId, learner }: { enrollmentId: string; learner: string }) {
  const { toast } = useToast();
  const { data, loading, error, refetch } = useApi<{ lessons: DetailLesson[]; enrollment: { progress: number } }>(
    `/api/lms/enrollments/${enrollmentId}`
  );
  const [toggling, setToggling] = useState<string | null>(null);

  async function toggle(lesson: DetailLesson, done: boolean) {
    setToggling(lesson.id);
    try {
      const res = await api.post<{ progress: number; status: string }>("/api/lms/progress", {
        enrollmentId,
        lessonId: lesson.id,
        done,
      });
      toast({
        title: done ? `“${lesson.title}” completed` : `“${lesson.title}” reopened`,
        description: `${learner} · progress ${res.progress}% · status ${res.status}`,
      });
      await refetch();
    } catch (err) {
      toast({ title: "Update failed", description: err instanceof Error ? err.message : "Try again", variant: "destructive" });
    } finally {
      setToggling(null);
    }
  }

  if (loading)
    return (
      <div className="flex items-center justify-center gap-2 py-4 text-xs text-muted-foreground">
        <Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading lessons…
      </div>
    );
  if (error) return <p className="py-3 text-center text-xs text-destructive">{error}</p>;
  const lessons = data?.lessons ?? [];
  if (lessons.length === 0)
    return <p className="py-3 text-center text-xs text-muted-foreground">This course has no lessons yet.</p>;

  return (
    <ul className="grid gap-1 sm:grid-cols-2">
      {lessons.map((l) => (
        <li
          key={l.id}
          className={cn(
            "flex items-center gap-2 rounded-xl px-2 py-1.5",
            l.completed ? "bg-emerald-50/70 dark:bg-emerald-500/10" : "bg-card"
          )}
        >
          <Checkbox
            checked={l.completed}
            onCheckedChange={(checked) => void toggle(l, checked === true)}
            disabled={toggling === l.id}
            aria-label={`Mark ${l.title} ${l.completed ? "incomplete" : "complete"}`}
          />
          <LessonTypeIcon type={l.type} />
          <div className="min-w-0">
            <p className={cn("truncate text-xs font-medium", l.completed && "line-through opacity-70")}>{l.title}</p>
            <p className="truncate text-[10px] text-muted-foreground">{l.moduleTitle}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}
