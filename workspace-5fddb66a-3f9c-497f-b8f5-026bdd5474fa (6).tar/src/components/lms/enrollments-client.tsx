"use client";

import { useMemo, useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { CreateButton, EmptyState, LoadingBlock, ErrorBlock } from "@/components/platform/states";
import { StatusBadge } from "@/components/platform/status-badge";
import { DataTable, type Column } from "@/components/platform/data-table";
import { LessonTypeIcon, ProgressBar, asList, type BasicCourse } from "@/components/lms/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Award,
  ClipboardCheck,
  GraduationCap,
  Loader2,
  PenLine,
  Percent,
  Search,
  Trash2,
  UserCheck,
  UserMinus,
  UserPlus,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface EnrollmentRow {
  id: string;
  status: string;
  progress: number;
  batchName: string | null;
  enrolledAt: string;
  courseId: string | null;
  courseTitle: string;
  learnerName: string;
  email: string | null;
  phone: string | null;
}

interface EnrollmentList {
  items: EnrollmentRow[];
  total: number;
  counts: Record<string, number>;
}

interface DetailLesson {
  id: string;
  moduleTitle: string;
  title: string;
  type: string;
  durationMin: number;
  completed: boolean;
}

interface EnrollmentDetail {
  enrollment: EnrollmentRow & { itemSlug: string; itemType: string };
  contact: { id: string; name: string; email: string | null; phone: string | null; city: string | null } | null;
  course: { id: string; title: string; slug: string; level: string } | null;
  lessons: DetailLesson[];
  attempts: { id: string; quizTitle: string; score: number; maxScore: number; percent: number; passed: boolean; submittedAt: string }[];
  submissions: {
    id: string;
    assignmentTitle: string;
    maxPoints: number;
    contentText: string | null;
    fileUrl: string | null;
    status: string;
    grade: number | null;
    feedback: string | null;
    submittedAt: string;
  }[];
  certificate: { id: string; serial: string; issuedAt: string } | null;
}

interface ContactBasic {
  id: string;
  name: string;
  email?: string | null;
}

const STATUS_TABS = ["ALL", "ACTIVE", "PAUSED", "COMPLETED", "DROPPED"];

export function EnrollmentsClient({
  canManage,
  initialCourseId,
}: {
  canManage: boolean;
  initialCourseId: string;
}) {
  const { toast } = useToast();
  const [statusTab, setStatusTab] = useState("ALL");
  const [courseId, setCourseId] = useState(initialCourseId);
  const [batch, setBatch] = useState("");
  const [q, setQ] = useState("");

  const listUrl = useMemo(() => {
    const params = new URLSearchParams({ pageSize: "100" });
    if (statusTab !== "ALL") params.set("status", statusTab);
    if (courseId && courseId !== "ALL") params.set("courseId", courseId);
    if (batch.trim()) params.set("batch", batch.trim());
    if (q.trim()) params.set("q", q.trim());
    return `/api/lms/enrollments?${params.toString()}`;
  }, [statusTab, courseId, batch, q]);

  const { data, loading, error, refetch } = useApi<EnrollmentList>(listUrl);
  const { data: courses } = useApi<BasicCourse[]>("/api/lms/courses?basic=1");

  const [enrollOpen, setEnrollOpen] = useState(false);
  const [editing, setEditing] = useState<EnrollmentRow | null>(null);
  const [dropping, setDropping] = useState<EnrollmentRow | null>(null);
  const [removing, setRemoving] = useState<EnrollmentRow | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const rows = data?.items ?? [];
  const counts = data?.counts ?? {};

  async function dropEnrollment() {
    if (!dropping) return;
    setBusy(true);
    try {
      await api.patch(`/api/lms/enrollments/${dropping.id}`, { status: "DROPPED" });
      toast({ title: "Learner dropped", description: `${dropping.learnerName} → DROPPED.` });
      setDropping(null);
      await refetch();
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  async function removeEnrollment() {
    if (!removing) return;
    setBusy(true);
    try {
      await api.delete(`/api/lms/enrollments/${removing.id}`);
      toast({ title: "Enrollment removed", description: `${removing.learnerName}'s enrollment was deleted.` });
      setRemoving(null);
      await refetch();
    } catch (e) {
      toast({ title: "Delete failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  const columns: Column<EnrollmentRow>[] = [
    {
      key: "learnerName",
      header: "Learner",
      sortable: true,
      render: (r) => (
        <div className="min-w-0">
          <p className="truncate font-semibold">{r.learnerName}</p>
          {r.email ? <p className="truncate text-xs text-muted-foreground">{r.email}</p> : null}
        </div>
      ),
    },
    {
      key: "courseTitle",
      header: "Course",
      sortable: true,
      render: (r) => <span className="line-clamp-1 max-w-[220px]">{r.courseTitle}</span>,
    },
    {
      key: "batchName",
      header: "Batch",
      render: (r) => r.batchName ? <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-medium">{r.batchName}</span> : <span className="text-muted-foreground">—</span>,
    },
    { key: "status", header: "Status", render: (r) => <StatusBadge value={r.status} /> },
    {
      key: "progress",
      header: "Progress",
      sortable: true,
      render: (r) => (
        <div className="flex w-28 items-center gap-2">
          <ProgressBar value={r.progress} className="h-1.5 flex-1" />
          <span className="w-8 text-right text-xs font-semibold">{r.progress}%</span>
        </div>
      ),
    },
    {
      key: "enrolledAt",
      header: "Enrolled",
      sortable: true,
      render: (r) => <span className="whitespace-nowrap text-muted-foreground">{fmt.date(r.enrolledAt)}</span>,
    },
    {
      key: "actions",
      header: "",
      className: "w-20",
      render: (r) =>
        canManage ? (
          <div className="flex justify-end gap-0.5">
            <Button variant="ghost" size="icon" className="h-8 w-8" aria-label={`Manage ${r.learnerName}`} onClick={(e) => { e.stopPropagation(); setEditing(r); }}>
              <UserCheck className="h-4 w-4" />
            </Button>
            {r.status !== "DROPPED" ? (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive"
                aria-label={`Drop ${r.learnerName}`}
                onClick={(e) => {
                  e.stopPropagation();
                  setDropping(r);
                }}
              >
                <UserMinus className="h-4 w-4" />
              </Button>
            ) : null}
          </div>
        ) : null,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Enrollments"
        description="Learners taking courses, their batch, status and academic progress."
        actions={canManage ? <CreateButton label="Enroll learner" icon={UserPlus} onClick={() => setEnrollOpen(true)} /> : undefined}
      />

      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard label="Total enrollments" value={counts.total ?? 0} icon={Users} />
        <StatCard label="Active" value={counts.ACTIVE ?? 0} icon={UserCheck} tone="green" />
        <StatCard label="Completed" value={counts.COMPLETED ?? 0} icon={Award} tone="orange" />
        <StatCard label="Avg progress" value={`${counts.avgProgress ?? 0}%`} icon={Percent} tone="amber" />
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Filter by status">
          {STATUS_TABS.map((t) => {
            const n = t === "ALL" ? counts.total ?? 0 : counts[t] ?? 0;
            return (
              <button
                key={t}
                role="tab"
                aria-selected={statusTab === t}
                onClick={() => setStatusTab(t)}
                className={cn(
                  "rounded-full border px-3 py-1.5 text-xs font-semibold transition",
                  statusTab === t
                    ? "border-brand bg-brand text-white"
                    : "border-border bg-card text-muted-foreground hover:text-foreground"
                )}
              >
                {t === "ALL" ? "All" : t.charAt(0) + t.slice(1).toLowerCase()} ({n})
              </button>
            );
          })}
        </div>
        <div className="flex flex-1 flex-wrap items-center justify-end gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search learner or course…"
              className="h-9 w-48 rounded-xl pl-8"
              aria-label="Search enrollments"
            />
          </div>
          <Select value={courseId} onValueChange={setCourseId}>
            <SelectTrigger className="h-9 w-44 rounded-xl" aria-label="Filter by course">
              <SelectValue placeholder="All courses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All courses</SelectItem>
              {(courses ?? []).map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            value={batch}
            onChange={(e) => setBatch(e.target.value)}
            placeholder="Batch e.g. DA-0126"
            className="h-9 w-36 rounded-xl"
            aria-label="Filter by batch"
          />
        </div>
      </div>

      {loading ? (
        <LoadingBlock label="Loading enrollments…" />
      ) : error ? (
        <ErrorBlock message={error} onRetry={refetch} />
      ) : rows.length === 0 ? (
        <EmptyState
          icon={GraduationCap}
          title="No enrollments found"
          hint={canManage ? "Enroll a learner from CRM contacts into any course." : "Try different filters."}
          action={
            canManage ? (
              <CreateButton label="Enroll learner" icon={UserPlus} onClick={() => setEnrollOpen(true)} />
            ) : undefined
          }
        />
      ) : (
        <DataTable
          columns={columns}
          rows={rows}
          rowKey={(r) => r.id}
          onRowClick={(r) => setDetailId(r.id)}
          pageSize={10}
          emptyTitle="No enrollments"
        />
      )}

      <EnrollDialog
        open={enrollOpen}
        onOpenChange={setEnrollOpen}
        courses={courses ?? []}
        onEnrolled={refetch}
      />

      <EditEnrollmentDialog
        open={editing !== null}
        enrollment={editing}
        onClose={async (saved) => {
          setEditing(null);
          if (saved) await refetch();
        }}
      />

      {/* detail sheet */}
      <Sheet open={detailId !== null} onOpenChange={(open) => !open && setDetailId(null)}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-lg nice-scrollbar">
          <SheetTitle className="sr-only">Enrollment details</SheetTitle>
          {detailId ? (
            <EnrollmentDetailPanel id={detailId} onChanged={refetch} />
          ) : null}
        </SheetContent>
      </Sheet>

      {/* drop confirm */}
      <AlertDialog open={dropping !== null} onOpenChange={(open) => !open && setDropping(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Drop {dropping?.learnerName}?</AlertDialogTitle>
            <AlertDialogDescription>
              Their enrollment will be marked DROPPED. Progress is kept for records.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault();
                void dropEnrollment();
              }}
            >
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Drop learner
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* delete confirm */}
      <AlertDialog open={removing !== null} onOpenChange={(open) => !open && setRemoving(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete enrollment permanently?</AlertDialogTitle>
            <AlertDialogDescription>
              {removing?.learnerName}'s enrollment, lesson progress, quiz attempts and submissions will be removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault();
                void removeEnrollment();
              }}
            >
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ── Enroll dialog ── */

function EnrollDialog({
  open,
  onOpenChange,
  courses,
  onEnrolled,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  courses: BasicCourse[];
  onEnrolled: () => void | Promise<void>;
}) {
  const { toast } = useToast();
  const { data: contacts, loading: contactsLoading, error: contactsError } = useApi<ContactBasic[]>(
    open ? "/api/crm/contacts?basic=1" : null
  );
  const [contactId, setContactId] = useState("");
  const [course, setCourse] = useState("");
  const [batchName, setBatchName] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!contactId || !course) {
      toast({ title: "Select a learner and a course", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.post("/api/lms/enrollments", {
        contactId,
        courseId: course,
        batchName: batchName.trim() || null,
        itemType: "course",
      });
      toast({ title: "Learner enrolled", description: "The learner is now active in the course." });
      setContactId("");
      setCourse("");
      setBatchName("");
      onOpenChange(false);
      await onEnrolled();
    } catch (e) {
      toast({ title: "Enrollment failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Enroll learner</DialogTitle>
          <DialogDescription>Pick a CRM contact and a course. Duplicate active enrollments are blocked.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label>Learner (CRM contact) *</Label>
            {contactsLoading ? (
              <div className="flex h-9 items-center gap-2 rounded-xl border px-3 text-xs text-muted-foreground">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading contacts…
              </div>
            ) : contactsError ? (
              <div className="rounded-xl border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                Could not load contacts ({contactsError}). Ask a CRM admin to check the CRM module.
              </div>
            ) : asList<ContactBasic>(contacts).length === 0 ? (
              <div className="rounded-xl border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
                No contacts yet — create contacts in the CRM first.
              </div>
            ) : (
              <Select value={contactId} onValueChange={setContactId}>
                <SelectTrigger aria-label="Select learner">
                  <SelectValue placeholder="Select contact" />
                </SelectTrigger>
                <SelectContent className="max-h-64">
                  {asList<ContactBasic>(contacts).map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                      {c.email ? ` · ${c.email}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <div className="grid gap-1.5">
            <Label>Course *</Label>
            <Select value={course} onValueChange={setCourse}>
              <SelectTrigger aria-label="Select course">
                <SelectValue placeholder="Select course" />
              </SelectTrigger>
              <SelectContent className="max-h-64">
                {courses.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="enroll-batch">Batch</Label>
            <Input
              id="enroll-batch"
              value={batchName}
              onChange={(e) => setBatchName(e.target.value)}
              placeholder="e.g. DA-0126"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={() => void submit()} disabled={saving || contactsLoading}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
            Enroll
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Edit status/batch dialog ── */

function EditEnrollmentDialog({
  open,
  enrollment,
  onClose,
}: {
  open: boolean;
  enrollment: EnrollmentRow | null;
  onClose: (saved: boolean) => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [status, setStatus] = useState("ACTIVE");
  const [batchName, setBatchName] = useState("");
  const [saving, setSaving] = useState(false);
  const [seed, setSeed] = useState("");

  if (open && enrollment && seed !== enrollment.id) {
    setSeed(enrollment.id);
    setStatus(enrollment.status);
    setBatchName(enrollment.batchName ?? "");
  }

  async function save() {
    if (!enrollment) return;
    setSaving(true);
    try {
      await api.patch(`/api/lms/enrollments/${enrollment.id}`, {
        status,
        batchName: batchName.trim() || null,
      });
      toast({ title: "Enrollment updated", description: `${enrollment.learnerName} → ${status}.` });
      await onClose(true);
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function remove() {
    if (!enrollment) return;
    setSaving(true);
    try {
      await api.delete(`/api/lms/enrollments/${enrollment.id}`);
      toast({ title: "Enrollment deleted" });
      await onClose(true);
    } catch (e) {
      toast({ title: "Delete failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && void onClose(false)}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Manage enrollment</DialogTitle>
          <DialogDescription>
            {enrollment?.learnerName} · {enrollment?.courseTitle}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label>Status</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger aria-label="Enrollment status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="PAUSED">Paused</SelectItem>
                <SelectItem value="COMPLETED">Completed</SelectItem>
                <SelectItem value="DROPPED">Dropped</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">Setting COMPLETED pins progress to 100%.</p>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="edit-batch">Batch</Label>
            <Input id="edit-batch" value={batchName} onChange={(e) => setBatchName(e.target.value)} placeholder="e.g. DA-0326" />
          </div>
        </div>
        <DialogFooter className="sm:justify-between">
          <Button
            variant="ghost"
            className="text-destructive"
            onClick={() => void remove()}
            disabled={saving}
          >
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
            Delete
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => void onClose(false)} disabled={saving}>
              Cancel
            </Button>
            <Button onClick={() => void save()} disabled={saving}>
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Save
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Detail panel inside the sheet ── */

function EnrollmentDetailPanel({ id, onChanged }: { id: string; onChanged: () => void | Promise<void> }) {
  const { toast } = useToast();
  const { data, loading, error, refetch } = useApi<EnrollmentDetail>(`/api/lms/enrollments/${id}`);
  const [toggling, setToggling] = useState<string | null>(null);

  async function toggleLesson(lesson: DetailLesson, done: boolean) {
    setToggling(lesson.id);
    try {
      const res = await api.post<{ progress: number; status: string; completed: number; total: number }>(
        "/api/lms/progress",
        { enrollmentId: id, lessonId: lesson.id, done }
      );
      toast({
        title: done ? `“${lesson.title}” completed` : `“${lesson.title}” marked incomplete`,
        description: `Progress ${res.progress}% · ${res.completed}/${res.total} lessons · status ${res.status}`,
      });
      await refetch();
      await onChanged();
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setToggling(null);
    }
  }

  if (loading) return <LoadingBlock label="Loading enrollment…" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;
  if (!data) return null;

  const { enrollment, contact, course, lessons, attempts, submissions, certificate } = data;

  return (
    <div className="space-y-5">
      <SheetHeader>
        <SheetTitle className="flex items-center gap-2">
          {enrollment.learnerName} <StatusBadge value={enrollment.status} />
        </SheetTitle>
        <SheetDescription>
          {course?.title ?? enrollment.itemSlug}
          {enrollment.batchName ? ` · Batch ${enrollment.batchName}` : ""} · enrolled {fmt.date(enrollment.enrolledAt)}
        </SheetDescription>
      </SheetHeader>

      <div className="rounded-2xl border bg-muted/30 p-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-muted-foreground">Progress</span>
          <span className="font-bold">{enrollment.progress}%</span>
        </div>
        <ProgressBar value={enrollment.progress} className="mt-1.5 h-2" />
        {contact ? (
          <p className="mt-2 text-xs text-muted-foreground">
            {contact.email ?? "no email"} {contact.phone ? `· ${contact.phone}` : ""} {contact.city ? `· ${contact.city}` : ""}
          </p>
        ) : null}
        {certificate ? (
          <p className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 px-2 py-1 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
            <Award className="h-3 w-3" /> Certificate {certificate.serial}
          </p>
        ) : null}
      </div>

      {/* lessons checklist */}
      <section aria-label="Lesson checklist">
        <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
          Lessons ({lessons.filter((l) => l.completed).length}/{lessons.length})
        </h3>
        {lessons.length === 0 ? (
          <p className="rounded-xl border border-dashed p-4 text-center text-xs text-muted-foreground">
            This course has no lessons yet.
          </p>
        ) : (
          <ul className="max-h-72 space-y-1 overflow-y-auto rounded-2xl border p-2 nice-scrollbar">
            {lessons.map((l) => (
              <li
                key={l.id}
                className={cn(
                  "flex items-center gap-2.5 rounded-xl px-2 py-2 transition",
                  l.completed ? "bg-emerald-50/60 dark:bg-emerald-500/10" : "hover:bg-muted/60"
                )}
              >
                <Checkbox
                  checked={l.completed}
                  onCheckedChange={(checked) => void toggleLesson(l, checked === true)}
                  disabled={toggling === l.id}
                  aria-label={`Mark ${l.title} ${l.completed ? "incomplete" : "complete"}`}
                />
                <LessonTypeIcon type={l.type} />
                <div className="min-w-0 flex-1">
                  <p className={cn("truncate text-[13px] font-medium", l.completed && "line-through opacity-70")}>
                    {l.title}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {l.moduleTitle} · {l.durationMin} min
                  </p>
                </div>
                {toggling === l.id ? <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" /> : null}
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* attempts */}
      <section aria-label="Quiz attempts">
        <h3 className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
          <ClipboardCheck className="h-3.5 w-3.5" /> Quiz attempts ({attempts.length})
        </h3>
        {attempts.length === 0 ? (
          <p className="rounded-xl border border-dashed p-3 text-center text-xs text-muted-foreground">No quiz attempts yet.</p>
        ) : (
          <ul className="space-y-1.5">
            {attempts.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-2 rounded-xl border px-3 py-2 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-medium">{a.quizTitle}</p>
                  <p className="text-[11px] text-muted-foreground">{fmt.dateTime(a.submittedAt)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold">
                    {a.score}/{a.maxScore} ({a.percent}%)
                  </span>
                  <StatusBadge value={a.passed ? "PASSED" : "FAILED"} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* submissions */}
      <section aria-label="Assignment submissions">
        <h3 className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
          <PenLine className="h-3.5 w-3.5" /> Submissions ({submissions.length})
        </h3>
        {submissions.length === 0 ? (
          <p className="rounded-xl border border-dashed p-3 text-center text-xs text-muted-foreground">No submissions yet.</p>
        ) : (
          <ul className="space-y-1.5">
            {submissions.map((s) => (
              <li key={s.id} className="rounded-xl border px-3 py-2 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate font-medium">{s.assignmentTitle}</p>
                  <StatusBadge value={s.status} />
                </div>
                {s.contentText ? (
                  <p className="mt-1 line-clamp-2 rounded-lg bg-muted/50 px-2 py-1 text-xs text-muted-foreground">{s.contentText}</p>
                ) : null}
                {s.fileUrl ? (
                  <a href={s.fileUrl} target="_blank" rel="noreferrer" className="mt-1 inline-block text-xs font-medium text-brand hover:underline">
                    View attachment →
                  </a>
                ) : null}
                <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                  <span>{fmt.dateTime(s.submittedAt)}</span>
                  {s.grade !== null ? (
                    <span className="font-semibold text-foreground">
                      Grade {s.grade}/{s.maxPoints}
                    </span>
                  ) : (
                    <span>Awaiting grade</span>
                  )}
                </div>
                {s.feedback ? <p className="mt-1 text-xs italic text-muted-foreground">“{s.feedback}”</p> : null}
              </li>
            ))}
          </ul>
        )}
      </section>
      <Separator />
      <p className="text-center text-[11px] text-muted-foreground">Enrollment ID {enrollment.id}</p>
    </div>
  );
}
