"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { api, useApi, fmt } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { LoadingBlock, ErrorBlock, EmptyState } from "@/components/platform/states";
import { StatusBadge } from "@/components/platform/status-badge";
import { FlowDiagram } from "@/components/platform/flow";
import { CourseFormDialog } from "@/components/lms/courses-client";
import { QuizBuilderDialog } from "@/components/lms/quiz-builder";
import { LESSON_TYPE_META, LessonTypeIcon, ProgressBar } from "@/components/lms/shared";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Archive,
  Award,
  BookOpen,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  Clock,
  Eye,
  FileText,
  GraduationCap,
  Layers,
  Loader2,
  PenLine,
  Plus,
  Rocket,
  RotateCcw,
  Star,
  Trash2,
  Users,
  Video,
} from "lucide-react";

/* ── Types matching the API ── */

interface LessonRow {
  id: string;
  title: string;
  type: string;
  url: string | null;
  body: string | null;
  durationMin: number;
  isPreview: boolean;
  order: number;
  quiz: { id: string; title: string; questionCount: number } | null;
  assignment: { id: string; title: string; maxPoints: number } | null;
}

interface ModuleRow {
  id: string;
  courseId: string;
  title: string;
  description: string | null;
  order: number;
  lessons: LessonRow[];
}

interface CourseDetail {
  course: {
    id: string;
    slug: string;
    title: string;
    description: string;
    status: string;
    level: string;
    weeks: number;
    hrsPerDay: number;
    prerequisite: string;
    icon: string;
    thumbnail: string | null;
    categoryId: string | null;
  };
  category: { id: string; name: string; color: string } | null;
  owner: { id: string; name: string; email: string } | null;
  modules: ModuleRow[];
  stats: {
    enrollments: number;
    active: number;
    completed: number;
    avgProgress: number;
    lessonCount: number;
  };
}

interface EnrollmentMini {
  id: string;
  learnerName: string;
  status: string;
  progress: number;
  batchName: string | null;
  enrolledAt: string;
}

export function CourseBuilderClient({ courseId, canManage }: { courseId: string; canManage: boolean }) {
  const { toast } = useToast();
  const { data, loading, error, refetch } = useApi<CourseDetail>(`/api/lms/courses/${courseId}`);
  const { data: enrollmentData } = useApi<{ items: EnrollmentMini[] }>(
    `/api/lms/enrollments?courseId=${courseId}&pageSize=20`
  );

  const [editOpen, setEditOpen] = useState(false);
  const [moduleDialog, setModuleDialog] = useState<{ mode: "create" } | { mode: "edit"; module: ModuleRow } | null>(null);
  const [lessonDialog, setLessonDialog] = useState<{ moduleId: string; lesson: LessonRow | null } | null>(null);
  const [assignmentDialog, setAssignmentDialog] = useState<{ lessonId: string; assignmentId: string | null; courseId: string } | null>(null);
  const [quizOpen, setQuizOpen] = useState(false);
  const [quizId, setQuizId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<
    { kind: "module"; id: string; title: string } | { kind: "lesson"; id: string; title: string } | null
  >(null);
  const [busy, setBusy] = useState(false);

  if (loading) return <LoadingBlock label="Loading course…" className="min-h-[60vh]" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;
  if (!data) return <EmptyState title="Course not found" hint="It may have been deleted." />;

  const { course, category, owner, stats, modules } = data;
  const enrollments = enrollmentData?.items ?? [];

  async function setStatus(status: string) {
    setBusy(true);
    try {
      await api.patch(`/api/lms/courses/${courseId}`, { status });
      toast({
        title: status === "PUBLISHED" ? "Course published" : status === "DRAFT" ? "Moved to draft" : "Course archived",
        description:
          status === "PUBLISHED" ? "Learners can now see it on the website." : `"${course.title}" is now ${status.toLowerCase()}.`,
      });
      await refetch();
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  async function openQuizForLesson(lesson: LessonRow) {
    if (lesson.quiz) {
      setQuizId(lesson.quiz.id);
      setQuizOpen(true);
      return;
    }
    // create a quiz bound to this lesson, then open the builder
    setBusy(true);
    try {
      const quiz = await api.post<{ id: string }>("/api/lms/quizzes", {
        courseId,
        lessonId: lesson.id,
        title: `${lesson.title} — Quiz`,
        passScore: 60,
      });
      toast({ title: "Quiz created", description: "Add questions to make it gradable." });
      await refetch();
      setQuizId(quiz.id);
      setQuizOpen(true);
    } catch (e) {
      toast({ title: "Could not create quiz", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      if (deleteTarget.kind === "module") {
        await api.delete(`/api/lms/modules/${deleteTarget.id}`);
        toast({ title: "Module deleted", description: `"${deleteTarget.title}" and its lessons were removed.` });
      } else {
        await api.delete(`/api/lms/lessons/${deleteTarget.id}`);
        toast({ title: "Lesson deleted", description: `"${deleteTarget.title}" was removed.` });
      }
      setDeleteTarget(null);
      await refetch();
    } catch (e) {
      toast({ title: "Delete failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  const editingCourse = {
    ...course,
    categoryName: category?.name ?? null,
    categoryColor: category?.color ?? null,
    ownerName: owner?.name ?? null,
    moduleCount: modules.length,
    lessonCount: stats.lessonCount,
    enrollmentCount: stats.enrollments,
  };

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div className="overflow-hidden rounded-3xl border bg-card shadow-sm">
        <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-start sm:p-6">
          <div className="relative h-28 w-full shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br from-brand to-[#9b5cf0] sm:w-44">
            {course.thumbnail ? (
              <Image src={course.thumbnail} alt="" width={352} height={224} className="h-28 w-full object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-white/90">
                <BookOpen className="h-9 w-9" aria-hidden="true" />
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge value={course.status} />
              {category ? (
                <span
                  className="rounded-full border px-2 py-0.5 text-[11px] font-medium"
                  style={{ borderColor: `${category.color}55`, color: category.color, background: `${category.color}11` }}
                >
                  {category.name}
                </span>
              ) : null}
              <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                <GraduationCap className="h-3 w-3" /> {course.level}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                <Layers className="h-3 w-3" /> {modules.length} modules · {stats.lessonCount} lessons
              </span>
            </div>
            <h1 className="mt-2 text-xl font-bold tracking-tight sm:text-2xl">{course.title}</h1>
            <p className="mt-1 line-clamp-2 max-w-3xl text-sm text-muted-foreground">{course.description}</p>
            <p className="mt-2 text-xs text-muted-foreground">
              Owner: {owner?.name ?? "Unassigned"} · {course.weeks} weeks · {course.hrsPerDay}h/day ·{" "}
              {course.prerequisite || "No prerequisites"}
            </p>
          </div>
          {canManage ? (
            <div className="flex shrink-0 flex-wrap items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setEditOpen(true)}>
                Edit details
              </Button>
              {course.status !== "PUBLISHED" ? (
                <Button size="sm" onClick={() => void setStatus("PUBLISHED")} disabled={busy}>
                  <Rocket className="mr-2 h-3.5 w-3.5" /> Publish
                </Button>
              ) : (
                <Button variant="outline" size="sm" onClick={() => void setStatus("DRAFT")} disabled={busy}>
                  <RotateCcw className="mr-2 h-3.5 w-3.5" /> Unpublish
                </Button>
              )}
              {course.status !== "ARCHIVED" ? (
                <Button variant="ghost" size="sm" onClick={() => void setStatus("ARCHIVED")} disabled={busy}>
                  <Archive className="mr-2 h-3.5 w-3.5" /> Archive
                </Button>
              ) : null}
            </div>
          ) : null}
        </div>
        {/* learning journey */}
        <div className="border-t bg-muted/30 px-4 py-3 sm:px-6">
          <FlowDiagram
            steps={[
              { icon: Users, label: "Enrollment", sub: "Learner joins", tone: "brand" },
              { icon: Layers, label: "Module", sub: `${modules.length} total`, tone: "slate" },
              { icon: Video, label: "Lesson", sub: `${stats.lessonCount} total`, tone: "slate" },
              { icon: ClipboardCheck, label: "Quiz / Assignment", sub: "Assessed", tone: "amber" },
              { icon: GraduationCap, label: "100% Progress", sub: `${stats.avgProgress}% avg now`, tone: "green" },
              { icon: Award, label: "Certificate", sub: `${stats.completed} completed`, tone: "orange" },
            ]}
          />
        </div>
      </div>

      {/* ── Content grid ── */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* modules column */}
        <div className="space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">Learning journey</h2>
            {canManage ? (
              <Button size="sm" onClick={() => setModuleDialog({ mode: "create" })}>
                <Plus className="mr-1.5 h-4 w-4" /> Add module
              </Button>
            ) : null}
          </div>

          {modules.length === 0 ? (
            <EmptyState
              icon={Layers}
              title="No modules yet"
              hint={canManage ? "Add your first module — lessons live inside modules." : "The instructor hasn't added content yet."}
              action={
                canManage ? (
                  <Button onClick={() => setModuleDialog({ mode: "create" })}>
                    <Plus className="mr-2 h-4 w-4" /> Add module
                  </Button>
                ) : undefined
              }
            />
          ) : (
            <div className="space-y-3">
              {modules.map((mod, idx) => (
                <CollapsibleModule
                  key={mod.id}
                  module={mod}
                  index={idx}
                  canManage={canManage}
                  busy={busy}
                  onEdit={() => setModuleDialog({ mode: "edit", module: mod })}
                  onDelete={() => setDeleteTarget({ kind: "module", id: mod.id, title: mod.title })}
                  onAddLesson={() => setLessonDialog({ moduleId: mod.id, lesson: null })}
                  onEditLesson={(lesson) => setLessonDialog({ moduleId: mod.id, lesson })}
                  onDeleteLesson={(lesson) => setDeleteTarget({ kind: "lesson", id: lesson.id, title: lesson.title })}
                  onOpenQuiz={(lesson) => void openQuizForLesson(lesson)}
                  onOpenAssignment={(lesson) =>
                    setAssignmentDialog({
                      lessonId: lesson.id,
                      assignmentId: lesson.assignment?.id ?? null,
                      courseId,
                    })
                  }
                />
              ))}
            </div>
          )}
        </div>

        {/* enrollments column */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">Learners</h2>
            <Link href={`/lms/enrollments?courseId=${courseId}`} className="text-xs font-semibold text-brand hover:underline">
              View all →
            </Link>
          </div>
          <div className="rounded-2xl border bg-card p-2 shadow-sm">
            {enrollments.length === 0 ? (
              <p className="px-3 py-6 text-center text-xs text-muted-foreground">
                No enrollments in this course yet. Enroll learners from the Enrollments page.
              </p>
            ) : (
              <ul className="max-h-[420px] space-y-1 overflow-y-auto nice-scrollbar">
                {enrollments.map((e) => (
                  <li key={e.id} className="rounded-xl px-3 py-2.5 transition hover:bg-muted/60">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-[13px] font-semibold">{e.learnerName}</p>
                      <StatusBadge value={e.status} />
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <ProgressBar value={e.progress} className="h-1.5 flex-1" />
                      <span className="w-9 text-right text-[11px] font-semibold text-muted-foreground">{e.progress}%</span>
                    </div>
                    <p className="mt-1 text-[11px] text-muted-foreground">
                      {e.batchName ? `Batch ${e.batchName} · ` : ""}
                      joined {fmt.date(e.enrolledAt)}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="rounded-2xl border bg-card p-4 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Course stats</p>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">Enrollments</dt>
                <dd className="font-semibold">{stats.enrollments}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">Avg progress</dt>
                <dd className="font-semibold">{stats.avgProgress}%</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">Completed</dt>
                <dd className="font-semibold">{stats.completed}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">Public URL</dt>
                <dd className="truncate font-mono text-[11px]">/courses/{course.slug}</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>

      {/* ── Dialogs ── */}
      <CourseFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        categories={category ? [category] : []}
        course={editingCourse}
        onSaved={refetch}
      />

      <ModuleDialog
        open={moduleDialog !== null}
        courseId={courseId}
        module={moduleDialog?.mode === "edit" ? moduleDialog.module : null}
        onClose={async (saved) => {
          setModuleDialog(null);
          if (saved) await refetch();
        }}
      />

      <LessonDialog
        open={lessonDialog !== null}
        moduleId={lessonDialog?.moduleId ?? ""}
        lesson={lessonDialog?.lesson ?? null}
        courseId={courseId}
        onClose={async (saved) => {
          setLessonDialog(null);
          if (saved) await refetch();
        }}
      />

      <AssignmentDialog
        open={assignmentDialog !== null}
        courseId={assignmentDialog?.courseId ?? ""}
        lessonId={assignmentDialog?.lessonId ?? ""}
        assignmentId={assignmentDialog?.assignmentId ?? null}
        onClose={async (saved) => {
          setAssignmentDialog(null);
          if (saved) await refetch();
        }}
      />

      <QuizBuilderDialog open={quizOpen} onOpenChange={setQuizOpen} quizId={quizId} onChanged={refetch} />

      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {deleteTarget?.kind === "module" ? "module" : "lesson"} “{deleteTarget?.title}”?
            </AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.kind === "module"
                ? "The module and all its lessons — including linked quizzes, assignments and learner progress — will be permanently removed."
                : "The lesson and any linked quiz, assignment and learner progress rows will be permanently removed."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault();
                void confirmDelete();
              }}
            >
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ── Module accordion item ── */

function CollapsibleModule({
  module,
  index,
  canManage,
  busy,
  onEdit,
  onDelete,
  onAddLesson,
  onEditLesson,
  onDeleteLesson,
  onOpenQuiz,
  onOpenAssignment,
}: {
  module: ModuleRow;
  index: number;
  canManage: boolean;
  busy: boolean;
  onEdit: () => void;
  onDelete: () => void;
  onAddLesson: () => void;
  onEditLesson: (lesson: LessonRow) => void;
  onDeleteLesson: (lesson: LessonRow) => void;
  onOpenQuiz: (lesson: LessonRow) => void;
  onOpenAssignment: (lesson: LessonRow) => void;
}) {
  const [open, setOpen] = useState(index === 0);
  const totalMin = module.lessons.reduce((s, l) => s + l.durationMin, 0);

  return (
    <Collapsible
      open={open}
      onOpenChange={setOpen}
      className="overflow-hidden rounded-2xl border bg-card shadow-sm"
    >
      <div className="flex items-center gap-2 p-3">
        <CollapsibleTrigger asChild>
          <button
            type="button"
            className="flex min-w-0 flex-1 items-center gap-3 text-left"
            aria-expanded={open}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-xs font-bold text-brand dark:bg-brand/15 dark:text-violet-300">
              {index + 1}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-semibold">{module.title}</span>
              <span className="block text-[11px] text-muted-foreground">
                {module.lessons.length} lesson{module.lessons.length === 1 ? "" : "s"} · {Math.round(totalMin)} min
              </span>
            </span>
            {open ? (
              <ChevronDown className="ml-auto h-4 w-4 shrink-0 text-muted-foreground" />
            ) : (
              <ChevronRight className="ml-auto h-4 w-4 shrink-0 text-muted-foreground" />
            )}
          </button>
        </CollapsibleTrigger>
        {canManage ? (
          <div className="flex shrink-0 items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg" onClick={onAddLesson} aria-label={`Add lesson to ${module.title}`}>
              <Plus className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg" onClick={onEdit} aria-label={`Rename ${module.title}`}>
              <PenLine className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-lg text-destructive"
              onClick={onDelete}
              disabled={busy}
              aria-label={`Delete ${module.title}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ) : null}
      </div>
      <CollapsibleContent>
        <div className="border-t px-3 py-2">
          {module.lessons.length === 0 ? (
            <p className="py-3 text-center text-xs text-muted-foreground">
              No lessons in this module yet.
            </p>
          ) : (
            <ul className="space-y-1">
              {module.lessons.map((lesson, li) => {
                const meta = LESSON_TYPE_META[lesson.type] ?? LESSON_TYPE_META.DOCUMENT;
                return (
                  <li
                    key={lesson.id}
                    className="group flex items-center gap-3 rounded-xl px-2 py-2 transition hover:bg-muted/60"
                  >
                    <LessonTypeIcon type={lesson.type} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium">
                        {index + 1}.{li + 1} {lesson.title}
                      </p>
                      <p className="flex flex-wrap items-center gap-x-2 text-[11px] text-muted-foreground">
                        <span>{meta.label}</span>
                        <span>· {lesson.durationMin} min</span>
                        {lesson.isPreview ? (
                          <span className="inline-flex items-center gap-0.5 font-medium text-emerald-600 dark:text-emerald-400">
                            <Eye className="h-3 w-3" /> Free preview
                          </span>
                        ) : null}
                        {lesson.quiz ? (
                          <span className="inline-flex items-center gap-0.5 font-medium text-brand">
                            <ClipboardCheck className="h-3 w-3" /> Quiz · {lesson.quiz.questionCount} Q
                          </span>
                        ) : null}
                        {lesson.assignment ? (
                          <span className="inline-flex items-center gap-0.5 font-medium text-amber-600 dark:text-amber-400">
                            <PenLine className="h-3 w-3" /> Assignment · {lesson.assignment.maxPoints} pts
                          </span>
                        ) : null}
                      </p>
                    </div>
                    {canManage ? (
                      <div className="flex shrink-0 items-center gap-0.5 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100">
                        {lesson.type === "QUIZ" ? (
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => onOpenQuiz(lesson)}>
                            <ClipboardCheck className="mr-1 h-3 w-3" />
                            {lesson.quiz ? "Edit quiz" : "Create quiz"}
                          </Button>
                        ) : null}
                        {lesson.type === "ASSIGNMENT" ? (
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => onOpenAssignment(lesson)}>
                            <PenLine className="mr-1 h-3 w-3" />
                            {lesson.assignment ? "Edit assignment" : "Create assignment"}
                          </Button>
                        ) : null}
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEditLesson(lesson)} aria-label={`Edit ${lesson.title}`}>
                          <PenLine className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive"
                          onClick={() => onDeleteLesson(lesson)}
                          aria-label={`Delete ${lesson.title}`}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

/* ── Module create/edit dialog ── */

function ModuleDialog({
  open,
  courseId,
  module,
  onClose,
}: {
  open: boolean;
  courseId: string;
  module: ModuleRow | null;
  onClose: (saved: boolean) => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const [seed, setSeed] = useState("");

  const key = module?.id ?? "create";
  if (open && seed !== key) {
    setSeed(key);
    setTitle(module?.title ?? "");
    setDescription(module?.description ?? "");
  }

  async function save() {
    if (!title.trim()) {
      toast({ title: "Module title is required", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (module) {
        await api.patch(`/api/lms/modules/${module.id}`, { title: title.trim(), description: description.trim() || null });
        toast({ title: "Module updated" });
      } else {
        await api.post(`/api/lms/courses/${courseId}/modules`, { title: title.trim(), description: description.trim() || null });
        toast({ title: "Module added" });
      }
      await onClose(true);
    } catch (e) {
      toast({ title: "Save failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && void onClose(false)}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{module ? "Rename module" : "Add module"}</DialogTitle>
          <DialogDescription>Modules group lessons into a learning journey.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label htmlFor="module-title">Title *</Label>
            <Input id="module-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Data Foundations" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="module-desc">Description</Label>
            <Textarea id="module-desc" rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => void onClose(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={() => void save()} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {module ? "Save" : "Add module"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Lesson create/edit dialog (type-aware) ── */

function LessonDialog({
  open,
  moduleId,
  lesson,
  courseId,
  onClose,
}: {
  open: boolean;
  moduleId: string;
  lesson: LessonRow | null;
  courseId: string;
  onClose: (saved: boolean) => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [type, setType] = useState("VIDEO");
  const [url, setUrl] = useState("");
  const [body, setBody] = useState("");
  const [durationMin, setDurationMin] = useState("10");
  const [isPreview, setIsPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [seed, setSeed] = useState("");

  const key = lesson?.id ?? "create";
  if (open && seed !== key) {
    setSeed(key);
    setTitle(lesson?.title ?? "");
    setType(lesson?.type ?? "VIDEO");
    setUrl(lesson?.url ?? "");
    setBody(lesson?.body ?? "");
    setDurationMin(String(lesson?.durationMin ?? 10));
    setIsPreview(lesson?.isPreview ?? false);
  }

  async function save() {
    if (!title.trim()) {
      toast({ title: "Lesson title is required", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim(),
        type,
        url: url.trim() || null,
        body: body.trim() || null,
        durationMin: Math.max(0, Number(durationMin) || 0),
        isPreview,
      };
      if (lesson) {
        await api.patch(`/api/lms/lessons/${lesson.id}`, payload);
        toast({ title: "Lesson updated" });
      } else {
        await api.post(`/api/lms/modules/${moduleId}/lessons`, payload);
        toast({ title: "Lesson added" });
      }
      await onClose(true);
    } catch (e) {
      toast({ title: "Save failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && void onClose(false)}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{lesson ? "Edit lesson" : "Add lesson"}</DialogTitle>
          <DialogDescription>
            {type === "QUIZ"
              ? "Quiz lessons hold a graded quiz — create the quiz after saving the lesson."
              : type === "ASSIGNMENT"
                ? "Assignment lessons hold a gradable assignment — create it after saving the lesson."
                : "Learners complete lessons to move their progress bar."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label htmlFor="lesson-title">Title *</Label>
            <Input id="lesson-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Intro to Pandas" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label>Type</Label>
              <Select value={type} onValueChange={setType} disabled={Boolean(lesson)}>
                <SelectTrigger aria-label="Lesson type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="VIDEO">Video</SelectItem>
                  <SelectItem value="DOCUMENT">Document</SelectItem>
                  <SelectItem value="QUIZ">Quiz</SelectItem>
                  <SelectItem value="ASSIGNMENT">Assignment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="lesson-duration">Duration (min)</Label>
              <Input id="lesson-duration" type="number" min={0} max={600} value={durationMin} onChange={(e) => setDurationMin(e.target.value)} />
            </div>
          </div>
          {type === "VIDEO" ? (
            <div className="grid gap-1.5">
              <Label htmlFor="lesson-url">Video URL</Label>
              <Input id="lesson-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://youtube.com/watch?v=…" />
            </div>
          ) : null}
          {type === "DOCUMENT" ? (
            <>
              <div className="grid gap-1.5">
                <Label htmlFor="lesson-doc-url">Document link (optional)</Label>
                <Input id="lesson-doc-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://docs.example.com/…" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="lesson-body">Lesson notes</Label>
                <Textarea id="lesson-body" rows={4} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Reading material or instructions…" />
              </div>
            </>
          ) : null}
          {type === "QUIZ" ? (
            <div className="rounded-xl border bg-muted/40 p-3 text-xs text-muted-foreground">
              <p className="flex items-center gap-1.5 font-medium text-foreground">
                <ClipboardCheck className="h-3.5 w-3.5" /> Quiz attachment
              </p>
              <p className="mt-1">
                {lesson?.quiz
                  ? `Attached quiz: “${lesson.quiz.title}” (${lesson.quiz.questionCount} questions). Use “Edit quiz” on the lesson row after saving.`
                  : "Save the lesson, then use “Create quiz” on its row to build the quiz and questions."}
              </p>
            </div>
          ) : null}
          {type === "ASSIGNMENT" ? (
            <div className="rounded-xl border bg-muted/40 p-3 text-xs text-muted-foreground">
              <p className="flex items-center gap-1.5 font-medium text-foreground">
                <PenLine className="h-3.5 w-3.5" /> Assignment attachment
              </p>
              <p className="mt-1">
                {lesson?.assignment
                  ? `Attached assignment: “${lesson.assignment.title}” (${lesson.assignment.maxPoints} points). Use “Edit assignment” on the lesson row.`
                  : "Save the lesson, then use “Create assignment” on its row to configure points and instructions."}
              </p>
            </div>
          ) : null}
          <div className="flex items-center justify-between rounded-xl border px-3 py-2.5">
            <div>
              <Label htmlFor="lesson-preview" className="text-sm">
                Free preview
              </Label>
              <p className="text-[11px] text-muted-foreground">Show this lesson to prospects on the website.</p>
            </div>
            <Switch id="lesson-preview" checked={isPreview} onCheckedChange={setIsPreview} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => void onClose(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={() => void save()} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {lesson ? "Save lesson" : "Add lesson"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Assignment create/edit dialog ── */

function AssignmentDialog({
  open,
  courseId,
  lessonId,
  assignmentId,
  onClose,
}: {
  open: boolean;
  courseId: string;
  lessonId: string;
  assignmentId: string | null;
  onClose: (saved: boolean) => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [instructions, setInstructions] = useState("");
  const [maxPoints, setMaxPoints] = useState("100");
  const [dueInDays, setDueInDays] = useState("");
  const [saving, setSaving] = useState(false);
  const [seed, setSeed] = useState("");
  const { data: existing } = useApi<{
    id: string;
    title: string;
    instructions: string | null;
    maxPoints: number;
    dueInDays: number | null;
  }>(open && assignmentId ? `/api/lms/assignments/${assignmentId}` : null);

  const key = assignmentId ?? "create";
  if (open && seed !== key) {
    setSeed(key);
    setTitle("");
    setInstructions("");
    setMaxPoints("100");
    setDueInDays("");
  }

  // hydrate once the fetch for an existing assignment resolves
  const hydratedKey = existing?.id ?? "";
  if (open && existing && seed === existing.id && !title && hydratedKey) {
    setTitle(existing.title);
    setInstructions(existing.instructions ?? "");
    setMaxPoints(String(existing.maxPoints));
    setDueInDays(existing.dueInDays ? String(existing.dueInDays) : "");
  }

  async function save() {
    if (!title.trim()) {
      toast({ title: "Assignment title is required", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        courseId,
        lessonId,
        title: title.trim(),
        instructions: instructions.trim() || null,
        maxPoints: Math.max(1, Number(maxPoints) || 100),
        dueInDays: dueInDays ? Math.max(0, Number(dueInDays)) : null,
      };
      if (assignmentId) {
        await api.patch(`/api/lms/assignments/${assignmentId}`, {
          title: payload.title,
          instructions: payload.instructions,
          maxPoints: payload.maxPoints,
          dueInDays: payload.dueInDays,
        });
        toast({ title: "Assignment updated" });
      } else {
        await api.post("/api/lms/assignments", payload);
        toast({ title: "Assignment created" });
      }
      await onClose(true);
    } catch (e) {
      toast({ title: "Save failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && void onClose(false)}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{assignmentId ? "Edit assignment" : "Create assignment"}</DialogTitle>
          <DialogDescription>Learners submit work; staff grade it from the Assessments page.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-1">
          <div className="grid gap-1.5">
            <Label htmlFor="asg-title">Title *</Label>
            <Input id="asg-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Build a sales dashboard" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="asg-instructions">Instructions</Label>
            <Textarea id="asg-instructions" rows={4} value={instructions} onChange={(e) => setInstructions(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="asg-points">Max points</Label>
              <Input id="asg-points" type="number" min={1} max={1000} value={maxPoints} onChange={(e) => setMaxPoints(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="asg-due">Due (days after start)</Label>
              <Input id="asg-due" type="number" min={0} max={365} value={dueInDays} onChange={(e) => setDueInDays(e.target.value)} placeholder="—" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => void onClose(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={() => void save()} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {assignmentId ? "Save" : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
