"use client";

import { useEffect, useState } from "react";
import { api, useApi } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { HelpCircle, Loader2, Plus, Save, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

export interface QuizQuestionRow {
  id: string;
  text: string;
  type: string; // SINGLE | MULTI | BOOLEAN
  options: string[];
  correct: number[];
  points: number;
  order: number;
}

interface QuizDetail {
  quiz: {
    id: string;
    courseId: string;
    lessonId: string | null;
    title: string;
    description: string | null;
    passScore: number;
    timeLimitMin: number | null;
  };
  questions: QuizQuestionRow[];
  attempts: unknown[];
}

/** Quiz settings + question editor used inside the Course Builder. */
export function QuizBuilderDialog({
  open,
  onOpenChange,
  quizId,
  onChanged,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  quizId: string | null;
  onChanged: () => void | Promise<void>;
}) {
  const { toast } = useToast();
  const { data, loading, error, refetch } = useApi<QuizDetail>(
    open && quizId ? `/api/lms/quizzes?quizId=${quizId}` : null
  );
  const [title, setTitle] = useState("");
  const [passScore, setPassScore] = useState("60");
  const [timeLimit, setTimeLimit] = useState("");
  const [savingMeta, setSavingMeta] = useState(false);

  useEffect(() => {
    if (data?.quiz) {
      setTitle(data.quiz.title);
      setPassScore(String(data.quiz.passScore));
      setTimeLimit(data.quiz.timeLimitMin ? String(data.quiz.timeLimitMin) : "");
    }
  }, [data]);

  async function saveMeta() {
    if (!quizId) return;
    setSavingMeta(true);
    try {
      await api.patch(`/api/lms/quizzes/${quizId}`, {
        title: title.trim() || "Untitled quiz",
        passScore: Math.max(1, Math.min(100, Number(passScore) || 60)),
        timeLimitMin: timeLimit ? Math.max(1, Number(timeLimit)) : null,
      });
      toast({ title: "Quiz settings saved" });
      await refetch();
      await onChanged();
    } catch (e) {
      toast({ title: "Save failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSavingMeta(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Quiz builder</DialogTitle>
          <DialogDescription>
            Configure the quiz and its questions. Learners need {data?.quiz.passScore ?? "—"}% to pass.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="space-y-3 py-4">
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : error ? (
          <p className="py-6 text-center text-sm text-destructive">{error}</p>
        ) : data ? (
          <div className="space-y-4 py-1">
            {/* settings */}
            <div className="grid gap-3 rounded-2xl border bg-muted/30 p-3 sm:grid-cols-[1fr_100px_100px]">
              <div className="grid gap-1.5">
                <Label htmlFor="quiz-title">Quiz title</Label>
                <Input id="quiz-title" value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="quiz-pass">Pass %</Label>
                <Input id="quiz-pass" type="number" min={1} max={100} value={passScore} onChange={(e) => setPassScore(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="quiz-time">Time (min)</Label>
                <Input id="quiz-time" type="number" min={1} placeholder="—" value={timeLimit} onChange={(e) => setTimeLimit(e.target.value)} />
              </div>
              <div className="sm:col-span-3">
                <Button size="sm" variant="outline" onClick={() => void saveMeta()} disabled={savingMeta}>
                  {savingMeta ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <Save className="mr-2 h-3.5 w-3.5" />}
                  Save settings
                </Button>
              </div>
            </div>

            <Separator />

            {/* questions */}
            <div className="space-y-3">
              <p className="text-sm font-semibold">
                Questions <span className="ml-1 text-xs font-normal text-muted-foreground">({data.questions.length})</span>
              </p>
              {data.questions.length === 0 ? (
                <p className="rounded-xl border border-dashed p-4 text-center text-xs text-muted-foreground">
                  No questions yet — add the first one below.
                </p>
              ) : (
                data.questions.map((q) => (
                  <QuestionEditor key={q.id} question={q} onChanged={async () => { await refetch(); await onChanged(); }} />
                ))
              )}
              <AddQuestion quizId={quizId!} onAdded={async () => { await refetch(); await onChanged(); }} />
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

/* ── One editable question card ── */

function QuestionEditor({ question, onChanged }: { question: QuizQuestionRow; onChanged: () => void | Promise<void> }) {
  const { toast } = useToast();
  const [text, setText] = useState(question.text);
  const [type, setType] = useState(question.type);
  const [options, setOptions] = useState<string[]>(question.options);
  const [correct, setCorrect] = useState<number[]>(question.correct);
  const [points, setPoints] = useState(String(question.points));
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  const isBoolean = type === "BOOLEAN";
  const opts = isBoolean ? ["True", "False"] : options;

  function touch<K extends "text" | "type" | "options" | "correct" | "points">(
    key: K,
    value: (typeof text & string) | string | string[] | number[] | string
  ) {
    setDirty(true);
    if (key === "text") setText(value as string);
    if (key === "type") {
      setType(value as string);
      if (value === "BOOLEAN") setCorrect((c) => (c.length ? [c[0]] : []));
    }
    if (key === "options") setOptions(value as string[]);
    if (key === "correct") setCorrect(value as number[]);
    if (key === "points") setPoints(value as string);
  }

  async function save() {
    setSaving(true);
    try {
      await api.patch(`/api/lms/questions/${question.id}`, {
        text: text.trim(),
        type,
        options: isBoolean ? undefined : opts,
        correct: correct.length ? correct : [0],
        points: Math.max(1, Number(points) || 1),
      });
      toast({ title: "Question saved" });
      setDirty(false);
      await onChanged();
    } catch (e) {
      toast({ title: "Save failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function remove() {
    setSaving(true);
    try {
      await api.delete(`/api/lms/questions/${question.id}`);
      toast({ title: "Question deleted" });
      await onChanged();
    } catch (e) {
      toast({ title: "Delete failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-2xl border bg-card p-3">
      <div className="grid gap-2">
        <div className="flex gap-2">
          <Input
            value={text}
            onChange={(e) => touch("text", e.target.value)}
            placeholder="Question text"
            aria-label="Question text"
            className="flex-1"
          />
          <Select
            value={type}
            onValueChange={(v) => touch("type", v)}
          >
            <SelectTrigger className="w-32 shrink-0" aria-label="Question type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="SINGLE">Single choice</SelectItem>
              <SelectItem value="MULTI">Multiple</SelectItem>
              <SelectItem value="BOOLEAN">True / False</SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="number"
            min={1}
            max={100}
            value={points}
            onChange={(e) => touch("points", e.target.value)}
            className="w-16 shrink-0"
            aria-label="Points"
          />
        </div>
        <div className="grid gap-1.5 sm:grid-cols-2">
          {opts.map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <Checkbox
                id={`correct-${question.id}-${i}`}
                checked={correct.includes(i)}
                onCheckedChange={(checked) =>
                  touch(
                    "correct",
                    checked
                      ? type === "SINGLE" || type === "BOOLEAN"
                        ? [i]
                        : [...correct, i]
                      : correct.filter((x) => x !== i)
                  )
                }
                aria-label={`Option ${i + 1} is correct`}
              />
              {isBoolean ? (
                <Label htmlFor={`correct-${question.id}-${i}`} className="flex-1 text-sm font-normal">
                  {opt}
                </Label>
              ) : (
                <Input
                  value={opt}
                  onChange={(e) => {
                    const next = [...opts];
                    next[i] = e.target.value;
                    touch("options", next);
                  }}
                  className="h-8"
                  aria-label={`Option ${i + 1}`}
                />
              )}
            </div>
          ))}
        </div>
        {!isBoolean ? (
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
              <HelpCircle className="h-3 w-3" /> Tick the correct option(s) — {type === "MULTI" ? "multiple allowed" : "one only"}
            </span>
            <div className="flex gap-1.5">
              {opts.length < 10 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => touch("options", [...opts, ""])}
                >
                  <Plus className="mr-1 h-3 w-3" /> Option
                </Button>
              ) : null}
              {opts.length > 2 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="text-destructive"
                  onClick={() => {
                    const next = [...opts];
                    next.pop();
                    touch("options", next);
                    setCorrect((c) => c.filter((x) => x < next.length));
                  }}
                >
                  <Trash2 className="mr-1 h-3 w-3" /> Option
                </Button>
              ) : null}
            </div>
          </div>
        ) : null}
        <div className="flex justify-end gap-1.5 border-t pt-2">
          <Button size="sm" variant="ghost" className="text-destructive" onClick={() => void remove()} disabled={saving}>
            <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete
          </Button>
          <Button size="sm" onClick={() => void save()} disabled={saving || !dirty}>
            {saving ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Save className="mr-1.5 h-3.5 w-3.5" />}
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ── Add-question form ── */

function AddQuestion({ quizId, onAdded }: { quizId: string; onAdded: () => void | Promise<void> }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [type, setType] = useState("SINGLE");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [correct, setCorrect] = useState<number[]>([]);
  const [points, setPoints] = useState("1");
  const [saving, setSaving] = useState(false);

  const isBoolean = type === "BOOLEAN";
  const opts = isBoolean ? ["True", "False"] : options.map((o, i) => (o.trim() ? o.trim() : `Option ${i + 1}`));

  async function submit() {
    if (!text.trim()) {
      toast({ title: "Question text required", variant: "destructive" });
      return;
    }
    if (correct.length === 0) {
      toast({ title: "Mark at least one correct option", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.post(`/api/lms/quizzes/${quizId}/questions`, {
        text: text.trim(),
        type,
        options: isBoolean ? undefined : opts,
        correct,
        points: Math.max(1, Number(points) || 1),
      });
      toast({ title: "Question added" });
      setText("");
      setOptions(["", "", "", ""]);
      setCorrect([]);
      setPoints("1");
      setOpen(false);
      await onAdded();
    } catch (e) {
      toast({ title: "Add failed", description: e instanceof Error ? e.message : "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  if (!open) {
    return (
      <Button variant="outline" size="sm" className="w-full border-dashed" onClick={() => setOpen(true)}>
        <Plus className="mr-2 h-4 w-4" /> Add question
      </Button>
    );
  }

  return (
    <div className="rounded-2xl border border-brand/30 bg-brand-soft/40 p-3 dark:bg-brand/10">
      <div className="grid gap-2">
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Question text" aria-label="New question text" />
        <div className="flex gap-2">
          <Select value={type} onValueChange={(v) => { setType(v); setCorrect([]); }}>
            <SelectTrigger className="w-40" aria-label="New question type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="SINGLE">Single choice</SelectItem>
              <SelectItem value="MULTI">Multiple</SelectItem>
              <SelectItem value="BOOLEAN">True / False</SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="number"
            min={1}
            max={100}
            value={points}
            onChange={(e) => setPoints(e.target.value)}
            className="w-20"
            aria-label="Points"
          />
        </div>
        <div className="grid gap-1.5 sm:grid-cols-2">
          {opts.map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <Checkbox
                checked={correct.includes(i)}
                onCheckedChange={(checked) =>
                  setCorrect((c) =>
                    checked
                      ? type === "SINGLE" || type === "BOOLEAN"
                        ? [i]
                        : [...c, i]
                      : c.filter((x) => x !== i)
                  )
                }
                aria-label={`New option ${i + 1} is correct`}
              />
              {isBoolean ? (
                <span className="text-sm">{opt}</span>
              ) : (
                <Input
                  value={options[i] ?? ""}
                  onChange={(e) => {
                    const next = [...options];
                    next[i] = e.target.value;
                    setOptions(next);
                  }}
                  className={cn("h-8")}
                  aria-label={`New option ${i + 1}`}
                />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-end gap-1.5">
          <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={() => void submit()} disabled={saving}>
            {saving ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Plus className="mr-1.5 h-3.5 w-3.5" />}
            Add question
          </Button>
        </div>
      </div>
    </div>
  );
}
