"use client";

import { useMemo, useState } from "react";
import { Award, Copy, Loader2, ShieldCheck, Trophy } from "lucide-react";
import { api, fmt, useApi } from "@/lib/api-client";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { StatusBadge } from "@/components/platform/status-badge";
import { DataTable, type Column } from "@/components/platform/data-table";
import { LoadingBlock, ErrorBlock, EmptyState } from "@/components/platform/states";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface CertificateRow {
  id: string;
  serial: string;
  enrollmentId: string;
  learnerName: string;
  courseTitle: string;
  grade: string | null;
  issuedBy: string | null;
  issuerName: string | null;
  issuedAt: string;
  enrollmentStatus: string | null;
  enrollmentProgress: number | null;
  batchName: string | null;
}

interface EnrollmentRow {
  id: string;
  learnerName: string;
  courseTitle: string;
  courseId: string | null;
  status: string;
  progress: number;
  batchName: string | null;
}

export function CertificatesClient({ canIssue }: { canIssue: boolean }) {
  const { toast } = useToast();
  const certsApi = useApi<{ items: CertificateRow[] }>("/api/lms/certificates");
  const enrollmentsApi = useApi<{ items: EnrollmentRow[] }>(
    canIssue ? "/api/lms/enrollments?status=COMPLETED&pageSize=100" : null
  );

  const [issueOpen, setIssueOpen] = useState(false);
  const [selected, setSelected] = useState<string>("");
  const [grade, setGrade] = useState<string>("none");
  const [issuing, setIssuing] = useState(false);
  const [issued, setIssued] = useState<CertificateRow | null>(null);

  const certified = useMemo(
    () => new Set((certsApi.data?.items ?? []).map((c) => c.enrollmentId)),
    [certsApi.data]
  );

  const eligible = useMemo(
    () =>
      (enrollmentsApi.data?.items ?? []).filter(
        (e) => e.progress === 100 && !certified.has(e.id)
      ),
    [enrollmentsApi.data, certified]
  );

  const rows = certsApi.data?.items ?? [];

  const columns: Column<CertificateRow>[] = [
    {
      key: "serial",
      header: "Serial",
      sortable: true,
      render: (r) => <span className="font-mono text-xs font-semibold">{r.serial}</span>,
    },
    {
      key: "learnerName",
      header: "Learner",
      sortable: true,
      render: (r) => (
        <div>
          <p className="font-semibold">{r.learnerName}</p>
          {r.batchName ? <p className="text-xs text-muted-foreground">Batch {r.batchName}</p> : null}
        </div>
      ),
    },
    { key: "courseTitle", header: "Course", sortable: true, render: (r) => <span className="max-w-56 truncate">{r.courseTitle}</span> },
    {
      key: "grade",
      header: "Grade",
      render: (r) =>
        r.grade ? (
          <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-brand-soft text-xs font-bold text-brand dark:bg-brand/15 dark:text-violet-300">
            {r.grade}
          </span>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        ),
    },
    {
      key: "issuedAt",
      header: "Issued",
      sortable: true,
      render: (r) => (
        <div>
          <p>{fmt.date(r.issuedAt)}</p>
          {r.issuerName ? <p className="text-xs text-muted-foreground">by {r.issuerName}</p> : null}
        </div>
      ),
    },
    {
      key: "enrollmentStatus",
      header: "Enrollment",
      render: (r) =>
        r.enrollmentStatus ? (
          <StatusBadge value={r.enrollmentStatus} />
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        ),
    },
    {
      key: "actions",
      header: "",
      render: (r) => (
        <Button
          variant="ghost"
          size="sm"
          className="h-8 rounded-lg text-xs"
          onClick={(e) => {
            e.stopPropagation();
            void navigator.clipboard
              .writeText(`${window.location.origin}/verify/certificate/${r.serial}`)
              .then(() => toast({ title: "Verification link copied", description: r.serial }));
          }}
        >
          <Copy className="mr-1.5 h-3.5 w-3.5" /> Verify link
        </Button>
      ),
    },
  ];

  async function handleIssue() {
    if (!selected) return;
    setIssuing(true);
    try {
      const cert = await api.post<CertificateRow>("/api/lms/certificates", {
        enrollmentId: selected,
        grade: grade === "none" ? null : grade,
      });
      toast({
        title: "Certificate issued 🎓",
        description: `${cert.serial} — ${cert.learnerName}`,
      });
      setIssued(cert);
      setIssueOpen(false);
      setSelected("");
      setGrade("none");
      await certsApi.refetch();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not issue certificate",
        description: err instanceof Error ? err.message : "Please try again.",
      });
    } finally {
      setIssuing(false);
    }
  }

  if (certsApi.loading) return <LoadingBlock label="Loading certificates…" />;
  if (certsApi.error) return <ErrorBlock message={certsApi.error} onRetry={certsApi.refetch} />;

  const completable = (enrollmentsApi.data?.items ?? []).filter((e) => e.progress === 100).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Certificates"
        description="Issue verifiable completion certificates and share public verification links."
        actions={
          canIssue ? (
            <Button className="rounded-xl" onClick={() => setIssueOpen(true)}>
              <Award className="mr-2 h-4 w-4" /> Issue certificate
            </Button>
          ) : null
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard label="Certificates issued" value={rows.length} icon={Trophy} tone="amber" hint="All time" />
        <StatCard
          label="Ready to issue"
          value={Math.max(0, completable - certified.size)}
          icon={Award}
          tone="green"
          hint="100% completed, no certificate yet"
        />
        <StatCard
          label="Verified completions"
          value={rows.filter((r) => r.enrollmentStatus === "COMPLETED").length}
          icon={ShieldCheck}
          tone="brand"
          hint="Enrollments with COMPLETED status"
        />
        <StatCard
          label="This year"
          value={rows.filter((r) => new Date(r.issuedAt).getFullYear() === new Date().getFullYear()).length}
          icon={Award}
          tone="orange"
          hint={`${new Date().getFullYear()} issues`}
        />
      </div>

      <div className="rounded-2xl border border-brand/20 bg-brand-soft/50 p-4 text-[13px] leading-relaxed text-ink dark:bg-brand/10 dark:text-foreground">
        <p className="font-semibold">Public verification</p>
        <p className="mt-0.5 text-muted-foreground">
          Every certificate has a public verification page at{" "}
          <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">/verify/certificate/&lt;serial&gt;</code>{" "}
          — share it with employers to verify authenticity instantly.
        </p>
      </div>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={(r) => r.id}
        searchPlaceholder="Search learner, course or serial…"
        filterFn={(r, q) =>
          `${r.learnerName} ${r.courseTitle} ${r.serial}`.toLowerCase().includes(q)
        }
        emptyTitle="No certificates issued yet"
        emptyHint="Certificates unlock automatically when a learner reaches 100% progress and is marked COMPLETED."
      />

      {/* Issue dialog */}
      <Dialog open={issueOpen} onOpenChange={(o) => { setIssueOpen(o); if (!o) setIssued(null); }}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Issue a certificate</DialogTitle>
            <DialogDescription>
              Certificates can only be issued for enrollments at 100% progress without an existing certificate.
            </DialogDescription>
          </DialogHeader>
          {issued ? (
            <div className="space-y-3 py-2 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300">
                <Trophy className="h-6 w-6" />
              </div>
              <p className="text-sm font-bold">{issued.learnerName} is now certified 🎉</p>
              <p className="font-mono text-xs text-muted-foreground">{issued.serial}</p>
              <Button
                variant="outline"
                className="w-full rounded-xl"
                onClick={() => {
                  void navigator.clipboard.writeText(
                    `${window.location.origin}/verify/certificate/${issued.serial}`
                  );
                  toast({ title: "Verification link copied" });
                }}
              >
                <Copy className="mr-2 h-4 w-4" /> Copy verification link
              </Button>
            </div>
          ) : (
            <>
              <div className="space-y-4 py-1">
                <div className="space-y-1.5">
                  <p className="text-[13px] font-semibold">Completed enrollment</p>
                  {eligible.length === 0 ? (
                    <p className="rounded-xl bg-muted px-3 py-4 text-center text-xs text-muted-foreground">
                      No eligible enrollments — learners must reach 100% progress first.
                    </p>
                  ) : (
                    <Select value={selected} onValueChange={setSelected}>
                      <SelectTrigger className="w-full rounded-xl">
                        <SelectValue placeholder="Select a learner" />
                      </SelectTrigger>
                      <SelectContent>
                        {eligible.map((e) => (
                          <SelectItem key={e.id} value={e.id}>
                            {e.learnerName} — {e.courseTitle}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
                <div className="space-y-1.5">
                  <p className="text-[13px] font-semibold">Grade (optional)</p>
                  <Select value={grade} onValueChange={setGrade}>
                    <SelectTrigger className="w-full rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No grade</SelectItem>
                      <SelectItem value="A">A — Outstanding</SelectItem>
                      <SelectItem value="B">B — Proficient</SelectItem>
                      <SelectItem value="C">C — Satisfactory</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button
                  onClick={handleIssue}
                  disabled={!selected || issuing}
                  className="w-full rounded-xl"
                >
                  {issuing && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
                  Issue certificate
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
