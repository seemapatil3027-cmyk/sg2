"use client";

import { useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const BASE_BTN =
  "inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-border bg-white px-3.5 text-sm font-medium text-ink transition hover:border-brand hover:text-brand disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:border-border disabled:hover:text-ink";

function getPageNumbers(current: number, total: number): (number | "ellipsis")[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const wanted = new Set(
    [1, 2, current - 1, current, current + 1, total - 1, total].filter((p) => p >= 1 && p <= total)
  );
  const sorted = [...wanted].sort((a, b) => a - b);
  const out: (number | "ellipsis")[] = [];
  let prev = 0;
  for (const p of sorted) {
    if (p - prev > 1) out.push("ellipsis");
    out.push(p);
    prev = p;
  }
  return out;
}

export function BlogsPagination({
  currentPage,
  totalPages,
}: {
  currentPage: number;
  totalPages: number;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const goTo = useCallback(
    (page: number) => {
      if (page < 1 || page > totalPages || page === currentPage) return;
      const params = new URLSearchParams(searchParams.toString());
      if (page <= 1) params.delete("page");
      else params.set("page", String(page));
      const qs = params.toString();
      router.push(qs ? `/blogs?${qs}` : "/blogs", { scroll: true });
    },
    [currentPage, router, searchParams, totalPages]
  );

  if (totalPages <= 1) return null;

  const pages = getPageNumbers(currentPage, totalPages);

  return (
    <nav aria-label="Blog pages" className="flex flex-wrap items-center justify-center gap-2">
      <button type="button" className={BASE_BTN} onClick={() => goTo(1)} disabled={currentPage <= 1}>
        First
      </button>
      <button
        type="button"
        className={BASE_BTN}
        onClick={() => goTo(currentPage - 1)}
        disabled={currentPage <= 1}
        aria-label="Previous page"
      >
        <ChevronLeft className="h-4 w-4" />
      </button>

      {pages.map((p, i) =>
        p === "ellipsis" ? (
          <span key={`ellipsis-${i}`} className="px-1 text-sm text-ink-soft" aria-hidden="true">
            …
          </span>
        ) : (
          <button
            key={p}
            type="button"
            onClick={() => goTo(p)}
            aria-current={p === currentPage ? "page" : undefined}
            aria-label={`Go to page ${p}`}
            className={cn(
              BASE_BTN,
              p === currentPage && "border-primary bg-primary text-white hover:bg-brand-dark hover:text-white"
            )}
          >
            {p}
          </button>
        )
      )}

      <button
        type="button"
        className={BASE_BTN}
        onClick={() => goTo(currentPage + 1)}
        disabled={currentPage >= totalPages}
        aria-label="Next page"
      >
        <ChevronRight className="h-4 w-4" />
      </button>
      <button
        type="button"
        className={BASE_BTN}
        onClick={() => goTo(totalPages)}
        disabled={currentPage >= totalPages}
      >
        Last
      </button>
    </nav>
  );
}
