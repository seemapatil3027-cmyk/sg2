import { Award, BookOpen, BriefcaseBusiness, Hammer, MessagesSquare, Trophy } from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";

const STEPS = [
  { n: "01", title: "Learn", desc: "Structured, industry-aligned curriculum", icon: BookOpen },
  { n: "02", title: "Practice", desc: "Real-world projects and simulations", icon: Hammer },
  { n: "03", title: "Get Feedback", desc: "Mentor reviews and assessments", icon: MessagesSquare },
  { n: "04", title: "Build Proof", desc: "Projects, portfolio and certificates", icon: Award },
  { n: "05", title: "Get Career Ready", desc: "Resume + LinkedIn + interview preparation", icon: BriefcaseBusiness },
  { n: "06", title: "Get Hired", desc: "Job matching + placement support", icon: Trophy },
] as const;

export function WhyDifferent() {
  return (
    <Section className="bg-muted/50">
      <SectionHeading
        align="center"
        label="THE SKILLGORILA WAY"
        title="Why SkillGorila is different"
        sub="A career operating system, not just video lectures — six stages that take you from first lesson to offer letter."
      />
      <ol className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {STEPS.map((step) => (
          <li
            key={step.n}
            className="card-lift relative overflow-hidden rounded-2xl border border-border bg-white p-6 shadow-soft hover:border-brand/25 hover:shadow-card"
          >
            <span
              aria-hidden
              className="pointer-events-none absolute -right-2 -top-4 select-none text-[72px] font-black leading-none text-brand-soft"
            >
              {step.n}
            </span>
            <span className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft">
              <step.icon className="h-5 w-5 text-brand" aria-hidden />
            </span>
            <p className="relative mt-4 text-[12px] font-bold uppercase tracking-[0.12em] text-gold">
              Step {step.n}
            </p>
            <h3 className="relative mt-1 text-[18px] font-bold text-ink">{step.title}</h3>
            <p className="relative mt-1.5 text-[13.5px] leading-6 text-ink-soft">{step.desc}</p>
          </li>
        ))}
      </ol>
    </Section>
  );
}
