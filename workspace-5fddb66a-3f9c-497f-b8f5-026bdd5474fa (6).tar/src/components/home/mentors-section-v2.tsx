"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { Mentor } from "@prisma/client";
import { Section, SectionHeading } from "@/components/shared/section";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { cn } from "@/lib/utils";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "data", label: "Data" },
  { key: "ai", label: "AI" },
  { key: "software", label: "Software" },
] as const;

type FilterKey = (typeof FILTERS)[number]["key"];

function mentorCategory(m: Mentor): Exclude<FilterKey, "all"> {
  const r = `${m.role} ${m.ex ?? ""}`.toLowerCase();
  if (/(machine learning|\bml\b|data scient|\bai\b|genai)/.test(r)) return "ai";
  if (/(software|engineer|developer|cto|founder|full.?stack)/.test(r)) return "software";
  return "data";
}

export function MentorsSectionV2({ mentors }: { mentors: Mentor[] }) {
  const [filter, setFilter] = useState<FilterKey>("all");

  const visible = (filter === "all" ? mentors : mentors.filter((m) => mentorCategory(m) === filter)).slice(0, 8);

  return (
    <Section>
      <SectionHeading
        align="center"
        label="MENTORS"
        title="Learn from people doing the work"
        sub="Analysts, data scientists and engineers from companies you know — reviewing your work, not just recording videos."
      />

      {/* filter chips */}
      <div className="mt-7 flex flex-wrap items-center justify-center gap-2" role="tablist" aria-label="Filter mentors by domain">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            type="button"
            role="tab"
            aria-selected={filter === f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "rounded-full border px-5 py-2 text-[13.5px] font-semibold transition",
              filter === f.key
                ? "border-transparent bg-primary text-white shadow-soft"
                : "border-input bg-white text-ink hover:border-brand/40 hover:bg-brand-soft/50"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {visible.map((m) => (
          <div
            key={m.id}
            className="card-lift flex flex-col rounded-2xl border border-border bg-white p-5 shadow-soft hover:border-brand/25 hover:shadow-card"
          >
            <InitialAvatar name={m.name} className="h-14 w-14 text-base" />
            <p className="mt-3.5 text-[15px] font-bold text-ink">{m.name}</p>
            <p className="mt-0.5 text-[12.5px] leading-5 text-ink-soft">{m.role}</p>
            <p className="mt-1 text-[13px] font-semibold text-ink">{m.company}</p>
            {m.ex && <p className="mt-0.5 text-[11.5px] text-muted-foreground">{m.ex}</p>}
            <Link
              href="/tracks"
              className="mt-auto inline-flex items-center gap-1 pt-4 text-[12.5px] font-bold text-brand"
            >
              View Profile
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden />
            </Link>
          </div>
        ))}
      </div>
    </Section>
  );
}
