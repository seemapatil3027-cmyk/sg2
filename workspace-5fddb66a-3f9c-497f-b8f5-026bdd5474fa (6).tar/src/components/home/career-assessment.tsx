"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  ClipboardList,
  Loader2,
  PhoneCall,
  RotateCcw,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import {
  buildAssessmentNote,
  runAssessment,
  type AssessmentAnswers,
  type AssessmentResult,
} from "@/lib/assessment";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Option metadata                                                     */
/* ------------------------------------------------------------------ */

type Education = AssessmentAnswers["education"];
type RoleStatus = AssessmentAnswers["role"];
type Experience = AssessmentAnswers["experience"];
type Salary = AssessmentAnswers["salary"];
type Learning = AssessmentAnswers["learning"];
type Hours = AssessmentAnswers["hours"];

const EDUCATION_OPTIONS: { value: Education; label: string }[] = [
  { value: "school", label: "Still in school" },
  { value: "bachelor", label: "Bachelor's degree" },
  { value: "master", label: "Master's or above" },
  { value: "other", label: "Diploma / Other" },
];

const STATUS_OPTIONS: { value: RoleStatus; label: string }[] = [
  { value: "student", label: "Currently a student" },
  { value: "fresher", label: "Fresher — job hunting" },
  { value: "working", label: "Working professional" },
  { value: "career-gap", label: "On a career break" },
];

const EXPERIENCE_OPTIONS: { value: Experience; label: string }[] = [
  { value: "none", label: "No experience yet" },
  { value: "0-2", label: "0–2 years" },
  { value: "2-5", label: "2–5 years" },
  { value: "5+", label: "5+ years" },
];

const SKILL_OPTIONS: { value: string; label: string }[] = [
  { value: "excel", label: "Excel" },
  { value: "sql", label: "SQL" },
  { value: "python", label: "Python" },
  { value: "powerbi", label: "Power BI" },
  { value: "ml", label: "Machine Learning" },
  { value: "coding", label: "Coding" },
  { value: "genai", label: "Generative AI" },
  { value: "sap", label: "SAP" },
];

const SALARY_OPTIONS: { value: Salary; label: string }[] = [
  { value: "3-6", label: "₹3–6 LPA" },
  { value: "6-12", label: "₹6–12 LPA" },
  { value: "12+", label: "₹12+ LPA" },
];

const LEARNING_OPTIONS: { value: Learning; label: string }[] = [
  { value: "live-online", label: "Live online classes" },
  { value: "self-paced", label: "Self-paced" },
  { value: "classroom", label: "Classroom" },
];

const HOURS_OPTIONS: { value: Hours; label: string }[] = [
  { value: "0-5", label: "0–5 hrs / week" },
  { value: "5-10", label: "5–10 hrs / week" },
  { value: "10-20", label: "10–20 hrs / week" },
  { value: "20+", label: "20+ hrs / week" },
];

const TOTAL_STEPS = 7;

/* ------------------------------------------------------------------ */
/* Local answers state (nullable until each step is answered)          */
/* ------------------------------------------------------------------ */

interface LocalAnswers {
  education: Education | null;
  role: RoleStatus | null;
  experience: Experience | null;
  skills: string[];
  goal: string;
  salary: Salary | null;
  learning: Learning | null;
  hours: Hours | null;
}

const INITIAL_ANSWERS: LocalAnswers = {
  education: null,
  role: null,
  experience: null,
  skills: [],
  goal: "",
  salary: null,
  learning: null,
  hours: null,
};

function toAssessmentAnswers(a: LocalAnswers): AssessmentAnswers {
  return {
    education: a.education ?? "bachelor",
    role: a.role ?? "fresher",
    experience: a.experience ?? "none",
    skills: a.skills,
    goal: a.goal.trim(),
    salary: a.salary ?? "6-12",
    learning: a.learning ?? "live-online",
    hours: a.hours ?? "5-10",
  };
}

/* ------------------------------------------------------------------ */
/* Small presentational helpers                                        */
/* ------------------------------------------------------------------ */

function OptionCard({
  selected,
  label,
  onClick,
}: {
  selected: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={cn(
        "flex items-center justify-between gap-2 rounded-xl border px-4 py-3.5 text-left text-[14px] font-medium transition",
        selected
          ? "border-brand bg-brand-soft text-brand shadow-soft"
          : "border-input bg-white text-ink hover:border-brand/40 hover:bg-brand-soft/40"
      )}
    >
      <span>{label}</span>
      {selected && <CheckCircle2 className="h-4.5 w-4.5 shrink-0" aria-hidden />}
    </button>
  );
}

function ProgressRing({
  value,
  label,
  color,
}: {
  value: number;
  label: string;
  color: string;
}) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div
        role="img"
        aria-label={`${label}: ${value}%`}
        className="relative h-24 w-24 rounded-full sm:h-28 sm:w-28"
        style={{ background: `conic-gradient(${color} ${value}%, #ECE9F4 0)` }}
      >
        <div className="absolute inset-[9px] flex items-center justify-center rounded-full bg-white">
          <span className="text-xl font-bold text-ink sm:text-2xl">{value}%</span>
        </div>
      </div>
      <p className="text-center text-[12.5px] font-semibold leading-tight text-ink-soft">{label}</p>
    </div>
  );
}

function StepHeader({ step, total, title, hint }: { step: number; total: number; title: string; hint?: string }) {
  return (
    <div>
      <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-brand">
        Step {step} of {total}
      </p>
      <h3 className="mt-1.5 text-[19px] font-bold leading-snug text-ink sm:text-[21px]">{title}</h3>
      {hint && <p className="mt-1 text-[13px] text-ink-soft">{hint}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Result view                                                         */
/* ------------------------------------------------------------------ */

function ResultView({
  answers,
  result,
  onRetake,
}: {
  answers: AssessmentAnswers;
  result: AssessmentResult;
  onRetake: () => void;
}) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          phone,
          email,
          source: "assessment",
          itemSlug: result.recommended.slug,
          note: buildAssessmentNote(answers, result),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error || "Something went wrong. Please try again.");
      } else {
        setSubmitted(true);
      }
    } catch {
      setFormError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="animate-pop">
      <div className="flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-soft">
          <Sparkles className="h-4 w-4 text-brand" aria-hidden />
        </span>
        <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-brand">
          Your Recommended Career Path
        </p>
      </div>

      <div className="mt-3 rounded-2xl bg-brand-gradient p-5 text-white shadow-card sm:p-6">
        <h3 className="text-[22px] font-bold leading-tight sm:text-[26px]">{result.recommended.title}</h3>
        <p className="mt-1.5 text-[14px] text-white/85">{result.recommended.tagline}</p>
        <p className="mt-4 text-[13px] leading-6 text-white/80">{result.rationale}</p>
        <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-[12px] font-semibold">
          <TrendingUp className="h-3.5 w-3.5" aria-hidden />
          Also matches: {result.runnerUp.title}
        </div>
      </div>

      {/* Skill gap + readiness */}
      <div className="mt-5 grid grid-cols-2 gap-3 rounded-2xl border border-border bg-white p-5 shadow-soft">
        <ProgressRing value={result.readiness} label="Career readiness today" color="#5d18be" />
        <ProgressRing value={result.skillGap} label="Skill gap this path closes" color="#ffb020" />
      </div>

      {/* Plan */}
      <div className="mt-5">
        <p className="text-[14px] font-bold text-ink">Your step-by-step plan</p>
        <ol className="mt-3 flex flex-col gap-2.5">
          {result.plan.map((step, i) => (
            <li
              key={step}
              className="flex items-start gap-3 rounded-xl border border-border bg-white px-4 py-3 shadow-soft"
            >
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft text-[12px] font-bold text-brand">
                {i + 1}
              </span>
              <span className="text-[13.5px] leading-5 text-ink">{step}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* CTAs */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <Link
          href={`/tracks/${result.recommended.slug}`}
          className="inline-flex h-12 flex-1 items-center justify-center rounded-xl bg-primary px-6 text-[15px] font-semibold text-white shadow-[0_8px_24px_rgba(93,24,190,0.25)] transition hover:bg-brand-dark"
        >
          Start Learning Path
        </Link>
        {!submitted && (
          <button
            type="button"
            onClick={() => setShowForm((v) => !v)}
            className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-brand px-6 text-[15px] font-semibold text-brand transition hover:bg-brand-soft"
          >
            <PhoneCall className="h-4 w-4" aria-hidden />
            Get the full plan on a free call
          </button>
        )}
      </div>

      {/* Lead capture */}
      {showForm && !submitted && (
        <form onSubmit={handleSubmit} className="animate-pop mt-4 flex flex-col gap-3 rounded-2xl border border-border bg-brand-soft/50 p-4" noValidate>
          <p className="text-[13px] font-semibold text-ink">
            Leave your details — a career expert will walk you through the full plan.
          </p>
          <Input
            aria-label="Your name"
            placeholder="Your name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="h-11 rounded-xl border-input bg-white px-4 text-[14px]"
            required
          />
          <Input
            aria-label="Mobile number"
            placeholder="Mobile number"
            type="tel"
            autoComplete="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="h-11 rounded-xl border-input bg-white px-4 text-[14px]"
            required
          />
          <Input
            aria-label="Email address"
            placeholder="Email address"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="h-11 rounded-xl border-input bg-white px-4 text-[14px]"
            required
          />
          {formError && <p className="text-[13px] font-medium text-red-600">{formError}</p>}
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary text-[14px] font-semibold text-white transition hover:bg-brand-dark disabled:opacity-60"
          >
            {submitting && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
            {submitting ? "Sending…" : "Send me the plan"}
          </button>
        </form>
      )}

      {submitted && (
        <div className="animate-pop mt-4 flex items-start gap-3 rounded-2xl bg-[#EAF8F0] p-4">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-600" aria-hidden />
          <p className="text-[14px] font-semibold leading-6 text-green-700">
            Your career plan is on its way — our expert will call within 24 hrs
          </p>
        </div>
      )}

      <button
        type="button"
        onClick={onRetake}
        className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-soft transition hover:text-brand"
      >
        <RotateCcw className="h-3.5 w-3.5" aria-hidden />
        Retake assessment
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main stepper                                                        */
/* ------------------------------------------------------------------ */

export function CareerAssessment({ className }: { className?: string }) {
  const [answers, setAnswers] = useState<LocalAnswers>(INITIAL_ANSWERS);
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);

  const result = useMemo(
    () => (done ? runAssessment(toAssessmentAnswers(answers)) : null),
    [done, answers]
  );

  function canProceed(): boolean {
    switch (step) {
      case 0:
        return answers.education !== null;
      case 1:
        return answers.role !== null;
      case 2:
        return answers.experience !== null;
      case 3:
        return true; // skills optional — beginners skip
      case 4:
        return true; // desired role optional
      case 5:
        return answers.salary !== null;
      case 6:
        return answers.learning !== null && answers.hours !== null;
      default:
        return false;
    }
  }

  function handleNext() {
    if (!canProceed()) return;
    if (step === TOTAL_STEPS - 1) {
      setDone(true);
    } else {
      setStep((s) => Math.min(s + 1, TOTAL_STEPS - 1));
    }
  }

  function handleBack() {
    setStep((s) => Math.max(s - 1, 0));
  }

  function handleRetake() {
    setAnswers(INITIAL_ANSWERS);
    setStep(0);
    setDone(false);
  }

  function toggleSkill(value: string) {
    setAnswers((a) => ({
      ...a,
      skills: a.skills.includes(value)
        ? a.skills.filter((s) => s !== value)
        : [...a.skills, value],
    }));
  }

  const progress = done ? 100 : Math.round((step / TOTAL_STEPS) * 100);

  return (
    <div className={cn("flex flex-col", className)}>
      {/* Progress bar */}
      <div className="mb-5">
        <div className="h-2 w-full overflow-hidden rounded-full bg-brand-soft" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Assessment progress">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand to-brand-light transition-all duration-300"
            style={{ width: `${Math.max(progress, 6)}%` }}
          />
        </div>
      </div>

      {done && result ? (
        <ResultView
          answers={toAssessmentAnswers(answers)}
          result={result}
          onRetake={handleRetake}
        />
      ) : (
        <>
          {step === 0 && (
            <div className="animate-pop">
              <StepHeader step={1} total={TOTAL_STEPS} title="What's your highest education?" />
              <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
                {EDUCATION_OPTIONS.map((o) => (
                  <OptionCard
                    key={o.value}
                    label={o.label}
                    selected={answers.education === o.value}
                    onClick={() => setAnswers((a) => ({ ...a, education: o.value }))}
                  />
                ))}
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="animate-pop">
              <StepHeader step={2} total={TOTAL_STEPS} title="What are you currently doing?" />
              <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
                {STATUS_OPTIONS.map((o) => (
                  <OptionCard
                    key={o.value}
                    label={o.label}
                    selected={answers.role === o.value}
                    onClick={() => setAnswers((a) => ({ ...a, role: o.value }))}
                  />
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-pop">
              <StepHeader step={3} total={TOTAL_STEPS} title="How much work experience do you have?" />
              <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
                {EXPERIENCE_OPTIONS.map((o) => (
                  <OptionCard
                    key={o.value}
                    label={o.label}
                    selected={answers.experience === o.value}
                    onClick={() => setAnswers((a) => ({ ...a, experience: o.value }))}
                  />
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-pop">
              <StepHeader
                step={4}
                total={TOTAL_STEPS}
                title="Which of these skills do you already know?"
                hint="Skip ahead if you're starting from zero."
              />
              <div className="mt-4 flex flex-wrap gap-2">
                {SKILL_OPTIONS.map((o) => {
                  const selected = answers.skills.includes(o.value);
                  return (
                    <button
                      key={o.value}
                      type="button"
                      aria-pressed={selected}
                      onClick={() => toggleSkill(o.value)}
                      className={cn(
                        "rounded-full border px-4 py-2 text-[13.5px] font-semibold transition",
                        selected
                          ? "border-brand bg-brand text-white shadow-soft"
                          : "border-input bg-white text-ink hover:border-brand/40 hover:bg-brand-soft/40"
                      )}
                    >
                      {o.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="animate-pop">
              <StepHeader
                step={5}
                total={TOTAL_STEPS}
                title="What role do you want?"
                hint="Type your dream role — we'll map the path to it."
              />
              <Input
                aria-label="Desired role"
                placeholder="e.g. Data Analyst, AI Engineer, Software Developer"
                autoComplete="off"
                value={answers.goal}
                onChange={(e) => setAnswers((a) => ({ ...a, goal: e.target.value }))}
                className="mt-4 h-12 rounded-xl border-input bg-white px-4 text-[15px]"
              />
            </div>
          )}

          {step === 5 && (
            <div className="animate-pop">
              <StepHeader step={6} total={TOTAL_STEPS} title="What's your salary goal?" />
              <div className="mt-4 grid gap-2.5 sm:grid-cols-3">
                {SALARY_OPTIONS.map((o) => (
                  <OptionCard
                    key={o.value}
                    label={o.label}
                    selected={answers.salary === o.value}
                    onClick={() => setAnswers((a) => ({ ...a, salary: o.value }))}
                  />
                ))}
              </div>
            </div>
          )}

          {step === 6 && (
            <div className="animate-pop">
              <StepHeader step={7} total={TOTAL_STEPS} title="How do you like to learn?" />
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <label className="flex flex-col gap-1.5">
                  <span className="text-[13px] font-semibold text-ink">Learning preference</span>
                  <select
                    aria-label="Learning preference"
                    value={answers.learning ?? ""}
                    onChange={(e) => setAnswers((a) => ({ ...a, learning: e.target.value as Learning }))}
                    className="h-12 w-full rounded-xl border border-input bg-white px-3 text-[14px] text-ink outline-none transition focus:border-brand"
                  >
                    <option value="" disabled>
                      Select…
                    </option>
                    {LEARNING_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex flex-col gap-1.5">
                  <span className="text-[13px] font-semibold text-ink">Weekly study time</span>
                  <select
                    aria-label="Weekly study hours"
                    value={answers.hours ?? ""}
                    onChange={(e) => setAnswers((a) => ({ ...a, hours: e.target.value as Hours }))}
                    className="h-12 w-full rounded-xl border border-input bg-white px-3 text-[14px] text-ink outline-none transition focus:border-brand"
                  >
                    <option value="" disabled>
                      Select…
                    </option>
                    {HOURS_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            </div>
          )}

          {/* Nav buttons */}
          <div className="mt-7 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleBack}
              disabled={step === 0}
              className="inline-flex h-11 items-center gap-1.5 rounded-xl px-4 text-[14px] font-semibold text-ink-soft transition hover:text-brand disabled:pointer-events-none disabled:opacity-0"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden />
              Back
            </button>
            <button
              type="button"
              onClick={handleNext}
              disabled={!canProceed()}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-primary px-6 text-[14px] font-semibold text-white shadow-[0_8px_24px_rgba(93,24,190,0.25)] transition hover:bg-brand-dark disabled:pointer-events-none disabled:opacity-40"
            >
              <ClipboardList className="h-4 w-4" aria-hidden />
              {step === TOTAL_STEPS - 1 ? "See My Result" : "Next"}
              {step < TOTAL_STEPS - 1 && <ArrowRight className="h-4 w-4" aria-hidden />}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Dialog wrapper for the hero CTA                                     */
/* ------------------------------------------------------------------ */

export function AssessmentDialogButton({
  label = "Take Career Assessment",
  className,
}: {
  label?: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {/* Controlled trigger (no DialogTrigger) — Radix wires aria-controls to a
          generated content id that differs between SSR and hydration for
          unmounted content, causing a hydration mismatch. A plain button with
          aria-haspopup/aria-expanded is hydration-safe and screen-reader safe. */}
      <button
        type="button"
        className={className}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen(true)}
      >
        {label}
      </button>
      <DialogContent className="max-h-[90vh] overflow-y-auto rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[18px]">
            <Sparkles className="h-5 w-5 text-brand" aria-hidden />
            Career Assessment
          </DialogTitle>
          <DialogDescription>
            7 quick questions — get your personalised career path instantly. No sign-up needed.
          </DialogDescription>
        </DialogHeader>
        <CareerAssessment />
      </DialogContent>
    </Dialog>
  );
}
