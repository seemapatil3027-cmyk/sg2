import Link from "next/link";
import { ArrowRight, CalendarRange, CheckCircle2, FolderKanban, Radio } from "lucide-react";
import { cn } from "@/lib/utils";

export interface CareerPathCardProps {
  title: string;
  href: string;
  /** Small chip under the title. Defaults to "Beginner → Job Ready". */
  chip?: string;
  chipTone?: "brand" | "gold";
  months?: number;
  projects?: number;
  liveSessions?: number;
  /** Short line for cohorts that are still forming (no hard stats yet). */
  note?: string;
  ctaLabel?: string;
  className?: string;
}

/**
 * Clean career-path card for the homepage — no discount/seats/promo noise.
 */
export function CareerPathCard({
  title,
  href,
  chip = "Beginner → Job Ready",
  chipTone = "brand",
  months,
  projects,
  liveSessions,
  note,
  ctaLabel = "Explore Path",
  className,
}: CareerPathCardProps) {
  const hasStats = typeof months === "number" && typeof projects === "number" && typeof liveSessions === "number";
  return (
    <Link
      href={href}
      className={cn(
        "card-lift group flex flex-col rounded-2xl border border-border bg-white p-5 shadow-soft hover:border-brand/30 hover:shadow-card",
        className
      )}
    >
      <span
        className={cn(
          "inline-flex w-fit items-center rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wide",
          chipTone === "gold" ? "bg-[#FFF6E5] text-[#B37B00]" : "bg-brand-soft text-brand"
        )}
      >
        {chip}
      </span>

      <h3 className="mt-3 text-[17px] font-bold leading-snug text-ink transition-colors group-hover:text-brand">
        {title}
      </h3>

      {note && <p className="mt-2 text-[13px] leading-5 text-ink-soft">{note}</p>}

      {hasStats && (
        <div className="mt-4 grid grid-cols-3 divide-x divide-border rounded-xl bg-muted/60 py-2.5 text-center">
          <div className="px-1">
            <p className="flex items-center justify-center gap-1 text-[13.5px] font-bold text-ink">
              <CalendarRange className="h-3.5 w-3.5 text-brand" aria-hidden />
              {months} Mo
            </p>
            <p className="mt-0.5 text-[10.5px] uppercase tracking-wide text-ink-soft">Duration</p>
          </div>
          <div className="px-1">
            <p className="flex items-center justify-center gap-1 text-[13.5px] font-bold text-ink">
              <FolderKanban className="h-3.5 w-3.5 text-brand" aria-hidden />
              {projects}
            </p>
            <p className="mt-0.5 text-[10.5px] uppercase tracking-wide text-ink-soft">Projects</p>
          </div>
          <div className="px-1">
            <p className="flex items-center justify-center gap-1 text-[13.5px] font-bold text-ink">
              <Radio className="h-3.5 w-3.5 text-brand" aria-hidden />
              {liveSessions}
            </p>
            <p className="mt-0.5 text-[10.5px] uppercase tracking-wide text-ink-soft">Live Sessions</p>
          </div>
        </div>
      )}

      <div className="mt-4 flex items-center gap-4">
        <span className="flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-soft">
          <CheckCircle2 className="h-4 w-4 text-green-600" aria-hidden />
          Mentor support
        </span>
        <span className="flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-soft">
          <CheckCircle2 className="h-4 w-4 text-green-600" aria-hidden />
          Placement support
        </span>
      </div>

      <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-[13.5px] font-bold text-brand">
        {ctaLabel}
        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden />
      </span>
    </Link>
  );
}
