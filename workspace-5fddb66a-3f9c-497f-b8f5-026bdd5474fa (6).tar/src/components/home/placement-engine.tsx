import Link from "next/link";
import {
  BadgeCheck,
  BookOpen,
  ClipboardCheck,
  FileText,
  FolderKanban,
  MessagesSquare,
  Target,
  Trophy,
  Video,
} from "lucide-react";
import { SectionHeading } from "@/components/shared/section";

const STEPS = [
  { label: "Skills", icon: BookOpen },
  { label: "Assessment", icon: ClipboardCheck },
  { label: "Projects", icon: FolderKanban },
  { label: "Resume", icon: FileText },
  { label: "Mock Interview", icon: MessagesSquare },
  { label: "Career Ready", icon: BadgeCheck },
  { label: "Job Matching", icon: Target },
  { label: "Interview", icon: Video },
  { label: "Offer", icon: Trophy },
] as const;

export function PlacementEngine() {
  return (
    <section className="relative overflow-hidden bg-brand-gradient py-14 sm:py-18">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 -top-32 h-[26rem] w-[26rem] rounded-full bg-white/10 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-40 -right-24 h-[28rem] w-[28rem] rounded-full bg-[#9333ea]/40 blur-3xl"
      />

      <div className="container-sv relative">
        <SectionHeading
          dark
          align="center"
          label="PLACEMENT ENGINE"
          title="From learning to hiring — trackable at every step"
        />

        <div className="relative mt-12">
          {/* connector line (desktop) */}
          <div
            aria-hidden
            className="absolute left-[6%] right-[6%] top-7 hidden h-px bg-white/25 lg:block"
          />
          <ol className="relative grid grid-cols-3 gap-x-3 gap-y-8 sm:grid-cols-5 lg:grid-cols-9">
            {STEPS.map((step, i) => (
              <li key={step.label} className="flex flex-col items-center gap-2.5 text-center">
                <span
                  className={`flex h-14 w-14 items-center justify-center rounded-2xl border shadow-elevate ${
                    i === STEPS.length - 1
                      ? "border-gold/60 bg-gold text-ink"
                      : "border-white/25 bg-white/12 text-white"
                  }`}
                >
                  <step.icon className="h-6 w-6" aria-hidden />
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/50">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-[12.5px] font-bold leading-tight text-white">{step.label}</span>
              </li>
            ))}
          </ol>
        </div>

        <p className="mx-auto mt-10 max-w-xl text-center text-[14.5px] leading-7 text-white/80">
          Every step is tracked inside your student dashboard.
        </p>
        <div className="mt-5 flex justify-center">
          <Link
            href="/dashboard"
            className="inline-flex h-12 items-center justify-center rounded-xl bg-white px-7 text-[15px] font-semibold text-brand shadow-elevate transition hover:bg-brand-soft"
          >
            Track It In Your Dashboard
          </Link>
        </div>
      </div>
    </section>
  );
}
