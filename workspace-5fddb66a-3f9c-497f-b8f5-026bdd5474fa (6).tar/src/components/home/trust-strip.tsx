import { Section } from "@/components/shared/section";

const STATS = [
  { value: "6,000+", label: "Learners" },
  { value: "92%", label: "Placement rate*" },
  { value: "300+", label: "Hiring partners" },
  { value: "100+", label: "Industry mentors" },
  { value: "20+", label: "Career domains" },
  { value: "4.8/5", label: "Learner rating" },
];

export function TrustStrip() {
  return (
    <Section className="py-10 sm:py-12">
      <div className="rounded-3xl border border-border bg-white px-6 py-8 shadow-card sm:px-10">
        <p className="text-center text-[12.5px] font-bold uppercase tracking-[0.14em] text-brand">
          SkillGorila by the numbers
        </p>
        <dl className="mt-6 grid grid-cols-2 gap-y-7 sm:grid-cols-3 lg:grid-cols-6">
          {STATS.map((s) => (
            <div key={s.label} className="flex flex-col items-center gap-1 text-center">
              <dd className="text-[24px] font-extrabold leading-none text-gradient-brand sm:text-[27px]">
                {s.value}
              </dd>
              <dt className="text-[12.5px] font-medium text-ink-soft">{s.label}</dt>
            </div>
          ))}
        </dl>
        <p className="mt-7 text-center text-[11.5px] text-muted-foreground">
          *Placement statistics based on eligible students during the stated reporting period.
        </p>
      </div>
    </Section>
  );
}
