import Link from "next/link";
import { ArrowRight, BarChart3, BrainCircuit, Building2 } from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";
import { cn } from "@/lib/utils";

const PROJECTS = [
  {
    title: "E-commerce Sales Intelligence",
    stack: ["SQL", "Python", "Power BI"],
    level: "Intermediate",
    skills: "12 skills",
    icon: BarChart3,
    tone: "brand" as const,
  },
  {
    title: "Customer Churn Prediction",
    stack: ["Python", "ML", "Power BI"],
    level: "Intermediate",
    skills: "10 skills",
    icon: BrainCircuit,
    tone: "brand" as const,
  },
  {
    title: "SAP Procurement Implementation",
    stack: ["SAP MM", "Ariba"],
    level: "Advanced",
    skills: "9 skills",
    icon: Building2,
    tone: "gold" as const,
  },
];

export function ProjectsShowcase() {
  return (
    <Section className="bg-muted/50">
      <SectionHeading
        align="center"
        label="REAL PROJECTS"
        title="Don't just watch. Build."
        sub="Every program ends with portfolio projects modelled on real industry problems — the proof hiring managers actually ask for."
      />

      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {PROJECTS.map((p) => (
          <div
            key={p.title}
            className="card-lift flex flex-col rounded-2xl border border-border bg-white p-6 shadow-soft hover:border-brand/25 hover:shadow-card"
          >
            <span
              className={cn(
                "flex h-12 w-12 items-center justify-center rounded-2xl",
                p.tone === "gold" ? "bg-[#FFF6E5]" : "bg-brand-soft"
              )}
            >
              <p.icon className={cn("h-6 w-6", p.tone === "gold" ? "text-gold" : "text-brand")} aria-hidden />
            </span>
            <h3 className="mt-4 text-[17px] font-bold leading-snug text-ink">{p.title}</h3>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {p.stack.map((s) => (
                <span
                  key={s}
                  className="rounded-full border border-border bg-muted/60 px-2.5 py-1 text-[11.5px] font-semibold text-ink"
                >
                  {s}
                </span>
              ))}
            </div>
            <div className="mt-auto flex items-center justify-between pt-5">
              <span
                className={cn(
                  "rounded-full px-3 py-1 text-[11.5px] font-bold",
                  p.level === "Advanced" ? "bg-accento-soft text-accento" : "bg-[#FFF6E5] text-[#B37B00]"
                )}
              >
                {p.level}
              </span>
              <span className="text-[12.5px] font-semibold text-ink-soft">{p.skills}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 flex justify-center">
        <Link
          href="/courses"
          className="inline-flex h-11 items-center gap-2 rounded-xl border border-brand px-6 text-[14px] font-semibold text-brand transition hover:bg-brand-soft"
        >
          Explore Projects
          <ArrowRight className="h-4 w-4" aria-hidden />
        </Link>
      </div>
    </Section>
  );
}
