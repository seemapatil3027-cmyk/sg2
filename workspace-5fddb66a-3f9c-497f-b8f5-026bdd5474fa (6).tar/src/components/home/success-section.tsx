import Link from "next/link";
import { ArrowRight, ArrowRight as ArrowIcon } from "lucide-react";
import type { PlacedStudent } from "@prisma/client";
import { Section, SectionHeading } from "@/components/shared/section";
import { InitialAvatar } from "@/components/shared/initial-avatar";

export function SuccessSection({ students }: { students: PlacedStudent[] }) {
  // Deterministic: prefer students with a hike stat, then seed order.
  const featured = [...students.filter((s) => s.hike), ...students.filter((s) => !s.hike)].slice(0, 6);

  return (
    <Section className="bg-muted/50">
      <SectionHeading
        align="center"
        label="STUDENT SUCCESS"
        title="Real learners. Real career moves."
        sub="Before and after — see how SkillGorila learners transformed their careers."
      />

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {featured.map((s) => (
          <article
            key={s.id}
            className="card-lift flex flex-col rounded-2xl border border-border bg-white p-5 shadow-soft hover:border-brand/25 hover:shadow-card"
          >
            <div className="flex items-center gap-3">
              <InitialAvatar name={s.name} className="h-11 w-11 text-sm" />
              <div className="min-w-0">
                <p className="truncate text-[15px] font-bold text-ink">{s.name}</p>
                <p className="text-[12px] text-ink-soft">SkillGorila alum</p>
              </div>
              {s.hike && (
                <span className="ml-auto rounded-full bg-[#EAF8F0] px-3 py-1 text-[12.5px] font-extrabold text-green-700">
                  {s.hike}
                </span>
              )}
            </div>

            <div className="mt-4 rounded-xl bg-muted/60 p-3.5">
              <p className="text-[10.5px] font-bold uppercase tracking-[0.12em] text-ink-soft">
                Before · {s.status ?? "Learner"}
              </p>
              <div className="mt-2 flex items-center gap-2.5">
                <ArrowIcon className="h-4 w-4 shrink-0 text-gold" aria-hidden />
                <div className="min-w-0">
                  <p className="truncate text-[14.5px] font-bold leading-tight text-ink">{s.role}</p>
                  <p className="truncate text-[13px] font-semibold text-brand">@ {s.company}</p>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>

      <div className="mt-8 flex justify-center">
        <Link
          href="/success-stories"
          className="inline-flex items-center gap-2 text-[14px] font-bold text-brand transition hover:text-brand-dark"
        >
          Read all success stories
          <ArrowRight className="h-4 w-4" aria-hidden />
        </Link>
      </div>
    </Section>
  );
}
