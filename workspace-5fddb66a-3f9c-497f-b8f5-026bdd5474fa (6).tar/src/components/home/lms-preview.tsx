import Link from "next/link";
import { ArrowRight, CalendarClock, FolderKanban, ListChecks, Trophy, Video } from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";

const SIDE_STATS = [
  { icon: FolderKanban, label: "Projects", value: "7/10" },
  { icon: ListChecks, label: "Assessments", value: "82%" },
  { icon: Trophy, label: "Career Readiness", value: "76%" },
] as const;

export function LmsPreview() {
  return (
    <Section>
      <SectionHeading
        align="center"
        label="STUDENT DASHBOARD"
        title={
          <>
            More than courses.{" "}
            <span className="text-gradient-brand">A learning operating system.</span>
          </>
        }
      />

      {/* Dashboard mockup */}
      <div className="mx-auto mt-10 max-w-[1020px] overflow-hidden rounded-3xl border border-border bg-white shadow-elevate">
        {/* browser chrome */}
        <div className="flex items-center gap-2 border-b border-border bg-muted/60 px-5 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" aria-hidden />
          <span className="h-2.5 w-2.5 rounded-full bg-[#FEBC2E]" aria-hidden />
          <span className="h-2.5 w-2.5 rounded-full bg-[#28C840]" aria-hidden />
          <span className="ml-3 hidden rounded-md bg-white px-3 py-1 text-[11px] font-medium text-ink-soft shadow-soft sm:inline-block">
            app.skillgorila.com/dashboard
          </span>
        </div>

        <div className="grid gap-5 p-5 sm:p-7 lg:grid-cols-[1.35fr_1fr]">
          {/* main column */}
          <div className="rounded-2xl border border-border bg-gradient-to-br from-brand-soft/60 to-white p-5 sm:p-6">
            <p className="text-[18px] font-bold text-ink sm:text-[20px]">Good morning, Rahul 👋</p>
            <p className="mt-0.5 text-[13px] text-ink-soft">Data Analytics Career Track</p>

            <div className="mt-5">
              <div className="flex items-center justify-between text-[12.5px] font-semibold">
                <span className="text-ink">Career Progress</span>
                <span className="text-brand">72%</span>
              </div>
              <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-white">
                <div className="h-full w-[72%] rounded-full bg-gradient-to-r from-brand to-brand-light" />
              </div>
            </div>

            <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-border bg-white p-4 shadow-soft sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wide text-gold">Up next</p>
                <p className="mt-0.5 text-[15px] font-bold text-ink">SQL Window Functions</p>
                <p className="text-[12.5px] text-ink-soft">Module 3 · ~45 mins</p>
              </div>
              <span className="inline-flex h-10 items-center justify-center rounded-xl bg-primary px-5 text-[13px] font-semibold text-white transition hover:bg-brand-dark">
                Continue Learning
              </span>
            </div>
          </div>

          {/* side column */}
          <div className="flex flex-col gap-4">
            <div className="rounded-2xl border border-border bg-white p-4 shadow-soft">
              <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-ink-soft">
                <CalendarClock className="h-4 w-4 text-brand" aria-hidden />
                Upcoming Live Class
              </div>
              <p className="mt-2 text-[14.5px] font-bold text-ink">SQL Interview Workshop</p>
              <p className="text-[12.5px] text-ink-soft">Today · 7:00 PM · Live with mentor</p>
              <span className="mt-3 inline-flex h-9 items-center justify-center gap-1.5 rounded-lg bg-brand-soft px-4 text-[12.5px] font-bold text-brand">
                <Video className="h-3.5 w-3.5" aria-hidden />
                Join Class
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {SIDE_STATS.map((s) => (
                <div key={s.label} className="rounded-2xl border border-border bg-white p-3 text-center shadow-soft">
                  <s.icon className="mx-auto h-4 w-4 text-brand" aria-hidden />
                  <p className="mt-1.5 text-[15px] font-extrabold leading-none text-ink">{s.value}</p>
                  <p className="mt-1 text-[10.5px] leading-tight text-ink-soft">{s.label}</p>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between rounded-2xl border border-[#BFE6CE] bg-[#EAF8F0] p-4">
              <div className="flex items-center gap-2.5">
                <Trophy className="h-5 w-5 text-green-600" aria-hidden />
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wide text-green-700/70">Placement Status</p>
                  <p className="text-[14.5px] font-bold text-green-700">Interview Ready</p>
                </div>
              </div>
              <span className="rounded-full bg-green-600 px-2.5 py-1 text-[10px] font-bold uppercase text-white">
                Active
              </span>
            </div>
          </div>
        </div>
      </div>

      <p className="mx-auto mt-8 max-w-2xl text-center text-[15px] leading-7 text-ink-soft">
        Every SkillGorila student gets a personal learning dashboard — progress, classes, projects
        and placement tracking in one place.
      </p>
      <div className="mt-5 flex justify-center">
        <Link
          href="/dashboard"
          className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-primary px-7 text-[15px] font-semibold text-white shadow-[0_8px_24px_rgba(93,24,190,0.28)] transition hover:bg-brand-dark"
        >
          See it for yourself — Student Login
          <ArrowRight className="h-4 w-4" aria-hidden />
        </Link>
      </div>
    </Section>
  );
}
