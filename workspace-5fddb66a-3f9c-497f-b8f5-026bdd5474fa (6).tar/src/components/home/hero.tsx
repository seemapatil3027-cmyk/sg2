import Link from "next/link";
import {
  BookOpen,
  Building2,
  ClipboardCheck,
  Hammer,
  Handshake,
  Headset,
  LayoutGrid,
  Radio,
  Sparkles,
  Trophy,
  Users,
} from "lucide-react";
import { AssessmentDialogButton } from "@/components/home/career-assessment";

const CHIPS = [
  { label: "Live Learning", icon: Radio },
  { label: "Real Projects", icon: Hammer },
  { label: "Mentor Support", icon: Users },
  { label: "Career Services", icon: Headset },
] as const;

const OS_PHASES = [
  { label: "Learn", desc: "Industry-aligned curriculum", icon: BookOpen },
  { label: "Practice", desc: "Real projects & labs", icon: Hammer },
  { label: "Prove", desc: "Portfolio & certificates", icon: ClipboardCheck },
  { label: "Connect", desc: "Mentors & community", icon: Handshake },
  { label: "Get Hired", desc: "Job matching & placement", icon: Trophy },
] as const;

const FLOAT_CARDS = [
  { stat: "92%", label: "Placement support", icon: Trophy, position: "-left-3 top-8 sm:-left-8", float: true },
  { stat: "300+", label: "Hiring partners", icon: Building2, position: "-right-3 top-1/3 sm:-right-6", float: false },
  { stat: "20+", label: "Career domains", icon: LayoutGrid, position: "-bottom-6 left-6 sm:left-10", float: false },
] as const;

function StatCard({ card, className }: { card: (typeof FLOAT_CARDS)[number]; className?: string }) {
  return (
    <div className={`flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-elevate ${className ?? ""}`}>
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-soft">
        <card.icon className="h-5 w-5 text-brand" aria-hidden />
      </span>
      <div>
        <p className="text-[17px] font-extrabold leading-tight text-ink">{card.stat}</p>
        <p className="text-[11.5px] font-medium text-ink-soft">{card.label}</p>
      </div>
    </div>
  );
}

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-brand-soft/70 via-background to-background">
      {/* dot-grid texture, faded towards the bottom */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-full bg-grid-soft opacity-70 [mask-image:radial-gradient(80%_70%_at_30%_0%,black,transparent)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-brand-light/15 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-24 bottom-0 h-72 w-72 rounded-full bg-gold/10 blur-3xl"
      />

      <div className="container-sv relative grid items-center gap-14 py-12 sm:py-16 lg:grid-cols-[1.04fr_0.96fr] lg:gap-10 lg:py-20">
        {/* LEFT — copy */}
        <div className="relative z-10">
          <span
            className="animate-rise inline-flex items-center gap-2 rounded-full border border-brand/20 bg-white px-4 py-2 text-[12.5px] font-bold uppercase tracking-[0.1em] text-brand shadow-soft"
            style={{ animationDelay: "0ms" }}
          >
            <Sparkles className="h-4 w-4 text-gold" aria-hidden />
            The Career Operating System
          </span>

          <h1
            className="animate-rise mt-6 max-w-[560px] text-[36px] font-extrabold leading-[1.1] tracking-tight text-ink sm:text-[50px]"
            style={{ animationDelay: "80ms" }}
          >
            Build Skills That{" "}
            <span className="text-gradient-brand">Move Your Career</span> Forward
          </h1>

          <p
            className="animate-rise mt-5 max-w-lg text-[16px] leading-7 text-ink-soft sm:text-[17px]"
            style={{ animationDelay: "160ms" }}
          >
            Industry-led programs, real projects, expert mentorship and a structured path from
            learning to employment.
          </p>

          <div
            className="animate-rise mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
            style={{ animationDelay: "240ms" }}
          >
            <Link
              href="/tracks"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-primary px-7 text-[15px] font-semibold text-white shadow-[0_8px_24px_rgba(93,24,190,0.28)] transition hover:bg-brand-dark"
            >
              Explore Career Programs
            </Link>
            <AssessmentDialogButton className="inline-flex h-12 items-center justify-center rounded-xl border border-brand bg-white px-7 text-[15px] font-semibold text-brand shadow-soft transition hover:bg-brand-soft" />
          </div>

          {/* chip row */}
          <ul
            className="animate-rise mt-8 flex flex-wrap items-center gap-x-5 gap-y-3"
            style={{ animationDelay: "320ms" }}
          >
            {CHIPS.map((chip) => (
              <li key={chip.label} className="flex items-center gap-2 text-[13.5px] font-semibold text-ink">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-soft">
                  <chip.icon className="h-3.5 w-3.5 text-brand" aria-hidden />
                </span>
                {chip.label}
              </li>
            ))}
          </ul>
        </div>

        {/* RIGHT — career OS panel with floating stat cards */}
        <div className="relative z-10 mx-auto w-full max-w-[520px] px-2 sm:px-0">
          <div className="relative rounded-[28px] bg-brand-gradient p-6 shadow-elevate sm:p-8">
            <div aria-hidden className="pointer-events-none absolute inset-0 rounded-[28px] bg-grid-soft-light opacity-60" />
            <div className="relative">
              <p className="text-[12px] font-bold uppercase tracking-[0.16em] text-gold">
                One platform · Every step
              </p>
              <div className="mt-5 flex flex-col gap-2.5">
                {OS_PHASES.map((phase, i) => (
                  <div
                    key={phase.label}
                    className="flex items-center gap-3.5 rounded-2xl bg-white/10 px-4 py-3 backdrop-blur-sm"
                  >
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/15">
                      <phase.icon className="h-4.5 w-4.5 text-white" aria-hidden />
                    </span>
                    <div className="min-w-0">
                      <p className="text-[14.5px] font-bold leading-tight text-white">
                        <span className="mr-2 text-gold">{String(i + 1).padStart(2, "0")}</span>
                        {phase.label}
                      </p>
                      <p className="truncate text-[12px] text-white/70">{phase.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* stat cards: static row on mobile, floating stickers on sm+ */}
          <div className="relative z-20 mt-5 flex flex-wrap justify-center gap-3 sm:hidden">
            {FLOAT_CARDS.map((card) => (
              <StatCard key={card.label} card={card} />
            ))}
          </div>
          {FLOAT_CARDS.map((card) => (
            <div
              key={card.label}
              className={`absolute z-20 hidden sm:block ${card.position} ${card.float ? "animate-float" : ""}`}
            >
              <StatCard card={card} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
