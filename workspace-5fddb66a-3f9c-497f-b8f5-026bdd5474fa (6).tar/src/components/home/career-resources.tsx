import Link from "next/link";
import { ArrowRight, Compass, MessagesSquare, Route, TrendingUp } from "lucide-react";
import { Section, SectionHeading } from "@/components/shared/section";
import { cn } from "@/lib/utils";

const RESOURCES = [
  {
    title: "Career Guides",
    desc: "Roadmaps, salary guides and skill deep-dives for modern IT careers.",
    href: "/blogs",
    icon: Compass,
    tone: "brand" as const,
  },
  {
    title: "Interview Prep",
    desc: "Playbooks for SQL, Python, analytics and HR interview rounds.",
    href: "/blogs",
    icon: MessagesSquare,
    tone: "accento" as const,
  },
  {
    title: "Placement Insights",
    desc: "Real placement data — rates, salaries, hikes and hiring trends.",
    href: "/placement-stats",
    icon: TrendingUp,
    tone: "green" as const,
  },
  {
    title: "How We Hire You",
    desc: "Inside our 9-step placement engine — from profile to offer letter.",
    href: "/how-it-works",
    icon: Route,
    tone: "gold" as const,
  },
];

const TONE_STYLES = {
  brand: "bg-brand-soft text-brand",
  accento: "bg-accento-soft text-accento",
  green: "bg-[#EAF8F0] text-green-600",
  gold: "bg-[#FFF6E5] text-gold",
} as const;

export function CareerResources() {
  return (
    <Section className="bg-muted/50">
      <SectionHeading
        align="center"
        label="CAREER RESOURCES"
        title="Career Intelligence"
        sub="Free, practical knowledge to keep you ahead — written by the same mentors who teach our programs."
      />

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {RESOURCES.map((r) => (
          <Link
            key={r.title}
            href={r.href}
            className="card-lift group flex flex-col rounded-2xl border border-border bg-white p-6 shadow-soft hover:border-brand/25 hover:shadow-card"
          >
            <span className={cn("flex h-11 w-11 items-center justify-center rounded-xl", TONE_STYLES[r.tone])}>
              <r.icon className="h-5 w-5" aria-hidden />
            </span>
            <h3 className="mt-4 text-[16.5px] font-bold text-ink transition-colors group-hover:text-brand">
              {r.title}
            </h3>
            <p className="mt-1.5 text-[13px] leading-6 text-ink-soft">{r.desc}</p>
            <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-[13px] font-bold text-brand">
              Open
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden />
            </span>
          </Link>
        ))}
      </div>
    </Section>
  );
}
