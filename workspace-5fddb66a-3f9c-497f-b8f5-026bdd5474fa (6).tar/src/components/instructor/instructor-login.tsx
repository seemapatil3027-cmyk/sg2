"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { GraduationCap, Loader2, LogIn } from "lucide-react";
import { Input } from "@/components/ui/input";
import { notifyUserChanged } from "@/hooks/use-user";

/**
 * Branded instructor sign-in card — shown on /instructor when no session exists.
 * Posts to /api/auth/signin and refreshes the server component on success.
 */
export function InstructorLogin() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (res.status === 401) {
        setError("Invalid credentials");
        return;
      }
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Something went wrong. Please try again.");
        return;
      }
      notifyUserChanged();
      router.refresh();
    } catch {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="w-full max-w-md rounded-3xl border bg-white p-6 shadow-lg sm:p-8">
      <div className="flex flex-col items-center text-center">
        <span
          className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-soft text-brand"
          aria-hidden="true"
        >
          <GraduationCap className="h-7 w-7" />
        </span>
        <h1 className="mt-4 text-2xl font-bold text-ink">Instructor sign in</h1>
        <p className="mt-1 text-sm text-ink-soft">
          Access the SkillGorila teaching console
        </p>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
        <div>
          <label htmlFor="instructor-email" className="mb-1.5 block text-sm font-medium text-ink">
            Email
          </label>
          <Input
            id="instructor-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@skillgorila.com"
            autoComplete="email"
            required
            className="h-12 rounded-xl"
          />
        </div>
        <div>
          <label htmlFor="instructor-password" className="mb-1.5 block text-sm font-medium text-ink">
            Password
          </label>
          <Input
            id="instructor-password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            autoComplete="current-password"
            required
            minLength={6}
            className="h-12 rounded-xl"
          />
        </div>

        {error && (
          <p role="alert" className="text-sm font-medium text-red-600">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-primary text-[15px] font-semibold text-white transition hover:bg-brand-dark disabled:opacity-60"
        >
          {submitting ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
          ) : (
            <LogIn className="h-4 w-4" aria-hidden="true" />
          )}
          {submitting ? "Signing in…" : "Sign in"}
        </button>
      </form>

      <p className="mt-5 rounded-xl bg-brand-soft px-4 py-3 text-center text-xs leading-5 text-ink-soft">
        Demo instructor account —{" "}
        <span className="font-semibold text-brand">instructor@skillgorila.com</span>
      </p>
    </div>
  );
}
