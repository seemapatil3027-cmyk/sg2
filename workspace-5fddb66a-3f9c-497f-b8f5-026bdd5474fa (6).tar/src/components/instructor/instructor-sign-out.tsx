"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { notifyUserChanged } from "@/hooks/use-user";

/**
 * Sign-out button used across the instructor console (header + access-denied card).
 * Posts /api/auth/signout, then refreshes the server component.
 */
export function InstructorSignOut({
  label = "Sign out",
  className,
}: {
  label?: string;
  className?: string;
}) {
  const router = useRouter();
  const [signingOut, setSigningOut] = useState(false);

  async function handleSignOut() {
    setSigningOut(true);
    try {
      await fetch("/api/auth/signout", { method: "POST" });
      notifyUserChanged();
      router.refresh();
    } finally {
      setSigningOut(false);
    }
  }

  return (
    <Button
      type="button"
      variant="outline"
      onClick={handleSignOut}
      disabled={signingOut}
      aria-label="Sign out of SkillGorila"
      className={
        className ??
        "h-11 rounded-xl border-border font-semibold text-ink hover:border-brand hover:text-brand"
      }
    >
      {signingOut ? (
        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
      ) : (
        <LogOut className="h-4 w-4" aria-hidden="true" />
      )}
      {signingOut ? "Signing out…" : label}
    </Button>
  );
}
