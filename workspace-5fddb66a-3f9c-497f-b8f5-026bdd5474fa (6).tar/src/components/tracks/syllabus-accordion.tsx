"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import type { SyllabusItem } from "@/lib/data";
import { cn } from "@/lib/utils";

/** Track syllabus accordion — "Course n" header with weeks pill, tag chips when open */
export function SyllabusAccordion({
  items,
  className,
}: {
  items: SyllabusItem[];
  className?: string;
}) {
  if (!items.length) return null;
  return (
    <Accordion
      type="single"
      collapsible
      defaultValue="module-0"
      className={cn("flex flex-col gap-4", className)}
    >
      {items.map((item, i) => (
        <AccordionItem
          key={`${item.title}-${i}`}
          value={`module-${i}`}
          className="rounded-2xl border border-border bg-white px-5 transition-shadow data-[state=open]:shadow-[0_8px_24px_rgba(34,28,51,0.07)] sm:px-6"
        >
          <AccordionTrigger className="py-5 hover:no-underline">
            <span className="flex flex-1 flex-wrap items-center justify-between gap-x-4 gap-y-2 pr-2 text-left">
              <span className="min-w-0">
                <span className="block text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-soft">
                  Course {i + 1}
                </span>
                <span className="mt-1 block text-[16px] font-bold leading-snug text-ink sm:text-[17px]">
                  {item.title}
                </span>
              </span>
              <span className="inline-flex shrink-0 items-center rounded-full bg-brand-soft px-3.5 py-1.5 text-[12.5px] font-semibold text-brand">
                {item.weeks} Weeks
              </span>
            </span>
          </AccordionTrigger>
          <AccordionContent className="pb-6">
            <div className="flex flex-wrap gap-2">
              {item.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-border px-3.5 py-1.5 text-[12.5px] font-medium text-ink-soft transition hover:border-brand hover:text-brand"
                >
                  {tag}
                </span>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
