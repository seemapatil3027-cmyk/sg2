"use client";

import { FolderKanban } from "lucide-react";
import type { ProjectItem } from "@/lib/data";

/** Infinite marquee of project / case-study cards (doubled array + animate-marquee-slow) */
export function ProjectsMarquee({ projects }: { projects: ProjectItem[] }) {
  if (!projects.length) return null;
  const doubled = [...projects, ...projects];
  return (
    <div className="marquee-paused relative overflow-hidden">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-background to-transparent" />
      <div className="animate-marquee-slow flex w-max gap-6 py-2">
        {doubled.map((p, i) => (
          <article
            key={`${p.title}-${i}`}
            aria-hidden={i >= projects.length}
            className="w-[300px] shrink-0 rounded-2xl bg-brand-soft p-6 transition hover:shadow-[0_12px_32px_rgba(93,24,190,0.14)] sm:w-[360px]"
          >
            <div
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white"
              aria-hidden
            >
              <FolderKanban className="h-5 w-5 text-brand" />
            </div>
            <h3 className="mt-4 text-[16px] font-bold leading-snug text-ink">{p.title}</h3>
            <p className="clamp-3 mt-2 text-[13.5px] leading-5.5 text-ink-soft">{p.description}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
