"use client";

import { useMemo, useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { CONTACT_LIFECYCLES } from "@/lib/crm-status";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { StatusBadge } from "@/components/platform/status-badge";
import { CreateButton } from "@/components/platform/states";
import { DataTable, type Column } from "@/components/platform/data-table";
import { Timeline } from "@/components/platform/flow";
import { Progress } from "@/components/ui/progress";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  GraduationCap,
  Award,
  Target,
  Building2,
  Pencil,
  Trash2,
  Loader2,
} from "lucide-react";
import {
  ConfirmDialog,
  Field,
  InitialsAvatar,
  LogActivityDialog,
  SheetSection,
  TextBadge,
  useOrgsBasic,
  useUsersBasic,
} from "@/components/crm/crm-shared";

/* ── Types ────────────────────────────────────────────────────────────────── */

interface ContactRow {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  title: string | null;
  organizationId: string | null;
  ownerId: string | null;
  source: string | null;
  status: string;
  lifecycle: string;
  city: string | null;
  notes: string | null;
  leadId: string | null;
  createdAt: string;
  organizationName: string | null;
  ownerName: string | null;
  enrollmentCount: number;
}

interface EnrollmentRow {
  id: string;
  courseId: string | null;
  courseTitle: string;
  batchName: string | null;
  status: string;
  progress: number;
  enrolledAt: string;
}

interface CertificateRow {
  id: string;
  serial: string;
  courseTitle: string;
  grade: string | null;
  issuedAt: string;
}

interface ContactDetail {
  contact: ContactRow;
  organization: { id: string; name: string; domain: string; industry: string } | null;
  owner: { id: string; name: string; email: string } | null;
  enrollments: EnrollmentRow[];
  certificates: CertificateRow[];
  deals: { id: string; title: string; value: number; stage: string; status: string }[];
  activities: {
    id: string;
    type: string;
    subject: string;
    detail: string | null;
    status: string | null;
    dueAt: string | null;
    createdAt: string;
    createdBy: string | null;
  }[];
}

export function ContactsClient() {
  const { can } = useUser();
  const canManage = can("crm.contacts.manage");
  const list = useApi<{ items: ContactRow[]; total: number }>("/api/crm/contacts?pageSize=500&sort=createdAt&dir=desc");

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ContactRow | null>(null);
  const [lifecycleFilter, setLifecycleFilter] = useState("all");

  const rows = useMemo(() => {
    let out = list.data?.items ?? [];
    if (lifecycleFilter !== "all") out = out.filter((c) => c.lifecycle === lifecycleFilter);
    return out;
  }, [list.data, lifecycleFilter]);

  const items = list.data?.items ?? [];
  const customers = items.filter((c) => c.lifecycle === "CUSTOMER").length;
  const totalEnrollments = items.reduce((s, c) => s + c.enrollmentCount, 0);

  const columns: Column<ContactRow>[] = [
    {
      key: "name",
      header: "Contact",
      sortable: true,
      render: (c) => (
        <div className="min-w-0">
          <p className="truncate font-semibold text-foreground">{c.name}</p>
          <p className="truncate text-xs text-muted-foreground">{c.title ?? "—"}</p>
        </div>
      ),
    },
    {
      key: "email",
      header: "Email",
      render: (c) => <span className="block max-w-48 truncate text-muted-foreground">{c.email ?? "—"}</span>,
    },
    { key: "phone", header: "Phone", render: (c) => <span className="whitespace-nowrap text-muted-foreground">{c.phone ?? "—"}</span> },
    {
      key: "organizationName",
      header: "Organization",
      render: (c) => <span className="block max-w-40 truncate text-muted-foreground">{c.organizationName ?? "—"}</span>,
    },
    { key: "lifecycle", header: "Lifecycle", render: (c) => <StatusBadge value={c.lifecycle} /> },
    { key: "enrollmentCount", header: "Enrollments", sortable: true, render: (c) => <span className="font-semibold tabular-nums">{c.enrollmentCount}</span> },
    {
      key: "owner",
      header: "Owner",
      render: (c) =>
        c.ownerName ? (
          <span className="flex items-center gap-2">
            <InitialsAvatar name={c.ownerName} />
            <span className="truncate text-[13px]">{c.ownerName}</span>
          </span>
        ) : (
          <span className="text-xs italic text-muted-foreground">Unassigned</span>
        ),
    },
    {
      key: "createdAt",
      header: "Created",
      sortable: true,
      render: (c) => <span className="whitespace-nowrap text-muted-foreground">{fmt.date(c.createdAt)}</span>,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Contacts"
        description="Customer directory with live LMS enrollments, progress and certificates."
        actions={
          canManage ? (
            <CreateButton
              label="New contact"
              onClick={() => {
                setEditing(null);
                setFormOpen(true);
              }}
            />
          ) : null
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total contacts" value={items.length} icon={Users} tone="brand" />
        <StatCard label="Customers" value={customers} icon={Target} tone="green" />
        <StatCard label="LMS enrollments" value={totalEnrollments} icon={GraduationCap} tone="orange" />
        <StatCard
          label="Organizations"
          value={new Set(items.map((c) => c.organizationId).filter(Boolean)).size}
          icon={Building2}
          tone="amber"
        />
      </div>

      <DataTable<ContactRow>
        columns={columns}
        rows={rows}
        loading={list.loading}
        error={list.error}
        onRetry={list.refetch}
        rowKey={(c) => c.id}
        onRowClick={(c) => setSelectedId(c.id)}
        searchPlaceholder="Search contacts…"
        pageSize={10}
        emptyTitle="No contacts yet"
        emptyHint={canManage ? "Convert a lead or add a contact manually." : "Contacts assigned to you will appear here."}
        filterFn={(c, q) =>
          [c.name, c.email, c.phone, c.organizationName, c.title]
            .filter(Boolean)
            .some((v) => String(v).toLowerCase().includes(q))
        }
        toolbar={
          <Select value={lifecycleFilter} onValueChange={setLifecycleFilter}>
            <SelectTrigger className="h-9 w-40 rounded-xl" aria-label="Filter by lifecycle">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All lifecycles</SelectItem>
              {CONTACT_LIFECYCLES.map((l) => (
                <SelectItem key={l} value={l}>
                  {l}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        }
      />

      <ContactSheet
        contactId={selectedId}
        canManage={canManage}
        onOpenChange={(open) => !open && setSelectedId(null)}
        onChanged={list.refetch}
        onEdit={(contact) => {
          setEditing(contact);
          setFormOpen(true);
        }}
      />

      <ContactFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        contact={editing}
        onSaved={list.refetch}
      />
    </div>
  );
}

/* ── Contact detail sheet (CRM ↔ LMS integration view) ───────────────────── */

function ContactSheet({
  contactId,
  canManage,
  onOpenChange,
  onChanged,
  onEdit,
}: {
  contactId: string | null;
  canManage: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
  onEdit: (contact: ContactRow) => void;
}) {
  const { toast } = useToast();
  const detail = useApi<ContactDetail>(contactId ? `/api/crm/contacts/${contactId}` : null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [logOpen, setLogOpen] = useState(false);
  const [deletePending, setDeletePending] = useState(false);

  const contact = detail.data?.contact ?? null;

  async function remove() {
    if (!contact) return;
    setDeletePending(true);
    try {
      await api.delete(`/api/crm/contacts/${contact.id}`);
      toast({ title: "Contact deleted" });
      setDeleteOpen(false);
      onOpenChange(false);
      onChanged();
    } catch (e) {
      toast({
        title: "Delete failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setDeletePending(false);
    }
  }

  return (
    <Sheet open={!!contactId} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full overflow-y-auto p-0 sm:max-w-xl">
        {detail.loading && !contact ? (
          <div className="space-y-3 p-6">
          <SheetTitle className="sr-only">Contact details</SheetTitle>
            <Skeleton className="h-8 w-2/3" />
            <Skeleton className="h-24 w-full rounded-2xl" />
            <Skeleton className="h-40 w-full rounded-2xl" />
          </div>
        ) : detail.error ? (
          <div className="p-6 text-sm text-destructive">{detail.error}</div>
        ) : contact ? (
          <div className="space-y-6 p-6">
            <SheetHeader className="p-0">
              <div className="flex items-start gap-3">
                <InitialsAvatar name={contact.name} className="h-11 w-11 text-sm" />
                <div className="min-w-0 flex-1">
                  <SheetTitle className="text-lg font-bold leading-tight">{contact.name}</SheetTitle>
                  <SheetDescription className="mt-0.5 text-xs">
                    {contact.title ?? "—"}
                    {detail.data?.organization ? ` · ${detail.data.organization.name}` : ""}
                  </SheetDescription>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <StatusBadge value={contact.lifecycle} />
                    <StatusBadge value={contact.status} />
                  </div>
                </div>
                {canManage ? (
                  <div className="flex shrink-0 flex-col gap-1.5">
                    <Button variant="outline" size="sm" className="rounded-xl" onClick={() => onEdit(contact)}>
                      <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="rounded-xl text-destructive hover:text-destructive"
                      onClick={() => setDeleteOpen(true)}
                    >
                      <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete
                    </Button>
                  </div>
                ) : null}
              </div>
            </SheetHeader>

            {/* Profile */}
            <SheetSection title="Profile">
              <div className="grid grid-cols-2 gap-x-4 gap-y-3 rounded-2xl border bg-card p-4 text-[13px] sm:grid-cols-3">
                <ProfileItem label="Email" value={contact.email} />
                <ProfileItem label="Phone" value={contact.phone} />
                <ProfileItem label="Organization" value={detail.data?.organization?.name ?? null} />
                <ProfileItem label="City" value={contact.city} />
                <ProfileItem label="Source" value={contact.source} />
                <ProfileItem label="Owner" value={detail.data?.owner?.name ?? null} />
                <ProfileItem label="Created" value={fmt.date(contact.createdAt)} />
              </div>
              {contact.notes ? (
                <div className="rounded-2xl border bg-muted/40 p-4 text-[13px] leading-relaxed text-muted-foreground">
                  {contact.notes}
                </div>
              ) : null}
            </SheetSection>

            {/* LMS integration panel */}
            <SheetSection
              title="LMS learning"
              action={<TextBadge>{detail.data?.enrollments.length ?? 0} enrollment(s)</TextBadge>}
            >
              <div className="space-y-2.5">
                {(detail.data?.enrollments ?? []).length === 0 ? (
                  <p className="rounded-2xl border border-dashed p-4 text-center text-xs text-muted-foreground">
                    No enrollments yet — convert a lead with &ldquo;Enroll in course&rdquo; to see learning data here.
                  </p>
                ) : (
                  (detail.data?.enrollments ?? []).map((e) => (
                    <div key={e.id} className="rounded-2xl border bg-card p-3.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="flex min-w-0 items-center gap-2 text-[13px] font-semibold text-foreground">
                          <GraduationCap className="h-4 w-4 shrink-0 text-brand dark:text-violet-300" />
                          <span className="truncate">{e.courseTitle}</span>
                        </p>
                        <div className="flex items-center gap-1.5">
                          {e.batchName ? <TextBadge>{e.batchName}</TextBadge> : null}
                          <StatusBadge value={e.status} />
                        </div>
                      </div>
                      <div className="mt-2.5 flex items-center gap-3">
                        <Progress value={e.progress} className="h-1.5 flex-1" />
                        <span className="text-xs font-semibold tabular-nums text-muted-foreground">{e.progress}%</span>
                      </div>
                      <p className="mt-1.5 text-[11px] text-muted-foreground">
                        Enrolled {fmt.date(e.enrolledAt)}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {(detail.data?.certificates ?? []).length > 0 ? (
                <div className="space-y-2 rounded-2xl border border-amber-200 bg-amber-50/60 p-3.5 dark:border-amber-500/30 dark:bg-amber-500/10">
                  <p className="flex items-center gap-2 text-[13px] font-semibold text-foreground">
                    <Award className="h-4 w-4 text-amber-500" /> Certificates
                  </p>
                  {(detail.data?.certificates ?? []).map((cert) => (
                    <div key={cert.id} className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-semibold text-foreground">{cert.courseTitle}</span>
                      <span className="flex items-center gap-2 text-muted-foreground">
                        {cert.grade ? <TextBadge>Grade {cert.grade}</TextBadge> : null}
                        <TextBadge className="font-mono">{cert.serial}</TextBadge>
                        <span>{fmt.date(cert.issuedAt)}</span>
                      </span>
                    </div>
                  ))}
                </div>
              ) : null}
            </SheetSection>

            {/* Deals */}
            <SheetSection title={`Deals (${detail.data?.deals.length ?? 0})`}>
              {(detail.data?.deals ?? []).length === 0 ? (
                <p className="rounded-2xl border border-dashed p-4 text-center text-xs text-muted-foreground">
                  No deals linked to this contact.
                </p>
              ) : (
                <div className="space-y-2">
                  {(detail.data?.deals ?? []).map((d) => (
                    <div key={d.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-card px-3.5 py-2.5">
                      <p className="min-w-0 truncate text-[13px] font-semibold text-foreground">{d.title}</p>
                      <span className="flex items-center gap-2">
                        <span className="text-[13px] font-bold text-brand dark:text-violet-300">{fmt.inrCompact(d.value)}</span>
                        <StatusBadge value={d.stage} />
                        <StatusBadge value={d.status} />
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </SheetSection>

            {canManage ? (
              <Button variant="outline" className="rounded-xl" onClick={() => setLogOpen(true)}>
                Log activity
              </Button>
            ) : null}

            <SheetSection title={`Timeline (${detail.data?.activities.length ?? 0})`}>
              {detail.loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-14 w-full rounded-xl" />
                  ))}
                </div>
              ) : (
                <Timeline
                  items={(detail.data?.activities ?? []).map((a) => ({
                    id: a.id,
                    type: a.type,
                    subject: a.subject,
                    detail: a.detail,
                    status: a.status,
                    createdAt: a.createdAt,
                    actor: a.createdBy,
                    dueAt: a.dueAt,
                  }))}
                />
              )}
            </SheetSection>

            {contact ? (
              <>
                <LogActivityDialog
                  open={logOpen}
                  onOpenChange={setLogOpen}
                  links={{ contactId: contact.id, organizationId: contact.organizationId }}
                  defaultOwnerId={contact.ownerId}
                  onLogged={() => {
                    detail.refetch();
                    onChanged();
                  }}
                />
                <ConfirmDialog
                  open={deleteOpen}
                  onOpenChange={setDeleteOpen}
                  title="Delete this contact?"
                  description={`"${contact.name}" and their activity history will be permanently removed.`}
                  loading={deletePending}
                  onConfirm={remove}
                />
              </>
            ) : null}
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

function ProfileItem({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="min-w-0">
      <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-0.5 truncate font-medium text-foreground" title={value ?? undefined}>
        {value || "—"}
      </p>
    </div>
  );
}

/* ── New / edit contact dialog ────────────────────────────────────────────── */

function ContactFormDialog({
  open,
  onOpenChange,
  contact,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contact: ContactRow | null;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const { orgs } = useOrgsBasic();
  const { users } = useUsersBasic();
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);
  const [initedFor, setInitedFor] = useState<string | null>(null);

  function blank() {
    return {
      name: "",
      email: "",
      phone: "",
      title: "",
      organizationId: "",
      ownerId: "",
      source: "website",
      lifecycle: "CONTACT",
      status: "ACTIVE",
      city: "",
      notes: "",
    };
  }

  if (open && initedFor !== (contact?.id ?? "new")) {
    setInitedFor(contact?.id ?? "new");
    if (contact) {
      setForm({
        name: contact.name,
        email: contact.email ?? "",
        phone: contact.phone ?? "",
        title: contact.title ?? "",
        organizationId: contact.organizationId ?? "",
        ownerId: contact.ownerId ?? "",
        source: contact.source ?? "website",
        lifecycle: contact.lifecycle,
        status: contact.status,
        city: contact.city ?? "",
        notes: contact.notes ?? "",
      });
    } else {
      setForm(blank());
    }
  }
  if (!open && initedFor) setInitedFor(null);

  const set = (key: keyof ReturnType<typeof blank>) => (v: string) => setForm((f) => ({ ...f, [key]: v }));

  async function submit() {
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        email: form.email.trim() || null,
        phone: form.phone.trim() || null,
        title: form.title.trim() || null,
        organizationId: form.organizationId || null,
        ownerId: form.ownerId || null,
        source: form.source,
        lifecycle: form.lifecycle,
        status: form.status,
        city: form.city.trim() || null,
        notes: form.notes.trim() || null,
      };
      if (contact) {
        await api.patch(`/api/crm/contacts/${contact.id}`, payload);
        toast({ title: "Contact updated" });
      } else {
        await api.post("/api/crm/contacts", payload);
        toast({ title: "Contact created", description: payload.name });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({
        title: contact ? "Update failed" : "Could not create contact",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{contact ? `Edit ${contact.name}` : "New contact"}</DialogTitle>
          <DialogDescription>
            {contact ? "Update the customer profile." : "Add a customer or prospect to the book of business."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Full name">
            <Input value={form.name} onChange={(e) => set("name")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Job title">
            <Input value={form.title} onChange={(e) => set("title")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Email">
            <Input type="email" value={form.email} onChange={(e) => set("email")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => set("phone")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Organization">
            <Select value={form.organizationId} onValueChange={set("organizationId")}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue placeholder="No organization" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">No organization</SelectItem>
                {orgs.map((o) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="City">
            <Input value={form.city} onChange={(e) => set("city")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Lifecycle">
            <Select value={form.lifecycle} onValueChange={set("lifecycle")}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CONTACT_LIFECYCLES.map((l) => (
                  <SelectItem key={l} value={l}>
                    {l}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Status">
            <Select value={form.status} onValueChange={set("status")}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                <SelectItem value="INACTIVE">INACTIVE</SelectItem>
                <SelectItem value="CHURNED">CHURNED</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Owner" className="sm:col-span-2">
            <Select value={form.ownerId} onValueChange={(v) => set("ownerId")(v === "" ? "" : v)}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue placeholder="Unassigned" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">Unassigned</SelectItem>
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={form.notes} onChange={(e) => set("notes")(e.target.value)} className="min-h-20 rounded-xl" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {contact ? "Save changes" : "Create contact"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
