"use client";

import { useEffect, useMemo, useState } from "react";
import { api, useApi } from "@/lib/api-client";
import { initialsOf } from "@/lib/crm-status";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ListChecks } from "lucide-react";
import { ACTIVITY_PRIORITIES, ACTIVITY_TYPES } from "@/lib/crm-status";

/* ── Shared types for CRM picker feeds ───────────────────────────────────── */

export interface BasicUser {
  id: string;
  name: string;
  email: string;
  role: string;
}
export interface BasicCourse {
  id: string;
  title: string;
  slug: string;
  status: string;
}
export interface BasicOrg {
  id: string;
  name: string;
}
export interface BasicContact {
  id: string;
  name: string;
  email: string | null;
}

/** Staff directory for owner/assignment pickers (cached per session). */
export function useUsersBasic() {
  const { data, loading, error } = useApi<{ items: BasicUser[] }>("/api/platform/users/basic");
  const users = useMemo(() => data?.items ?? [], [data]);
  return { users, loading, error };
}

export function useCoursesBasic() {
  const { data, loading, error } = useApi<{ items: BasicCourse[] }>("/api/platform/courses/basic");
  const courses = useMemo(() => data?.items ?? [], [data]);
  return { courses, loading, error };
}

export function useOrgsBasic() {
  const { data, loading, error } = useApi<{ items: BasicOrg[] }>("/api/crm/organizations?basic=1");
  const orgs = useMemo(() => data?.items ?? [], [data]);
  return { orgs, loading, error };
}

export function useContactsBasic() {
  const { data, loading, error } = useApi<{ items: BasicContact[] }>("/api/crm/contacts?basic=1");
  const contacts = useMemo(() => data?.items ?? [], [data]);
  return { contacts, loading, error };
}

/* ── Tiny visual primitives ──────────────────────────────────────────────── */

const AVATAR_TONES = [
  "bg-brand text-white",
  "bg-emerald-600 text-white",
  "bg-orange-500 text-white",
  "bg-amber-500 text-white",
  "bg-rose-500 text-white",
  "bg-teal-600 text-white",
];

export function InitialsAvatar({ name, className }: { name?: string | null; className?: string }) {
  const tone = AVATAR_TONES[(name ?? "?").charCodeAt(0) % AVATAR_TONES.length];
  return (
    <span
      className={cn(
        "inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-bold",
        tone,
        className
      )}
      aria-hidden="true"
    >
      {initialsOf(name)}
    </span>
  );
}

/** Mini score indicator: 0-100 with a colored progress bar. */
export function ScoreBar({ score, className }: { score: number; className?: string }) {
  const tone = score >= 75 ? "bg-emerald-500" : score >= 40 ? "bg-amber-500" : "bg-rose-400";
  const clamped = Math.min(100, Math.max(0, score));
  return (
    <div className={cn("flex min-w-24 items-center gap-2", className)}>
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted" role="presentation">
        <div
          className={cn("h-full rounded-full transition-all", tone)}
          style={{ width: `${clamped}%` }}
        />
      </div>
      <span className="text-xs font-semibold tabular-nums text-muted-foreground">{score}</span>
    </div>
  );
}

/** Small labelled field block used inside CRM forms. */
export function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

/** Small muted inline badge (linked records, meta chips). */
export function TextBadge({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex max-w-full items-center truncate rounded-md border bg-muted/50 px-1.5 py-0.5 text-[11px] text-muted-foreground",
        className
      )}
    >
      {children}
    </span>
  );
}

/** Linked-record chip shown in activity rows / reports. */
export function LinkChip({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <TextBadge>
      {label}: <span className="font-semibold">{value}</span>
    </TextBadge>
  );
}

/* ── ConfirmDialog — destructive action guard (AlertDialog) ──────────────── */

export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = "Delete",
  loading,
  onConfirm,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  confirmLabel?: string;
  loading?: boolean;
  onConfirm: () => void;
}) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="bg-destructive text-white hover:bg-destructive/90"
            disabled={loading}
            onClick={(e) => {
              e.preventDefault();
              onConfirm();
            }}
          >
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

/* ── UserSelect — owner / assignee picker ────────────────────────────────── */

export function UserSelect({
  value,
  onChange,
  allowUnassigned = true,
  placeholder = "Select owner",
  disabled,
  className,
  ariaLabel,
}: {
  value: string | null;
  onChange: (userId: string | null) => void;
  allowUnassigned?: boolean;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  ariaLabel?: string;
}) {
  const { users, loading } = useUsersBasic();
  return (
    <Select
      value={value ?? "__none"}
      onValueChange={(v) => onChange(v === "__none" ? null : v)}
      disabled={disabled || loading}
    >
      <SelectTrigger className={cn("h-9 rounded-xl", className)} aria-label={ariaLabel ?? placeholder}>
        {loading ? (
          <span className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading…
          </span>
        ) : (
          <SelectValue placeholder={placeholder} />
        )}
      </SelectTrigger>
      <SelectContent>
        {allowUnassigned ? <SelectItem value="__none">Unassigned</SelectItem> : null}
        {users.map((u) => (
          <SelectItem key={u.id} value={u.id}>
            {u.name}
            <span className="ml-1.5 text-[10px] text-muted-foreground">{u.role.replace("_", " ")}</span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/* ── LogActivityDialog — quick activity logger ───────────────────────────── */

export interface ActivityLinks {
  leadId?: string | null;
  contactId?: string | null;
  dealId?: string | null;
  organizationId?: string | null;
}

export function LogActivityDialog({
  open,
  onOpenChange,
  links,
  defaultOwnerId = null,
  onLogged,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  links: ActivityLinks;
  defaultOwnerId?: string | null;
  onLogged: () => void;
}) {
  const { toast } = useToast();
  const { users } = useUsersBasic();
  const [type, setType] = useState<string>("CALL");
  const [subject, setSubject] = useState("");
  const [detail, setDetail] = useState("");
  const [dueAt, setDueAt] = useState("");
  const [priority, setPriority] = useState<string>("MEDIUM");
  const [ownerId, setOwnerId] = useState<string>(defaultOwnerId ?? "__none");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setType("CALL");
      setSubject("");
      setDetail("");
      setDueAt("");
      setPriority("MEDIUM");
      setOwnerId(defaultOwnerId ?? "__none");
    }
  }, [open, defaultOwnerId]);

  async function submit() {
    if (subject.trim().length < 2) {
      toast({ title: "Subject is required", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.post("/api/crm/activities", {
        type,
        subject: subject.trim(),
        detail: detail.trim() || null,
        dueAt: dueAt || null,
        priority,
        ownerId: ownerId === "__none" ? null : ownerId,
        ...links,
      });
      toast({ title: "Activity logged", description: subject.trim() });
      onOpenChange(false);
      onLogged();
    } catch (e) {
      toast({
        title: "Could not log activity",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListChecks className="h-4 w-4 text-brand" /> Log activity
          </DialogTitle>
          <DialogDescription>Record a touchpoint or create a follow-up task.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Type">
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ACTIVITY_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t.replace("_", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Priority">
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ACTIVITY_PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="Subject">
            <Input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. Follow-up call about pricing"
              className="h-9 rounded-xl"
            />
          </Field>
          <Field label="Notes">
            <Textarea
              value={detail}
              onChange={(e) => setDetail(e.target.value)}
              placeholder="What was discussed? Next steps?"
              className="min-h-20 rounded-xl"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Due (optional)">
              <Input
                type="datetime-local"
                value={dueAt}
                onChange={(e) => setDueAt(e.target.value)}
                className="h-9 rounded-xl"
              />
            </Field>
            <Field label="Owner">
              <Select value={ownerId} onValueChange={setOwnerId}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue placeholder="Unassigned" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">Unassigned</SelectItem>
                  {users.map((u) => (
                    <SelectItem key={u.id} value={u.id}>
                      {u.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Log activity
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── DeleteRowButton + confirm combo used inside detail sheets ───────────── */

export function useDeleteEntity() {
  const { toast } = useToast();
  const [pending, setPending] = useState(false);

  async function remove(url: string, onDone: () => void, label = "Deleted") {
    setPending(true);
    try {
      await api.delete(url);
      toast({ title: label });
      onDone();
    } catch (e) {
      toast({
        title: "Delete failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setPending(false);
    }
  }

  return { remove, pending };
}

/* ── Sheet section scaffolding ───────────────────────────────────────────── */

export function SheetSection({
  title,
  action,
  children,
  className,
}: {
  title: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("space-y-2.5", className)}>
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-[13px] font-bold uppercase tracking-wide text-muted-foreground">{title}</h3>
        {action}
      </div>
      {children}
    </section>
  );
}

export function DetailSkeleton() {
  return (
    <div className="space-y-4 p-1">
      <Skeleton className="h-16 w-full rounded-2xl" />
      <Skeleton className="h-24 w-full rounded-2xl" />
      <Skeleton className="h-40 w-full rounded-2xl" />
    </div>
  );
}
