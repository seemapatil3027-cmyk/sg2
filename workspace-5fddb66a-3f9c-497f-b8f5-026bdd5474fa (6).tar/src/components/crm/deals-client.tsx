"use client";

import { useMemo, useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { DEAL_STAGES, DEAL_STAGE_LABELS } from "@/lib/crm-status";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { StatusBadge } from "@/components/platform/status-badge";
import { CreateButton } from "@/components/platform/states";
import { DataTable, type Column } from "@/components/platform/data-table";
import { Timeline } from "@/components/platform/flow";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Target,
  TrendingUp,
  Trophy,
  UserX,
  Pencil,
  Trash2,
  Loader2,
  CalendarDays,
} from "lucide-react";
import {
  ConfirmDialog,
  Field,
  InitialsAvatar,
  LogActivityDialog,
  SheetSection,
  TextBadge,
  useContactsBasic,
  useOrgsBasic,
  UserSelect,
} from "@/components/crm/crm-shared";
import { NewDealDialog, type DealRow } from "@/components/crm/pipeline-client";

interface DealsData {
  items: DealRow[];
  stageCounts: Record<string, { count: number; value: number }>;
  stats: { totalPipelineValue: number; openCount: number };
}

interface DealDetail {
  deal: DealRow;
  owner: { id: string; name: string; email: string } | null;
  contact: { id: string; name: string; email: string } | null;
  organization: { id: string; name: string } | null;
  activities: {
    id: string;
    type: string;
    subject: string;
    detail: string | null;
    status: string | null;
    dueAt: string | null;
    createdAt: string;
    createdBy: string | null;
  }[];
}

const toLocalInput = (d: string | null | undefined): string => {
  if (!d) return "";
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
};

export function DealsClient() {
  const { can } = useUser();
  const canManage = can("crm.deals.manage");
  const list = useApi<DealsData>("/api/crm/deals?pageSize=500&sort=createdAt&dir=desc");

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [ownerFilter, setOwnerFilter] = useState("all");
  const [stageFilter, setStageFilter] = useState("all");

  const rows = useMemo(() => {
    let out = list.data?.items ?? [];
    if (stageFilter !== "all") out = out.filter((d) => d.stage === stageFilter);
    if (ownerFilter === "unassigned") out = out.filter((d) => !d.ownerId);
    else if (ownerFilter !== "all") out = out.filter((d) => d.ownerId === ownerFilter);
    return out;
  }, [list.data, stageFilter, ownerFilter]);

  const stats = list.data?.stats;
  const stageCounts = list.data?.stageCounts;

  const columns: Column<DealRow>[] = [
    {
      key: "title",
      header: "Deal",
      sortable: true,
      render: (d) => (
        <div className="min-w-0">
          <p className="truncate font-semibold text-foreground">{d.title}</p>
          <p className="text-xs text-muted-foreground">{fmt.inrCompact(d.value)} · {d.probability}%</p>
        </div>
      ),
    },
    {
      key: "value",
      header: "Value",
      sortable: true,
      render: (d) => <span className="font-semibold text-foreground">{fmt.inr(d.value)}</span>,
    },
    { key: "stage", header: "Stage", render: (d) => <StatusBadge value={d.stage} /> },
    { key: "status", header: "Status", render: (d) => <StatusBadge value={d.status} /> },
    {
      key: "contactName",
      header: "Contact",
      render: (d) => (
        <div className="min-w-0">
          <p className="truncate text-[13px]">{d.contactName ?? "—"}</p>
          <p className="truncate text-xs text-muted-foreground">{d.organizationName ?? ""}</p>
        </div>
      ),
    },
    {
      key: "owner",
      header: "Owner",
      render: (d) =>
        d.ownerName ? (
          <span className="flex items-center gap-2">
            <InitialsAvatar name={d.ownerName} />
            <span className="truncate text-[13px]">{d.ownerName}</span>
          </span>
        ) : (
          <span className="text-xs italic text-muted-foreground">Unassigned</span>
        ),
    },
    {
      key: "expectedCloseAt",
      header: "Expected close",
      sortable: true,
      render: (d) => {
        const overdue =
          d.expectedCloseAt && d.status === "OPEN" && new Date(d.expectedCloseAt).getTime() < Date.now();
        return (
          <span
            className={
              overdue
                ? "inline-flex items-center gap-1 whitespace-nowrap rounded-md bg-rose-50 px-1.5 py-0.5 text-xs font-semibold text-rose-600 dark:bg-rose-500/15 dark:text-rose-300"
                : "whitespace-nowrap text-muted-foreground"
            }
          >
            {overdue ? <CalendarDays className="h-3 w-3" /> : null}
            {fmt.date(d.expectedCloseAt)}
          </span>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Deals"
        description="All opportunities with full profiles, stage history and follow-ups."
        actions={canManage ? <CreateButton label="New deal" onClick={() => setCreateOpen(true)} /> : null}
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Pipeline value" value={stats ? fmt.inrCompact(stats.totalPipelineValue) : "—"} icon={TrendingUp} tone="brand" hint={`${stats?.openCount ?? 0} open deals`} />
        <StatCard label="Open deals" value={stats?.openCount ?? "—"} icon={Target} tone="orange" />
        <StatCard
          label="Won"
          value={stageCounts ? stageCounts.WON?.count ?? 0 : "—"}
          hint={stageCounts ? fmt.inrCompact(stageCounts.WON?.value ?? 0) : undefined}
          icon={Trophy}
          tone="green"
        />
        <StatCard label="Lost" value={stageCounts ? stageCounts.LOST?.count ?? 0 : "—"} icon={UserX} tone="rose" />
      </div>

      <DataTable<DealRow>
        columns={columns}
        rows={rows}
        loading={list.loading}
        error={list.error}
        onRetry={list.refetch}
        rowKey={(d) => d.id}
        onRowClick={(d) => setSelectedId(d.id)}
        searchPlaceholder="Search deals…"
        pageSize={10}
        emptyTitle="No deals yet"
        emptyHint={canManage ? "Create your first opportunity to start tracking the pipeline." : "Deals assigned to you will appear here."}
        filterFn={(d, q) =>
          [d.title, d.contactName, d.organizationName, d.notes]
            .filter(Boolean)
            .some((v) => String(v).toLowerCase().includes(q))
        }
        toolbar={
          <>
            <Select value={stageFilter} onValueChange={setStageFilter}>
              <SelectTrigger className="h-9 w-36 rounded-xl" aria-label="Filter by stage">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All stages</SelectItem>
                {DEAL_STAGES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {DEAL_STAGE_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={ownerFilter} onValueChange={setOwnerFilter}>
              <SelectTrigger className="h-9 w-40 rounded-xl" aria-label="Filter by owner">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All owners</SelectItem>
                <SelectItem value="unassigned">Unassigned</SelectItem>
                {(list.data?.items ?? [])
                  .filter((d) => d.ownerId && d.ownerName)
                  .filter((d, i, arr) => arr.findIndex((x) => x.ownerId === d.ownerId) === i)
                  .map((d) => (
                    <SelectItem key={d.ownerId} value={d.ownerId!}>
                      {d.ownerName}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </>
        }
      />

      <DealSheet
        dealId={selectedId}
        canManage={canManage}
        onOpenChange={(open) => !open && setSelectedId(null)}
        onChanged={list.refetch}
      />

      <NewDealDialog open={createOpen} onOpenChange={setCreateOpen} onSaved={list.refetch} />
    </div>
  );
}

/* ── Deal detail sheet ────────────────────────────────────────────────────── */

function DealSheet({
  dealId,
  canManage,
  onOpenChange,
  onChanged,
}: {
  dealId: string | null;
  canManage: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
}) {
  const { toast } = useToast();
  const detail = useApi<DealDetail>(dealId ? `/api/crm/deals/${dealId}` : null);
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [logOpen, setLogOpen] = useState(false);
  const [deletePending, setDeletePending] = useState(false);
  const [savingField, setSavingField] = useState(false);

  const deal = detail.data?.deal ?? null;

  async function patch(fields: Record<string, unknown>, message: string) {
    if (!deal) return;
    setSavingField(true);
    try {
      await api.patch(`/api/crm/deals/${deal.id}`, fields);
      toast({ title: message });
      detail.refetch();
      onChanged();
    } catch (e) {
      toast({
        title: "Update failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSavingField(false);
    }
  }

  async function remove() {
    if (!deal) return;
    setDeletePending(true);
    try {
      await api.delete(`/api/crm/deals/${deal.id}`);
      toast({ title: "Deal deleted" });
      setDeleteOpen(false);
      onOpenChange(false);
      onChanged();
    } catch (e) {
      toast({
        title: "Delete failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setDeletePending(false);
    }
  }

  return (
    <Sheet open={!!dealId} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full overflow-y-auto p-0 sm:max-w-xl">
        {detail.loading && !deal ? (
          <div className="space-y-3 p-6">
          <SheetTitle className="sr-only">Deal details</SheetTitle>
            <Skeleton className="h-8 w-2/3" />
            <Skeleton className="h-24 w-full rounded-2xl" />
            <Skeleton className="h-40 w-full rounded-2xl" />
          </div>
        ) : detail.error ? (
          <div className="p-6 text-sm text-destructive">{detail.error}</div>
        ) : deal ? (
          <div className="space-y-6 p-6">
            <SheetHeader className="p-0">
              <SheetTitle className="text-lg font-bold leading-tight">{deal.title}</SheetTitle>
              <SheetDescription className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                <span className="text-base font-bold text-brand dark:text-violet-300">{fmt.inr(deal.value)}</span>
                <StatusBadge value={deal.stage} />
                <StatusBadge value={deal.status} />
              </SheetDescription>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                {detail.data?.contact ? <TextBadge>Contact: {detail.data.contact.name}</TextBadge> : null}
                {detail.data?.organization ? <TextBadge>Org: {detail.data.organization.name}</TextBadge> : null}
                <TextBadge>Owner: {detail.data?.owner?.name ?? "Unassigned"}</TextBadge>
                <TextBadge>Probability: {deal.probability}%</TextBadge>
                {deal.closedAt ? <TextBadge>Closed: {fmt.date(deal.closedAt)}</TextBadge> : null}
              </div>
            </SheetHeader>

            {canManage ? (
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" className="rounded-xl" onClick={() => setEditOpen(true)}>
                  <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit deal
                </Button>
                <Button size="sm" variant="outline" className="rounded-xl" onClick={() => setLogOpen(true)}>
                  Log activity
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="ml-auto rounded-xl text-destructive hover:text-destructive"
                  onClick={() => setDeleteOpen(true)}
                >
                  <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete
                </Button>
              </div>
            ) : null}

            {canManage ? (
              <SheetSection title="Stage & owner">
                <div className="grid grid-cols-2 gap-3 rounded-2xl border bg-card p-4">
                  <Field label="Stage">
                    <Select
                      value={deal.stage}
                      onValueChange={(v) => {
                        const label = DEAL_STAGE_LABELS[v as keyof typeof DEAL_STAGE_LABELS] ?? v;
                        patch(
                          { stage: v },
                          v === "WON" ? "Deal won 🎉" : v === "LOST" ? "Deal marked lost" : `Moved to ${label}`
                        );
                      }}
                      disabled={savingField}
                    >
                      <SelectTrigger className="h-9 rounded-xl" aria-label="Deal stage">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DEAL_STAGES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {DEAL_STAGE_LABELS[s]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Owner">
                    <UserSelect
                      value={deal.ownerId}
                      onChange={(ownerId) => patch({ ownerId }, ownerId ? "Owner updated" : "Owner unassigned")}
                      disabled={savingField}
                      ariaLabel="Deal owner"
                    />
                  </Field>
                </div>
              </SheetSection>
            ) : null}

            {deal.notes ? (
              <SheetSection title="Notes">
                <div className="rounded-2xl border bg-muted/40 p-4 text-[13px] leading-relaxed text-muted-foreground">
                  {deal.notes}
                </div>
              </SheetSection>
            ) : null}

            <SheetSection title={`Timeline (${detail.data?.activities.length ?? 0})`}>
              {detail.loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-14 w-full rounded-xl" />
                  ))}
                </div>
              ) : (
                <Timeline
                  items={(detail.data?.activities ?? []).map((a) => ({
                    id: a.id,
                    type: a.type,
                    subject: a.subject,
                    detail: a.detail,
                    status: a.status,
                    createdAt: a.createdAt,
                    actor: a.createdBy,
                    dueAt: a.dueAt,
                  }))}
                />
              )}
            </SheetSection>

            {deal ? (
              <>
                <DealEditDialog
                  open={editOpen}
                  onOpenChange={setEditOpen}
                  deal={deal}
                  onSaved={() => {
                    detail.refetch();
                    onChanged();
                  }}
                />
                <LogActivityDialog
                  open={logOpen}
                  onOpenChange={setLogOpen}
                  links={{ dealId: deal.id, contactId: deal.contactId, organizationId: deal.organizationId }}
                  defaultOwnerId={deal.ownerId}
                  onLogged={() => {
                    detail.refetch();
                    onChanged();
                  }}
                />
                <ConfirmDialog
                  open={deleteOpen}
                  onOpenChange={setDeleteOpen}
                  title="Delete this deal?"
                  description={`"${deal.title}" and its activity history will be permanently removed.`}
                  loading={deletePending}
                  onConfirm={remove}
                />
              </>
            ) : null}
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

/* ── Deal edit dialog ─────────────────────────────────────────────────────── */

function DealEditDialog({
  open,
  onOpenChange,
  deal,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  deal: DealRow;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const { contacts } = useContactsBasic();
  const { orgs } = useOrgsBasic();
  const [title, setTitle] = useState(deal.title);
  const [value, setValue] = useState(String(deal.value));
  const [probability, setProbability] = useState(String(deal.probability));
  const [expectedCloseAt, setExpectedCloseAt] = useState(toLocalInput(deal.expectedCloseAt));
  const [contactId, setContactId] = useState(deal.contactId ?? "");
  const [organizationId, setOrganizationId] = useState(deal.organizationId ?? "");
  const [lostReason, setLostReason] = useState(deal.lostReason ?? "");
  const [notes, setNotes] = useState(deal.notes ?? "");
  const [saving, setSaving] = useState(false);

  async function submit() {
    setSaving(true);
    try {
      await api.patch(`/api/crm/deals/${deal.id}`, {
        title: title.trim(),
        value: Math.max(0, Math.round(Number(value) || 0)),
        probability: Math.max(0, Math.min(100, Math.round(Number(probability) || 0))),
        expectedCloseAt: expectedCloseAt || null,
        contactId: contactId || null,
        organizationId: organizationId || null,
        lostReason: lostReason.trim() || null,
        notes: notes.trim() || null,
      });
      toast({ title: "Deal updated" });
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({
        title: "Update failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit deal</DialogTitle>
          <DialogDescription>Update the opportunity details.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <Field label="Title">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Value (₹)">
              <Input type="number" min={0} value={value} onChange={(e) => setValue(e.target.value)} className="h-9 rounded-xl" />
            </Field>
            <Field label="Probability (%)">
              <Input
                type="number"
                min={0}
                max={100}
                value={probability}
                onChange={(e) => setProbability(e.target.value)}
                className="h-9 rounded-xl"
              />
            </Field>
          </div>
          <Field label="Expected close">
            <Input
              type="date"
              value={expectedCloseAt}
              onChange={(e) => setExpectedCloseAt(e.target.value)}
              className="h-9 rounded-xl"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Contact">
              <Select value={contactId} onValueChange={setContactId}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue placeholder="No contact" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">No contact</SelectItem>
                  {contacts.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Organization">
              <Select value={organizationId} onValueChange={setOrganizationId}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue placeholder="No organization" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">No organization</SelectItem>
                  {orgs.map((o) => (
                    <SelectItem key={o.id} value={o.id}>
                      {o.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
          {deal.status === "LOST" ? (
            <Field label="Lost reason">
              <Input value={lostReason} onChange={(e) => setLostReason(e.target.value)} className="h-9 rounded-xl" />
            </Field>
          ) : null}
          <Field label="Notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-20 rounded-xl" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
