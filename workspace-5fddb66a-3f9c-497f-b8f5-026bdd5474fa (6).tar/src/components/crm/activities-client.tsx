"use client";

import { useMemo, useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { ACTIVITY_TYPES } from "@/lib/crm-status";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { StatusBadge } from "@/components/platform/status-badge";
import { EmptyState, LoadingBlock, ErrorBlock } from "@/components/platform/states";
import { activityIcon } from "@/components/platform/flow";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ListChecks,
  Circle,
  CheckCircle2,
  Pencil,
  Trash2,
  Loader2,
  Clock,
  Search,
} from "lucide-react";
import {
  ConfirmDialog,
  Field,
  InitialsAvatar,
  LogActivityDialog,
  LinkChip,
  useUsersBasic,
} from "@/components/crm/crm-shared";
import { cn } from "@/lib/utils";

/* ── Types ────────────────────────────────────────────────────────────────── */

interface ActivityRow {
  id: string;
  type: string;
  subject: string;
  detail: string | null;
  status: string;
  priority: string;
  dueAt: string | null;
  completedAt: string | null;
  leadId: string | null;
  contactId: string | null;
  dealId: string | null;
  organizationId: string | null;
  ownerId: string | null;
  createdBy: string | null;
  createdAt: string;
  leadName: string | null;
  contactName: string | null;
  dealTitle: string | null;
  organizationName: string | null;
  ownerName: string | null;
}

type TabKey = "open" | "overdue" | "completed";

export function ActivitiesClient() {
  const { can, user } = useUser();
  const canManage = can("crm.activities.manage");
  const { toast } = useToast();
  const { users } = useUsersBasic();
  const list = useApi<{ items: ActivityRow[]; total: number }>(
    "/api/crm/activities?pageSize=500&sort=dueAt&dir=asc"
  );

  const [tab, setTab] = useState<TabKey>("open");
  const [typeFilter, setTypeFilter] = useState("all");
  const [ownerFilter, setOwnerFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [logOpen, setLogOpen] = useState(false);
  const [editing, setEditing] = useState<ActivityRow | null>(null);
  const [deleting, setDeleting] = useState<ActivityRow | null>(null);

  const rows = list.data?.items ?? [];
  const now = Date.now();
  const todayEnd = new Date();
  todayEnd.setHours(23, 59, 59, 999);

  const kpis = useMemo(() => {
    const open = rows.filter((a) => a.status === "OPEN");
    return {
      open: open.length,
      overdue: open.filter((a) => a.dueAt && new Date(a.dueAt).getTime() < now).length,
      today: open.filter(
        (a) => a.dueAt && new Date(a.dueAt).getTime() >= now && new Date(a.dueAt).getTime() <= todayEnd.getTime()
      ).length,
      done7d: rows.filter(
        (a) => a.status === "COMPLETED" && a.completedAt && Date.now() - new Date(a.completedAt).getTime() < 7 * 86_400_000
      ).length,
    };
  }, [rows, now, todayEnd]);

  const visible = useMemo(() => {
    let out = rows;
    if (tab === "open") out = out.filter((a) => a.status === "OPEN");
    if (tab === "overdue")
      out = out.filter((a) => a.status === "OPEN" && a.dueAt && new Date(a.dueAt).getTime() < now);
    if (tab === "completed") out = out.filter((a) => a.status === "COMPLETED");
    if (typeFilter !== "all") out = out.filter((a) => a.type === typeFilter);
    if (ownerFilter === "me") out = out.filter((a) => a.ownerId && a.ownerId === user?.uid);
    else if (ownerFilter === "unassigned") out = out.filter((a) => !a.ownerId);
    else if (ownerFilter !== "all") out = out.filter((a) => a.ownerId === ownerFilter);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      out = out.filter((a) =>
        [a.subject, a.detail, a.leadName, a.contactName, a.dealTitle, a.organizationName]
          .filter(Boolean)
          .some((v) => String(v).toLowerCase().includes(q))
      );
    }
    // overdue first, then by due date
    return [...out].sort((a, b) => {
      const ad = a.dueAt ? new Date(a.dueAt).getTime() : Number.MAX_SAFE_INTEGER;
      const bd = b.dueAt ? new Date(b.dueAt).getTime() : Number.MAX_SAFE_INTEGER;
      return ad - bd;
    });
  }, [rows, tab, typeFilter, ownerFilter, search, user, now]);

  async function toggle(a: ActivityRow) {
    const next = a.status === "COMPLETED" ? "OPEN" : "COMPLETED";
    try {
      await api.patch(`/api/crm/activities/${a.id}`, { status: next });
      toast({
        title: next === "COMPLETED" ? "Marked complete ✓" : "Reopened",
        description: a.subject,
      });
      list.refetch();
    } catch (e) {
      toast({
        title: "Could not update activity",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Activities & Tasks"
        description="Calls, meetings, follow-ups and tasks across every lead, deal and customer."
        actions={canManage ? <Button className="rounded-xl" onClick={() => setLogOpen(true)}>
          <ListChecks className="mr-2 h-4 w-4" /> Log activity
        </Button> : null}
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Open" value={kpis.open} icon={ListChecks} tone="brand" />
        <StatCard label="Overdue" value={kpis.overdue} icon={Clock} tone="rose" />
        <StatCard label="Due today" value={kpis.today} icon={CheckCircle2} tone="orange" />
        <StatCard label="Done · 7 days" value={kpis.done7d} icon={CheckCircle2} tone="green" />
      </div>

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)}>
          <TabsList className="h-9 rounded-xl bg-muted/60 p-1">
            {(
              [
                ["open", `Open (${kpis.open})`],
                ["overdue", `Overdue (${kpis.overdue})`],
                ["completed", "Completed"],
              ] as [TabKey, string][]
            ).map(([key, label]) => (
              <TabsTrigger key={key} value={key} className="rounded-lg px-3 text-[13px] data-[state=active]:bg-card data-[state=active]:shadow-sm">
                {label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search activities…"
              className="h-9 w-44 rounded-xl pl-9"
              aria-label="Search activities"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="h-9 w-36 rounded-xl" aria-label="Filter by type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {ACTIVITY_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {t.replace("_", " ")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={ownerFilter} onValueChange={setOwnerFilter}>
            <SelectTrigger className="h-9 w-40 rounded-xl" aria-label="Filter by owner">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All owners</SelectItem>
              <SelectItem value="me">Assigned to me</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {users.map((u) => (
                <SelectItem key={u.id} value={u.id}>
                  {u.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {list.loading ? (
        <LoadingBlock label="Loading activities…" />
      ) : list.error ? (
        <ErrorBlock message={list.error} onRetry={list.refetch} />
      ) : visible.length === 0 ? (
        <EmptyState
          icon={ListChecks}
          title="Nothing here"
          hint={
            tab === "overdue"
              ? "No overdue activities — great job staying on top of follow-ups."
              : canManage
                ? "Log your first call, meeting or task."
                : "Activities assigned to you will appear here."
          }
          action={
            canManage ? (
              <Button className="rounded-xl" onClick={() => setLogOpen(true)}>
                Log activity
              </Button>
            ) : null
          }
        />
      ) : (
        <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
          <ul className="divide-y" aria-label="Activity list">
            {visible.map((a) => {
              const Icon = activityIcon(a.type);
              const done = a.status === "COMPLETED";
              const overdue = !done && a.dueAt && new Date(a.dueAt).getTime() < now;
              return (
                <li key={a.id} className={cn("flex items-start gap-3 px-4 py-3.5 transition hover:bg-accent/40", done && "opacity-60")}>
                  <button
                    type="button"
                    onClick={() => toggle(a)}
                    disabled={!canManage}
                    aria-label={done ? "Reopen activity" : "Mark complete"}
                    className={cn(
                      "mt-0.5 shrink-0 transition",
                      done ? "text-emerald-500" : "text-muted-foreground hover:text-brand",
                      !canManage && "cursor-default disabled:opacity-60"
                    )}
                  >
                    {done ? <CheckCircle2 className="h-5 w-5" /> : <Circle className="h-5 w-5" />}
                  </button>
                  <span
                    className={cn(
                      "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                      done ? "bg-muted text-muted-foreground" : "bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300"
                    )}
                  >
                    <Icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <p className={cn("text-[13px] font-semibold text-foreground", done && "line-through")}>
                        {a.subject}
                      </p>
                      <StatusBadge value={a.priority} />
                      <TextBadgeInline>{a.type.replace("_", " ")}</TextBadgeInline>
                      {overdue ? (
                        <span className="inline-flex items-center gap-1 rounded-md bg-rose-50 px-1.5 py-0.5 text-[11px] font-semibold text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
                          <Clock className="h-3 w-3" /> Overdue
                        </span>
                      ) : null}
                    </div>
                    {a.detail ? <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{a.detail}</p> : null}
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                      {a.dueAt ? (
                        <span className={cn(overdue && "font-semibold text-rose-600 dark:text-rose-300")}>
                          {done ? "Was due" : "Due"} {fmt.dateTime(a.dueAt)}
                        </span>
                      ) : null}
                      {done && a.completedAt ? <span>Completed {fmt.relative(a.completedAt)}</span> : null}
                      <LinkChip label="Lead" value={a.leadName} />
                      <LinkChip label="Contact" value={a.contactName} />
                      <LinkChip label="Deal" value={a.dealTitle} />
                      <LinkChip label="Org" value={a.organizationName} />
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1.5">
                    {a.ownerName ? <InitialsAvatar name={a.ownerName} /> : null}
                    {canManage ? (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 rounded-lg"
                          onClick={() => setEditing(a)}
                          aria-label={`Edit ${a.subject}`}
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 rounded-lg text-destructive hover:text-destructive"
                          onClick={() => setDeleting(a)}
                          aria-label={`Delete ${a.subject}`}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </>
                    ) : null}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      <LogActivityDialog open={logOpen} onOpenChange={setLogOpen} links={{}} onLogged={list.refetch} />

      <ActivityEditDialog
        activity={editing}
        onOpenChange={(open) => !open && setEditing(null)}
        onSaved={list.refetch}
      />

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete this activity?"
        description={deleting ? `"${deleting.subject}" will be permanently removed.` : ""}
        loading={false}
        onConfirm={async () => {
          if (!deleting) return;
          try {
            await api.delete(`/api/crm/activities/${deleting.id}`);
            setDeleting(null);
            list.refetch();
          } catch {
            setDeleting(null);
          }
        }}
      />
    </div>
  );
}

function TextBadgeInline({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-md border bg-muted/50 px-1.5 py-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">
      {children}
    </span>
  );
}

/* ── Activity edit dialog ─────────────────────────────────────────────────── */

function ActivityEditDialog({
  activity,
  onOpenChange,
  onSaved,
}: {
  activity: ActivityRow | null;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const { users } = useUsersBasic();
  const [type, setType] = useState("CALL");
  const [subject, setSubject] = useState("");
  const [detail, setDetail] = useState("");
  const [dueAt, setDueAt] = useState("");
  const [priority, setPriority] = useState("MEDIUM");
  const [ownerId, setOwnerId] = useState("");
  const [saving, setSaving] = useState(false);
  const [initedFor, setInitedFor] = useState<string | null>(null);

  const open = !!activity;
  if (open && activity && initedFor !== activity.id) {
    setInitedFor(activity.id);
    setType(activity.type);
    setSubject(activity.subject);
    setDetail(activity.detail ?? "");
    setPriority(activity.priority);
    setOwnerId(activity.ownerId ?? "");
    if (activity.dueAt) {
      const d = new Date(activity.dueAt);
      const pad = (n: number) => String(n).padStart(2, "0");
      setDueAt(`${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`);
    } else {
      setDueAt("");
    }
  }
  if (!open && initedFor) setInitedFor(null);

  async function submit() {
    if (!activity) return;
    setSaving(true);
    try {
      await api.patch(`/api/crm/activities/${activity.id}`, {
        type,
        subject: subject.trim(),
        detail: detail.trim() || null,
        dueAt: dueAt || null,
        priority,
        ownerId: ownerId || null,
      });
      toast({ title: "Activity updated" });
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({
        title: "Update failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit activity</DialogTitle>
          <DialogDescription>Update details or reschedule this activity.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Type">
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ACTIVITY_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t.replace("_", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Priority">
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="LOW">LOW</SelectItem>
                  <SelectItem value="MEDIUM">MEDIUM</SelectItem>
                  <SelectItem value="HIGH">HIGH</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="Subject">
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Notes">
            <Textarea value={detail} onChange={(e) => setDetail(e.target.value)} className="min-h-20 rounded-xl" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Due">
              <Input type="datetime-local" value={dueAt} onChange={(e) => setDueAt(e.target.value)} className="h-9 rounded-xl" />
            </Field>
            <Field label="Owner">
              <Select value={ownerId} onValueChange={(v) => setOwnerId(v === "" ? "" : v)}>
                <SelectTrigger className="h-9 rounded-xl">
                  <SelectValue placeholder="Unassigned" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">Unassigned</SelectItem>
                  {users.map((u) => (
                    <SelectItem key={u.id} value={u.id}>
                      {u.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
