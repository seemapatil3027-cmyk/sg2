"use client";

import { useEffect, useMemo, useState } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { api, fmt, useApi } from "@/lib/api-client";
import { DEAL_STAGES, DEAL_STAGE_LABELS, DEAL_STAGE_TONES } from "@/lib/crm-status";
import { PageHeader } from "@/components/platform/page-header";
import { CreateButton, LoadingBlock, ErrorBlock } from "@/components/platform/states";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { KanbanSquare, GripVertical, CalendarDays, Loader2, Timer } from "lucide-react";
import {
  Field,
  InitialsAvatar,
  useContactsBasic,
  useOrgsBasic,
  UserSelect,
} from "@/components/crm/crm-shared";

/* ── Types ────────────────────────────────────────────────────────────────── */

export interface DealRow {
  id: string;
  title: string;
  value: number;
  stage: string;
  status: string;
  probability: number;
  expectedCloseAt: string | null;
  closedAt: string | null;
  lostReason: string | null;
  ownerId: string | null;
  contactId: string | null;
  organizationId: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  contactName: string | null;
  organizationName: string | null;
  ownerName: string | null;
}

interface DealsData {
  items: DealRow[];
  stageCounts: Record<string, { count: number; value: number }>;
  stats: { totalPipelineValue: number; openCount: number };
}

/* ── Main client ──────────────────────────────────────────────────────────── */

export function PipelineClient() {
  const { can } = useUser();
  const canManage = can("crm.deals.manage");
  const { toast } = useToast();
  const list = useApi<DealsData>("/api/crm/deals?pageSize=500&sort=createdAt&dir=desc");

  // Local mirror for optimistic drag moves.
  const [deals, setDeals] = useState<DealRow[]>([]);
  useEffect(() => {
    if (list.data) setDeals(list.data.items);
  }, [list.data]);

  const [activeId, setActiveId] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  const byStage = useMemo(() => {
    const map: Record<string, DealRow[]> = {};
    for (const s of DEAL_STAGES) map[s] = [];
    for (const d of deals) (map[d.stage] ??= []).push(d);
    // biggest opportunities first within each column
    for (const s of DEAL_STAGES) map[s].sort((a, b) => b.value - a.value);
    return map;
  }, [deals]);

  const activeDeal = activeId ? deals.find((d) => d.id === activeId) ?? null : null;

  function onDragStart(e: DragStartEvent) {
    setActiveId(String(e.active.id));
  }

  async function onDragEnd(e: DragEndEvent) {
    setActiveId(null);
    const dealId = String(e.active.id);
    const stage = e.over ? String(e.over.id) : null;
    if (!stage) return;
    const deal = deals.find((d) => d.id === dealId);
    if (!deal || deal.stage === stage) return;

    const prev = deals;
    const nextStatus = stage === "WON" ? "WON" : stage === "LOST" ? "LOST" : "OPEN";
    setDeals((ds) => ds.map((d) => (d.id === dealId ? { ...d, stage, status: nextStatus } : d)));
    try {
      await api.patch(`/api/crm/deals/${dealId}`, { stage });
      if (stage === "WON") {
        toast({ title: "Deal won 🎉", description: `${deal.title} — ${fmt.inr(deal.value)}` });
      } else if (stage === "LOST") {
        toast({ title: "Deal marked lost", description: deal.title, variant: "destructive" });
      } else {
        toast({ title: `Moved to ${DEAL_STAGE_LABELS[stage as keyof typeof DEAL_STAGE_LABELS]}`, description: deal.title });
      }
      list.refetch();
    } catch (err) {
      setDeals(prev);
      toast({
        title: "Could not move deal",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    }
  }

  const openValue = deals
    .filter((d) => d.stage !== "WON" && d.stage !== "LOST")
    .reduce((s, d) => s + d.value, 0);
  const wonValue = deals.filter((d) => d.stage === "WON").reduce((s, d) => s + d.value, 0);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Pipeline"
        description="Drag deals across stages — moves are logged on the deal timeline automatically."
        actions={
          canManage ? <CreateButton label="New deal" onClick={() => setCreateOpen(true)} icon={KanbanSquare} /> : null
        }
      />

      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 rounded-2xl border bg-card px-5 py-3.5 shadow-sm">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Open pipeline</p>
          <p className="text-lg font-bold text-foreground">{fmt.inrCompact(openValue)}</p>
        </div>
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Open deals</p>
          <p className="text-lg font-bold text-foreground">{deals.filter((d) => d.status === "OPEN").length}</p>
        </div>
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Won to date</p>
          <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{fmt.inrCompact(wonValue)}</p>
        </div>
      </div>

      {list.loading && deals.length === 0 ? (
        <LoadingBlock label="Loading pipeline…" />
      ) : list.error ? (
        <ErrorBlock message={list.error} onRetry={list.refetch} />
      ) : (
        <DndContext sensors={sensors} onDragStart={onDragStart} onDragEnd={onDragEnd}>
          <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-3 pt-1">
            {DEAL_STAGES.map((stage) => (
              <KanbanColumn key={stage} stage={stage} deals={byStage[stage]} canManage={canManage} />
            ))}
          </div>
          <DragOverlay dropAnimation={{ duration: 180 }}>
            {activeDeal ? (
              <div className="w-64 rotate-1 opacity-90">
                <DealCardBody deal={activeDeal} dragging />
              </div>
            ) : null}
          </DragOverlay>
        </DndContext>
      )}

      <NewDealDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onSaved={() => list.refetch()}
      />
    </div>
  );
}

/* ── Column ───────────────────────────────────────────────────────────────── */

function KanbanColumn({
  stage,
  deals,
  canManage,
}: {
  stage: string;
  deals: DealRow[];
  canManage: boolean;
}) {
  const { isOver, setNodeRef } = useDroppable({ id: stage, disabled: !canManage });
  const value = deals.reduce((s, d) => s + d.value, 0);
  const label = DEAL_STAGE_LABELS[stage as keyof typeof DEAL_STAGE_LABELS] ?? stage;

  return (
    <div className="flex w-72 shrink-0 flex-col rounded-2xl border bg-muted/40 dark:bg-muted/20 sm:w-80">
      <div className="flex items-center gap-2 border-b px-3.5 py-2.5">
        <span className={cn("h-2 w-2 rounded-full", DEAL_STAGE_TONES[stage as keyof typeof DEAL_STAGE_TONES])} />
        <p className="text-[13px] font-bold text-foreground">{label}</p>
        <span className="ml-auto flex items-center gap-2 text-[11px] font-semibold text-muted-foreground">
          <span className="rounded-md bg-card px-1.5 py-0.5 shadow-sm">{deals.length}</span>
          <span>{fmt.inrCompact(value)}</span>
        </span>
      </div>

      <div
        ref={setNodeRef}
        className={cn(
          "flex min-h-40 flex-1 flex-col gap-2 overflow-y-auto p-2 transition",
          isOver && "rounded-b-2xl bg-brand-soft/70 ring-2 ring-inset ring-brand/40 dark:bg-brand/15"
        )}
        aria-label={`${label} column`}
      >
        {deals.length === 0 ? (
          <p className="flex flex-1 items-center justify-center px-3 py-6 text-center text-xs text-muted-foreground/70">
            Drop deals here
          </p>
        ) : (
          deals.map((deal) => <DraggableDealCard key={deal.id} deal={deal} disabled={!canManage} />)
        )}
      </div>

      <div className="border-t px-3.5 py-2 text-[11px] font-medium text-muted-foreground">
        {deals.length} deal{deals.length === 1 ? "" : "s"} · {fmt.inrCompact(value)}
      </div>
    </div>
  );
}

function DraggableDealCard({ deal, disabled }: { deal: DealRow; disabled?: boolean }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({ id: deal.id, disabled });
  return (
    <div ref={setNodeRef} {...listeners} {...attributes} className={cn(isDragging && "opacity-40")}>
      <DealCardBody deal={deal} />
    </div>
  );
}

function DealCardBody({ deal, dragging }: { deal: DealRow; dragging?: boolean }) {
  const days = Math.max(0, Math.floor((Date.now() - new Date(deal.updatedAt).getTime()) / 86_400_000));
  const overdue =
    deal.expectedCloseAt &&
    deal.status === "OPEN" &&
    new Date(deal.expectedCloseAt).getTime() < Date.now();

  return (
    <div
      className={cn(
        "group cursor-grab rounded-xl border bg-card p-3 shadow-sm transition hover:border-brand/40 hover:shadow-md active:cursor-grabbing",
        dragging && "shadow-lg ring-2 ring-brand/40"
      )}
      aria-roledescription="Draggable deal card"
    >
      <div className="flex items-start gap-1.5">
        <GripVertical className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground/50" aria-hidden="true" />
        <p className="line-clamp-2 min-w-0 flex-1 text-[13px] font-semibold leading-snug text-foreground">
          {deal.title}
        </p>
      </div>
      <p className="mt-1.5 text-sm font-bold text-brand dark:text-violet-300">{fmt.inrCompact(deal.value)}</p>
      <p className="mt-1 truncate text-[11px] text-muted-foreground">
        {deal.contactName ?? "No contact"}
        {deal.organizationName ? ` · ${deal.organizationName}` : ""}
      </p>
      <div className="mt-2.5 flex items-center gap-2">
        <InitialsAvatar name={deal.ownerName} className="h-5.5 w-5.5 text-[9px]" />
        <span className="truncate text-[11px] text-muted-foreground">{deal.ownerName ?? "Unassigned"}</span>
        <span className="ml-auto flex items-center gap-1">
          {overdue ? (
            <span className="inline-flex items-center gap-0.5 rounded-md bg-rose-50 px-1.5 py-0.5 text-[10px] font-semibold text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
              <CalendarDays className="h-3 w-3" /> Overdue
            </span>
          ) : deal.expectedCloseAt ? (
            <span className="text-[10px] text-muted-foreground">{fmt.date(deal.expectedCloseAt)}</span>
          ) : null}
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[10px] font-semibold",
              days > 21
                ? "bg-rose-50 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300"
                : days > 7
                  ? "bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300"
                  : "bg-muted text-muted-foreground"
            )}
          >
            <Timer className="h-3 w-3" /> {days}d
          </span>
        </span>
      </div>
    </div>
  );
}

/* ── New deal dialog (shared with /crm/deals) ─────────────────────────────── */

export function NewDealDialog({
  open,
  onOpenChange,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const { contacts } = useContactsBasic();
  const { orgs } = useOrgsBasic();
  const [title, setTitle] = useState("");
  const [value, setValue] = useState("");
  const [contactId, setContactId] = useState("");
  const [organizationId, setOrganizationId] = useState("");
  const [ownerId, setOwnerId] = useState<string | null>(null);
  const [expectedCloseAt, setExpectedCloseAt] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setTitle("");
      setValue("");
      setContactId("");
      setOrganizationId("");
      setOwnerId(null);
      setExpectedCloseAt("");
      setNotes("");
    }
  }, [open]);

  async function submit() {
    if (title.trim().length < 2) {
      toast({ title: "Give the deal a title", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.post("/api/crm/deals", {
        title: title.trim(),
        value: Math.max(0, Math.round(Number(value) || 0)),
        contactId: contactId || null,
        organizationId: organizationId || null,
        ownerId,
        expectedCloseAt: expectedCloseAt || null,
        notes: notes.trim() || null,
      });
      toast({ title: "Deal created", description: title.trim() });
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({
        title: "Could not create deal",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>New deal</DialogTitle>
          <DialogDescription>Open a new opportunity in the New stage.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <Field label="Title">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Data Analytics Track — 12 seats"
              className="h-9 rounded-xl"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Value (₹)">
              <Input
                type="number"
                min={0}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="0"
                className="h-9 rounded-xl"
              />
            </Field>
            <Field label="Expected close">
              <Input
                type="date"
                value={expectedCloseAt}
                onChange={(e) => setExpectedCloseAt(e.target.value)}
                className="h-9 rounded-xl"
              />
            </Field>
          </div>
          <Field label="Contact">
            <Select value={contactId} onValueChange={setContactId}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue placeholder="No contact" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">No contact</SelectItem>
                {contacts.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Organization">
            <Select value={organizationId} onValueChange={setOrganizationId}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue placeholder="No organization" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">No organization</SelectItem>
                {orgs.map((o) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Owner">
            <UserSelect value={ownerId} onChange={setOwnerId} ariaLabel="Deal owner" />
          </Field>
          <Field label="Notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-16 rounded-xl" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Create deal
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
