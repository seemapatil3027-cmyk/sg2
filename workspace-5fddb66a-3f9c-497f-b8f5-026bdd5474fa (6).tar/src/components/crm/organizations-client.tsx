"use client";

import { useMemo, useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { CreateButton, EmptyState } from "@/components/platform/states";
import { Timeline } from "@/components/platform/flow";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StatusBadge } from "@/components/platform/status-badge";
import {
  Building2,
  Pencil,
  Trash2,
  Users,
  Globe,
  Loader2,
  Briefcase,
  TrendingUp,
} from "lucide-react";
import {
  ConfirmDialog,
  Field,
  InitialsAvatar,
  LogActivityDialog,
  SheetSection,
  TextBadge,
  UserSelect,
} from "@/components/crm/crm-shared";

/* ── Types ────────────────────────────────────────────────────────────────── */

interface OrgRow {
  id: string;
  name: string;
  domain: string | null;
  industry: string | null;
  size: string | null;
  city: string | null;
  phone: string | null;
  website: string | null;
  notes: string | null;
  ownerId: string | null;
  createdAt: string;
  ownerName: string | null;
  contactsCount: number;
  openDealsValue: number;
  openDealsCount: number;
}

interface OrgDetail {
  organization: OrgRow;
  owner: { id: string; name: string; email: string } | null;
  contacts: { id: string; name: string; email: string; phone: string; title: string; lifecycle: string }[];
  deals: {
    id: string;
    title: string;
    value: number;
    stage: string;
    status: string;
    contactName: string | null;
    expectedCloseAt: string | null;
  }[];
  activities: {
    id: string;
    type: string;
    subject: string;
    detail: string | null;
    status: string | null;
    dueAt: string | null;
    createdAt: string;
    createdBy: string | null;
  }[];
  stats: { contactsCount: number; openDealsValue: number; wonDealsValue: number; totalDeals: number };
}

const SIZES = ["1-10", "11-50", "51-200", "201-1000", "1000+"] as const;

export function OrganizationsClient() {
  const { can } = useUser();
  const canManage = can("crm.organizations.manage");
  const list = useApi<{ items: OrgRow[]; total: number }>(
    "/api/crm/organizations?pageSize=500&dir=asc"
  );

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<OrgRow | null>(null);

  const items = useMemo(() => list.data?.items ?? [], [list.data]);
  const totalOpen = items.reduce((s, o) => s + o.openDealsValue, 0);
  const totalContacts = items.reduce((s, o) => s + o.contactsCount, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Organizations"
        description="Company accounts with contacts, open opportunities and relationship history."
        actions={
          canManage ? (
            <CreateButton
              label="New organization"
              onClick={() => {
                setEditing(null);
                setFormOpen(true);
              }}
            />
          ) : null
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Organizations" value={items.length} icon={Building2} tone="brand" />
        <StatCard label="Linked contacts" value={totalContacts} icon={Users} tone="orange" />
        <StatCard
          label="Open deal value"
          value={fmt.inrCompact(totalOpen)}
          icon={TrendingUp}
          tone="green"
        />
        <StatCard
          label="Active relationships"
          value={items.filter((o) => o.openDealsCount > 0).length}
          icon={Briefcase}
          tone="amber"
        />
      </div>

      {list.loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 w-full rounded-2xl" />
          ))}
        </div>
      ) : list.error ? (
        <EmptyState icon={Building2} title="Could not load organizations" hint={list.error} />
      ) : items.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No organizations yet"
          hint={canManage ? "Add your first company account." : "Organizations will appear here."}
          action={
            canManage ? (
              <Button
                onClick={() => {
                  setEditing(null);
                  setFormOpen(true);
                }}
              >
                New organization
              </Button>
            ) : null
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((org) => (
            <button
              key={org.id}
              type="button"
              onClick={() => setSelectedId(org.id)}
              className="group rounded-2xl border bg-card p-5 text-left shadow-sm transition hover:border-brand/40 hover:shadow-md"
              aria-label={`Open ${org.name}`}
            >
              <div className="flex items-start gap-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300">
                  <Building2 className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[15px] font-bold text-foreground">{org.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {org.industry ?? "—"}
                    {org.city ? ` · ${org.city}` : ""}
                  </p>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {org.size ? <TextBadge>{org.size} employees</TextBadge> : null}
                {org.domain ? <TextBadge>{org.domain}</TextBadge> : null}
                <TextBadge>{org.contactsCount} contact(s)</TextBadge>
              </div>
              <div className="mt-3 flex items-center justify-between border-t pt-3">
                <div>
                  <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Open deals</p>
                  <p className="text-sm font-bold text-foreground">
                    {fmt.inrCompact(org.openDealsValue)}
                    <span className="ml-1 text-[11px] font-medium text-muted-foreground">
                      ({org.openDealsCount})
                    </span>
                  </p>
                </div>
                {org.ownerName ? (
                  <span className="flex items-center gap-2">
                    <InitialsAvatar name={org.ownerName} />
                    <span className="max-w-24 truncate text-xs text-muted-foreground">{org.ownerName}</span>
                  </span>
                ) : null}
              </div>
            </button>
          ))}
        </div>
      )}

      <OrgSheet
        orgId={selectedId}
        canManage={canManage}
        onOpenChange={(open) => !open && setSelectedId(null)}
        onChanged={list.refetch}
        onEdit={(org) => {
          setEditing(org);
          setFormOpen(true);
        }}
      />

      <OrgFormDialog open={formOpen} onOpenChange={setFormOpen} org={editing} onSaved={list.refetch} />
    </div>
  );
}

/* ── Organization detail sheet ────────────────────────────────────────────── */

function OrgSheet({
  orgId,
  canManage,
  onOpenChange,
  onChanged,
  onEdit,
}: {
  orgId: string | null;
  canManage: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
  onEdit: (org: OrgRow) => void;
}) {
  const { toast } = useToast();
  const detail = useApi<OrgDetail>(orgId ? `/api/crm/organizations/${orgId}` : null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [logOpen, setLogOpen] = useState(false);
  const [deletePending, setDeletePending] = useState(false);

  const org = detail.data?.organization ?? null;

  async function remove() {
    if (!org) return;
    setDeletePending(true);
    try {
      await api.delete(`/api/crm/organizations/${org.id}`);
      toast({ title: "Organization deleted" });
      setDeleteOpen(false);
      onOpenChange(false);
      onChanged();
    } catch (e) {
      toast({
        title: "Delete failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setDeletePending(false);
    }
  }

  return (
    <Sheet open={!!orgId} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full overflow-y-auto p-0 sm:max-w-xl">
        {detail.loading && !org ? (
          <div className="space-y-3 p-6">
          <SheetTitle className="sr-only">Organization details</SheetTitle>
            <Skeleton className="h-8 w-2/3" />
            <Skeleton className="h-24 w-full rounded-2xl" />
            <Skeleton className="h-40 w-full rounded-2xl" />
          </div>
        ) : detail.error ? (
          <div className="p-6 text-sm text-destructive">{detail.error}</div>
        ) : org ? (
          <div className="space-y-6 p-6">
            <SheetHeader className="p-0">
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300">
                  <Building2 className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <SheetTitle className="text-lg font-bold leading-tight">{org.name}</SheetTitle>
                  <SheetDescription className="mt-0.5 text-xs">
                    {org.industry ?? "—"}
                    {org.city ? ` · ${org.city}` : ""}
                  </SheetDescription>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {org.size ? <TextBadge>{org.size} employees</TextBadge> : null}
                    {org.website ? (
                      <a
                        href={org.website}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 rounded-md border bg-muted/50 px-1.5 py-0.5 text-[11px] text-brand hover:underline dark:text-violet-300"
                      >
                        <Globe className="h-3 w-3" /> Website
                      </a>
                    ) : null}
                    <TextBadge>Owner: {detail.data?.owner?.name ?? "Unassigned"}</TextBadge>
                  </div>
                </div>
                {canManage ? (
                  <div className="flex shrink-0 flex-col gap-1.5">
                    <Button variant="outline" size="sm" className="rounded-xl" onClick={() => onEdit(org)}>
                      <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="rounded-xl text-destructive hover:text-destructive"
                      onClick={() => setDeleteOpen(true)}
                    >
                      <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete
                    </Button>
                  </div>
                ) : null}
              </div>
            </SheetHeader>

            <div className="grid grid-cols-3 gap-3">
              <MiniStat label="Contacts" value={detail.data?.stats.contactsCount ?? 0} />
              <MiniStat label="Open value" value={fmt.inrCompact(detail.data?.stats.openDealsValue ?? 0)} />
              <MiniStat label="Won value" value={fmt.inrCompact(detail.data?.stats.wonDealsValue ?? 0)} />
            </div>

            {org.notes ? (
              <div className="rounded-2xl border bg-muted/40 p-4 text-[13px] leading-relaxed text-muted-foreground">
                {org.notes}
              </div>
            ) : null}

            {/* Contacts */}
            <SheetSection title={`Contacts (${detail.data?.contacts.length ?? 0})`}>
              {(detail.data?.contacts ?? []).length === 0 ? (
                <p className="rounded-2xl border border-dashed p-4 text-center text-xs text-muted-foreground">
                  No contacts linked yet.
                </p>
              ) : (
                <div className="space-y-2">
                  {(detail.data?.contacts ?? []).map((c) => (
                    <div key={c.id} className="flex items-center gap-3 rounded-xl border bg-card px-3.5 py-2.5">
                      <InitialsAvatar name={c.name} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-semibold text-foreground">{c.name}</p>
                        <p className="truncate text-[11px] text-muted-foreground">
                          {c.title ?? c.email ?? "—"}
                        </p>
                      </div>
                      <StatusBadge value={c.lifecycle} />
                    </div>
                  ))}
                </div>
              )}
            </SheetSection>

            {/* Deals */}
            <SheetSection title={`Deals (${detail.data?.deals.length ?? 0})`}>
              {(detail.data?.deals ?? []).length === 0 ? (
                <p className="rounded-2xl border border-dashed p-4 text-center text-xs text-muted-foreground">
                  No deals for this organization yet.
                </p>
              ) : (
                <div className="space-y-2">
                  {(detail.data?.deals ?? []).map((d) => (
                    <div key={d.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-card px-3.5 py-2.5">
                      <div className="min-w-0">
                        <p className="truncate text-[13px] font-semibold text-foreground">{d.title}</p>
                        {d.contactName ? (
                          <p className="truncate text-[11px] text-muted-foreground">{d.contactName}</p>
                        ) : null}
                      </div>
                      <span className="flex items-center gap-2">
                        <span className="text-[13px] font-bold text-brand dark:text-violet-300">{fmt.inrCompact(d.value)}</span>
                        <StatusBadge value={d.stage} />
                        <StatusBadge value={d.status} />
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </SheetSection>

            {canManage ? (
              <Button variant="outline" className="rounded-xl" onClick={() => setLogOpen(true)}>
                Log activity
              </Button>
            ) : null}

            <SheetSection title={`Timeline (${detail.data?.activities.length ?? 0})`}>
              <Timeline
                items={(detail.data?.activities ?? []).map((a) => ({
                  id: a.id,
                  type: a.type,
                  subject: a.subject,
                  detail: a.detail,
                  status: a.status,
                  createdAt: a.createdAt,
                  actor: a.createdBy,
                  dueAt: a.dueAt,
                }))}
              />
            </SheetSection>

            {org ? (
              <>
                <LogActivityDialog
                  open={logOpen}
                  onOpenChange={setLogOpen}
                  links={{ organizationId: org.id }}
                  defaultOwnerId={org.ownerId}
                  onLogged={() => {
                    detail.refetch();
                    onChanged();
                  }}
                />
                <ConfirmDialog
                  open={deleteOpen}
                  onOpenChange={setDeleteOpen}
                  title="Delete this organization?"
                  description={`"${org.name}" will be permanently removed. Organizations with contacts or deals cannot be deleted.`}
                  loading={deletePending}
                  onConfirm={remove}
                />
              </>
            ) : null}
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

function MiniStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl border bg-card p-3.5 text-center">
      <p className="text-lg font-bold text-foreground">{value}</p>
      <p className="mt-0.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
    </div>
  );
}

/* ── New / edit organization dialog ──────────────────────────────────────── */

function OrgFormDialog({
  open,
  onOpenChange,
  org,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  org: OrgRow | null;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);
  const [initedFor, setInitedFor] = useState<string | null>(null);

  function blank() {
    return {
      name: "",
      domain: "",
      industry: "",
      size: "none",
      city: "",
      phone: "",
      website: "",
      notes: "",
      ownerId: "",
    };
  }

  if (open && initedFor !== (org?.id ?? "new")) {
    setInitedFor(org?.id ?? "new");
    if (org) {
      setForm({
        name: org.name,
        domain: org.domain ?? "",
        industry: org.industry ?? "",
        size: org.size ?? "none",
        city: org.city ?? "",
        phone: org.phone ?? "",
        website: org.website ?? "",
        notes: org.notes ?? "",
        ownerId: org.ownerId ?? "",
      });
    } else {
      setForm(blank());
    }
  }
  if (!open && initedFor) setInitedFor(null);

  const set = (key: keyof ReturnType<typeof blank>) => (v: string) => setForm((f) => ({ ...f, [key]: v }));

  async function submit() {
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        domain: form.domain.trim() || null,
        industry: form.industry.trim() || null,
        size: form.size === "none" ? null : form.size,
        city: form.city.trim() || null,
        phone: form.phone.trim() || null,
        website: form.website.trim() || null,
        notes: form.notes.trim() || null,
        ownerId: form.ownerId || null,
      };
      if (org) {
        await api.patch(`/api/crm/organizations/${org.id}`, payload);
        toast({ title: "Organization updated" });
      } else {
        await api.post("/api/crm/organizations", payload);
        toast({ title: "Organization created", description: payload.name });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({
        title: org ? "Update failed" : "Could not create organization",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{org ? `Edit ${org.name}` : "New organization"}</DialogTitle>
          <DialogDescription>
            {org ? "Update the company profile." : "Add a company account to the CRM."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Company name" className="sm:col-span-2">
            <Input value={form.name} onChange={(e) => set("name")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Domain">
            <Input value={form.domain} onChange={(e) => set("domain")(e.target.value)} placeholder="company.com" className="h-9 rounded-xl" />
          </Field>
          <Field label="Industry">
            <Input value={form.industry} onChange={(e) => set("industry")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Company size">
            <Select value={form.size} onValueChange={set("size")}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Not set</SelectItem>
                {SIZES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="City">
            <Input value={form.city} onChange={(e) => set("city")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => set("phone")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Website">
            <Input value={form.website} onChange={(e) => set("website")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Owner" className="sm:col-span-2">
            <UserSelect
              value={form.ownerId || null}
              onChange={(v) => setForm((f) => ({ ...f, ownerId: v ?? "" }))}
              ariaLabel="Organization owner"
            />
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={form.notes} onChange={(e) => set("notes")(e.target.value)} className="min-h-20 rounded-xl" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {org ? "Save changes" : "Create organization"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
