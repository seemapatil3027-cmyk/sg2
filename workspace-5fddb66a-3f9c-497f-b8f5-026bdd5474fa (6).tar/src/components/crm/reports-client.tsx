"use client";

import Link from "next/link";
import { fmt, useApi } from "@/lib/api-client";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { LoadingBlock, ErrorBlock, EmptyState } from "@/components/platform/states";
import { AreaTrend, BarsChart, DonutChart } from "@/components/platform/charts";
import { FlowDiagram, type FlowStep } from "@/components/platform/flow";
import { StatusBadge } from "@/components/platform/status-badge";
import {
  Users,
  TrendingUp,
  Trophy,
  UserPlus,
  Target,
  Handshake,
  FileText,
  MessagesSquare,
  Trophy as TrophyIcon,
  Clock,
} from "lucide-react";
import { TextBadge } from "@/components/crm/crm-shared";

/* ── Types ────────────────────────────────────────────────────────────────── */

interface ReportsData {
  funnel: { key: string; label: string; count: number }[];
  leadsBySource: { name: string; value: number }[];
  dealsByStage: { stage: string; label: string; count: number; value: number }[];
  revenueTrend: { month: string; value: number }[];
  ownerPerformance: {
    userId: string;
    name: string;
    role: string;
    leads: number;
    converted: number;
    dealsWon: number;
    revenue: number;
    activities: number;
  }[];
  followUpsDue: {
    id: string;
    type: string;
    subject: string;
    priority: string;
    dueAt: string | null;
    leadId: string | null;
    leadName: string | null;
    contactName: string | null;
    dealTitle: string | null;
    ownerName: string | null;
  }[];
  stats: {
    totalLeads: number;
    converted: number;
    conversionRate: number;
    pipelineValue: number;
    totalRevenue: number;
    activities: number;
  };
}

const FLOW_STEPS: FlowStep[] = [
  { icon: UserPlus, label: "Lead", sub: "captured", tone: "brand" },
  { icon: Target, label: "Qualification", sub: "new → contacted", tone: "brand" },
  { icon: Users, label: "Contact", sub: "engaged", tone: "amber" },
  { icon: Handshake, label: "Opportunity", sub: "qualified", tone: "amber" },
  { icon: FileText, label: "Proposal", sub: "sent", tone: "orange" },
  { icon: MessagesSquare, label: "Negotiation", sub: "terms", tone: "orange" },
  { icon: TrophyIcon, label: "Won / Lost", sub: "closed", tone: "green" },
];

export function ReportsClient() {
  const { data, loading, error, refetch } = useApi<ReportsData>("/api/crm/reports");

  if (loading) return <LoadingBlock label="Crunching numbers…" className="min-h-40" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;
  if (!data) return <EmptyState title="No report data" />;

  const funnelData = data.funnel.map((f) => ({ stage: f.label, count: f.count }));
  const won = data.dealsByStage.find((d) => d.stage === "WON");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Sales Reports"
        description="Funnel health, revenue trend and team performance — updated live from the CRM."
      />

      {/* Journey flow */}
      <div className="rounded-2xl border bg-card p-4 shadow-sm sm:p-5">
        <FlowDiagram steps={FLOW_STEPS} />
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total leads" value={data.stats.totalLeads} icon={Users} tone="brand" />
        <StatCard
          label="Conversion rate"
          value={`${data.stats.conversionRate}%`}
          hint={`${data.stats.converted} converted`}
          icon={TrendingUp}
          tone="orange"
        />
        <StatCard
          label="Open pipeline"
          value={fmt.inrCompact(data.stats.pipelineValue)}
          icon={Target}
          tone="amber"
        />
        <StatCard
          label="Revenue (6 mo)"
          value={fmt.inrCompact(data.stats.totalRevenue)}
          hint={won ? `${won.count} deals won` : undefined}
          icon={Trophy}
          tone="green"
        />
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground">Lead funnel</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">Leads by canonical pipeline stage.</p>
          <div className="mt-3">
            <BarsChart data={funnelData} xKey="stage" bars={[{ key: "count", name: "Leads" }]} horizontal height={260} />
          </div>
        </div>
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground">Leads by source</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">Where enquiries come from.</p>
          <div className="mt-3">
            <DonutChart data={data.leadsBySource} height={260} />
          </div>
        </div>
        <div className="rounded-2xl border bg-card p-5 shadow-sm lg:col-span-2">
          <h3 className="text-sm font-bold text-foreground">Revenue — deals won per month</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">Closed-won deal value over the last 6 months.</p>
          <div className="mt-3">
            <AreaTrend data={data.revenueTrend} xKey="month" yKey="value" currency height={240} />
          </div>
        </div>
      </div>

      {/* Owner performance */}
      <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
        <div className="border-b px-5 py-4">
          <h3 className="text-sm font-bold text-foreground">Owner performance</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">Per CRM team member — leads, conversions, wins and workload.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <th className="px-5 py-3">Owner</th>
                <th className="px-5 py-3 text-right">Leads</th>
                <th className="px-5 py-3 text-right">Converted</th>
                <th className="px-5 py-3 text-right">Deals won</th>
                <th className="px-5 py-3 text-right">Revenue</th>
                <th className="px-5 py-3 text-right">Activities</th>
              </tr>
            </thead>
            <tbody>
              {data.ownerPerformance.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-xs text-muted-foreground">
                    No CRM performance data yet.
                  </td>
                </tr>
              ) : (
                data.ownerPerformance.map((p) => (
                  <tr key={p.userId} className="border-b transition last:border-0 hover:bg-accent/40">
                    <td className="px-5 py-3">
                      <p className="font-semibold text-foreground">{p.name}</p>
                      <p className="text-[11px] text-muted-foreground">{p.role.replace("_", " ")}</p>
                    </td>
                    <td className="px-5 py-3 text-right tabular-nums">{p.leads}</td>
                    <td className="px-5 py-3 text-right tabular-nums">{p.converted}</td>
                    <td className="px-5 py-3 text-right tabular-nums">{p.dealsWon}</td>
                    <td className="px-5 py-3 text-right font-semibold tabular-nums text-foreground">
                      {fmt.inrCompact(p.revenue)}
                    </td>
                    <td className="px-5 py-3 text-right tabular-nums">{p.activities}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Follow-ups due */}
      <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-bold text-foreground">
              <Clock className="h-4 w-4 text-brand" /> Follow-ups due next
            </h3>
            <p className="mt-0.5 text-xs text-muted-foreground">The next 10 open activities by due date.</p>
          </div>
          <Link href="/crm/activities" className="text-xs font-semibold text-brand hover:underline dark:text-violet-300">
            View all
          </Link>
        </div>
        {data.followUpsDue.length === 0 ? (
          <p className="px-5 py-8 text-center text-xs text-muted-foreground">No scheduled follow-ups. 🎉</p>
        ) : (
          <ul className="divide-y">
            {data.followUpsDue.map((f) => {
              const overdue = f.dueAt ? new Date(f.dueAt).getTime() < Date.now() : false;
              return (
                <li key={f.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-5 py-3">
                  <StatusBadge value={f.priority} />
                  <p className="min-w-0 flex-1 truncate text-[13px] font-semibold text-foreground">{f.subject}</p>
                  {f.leadId && f.leadName ? (
                    <Link
                      href="/crm/leads"
                      className="text-xs font-medium text-brand hover:underline dark:text-violet-300"
                    >
                      {f.leadName}
                    </Link>
                  ) : (
                    <TextBadge>{f.contactName ?? f.dealTitle ?? f.type.replace("_", " ")}</TextBadge>
                  )}
                  <span className={overdue ? "text-xs font-semibold text-rose-600 dark:text-rose-300" : "text-xs text-muted-foreground"}>
                    {fmt.dateTime(f.dueAt)}
                  </span>
                  {f.ownerName ? <TextBadge>{f.ownerName}</TextBadge> : null}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
