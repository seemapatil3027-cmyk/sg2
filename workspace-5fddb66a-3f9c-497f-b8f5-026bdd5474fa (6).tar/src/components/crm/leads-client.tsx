"use client";

import { useMemo, useState } from "react";
import { api, fmt, useApi } from "@/lib/api-client";
import { normalizeLeadStatus, LEAD_STATUSES, LEAD_STATUS_LABELS, LEAD_SOURCES } from "@/lib/crm-status";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { StatusBadge } from "@/components/platform/status-badge";
import { CreateButton } from "@/components/platform/states";
import { DataTable, type Column } from "@/components/platform/data-table";
import { Timeline } from "@/components/platform/flow";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Sparkles,
  Target,
  UserCheck,
  UserX,
  TrendingUp,
  Pencil,
  Trash2,
  ArrowRightLeft,
  Loader2,
  Plus,
  CalendarClock,
} from "lucide-react";
import {
  ConfirmDialog,
  Field,
  InitialsAvatar,
  LogActivityDialog,
  ScoreBar,
  SheetSection,
  TextBadge,
  useCoursesBasic,
  useUsersBasic,
} from "@/components/crm/crm-shared";

/* ── Types ────────────────────────────────────────────────────────────────── */

export interface LeadRow {
  id: string;
  name: string;
  phone: string;
  email: string;
  source: string;
  note: string | null;
  itemSlug: string | null;
  status: string;
  score: number;
  ownerId: string | null;
  contactId: string | null;
  convertedAt: string | null;
  lostReason: string | null;
  city: string | null;
  education: string | null;
  experience: string | null;
  program: string | null;
  mode: string | null;
  nextFollowUpAt: string | null;
  createdAt: string;
  updatedAt: string;
  ownerName: string | null;
}

interface ActivityRow {
  id: string;
  type: string;
  subject: string;
  detail: string | null;
  status: string | null;
  dueAt: string | null;
  createdAt: string;
  createdBy: string | null;
}

interface LeadDetail {
  lead: LeadRow;
  owner: { id: string; name: string; email: string } | null;
  contact: { id: string; name: string; email: string; lifecycle: string } | null;
  activities: ActivityRow[];
}

interface LeadsData {
  items: LeadRow[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  counts: Record<string, number>;
  stats: {
    total: number;
    newThisWeek: number;
    qualified: number;
    converted: number;
    lost: number;
    conversionRate: number;
  };
}

type TabKey = "ALL" | "NEW" | "CONTACTED" | "QUALIFIED" | "CONVERTED" | "LOST";

const toLocalInput = (d: string | null | undefined): string => {
  if (!d) return "";
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

/* ── Main client ──────────────────────────────────────────────────────────── */

export function LeadsClient() {
  const { can } = useUser();
  const canManage = can("crm.leads.manage");
  const list = useApi<LeadsData>("/api/crm/leads?pageSize=500&sort=createdAt&dir=desc");

  const [tab, setTab] = useState<TabKey>("ALL");
  const [ownerFilter, setOwnerFilter] = useState<string>("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<LeadRow | null>(null);

  const rows = useMemo(() => {
    let out = list.data?.items ?? [];
    if (tab !== "ALL") out = out.filter((r) => normalizeLeadStatus(r.status) === tab);
    if (ownerFilter === "unassigned") out = out.filter((r) => !r.ownerId);
    else if (ownerFilter !== "all") out = out.filter((r) => r.ownerId === ownerFilter);
    return out;
  }, [list.data, tab, ownerFilter]);

  const counts = list.data?.counts ?? {};
  const stats = list.data?.stats;

  const columns: Column<LeadRow>[] = [
    {
      key: "name",
      header: "Lead",
      sortable: true,
      render: (r) => (
        <div className="min-w-0">
          <p className="truncate font-semibold text-foreground">{r.name}</p>
          <p className="truncate text-xs text-muted-foreground">{r.email}</p>
        </div>
      ),
    },
    {
      key: "score",
      header: "Score",
      sortable: true,
      render: (r) => <ScoreBar score={r.score} />,
    },
    {
      key: "status",
      header: "Status",
      render: (r) => <StatusBadge value={LEAD_STATUS_LABELS[normalizeLeadStatus(r.status)] ?? r.status} />,
    },
    { key: "source", header: "Source", render: (r) => <TextBadge>{r.source}</TextBadge> },
    {
      key: "program",
      header: "Program",
      render: (r) => <span className="block max-w-44 truncate text-muted-foreground">{r.program ?? "—"}</span>,
    },
    {
      key: "owner",
      header: "Owner",
      render: (r) =>
        r.ownerName ? (
          <span className="flex items-center gap-2">
            <InitialsAvatar name={r.ownerName} />
            <span className="truncate text-[13px]">{r.ownerName}</span>
          </span>
        ) : (
          <span className="text-xs italic text-muted-foreground">Unassigned</span>
        ),
    },
    {
      key: "createdAt",
      header: "Created",
      sortable: true,
      render: (r) => <span className="whitespace-nowrap text-muted-foreground">{fmt.date(r.createdAt)}</span>,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Leads"
        description="Every inbound enquiry in one funnel — qualify, assign, follow up and convert."
        actions={
          canManage ? (
            <CreateButton
              label="New lead"
              onClick={() => {
                setEditing(null);
                setFormOpen(true);
              }}
            />
          ) : null
        }
      />

      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total leads" value={stats?.total ?? "—"} icon={Users} tone="brand" />
        <StatCard label="New · 7 days" value={stats?.newThisWeek ?? "—"} icon={Sparkles} tone="amber" />
        <StatCard label="Qualified" value={stats?.qualified ?? "—"} icon={Target} tone="orange" />
        <StatCard label="Converted" value={stats?.converted ?? "—"} icon={UserCheck} tone="green" />
        <StatCard label="Lost" value={stats?.lost ?? "—"} icon={UserX} tone="rose" />
        <StatCard
          label="Conversion rate"
          value={stats ? `${stats.conversionRate}%` : "—"}
          icon={TrendingUp}
          tone="sky"
        />
      </div>

      {/* Status tabs */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)}>
        <TabsList className="h-9 flex-wrap justify-start gap-1 rounded-xl bg-muted/60 p-1">
          {(["ALL", ...LEAD_STATUSES] as TabKey[]).map((key) => (
            <TabsTrigger
              key={key}
              value={key}
              className="rounded-lg px-3 text-[13px] data-[state=active]:bg-card data-[state=active]:shadow-sm"
            >
              {key === "ALL" ? "All" : LEAD_STATUS_LABELS[key]}
              <span className="ml-1.5 text-[11px] font-semibold text-muted-foreground">
                {counts[key] ?? 0}
              </span>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      <DataTable<LeadRow>
        columns={columns}
        rows={rows}
        loading={list.loading}
        error={list.error}
        onRetry={list.refetch}
        rowKey={(r) => r.id}
        onRowClick={(r) => setSelectedId(r.id)}
        searchPlaceholder="Search name, email, phone…"
        pageSize={10}
        emptyTitle="No leads here yet"
        emptyHint={
          canManage
            ? "Capture enquiries from the website funnel or add one manually."
            : "Leads assigned to you will appear here."
        }
        filterFn={(r, q) =>
          [r.name, r.email, r.phone, r.program, r.source]
            .filter(Boolean)
            .some((v) => String(v).toLowerCase().includes(q))
        }
        toolbar={
          <Select value={ownerFilter} onValueChange={setOwnerFilter}>
            <SelectTrigger className="h-9 w-44 rounded-xl" aria-label="Filter by owner">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All owners</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {(list.data?.items ?? [])
                .filter((r) => r.ownerId && r.ownerName)
                .filter((r, i, arr) => arr.findIndex((x) => x.ownerId === r.ownerId) === i)
                .map((r) => (
                  <SelectItem key={r.ownerId} value={r.ownerId!}>
                    {r.ownerName}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        }
      />

      <LeadSheet
        leadId={selectedId}
        canManage={canManage}
        onOpenChange={(open) => !open && setSelectedId(null)}
        onChanged={() => {
          list.refetch();
        }}
        onEdit={(lead) => {
          setEditing(lead);
          setFormOpen(true);
        }}
      />
      <LeadFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        lead={editing}
        onSaved={() => {
          list.refetch();
        }}
      />
    </div>
  );
}

/* ── Lead detail sheet ────────────────────────────────────────────────────── */

function LeadSheet({
  leadId,
  canManage,
  onOpenChange,
  onChanged,
  onEdit,
}: {
  leadId: string | null;
  canManage: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
  onEdit: (lead: LeadRow) => void;
}) {
  const { toast } = useToast();
  const detail = useApi<LeadDetail>(leadId ? `/api/crm/leads/${leadId}` : null);
  const [convertOpen, setConvertOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deletePending, setDeletePending] = useState(false);
  const [scoreDraft, setScoreDraft] = useState<string>("");
  const [followUpDraft, setFollowUpDraft] = useState<string>("");
  const [savingField, setSavingField] = useState(false);

  const lead = detail.data?.lead ?? null;

  // keep local drafts in sync when a different lead opens
  const [syncedId, setSyncedId] = useState<string | null>(null);
  if (lead && syncedId !== lead.id) {
    setSyncedId(lead.id);
    setScoreDraft(String(lead.score ?? 0));
    setFollowUpDraft(toLocalInput(lead.nextFollowUpAt));
  }
  if (!lead && syncedId) setSyncedId(null);

  async function patch(fields: Record<string, unknown>, message: string) {
    if (!lead) return;
    setSavingField(true);
    try {
      await api.patch(`/api/crm/leads/${lead.id}`, fields);
      toast({ title: message });
      detail.refetch();
      onChanged();
    } catch (e) {
      toast({
        title: "Update failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSavingField(false);
    }
  }

  async function remove() {
    if (!lead) return;
    setDeletePending(true);
    try {
      await api.delete(`/api/crm/leads/${lead.id}`);
      toast({ title: "Lead deleted" });
      setDeleteOpen(false);
      onOpenChange(false);
      onChanged();
    } catch (e) {
      toast({
        title: "Delete failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setDeletePending(false);
    }
  }

  const converted = lead ? normalizeLeadStatus(lead.status) === "CONVERTED" : false;
  const showConvert = canManage && lead && !lead.contactId && !converted;

  return (
    <Sheet open={!!leadId} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full overflow-y-auto p-0 sm:max-w-xl">
        {detail.loading && !lead ? (
          <div className="space-y-3 p-6">
            <SheetTitle className="sr-only">Lead details</SheetTitle>
            <Skeleton className="h-8 w-2/3" />
            <Skeleton className="h-24 w-full rounded-2xl" />
            <Skeleton className="h-40 w-full rounded-2xl" />
          </div>
        ) : detail.error ? (
          <div className="p-6 text-sm text-destructive">
            <SheetTitle className="sr-only">Lead details</SheetTitle>
            {detail.error}
          </div>
        ) : lead ? (
          <div className="space-y-6 p-6">
            <SheetHeader className="p-0">
              <div className="flex items-start gap-3">
                <InitialsAvatar name={lead.name} className="h-11 w-11 text-sm" />
                <div className="min-w-0 flex-1">
                  <SheetTitle className="text-lg font-bold leading-tight">{lead.name}</SheetTitle>
                  <SheetDescription className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs">
                    <a className="hover:underline" href={`mailto:${lead.email}`}>{lead.email}</a>
                    <span>·</span>
                    <a className="hover:underline" href={`tel:${lead.phone}`}>{lead.phone}</a>
                  </SheetDescription>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <StatusBadge value={LEAD_STATUS_LABELS[normalizeLeadStatus(lead.status)] ?? lead.status} />
                    <ScoreBar score={lead.score} />
                    {detail.data?.contact ? (
                      <TextBadge className="border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300">
                        Customer · {detail.data.contact.name}
                      </TextBadge>
                    ) : null}
                  </div>
                </div>
                {canManage ? (
                  <div className="flex shrink-0 flex-col gap-1.5">
                    <Button variant="outline" size="sm" className="rounded-xl" onClick={() => onEdit(lead)}>
                      <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit
                    </Button>
                    {!lead.contactId ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-xl text-destructive hover:text-destructive"
                        onClick={() => setDeleteOpen(true)}
                      >
                        <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete
                      </Button>
                    ) : null}
                  </div>
                ) : null}
              </div>
            </SheetHeader>

            {showConvert ? (
              <div className="rounded-2xl border border-brand/25 bg-brand-soft p-4 dark:border-brand/40 dark:bg-brand/10">
                <p className="text-sm font-semibold text-foreground">Ready to close?</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Convert this lead into a customer record — optionally open a deal and enroll them in a course.
                </p>
                <Button className="mt-3 rounded-xl" onClick={() => setConvertOpen(true)}>
                  <ArrowRightLeft className="mr-2 h-4 w-4" /> Convert to customer
                </Button>
              </div>
            ) : null}

            {/* Quick controls */}
            {canManage ? (
              <SheetSection title="Quick actions">
                <div className="grid grid-cols-2 gap-3 rounded-2xl border bg-card p-4">
                  <Field label="Status">
                    <Select
                      value={normalizeLeadStatus(lead.status)}
                      onValueChange={(v) => patch({ status: v }, "Stage updated")}
                      disabled={savingField}
                    >
                      <SelectTrigger className="h-9 rounded-xl" aria-label="Lead status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LEAD_STATUSES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {LEAD_STATUS_LABELS[s]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Owner">
                    <OwnerPatchSelect
                      value={lead.ownerId}
                      onPick={(ownerId) => patch({ ownerId }, ownerId ? "Owner updated" : "Owner unassigned")}
                      disabled={savingField}
                    />
                  </Field>
                  <Field label="Follow-up date">
                    <div className="flex items-center gap-1.5">
                      <Input
                        type="datetime-local"
                        value={followUpDraft}
                        onChange={(e) => setFollowUpDraft(e.target.value)}
                        className="h-9 rounded-xl"
                        aria-label="Next follow-up"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-9 rounded-xl"
                        disabled={savingField}
                        onClick={() =>
                          patch(
                            { nextFollowUpAt: followUpDraft ? new Date(followUpDraft).toISOString() : null },
                            "Follow-up saved"
                          )
                        }
                      >
                        Save
                      </Button>
                    </div>
                  </Field>
                  <Field label="Lead score (0–100)">
                    <div className="flex items-center gap-1.5">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={scoreDraft}
                        onChange={(e) => setScoreDraft(e.target.value)}
                        className="h-9 rounded-xl"
                        aria-label="Lead score"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-9 rounded-xl"
                        disabled={savingField}
                        onClick={() => patch({ score: Math.max(0, Math.min(100, Number(scoreDraft) || 0)) }, "Score saved")}
                      >
                        Save
                      </Button>
                    </div>
                  </Field>
                </div>
              </SheetSection>
            ) : null}

            {/* Profile */}
            <SheetSection title="Profile">
              <div className="grid grid-cols-2 gap-x-4 gap-y-3 rounded-2xl border bg-card p-4 text-[13px] sm:grid-cols-3">
                <ProfileItem label="Source" value={lead.source} />
                <ProfileItem label="Program" value={lead.program} />
                <ProfileItem label="City" value={lead.city} />
                <ProfileItem label="Education" value={lead.education} />
                <ProfileItem label="Experience" value={lead.experience} />
                <ProfileItem label="Mode" value={lead.mode} />
                <ProfileItem label="Owner" value={detail.data?.owner?.name ?? null} />
                <ProfileItem label="Created" value={fmt.date(lead.createdAt)} />
                <ProfileItem
                  label="Next follow-up"
                  value={lead.nextFollowUpAt ? fmt.dateTime(lead.nextFollowUpAt) : null}
                  icon={<CalendarClock className="h-3 w-3" />}
                />
              </div>
              {lead.note ? (
                <div className="rounded-2xl border bg-muted/40 p-4 text-[13px] leading-relaxed text-muted-foreground">
                  {lead.note}
                </div>
              ) : null}
            </SheetSection>

            {/* Quick activity composer */}
            {canManage ? (
              <QuickComposer
                leadId={lead.id}
                onLogged={() => {
                  detail.refetch();
                  onChanged();
                }}
              />
            ) : null}

            {/* Timeline */}
            <SheetSection title={`Timeline (${detail.data?.activities.length ?? 0})`}>
              {detail.loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-14 w-full rounded-xl" />
                  ))}
                </div>
              ) : (
                <Timeline
                  items={(detail.data?.activities ?? []).map((a) => ({
                    id: a.id,
                    type: a.type,
                    subject: a.subject,
                    detail: a.detail,
                    status: a.status,
                    createdAt: a.createdAt,
                    actor: a.createdBy,
                    dueAt: a.dueAt,
                  }))}
                />
              )}
            </SheetSection>

            <LogActivityHolder
              leadId={lead.id}
              onLogged={() => {
                detail.refetch();
                onChanged();
              }}
            />

            {canManage ? (
              <>
                <ConvertDialog
                  open={convertOpen}
                  onOpenChange={setConvertOpen}
                  lead={lead}
                  onConverted={() => {
                    detail.refetch();
                    onChanged();
                  }}
                />
                <ConfirmDialog
                  open={deleteOpen}
                  onOpenChange={setDeleteOpen}
                  title="Delete this lead?"
                  description={`"${lead.name}" and their activity history will be permanently removed.`}
                  loading={deletePending}
                  onConfirm={remove}
                />
              </>
            ) : null}
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

function ProfileItem({
  label,
  value,
  icon,
}: {
  label: string;
  value?: string | null;
  icon?: React.ReactNode;
}) {
  return (
    <div className="min-w-0">
      <p className="flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {icon}
        {label}
      </p>
      <p className="mt-0.5 truncate font-medium text-foreground" title={value ?? undefined}>
        {value || "—"}
      </p>
    </div>
  );
}

/** Owner select wired to PATCH (shared by quick actions). */
function OwnerPatchSelect({
  value,
  onPick,
  disabled,
}: {
  value: string | null;
  onPick: (ownerId: string | null) => void;
  disabled?: boolean;
}) {
  const { users, loading } = useUsersBasic();
  return (
    <Select
      value={value ?? "__unassigned"}
      onValueChange={(v) => onPick(v === "__unassigned" ? null : v)}
      disabled={disabled || loading}
    >
      <SelectTrigger className="h-9 rounded-xl" aria-label="Assign owner">
        <SelectValue placeholder="Unassigned" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="__unassigned">Unassigned</SelectItem>
        {users.map((u) => (
          <SelectItem key={u.id} value={u.id}>
            {u.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/** Inline quick composer rendered in the sheet (type + subject + detail + due). */
function QuickComposer({ leadId, onLogged }: { leadId: string; onLogged: () => void }) {
  const { toast } = useToast();
  const [type, setType] = useState("CALL");
  const [subject, setSubject] = useState("");
  const [detail, setDetail] = useState("");
  const [dueAt, setDueAt] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (subject.trim().length < 2) {
      toast({ title: "Add a short subject first", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.post("/api/crm/activities", {
        type,
        subject: subject.trim(),
        detail: detail.trim() || null,
        dueAt: dueAt || null,
        leadId,
      });
      setSubject("");
      setDetail("");
      setDueAt("");
      toast({ title: "Activity logged" });
      onLogged();
    } catch (e) {
      toast({
        title: "Could not log activity",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <SheetSection title="Log activity">
      <div className="space-y-2.5 rounded-2xl border bg-card p-4">
        <div className="grid grid-cols-2 gap-2.5">
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="h-9 rounded-xl" aria-label="Activity type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {["CALL", "MEETING", "TASK", "FOLLOW_UP", "NOTE", "EMAIL", "WHATSAPP", "DEMO"].map((t) => (
                <SelectItem key={t} value={t}>
                  {t.replace("_", " ")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            type="datetime-local"
            value={dueAt}
            onChange={(e) => setDueAt(e.target.value)}
            className="h-9 rounded-xl"
            aria-label="Due date"
          />
        </div>
        <Input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Subject — e.g. Follow-up call about fee structure"
          className="h-9 rounded-xl"
        />
        <Textarea
          value={detail}
          onChange={(e) => setDetail(e.target.value)}
          placeholder="Notes (optional)"
          className="min-h-16 rounded-xl"
        />
        <Button size="sm" className="rounded-xl" onClick={submit} disabled={saving}>
          {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <Plus className="mr-2 h-3.5 w-3.5" />}
          Add to timeline
        </Button>
      </div>
    </SheetSection>
  );
}

/** Detailed activity dialog entry point for the sheet. */
function LogActivityHolder({ leadId, onLogged }: { leadId: string; onLogged: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" className="rounded-xl" onClick={() => setOpen(true)}>
        Detailed entry…
      </Button>
      <LogActivityDialog
        open={open}
        onOpenChange={setOpen}
        links={{ leadId }}
        onLogged={onLogged}
      />
    </>
  );
}

/* ── Convert dialog ───────────────────────────────────────────────────────── */

function ConvertDialog({
  open,
  onOpenChange,
  lead,
  onConverted,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead: LeadRow;
  onConverted: () => void;
}) {
  const { toast } = useToast();
  const { courses, loading: coursesLoading } = useCoursesBasic();
  const [createDeal, setCreateDeal] = useState(true);
  const [dealTitle, setDealTitle] = useState("");
  const [dealValue, setDealValue] = useState("");
  const [dealClose, setDealClose] = useState("");
  const [enroll, setEnroll] = useState(false);
  const [courseId, setCourseId] = useState("");
  const [batchName, setBatchName] = useState("");
  const [payment, setPayment] = useState("");
  const [saving, setSaving] = useState(false);
  const [inited, setInited] = useState(false);

  if (open && !inited) {
    setInited(true);
    setCreateDeal(true);
    setDealTitle(`${lead.name}${lead.program ? ` — ${lead.program}` : " — New opportunity"}`);
    setDealValue("");
    setDealClose("");
    setEnroll(false);
    setCourseId(courses[0]?.id ?? "");
    setBatchName("");
    setPayment("");
  }
  if (!open && inited) setInited(false);

  async function submit() {
    setSaving(true);
    try {
      const body: Record<string, unknown> = {};
      if (createDeal) {
        body.createDeal = {
          title: dealTitle.trim() || undefined,
          value: dealValue ? Math.max(0, Math.round(Number(dealValue))) : 0,
          expectedCloseAt: dealClose || null,
        };
      }
      if (enroll && courseId) {
        body.enrollCourseId = courseId;
        if (batchName.trim()) body.batchName = batchName.trim();
        if (payment) body.paymentAmount = Math.max(1, Math.round(Number(payment)));
      }
      const res = await api.post<{ contactId: string; dealId?: string; enrollmentId?: string }>(
        `/api/crm/leads/${lead.id}/convert`,
        body
      );
      toast({
        title: `${lead.name} is now a customer`,
        description: [
          "Contact created",
          res.dealId ? "deal opened" : null,
          res.enrollmentId ? "LMS enrollment created" : null,
        ]
          .filter(Boolean)
          .join(" · "),
      });
      onOpenChange(false);
      onConverted();
    } catch (e) {
      toast({
        title: "Conversion failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Convert {lead.name} to customer</DialogTitle>
          <DialogDescription>
            A contact record is always created. Choose what else to set up.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <label className="flex items-start gap-3 rounded-xl border p-3">
            <Checkbox
              checked={createDeal}
              onCheckedChange={(v) => setCreateDeal(v === true)}
              className="mt-0.5"
              aria-label="Create deal"
            />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">Create a deal</p>
              <p className="text-xs text-muted-foreground">Opens a proposal-stage opportunity for this customer.</p>
              {createDeal ? (
                <div className="mt-3 grid gap-2.5">
                  <Input
                    value={dealTitle}
                    onChange={(e) => setDealTitle(e.target.value)}
                    placeholder="Deal title"
                    className="h-9 rounded-xl"
                  />
                  <div className="grid grid-cols-2 gap-2.5">
                    <Input
                      type="number"
                      min={0}
                      value={dealValue}
                      onChange={(e) => setDealValue(e.target.value)}
                      placeholder="Value (₹)"
                      className="h-9 rounded-xl"
                    />
                    <Input
                      type="date"
                      value={dealClose}
                      onChange={(e) => setDealClose(e.target.value)}
                      className="h-9 rounded-xl"
                      aria-label="Expected close date"
                    />
                  </div>
                </div>
              ) : null}
            </div>
          </label>

          <label className="flex items-start gap-3 rounded-xl border p-3">
            <Checkbox
              checked={enroll}
              onCheckedChange={(v) => setEnroll(v === true)}
              className="mt-0.5"
              aria-label="Enroll in course"
            />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">Enroll in a course</p>
              <p className="text-xs text-muted-foreground">Creates an active LMS enrollment for this learner.</p>
              {enroll ? (
                <div className="mt-3 grid gap-2.5">
                  <Select value={courseId} onValueChange={setCourseId}>
                    <SelectTrigger className="h-9 rounded-xl" aria-label="Course">
                      {coursesLoading ? "Loading courses…" : <SelectValue placeholder="Select course" />}
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="grid grid-cols-2 gap-2.5">
                    <Input
                      value={batchName}
                      onChange={(e) => setBatchName(e.target.value)}
                      placeholder="Batch (e.g. DA-0126)"
                      className="h-9 rounded-xl"
                    />
                    <Input
                      type="number"
                      min={0}
                      value={payment}
                      onChange={(e) => setPayment(e.target.value)}
                      placeholder="Payment received (₹)"
                      className="h-9 rounded-xl"
                    />
                  </div>
                </div>
              ) : null}
            </div>
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Convert
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── New / edit lead dialog ───────────────────────────────────────────────── */

function LeadFormDialog({
  open,
  onOpenChange,
  lead,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead: LeadRow | null;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const { users } = useUsersBasic();
  const [form, setForm] = useState(defaultForm);
  const [saving, setSaving] = useState(false);
  const [initedFor, setInitedFor] = useState<string | null>(null);

  function defaultForm() {
    return {
      name: "",
      email: "",
      phone: "",
      source: "website",
      city: "",
      education: "",
      experience: "",
      program: "",
      mode: "none",
      score: "0",
      ownerId: "",
      note: "",
    };
  }

  // Reset when the dialog opens for a new lead, or hydrate for edit.
  if (open && initedFor !== (lead?.id ?? "new")) {
    setInitedFor(lead?.id ?? "new");
    if (lead) {
      setForm({
        name: lead.name,
        email: lead.email,
        phone: lead.phone,
        source: lead.source,
        city: lead.city ?? "",
        education: lead.education ?? "",
        experience: lead.experience ?? "",
        program: lead.program ?? "",
        mode: lead.mode ?? "none",
        score: String(lead.score ?? 0),
        ownerId: lead.ownerId ?? "",
        note: lead.note ?? "",
      });
    } else {
      setForm(defaultForm());
    }
  }
  if (!open && initedFor) setInitedFor(null);

  const set = (key: keyof ReturnType<typeof defaultForm>) => (v: string) =>
    setForm((f) => ({ ...f, [key]: v }));

  async function submit() {
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        source: form.source,
        city: form.city.trim() || null,
        education: form.education.trim() || null,
        experience: form.experience.trim() || null,
        program: form.program.trim() || null,
        mode: form.mode === "none" ? null : form.mode,
        note: form.note.trim() || null,
        ownerId: form.ownerId || null,
      };
      if (lead) {
        payload.score = Math.max(0, Math.min(100, Number(form.score) || 0));
        await api.patch(`/api/crm/leads/${lead.id}`, payload);
        toast({ title: "Lead updated" });
      } else {
        payload.score = Math.max(0, Math.min(100, Number(form.score) || 0));
        await api.post("/api/crm/leads", payload);
        toast({ title: "Lead created", description: `${form.name.trim()} added to the funnel.` });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({
        title: lead ? "Update failed" : "Could not create lead",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{lead ? `Edit ${lead.name}` : "New lead"}</DialogTitle>
          <DialogDescription>
            {lead ? "Update the lead profile and assignment." : "Capture a new enquiry into the funnel."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Full name">
            <Input value={form.name} onChange={(e) => set("name")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Email">
            <Input type="email" value={form.email} onChange={(e) => set("email")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => set("phone")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Source">
            <Select value={form.source} onValueChange={set("source")}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LEAD_SOURCES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Program interest">
            <Input value={form.program} onChange={(e) => set("program")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="City">
            <Input value={form.city} onChange={(e) => set("city")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Education">
            <Input value={form.education} onChange={(e) => set("education")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Experience">
            <Input value={form.experience} onChange={(e) => set("experience")(e.target.value)} className="h-9 rounded-xl" />
          </Field>
          <Field label="Preferred mode">
            <Select value={form.mode} onValueChange={set("mode")}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Not set</SelectItem>
                <SelectItem value="online">Online</SelectItem>
                <SelectItem value="classroom">Classroom</SelectItem>
                <SelectItem value="hybrid">Hybrid</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Lead score (0–100)">
            <Input
              type="number"
              min={0}
              max={100}
              value={form.score}
              onChange={(e) => set("score")(e.target.value)}
              className="h-9 rounded-xl"
            />
          </Field>
          <Field label="Owner" className="sm:col-span-2">
            <Select value={form.ownerId} onValueChange={(v) => set("ownerId")(v === "" ? "" : v)}>
              <SelectTrigger className="h-9 rounded-xl">
                <SelectValue placeholder="Unassigned" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">Unassigned</SelectItem>
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={form.note} onChange={(e) => set("note")(e.target.value)} className="min-h-20 rounded-xl" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {lead ? "Save changes" : "Create lead"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
