"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { LogOut, ShieldOff } from "lucide-react";
import { useUser } from "@/hooks/use-user";

export function LogOutButton() {
  const router = useRouter();
  const { signOut } = useUser();
  return (
    <Button
      className="rounded-xl"
      onClick={async () => {
        await signOut();
        router.push("/");
        router.refresh();
      }}
    >
      <LogOut className="mr-2 h-4 w-4" /> Sign out
    </Button>
  );
}

/** Rendered by pages when the session lacks the required permission. */
export function AccessDenied({ permission }: { permission?: string }) {
  return (
    <div className="flex min-h-[50vh] items-center justify-center">
      <div className="w-full max-w-md rounded-3xl border bg-card p-8 text-center shadow-lg">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
          <ShieldOff className="h-6 w-6" />
        </div>
        <h1 className="mt-4 text-lg font-bold">Access restricted</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {permission
            ? `Your role does not include the "${permission}" permission. Ask a Super Admin if you need access.`
            : "Your role does not have access to this area."}
        </p>
      </div>
    </div>
  );
}
