"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { NAV_GROUPS } from "@/components/platform/nav-config";
import { useUser, type SessionUser } from "@/hooks/use-user";
import { api, fmt } from "@/lib/api-client";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Bell,
  ChevronDown,
  ExternalLink,
  Globe,
  GraduationCap,
  LogOut,
  Menu,
  Moon,
  Settings,
  Sun,
  User,
  X,
} from "lucide-react";

interface AppUser extends SessionUser {
  uid?: string;
}

interface NotificationItem {
  id: string;
  title: string;
  body: string | null;
  type: string;
  link: string | null;
  readAt: string | null;
  createdAt: string;
}

export function AppShell({ session, children }: { session: AppUser; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { signOut } = useUser();
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs] = useState<NotificationItem[]>([]);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const data = await api.get<{ items: NotificationItem[]; unread: number }>(
          "/api/notifications?limit=8"
        );
        if (alive) {
          setNotifs(data.items);
          setUnread(data.unread);
        }
      } catch {
        /* silent — the bell simply shows empty */
      }
    };
    void load();
    const t = setInterval(load, 30000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [pathname]);

  async function markAllRead() {
    try {
      await api.post("/api/notifications", { all: true });
      setNotifs((n) => n.map((x) => ({ ...x, readAt: x.readAt ?? new Date().toISOString() })));
      setUnread(0);
    } catch {
      /* noop */
    }
  }

  async function handleSignOut() {
    await signOut();
    router.push("/");
    router.refresh();
  }

  const initials = session.name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const isActive = (href: string, exact?: boolean) =>
    exact ? pathname === href : pathname === href || pathname.startsWith(`${href}/`);

  const sidebar = (
    <SidebarContent
      session={session}
      pathname={pathname}
      isActive={isActive}
      onNavigate={() => setMobileOpen(false)}
    />
  );

  return (
    <div className="flex min-h-screen bg-muted/40 dark:bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r bg-card lg:flex">
        {sidebar}
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          {sidebar}
        </SheetContent>
      </Sheet>

      <div className="flex min-w-0 flex-1 flex-col lg:pl-64">
        {/* Topbar */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur sm:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 rounded-xl lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
          >
            <Menu className="h-5 w-5" />
          </Button>

          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-xl"
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
              aria-label="Toggle theme"
            >
              {theme === "dark" || resolvedTheme === "dark" ? (
                <Sun className="h-4.5 w-4.5" />
              ) : (
                <Moon className="h-4.5 w-4.5" />
              )}
            </Button>

            <Link
              href="/"
              target="_blank"
              className="hidden h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium text-muted-foreground transition hover:bg-accent hover:text-foreground sm:inline-flex"
            >
              <Globe className="h-4 w-4" />
              Website
              <ExternalLink className="h-3 w-3 opacity-60" />
            </Link>

            {/* Notifications */}
            <DropdownMenu open={notifOpen} onOpenChange={setNotifOpen}>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative h-9 w-9 rounded-xl" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}>
                  <Bell className="h-4.5 w-4.5" />
                  {unread > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[10px] font-bold text-white">
                      {unread > 9 ? "9+" : unread}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 rounded-xl p-0">
                <div className="flex items-center justify-between border-b px-3 py-2.5">
                  <p className="text-sm font-semibold">Notifications</p>
                  {unread > 0 && (
                    <button onClick={markAllRead} className="text-xs font-medium text-brand hover:underline">
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifs.length === 0 ? (
                    <p className="px-3 py-8 text-center text-xs text-muted-foreground">You&apos;re all caught up 🎉</p>
                  ) : (
                    notifs.map((n) => (
                      <Link
                        key={n.id}
                        href={n.link ?? "#"}
                        onClick={() => {
                          if (!n.readAt) void api.post("/api/notifications", { id: n.id }).catch(() => undefined);
                          setNotifOpen(false);
                        }}
                        className={cn(
                          "block border-b px-3 py-2.5 transition last:border-0 hover:bg-accent/60",
                          !n.readAt && "bg-brand-soft/60 dark:bg-brand/10"
                        )}
                      >
                        <p className="text-[13px] font-semibold leading-snug">{n.title}</p>
                        {n.body ? <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.body}</p> : null}
                        <p className="mt-1 text-[10px] text-muted-foreground">{fmt.relative(n.createdAt)}</p>
                      </Link>
                    ))
                  )}
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-xl py-1 pl-1 pr-2 transition hover:bg-accent" aria-label="Account menu">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-xs font-bold text-white">
                    {initials}
                  </span>
                  <span className="hidden min-w-0 text-left sm:block">
                    <span className="block max-w-32 truncate text-[13px] font-semibold leading-tight">{session.name}</span>
                    <span className="block max-w-32 truncate text-[11px] leading-tight text-muted-foreground">{session.roleLabel}</span>
                  </span>
                  <ChevronDown className="hidden h-3.5 w-3.5 opacity-60 sm:block" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 rounded-xl">
                <DropdownMenuLabel>
                  <p className="text-sm font-semibold">{session.name}</p>
                  <p className="text-xs font-normal text-muted-foreground">{session.email}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => router.push("/settings")}>
                  <User className="mr-2 h-4 w-4" /> Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => router.push("/settings")}>
                  <Settings className="mr-2 h-4 w-4" /> Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
          <div className="mx-auto w-full max-w-7xl">{children}</div>
        </main>
      </div>
    </div>
  );
}

function SidebarContent({
  session,
  pathname,
  isActive,
  onNavigate,
}: {
  session: AppUser;
  pathname: string;
  isActive: (href: string, exact?: boolean) => boolean;
  onNavigate?: () => void;
}) {
  const perms = session.permissions ?? [];
  const has = (perm: string) => perms.includes("*") || perms.includes(perm);
  const router = useRouter();

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center gap-2.5 border-b px-5">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand to-brand-dark text-white">
          <GraduationCap className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <p className="truncate text-[15px] font-extrabold leading-tight tracking-tight">
            Skill<span className="text-brand">Gorila</span>
          </p>
          <p className="text-[10px] font-medium uppercase tracking-widest text-muted-foreground">CRM + LMS</p>
        </div>
      </div>

      <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-4" aria-label="Platform navigation">
        {NAV_GROUPS.map((group, gi) => {
          const items = group.items.filter((i) => has(i.permission));
          if (items.length === 0) return null;
          return (
            <div key={gi}>
              {group.label ? (
                <p className="mb-1.5 px-2.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/70">
                  {group.label}
                </p>
              ) : null}
              <ul className="space-y-0.5">
                {items.map((item) => {
                  const active = isActive(item.href, item.exact);
                  return (
                    <li key={item.href}>
                      <button
                        type="button"
                        onClick={() => {
                          router.push(item.href);
                          onNavigate?.();
                        }}
                        aria-current={active ? "page" : undefined}
                        className={cn(
                          "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-[13px] font-medium transition",
                          active
                            ? "bg-brand text-white shadow-sm"
                            : "text-muted-foreground hover:bg-accent hover:text-foreground"
                        )}
                      >
                        <item.icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                        {item.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      <div className="border-t p-3">
        <div className="flex items-center gap-2.5 rounded-xl bg-muted/60 px-3 py-2.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand text-xs font-bold text-white">
            {session.name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase()}
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-semibold leading-tight">{session.name}</p>
            <p className="truncate text-[10px] leading-tight text-muted-foreground">{session.roleLabel}</p>
          </div>
          <X className="ml-auto hidden h-3 w-3 opacity-0" aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
