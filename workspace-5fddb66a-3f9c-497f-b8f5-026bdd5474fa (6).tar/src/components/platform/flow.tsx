"use client";

import { cn } from "@/lib/utils";
import { ChevronRight, type LucideIcon } from "lucide-react";
import {
  PhoneCall,
  Mail,
  MessageCircle,
  CalendarDays,
  StickyNote,
  CheckCircle2,
  Circle,
  Clock,
  Target,
  GraduationCap,
  Trophy,
  UserPlus,
  Repeat,
  Presentation,
} from "lucide-react";

/* ── Flow diagram (process/step visualization) ── */

export interface FlowStep {
  icon: LucideIcon;
  label: string;
  sub?: string;
  tone?: "brand" | "green" | "orange" | "amber" | "slate" | "rose";
}

const TONE_CLASSES: Record<string, string> = {
  brand: "border-brand/25 bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300",
  green: "border-emerald-200 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30",
  orange: "border-orange-200 bg-orange-50 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300 dark:border-orange-500/30",
  amber: "border-amber-200 bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30",
  rose: "border-rose-200 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/30",
  slate: "border-border bg-muted text-muted-foreground",
};

export function FlowDiagram({ steps, className }: { steps: FlowStep[]; className?: string }) {
  return (
    <div className={cn("flex flex-wrap items-stretch gap-1.5", className)} role="list" aria-label="Process flow">
      {steps.map((s, i) => (
        <div key={i} className="flex items-center gap-1.5" role="listitem">
          <div className={cn("flex items-center gap-2 rounded-xl border px-3 py-2", TONE_CLASSES[s.tone ?? "slate"])}>
            <s.icon className="h-4 w-4 shrink-0" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-xs font-semibold leading-tight">{s.label}</p>
              {s.sub ? <p className="truncate text-[10px] leading-tight opacity-70">{s.sub}</p> : null}
            </div>
          </div>
          {i < steps.length - 1 ? (
            <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/60" aria-hidden="true" />
          ) : null}
        </div>
      ))}
    </div>
  );
}

/* ── Activity timeline ── */

export const ACTIVITY_ICONS: Record<string, LucideIcon> = {
  CALL: PhoneCall,
  EMAIL: Mail,
  WHATSAPP: MessageCircle,
  MEETING: CalendarDays,
  TASK: CheckCircle2,
  FOLLOW_UP: Repeat,
  NOTE: StickyNote,
  DEMO: Presentation,
  STAGE_CHANGE: Target,
  CONVERTED: UserPlus,
  ENROLLMENT: GraduationCap,
  CERTIFICATE: Trophy,
};

export function activityIcon(type: string): LucideIcon {
  return ACTIVITY_ICONS[type?.toUpperCase()] ?? StickyNote;
}

export interface TimelineItem {
  id: string;
  type: string;
  subject: string;
  detail?: string | null;
  status?: string | null;
  createdAt: string | Date;
  actor?: string | null;
  completedAt?: string | Date | null;
  dueAt?: string | Date | null;
}

export function Timeline({ items, className }: { items: TimelineItem[]; className?: string }) {
  if (items.length === 0) {
    return <p className="py-6 text-center text-xs text-muted-foreground">No activity recorded yet.</p>;
  }
  return (
    <ol className={cn("relative space-y-4 border-l pl-5", className)} aria-label="Activity timeline">
      {items.map((item) => {
        const Icon = activityIcon(item.type);
        const done = item.status === "COMPLETED";
        return (
          <li key={item.id} className="relative">
            <span
              className={cn(
                "absolute -left-[27px] flex h-5 w-5 items-center justify-center rounded-full border bg-background",
                done ? "border-emerald-300 text-emerald-600 dark:text-emerald-400" : "border-border text-muted-foreground"
              )}
            >
              <Icon className="h-3 w-3" aria-hidden="true" />
            </span>
            <div className="rounded-xl border bg-muted/40 px-3 py-2">
              <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-0.5">
                <p className="text-[13px] font-semibold leading-snug text-foreground">{item.subject}</p>
                <time className="text-[11px] text-muted-foreground">{fmtRel(item.createdAt)}</time>
              </div>
              {item.detail ? <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{item.detail}</p> : null}
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
                <span className="font-medium">{item.actor ?? "System"}</span>
                {item.status ? (
                  <span className={cn("inline-flex items-center gap-1", done && "text-emerald-600 dark:text-emerald-400")}>
                    {done ? <CheckCircle2 className="h-3 w-3" /> : <Circle className="h-3 w-3" />}
                    {done ? "Completed" : "Open"}
                  </span>
                ) : null}
                {item.dueAt && !done ? (
                  <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                    <Clock className="h-3 w-3" /> Due {fmtRel(item.dueAt)}
                  </span>
                ) : null}
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function fmtRel(d: string | Date): string {
  const diff = Date.now() - new Date(d).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}
