import {
  LayoutDashboard,
  Users,
  UserPlus,
  Building2,
  Target,
  KanbanSquare,
  ListChecks,
  BarChart3,
  BookOpen,
  GraduationCap,
  ClipboardCheck,
  Award,
  LineChart,
  UserCog,
  ShieldCheck,
  ScrollText,
  Settings,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  permission: string;
  exact?: boolean;
}

export interface NavGroup {
  label: string | null; // null = standalone section
  items: NavItem[];
}

/** Permission-filtered navigation — items render only when the signed-in
 * user's role holds the matching permission. */
export const NAV_GROUPS: NavGroup[] = [
  {
    label: null,
    items: [{ href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, permission: "dashboard.view", exact: true }],
  },
  {
    label: "CRM",
    items: [
      { href: "/crm/leads", label: "Leads", icon: UserPlus, permission: "crm.leads.view" },
      { href: "/crm/pipeline", label: "Pipeline", icon: KanbanSquare, permission: "crm.deals.view" },
      { href: "/crm/deals", label: "Deals", icon: Target, permission: "crm.deals.view" },
      { href: "/crm/contacts", label: "Contacts", icon: Users, permission: "crm.contacts.view" },
      { href: "/crm/organizations", label: "Organizations", icon: Building2, permission: "crm.organizations.view" },
      { href: "/crm/activities", label: "Activities & Tasks", icon: ListChecks, permission: "crm.activities.view" },
      { href: "/crm/reports", label: "Sales Reports", icon: BarChart3, permission: "crm.reports.view" },
    ],
  },
  {
    label: "LMS",
    items: [
      { href: "/lms/courses", label: "Courses", icon: BookOpen, permission: "lms.courses.view" },
      { href: "/lms/enrollments", label: "Enrollments", icon: GraduationCap, permission: "lms.enrollments.view" },
      { href: "/lms/progress", label: "Progress", icon: LineChart, permission: "lms.progress.view" },
      { href: "/lms/assessments", label: "Assessments", icon: ClipboardCheck, permission: "lms.assessments.view" },
      { href: "/lms/certificates", label: "Certificates", icon: Award, permission: "lms.certificates.view" },
      { href: "/lms/reports", label: "LMS Reports", icon: BarChart3, permission: "lms.reports.view" },
    ],
  },
  {
    label: "Administration",
    items: [
      { href: "/admin/users", label: "Users", icon: UserCog, permission: "admin.users.view" },
      { href: "/admin/roles", label: "Roles & Permissions", icon: ShieldCheck, permission: "admin.roles.view" },
      { href: "/admin/audit", label: "Audit Log", icon: ScrollText, permission: "admin.audit.view" },
    ],
  },
  {
    label: null,
    items: [{ href: "/settings", label: "Settings", icon: Settings, permission: "dashboard.view" }],
  },
];
