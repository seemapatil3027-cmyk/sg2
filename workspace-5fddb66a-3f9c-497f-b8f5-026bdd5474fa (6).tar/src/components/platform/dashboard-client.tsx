"use client";

import { useApi, fmt } from "@/lib/api-client";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { StatusBadge } from "@/components/platform/status-badge";
import { LoadingBlock, ErrorBlock } from "@/components/platform/states";
import { AreaTrend, BarsChart, DonutChart } from "@/components/platform/charts";
import { FlowDiagram, activityIcon } from "@/components/platform/flow";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  UserPlus,
  Target,
  Trophy,
  TrendingUp,
  BookOpen,
  GraduationCap,
  Award,
  ClipboardCheck,
  Users,
  Flame,
  CalendarClock,
  Wallet,
  type LucideIcon,
} from "lucide-react";

interface DashboardData {
  role: string;
  crm: {
    totalLeads: number;
    newLeads7d: number;
    convertedLeads: number;
    lostLeads: number;
    conversionRate: number;
    avgLeadScore: number;
    openTasks: number;
    followUpsDue: number;
    activeDeals: number;
    wonDeals: number;
    lostDeals: number;
    pipelineValue: number;
    revenueWon: number;
    funnel: { stage: string; count: number }[];
    leadsBySource: { name: string; value: number }[];
    dealsByStage: { stage: string; count: number; value: number }[];
    revenueTrend: { month: string; value: number }[];
  } | null;
  lms: {
    totalCourses: number;
    publishedCourses: number;
    totalEnrollments: number;
    activeEnrollments: number;
    completedEnrollments: number;
    completionRate: number;
    avgProgress: number;
    certificatesIssued: number;
    pendingGrading: number;
    quizAttempts: number;
    avgQuizScore: number;
    quizPassRate: number;
    enrollmentsTrend: { month: string; value: number }[];
    coursePerformance: { title: string; enrollments: number; avgProgress: number }[];
  } | null;
  recentActivities: {
    id: string;
    type: string;
    subject: string;
    status: string;
    priority: string;
    dueAt: string | null;
    owner: string;
    createdAt: string;
  }[];
  myTasks: {
    id: string;
    type: string;
    subject: string;
    status: string;
    priority: string;
    dueAt: string | null;
  }[];
}

const CRM_ROLES = ["SUPER_ADMIN", "ADMIN", "CRM_MANAGER", "CRM_EXECUTIVE"];
const LMS_ROLES = ["SUPER_ADMIN", "ADMIN", "LMS_MANAGER", "INSTRUCTOR"];
const REPORT_ROLES = ["SUPER_ADMIN", "ADMIN", "CRM_MANAGER", "LMS_MANAGER"];

export function DashboardClient({ role, name }: { role: string; name: string }) {
  const { data, loading, error, refetch } = useApi<DashboardData>("/api/platform/dashboard");

  if (loading) return <LoadingBlock label="Loading your dashboard…" className="min-h-[50vh]" />;
  if (error) return <ErrorBlock message={error} onRetry={refetch} />;
  if (!data) return null;

  const showCrm = CRM_ROLES.includes(role) && data.crm;
  const showLms = LMS_ROLES.includes(role) && data.lms;
  const showReports = REPORT_ROLES.includes(role);
  const firstName = name.split(" ")[0];

  const greeting =
    new Date().getHours() < 12 ? "Good morning" : new Date().getHours() < 17 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-brand to-brand-dark p-6 text-white sm:p-8">
        <div className="pointer-events-none absolute -right-16 -top-24 h-64 w-64 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-48 w-48 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
        <div className="relative">
          <p className="text-xs font-semibold uppercase tracking-widest text-white/70">{greeting}, {firstName} 👋</p>
          <h1 className="mt-1 text-xl font-bold sm:text-2xl">Here&apos;s what&apos;s happening across the platform</h1>
          {/* Integrated business flow — Lead → Customer → Enrollment → Learning → Certificate */}
          <div className="mt-5 hidden flex-wrap items-center gap-1.5 md:flex" aria-label="Integrated business flow">
            {[
              { icon: UserPlus, label: "Lead" },
              { icon: Target, label: "Deal" },
              { icon: Users, label: "Customer" },
              { icon: GraduationCap, label: "Enrollment" },
              { icon: BookOpen, label: "Learning" },
              { icon: Award, label: "Certificate" },
            ].map((s, i, arr) => (
              <span key={s.label} className="flex items-center gap-1.5">
                <span className="flex items-center gap-1.5 rounded-xl border border-white/25 bg-white/10 px-3 py-1.5 text-xs font-semibold backdrop-blur">
                  <s.icon className="h-3.5 w-3.5" aria-hidden="true" />
                  {s.label}
                </span>
                {i < arr.length - 1 && <span className="text-white/50">→</span>}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        {showCrm && (
          <>
            <StatCard label="Total Leads" value={data.crm!.totalLeads} hint={`+${data.crm!.newLeads7d} in last 7 days`} icon={UserPlus} tone="brand" />
            <StatCard label="Pipeline Value" value={fmt.inrCompact(data.crm!.pipelineValue)} hint={`${data.crm!.activeDeals} active deals`} icon={Wallet} tone="amber" />
            <StatCard label="Revenue Won" value={fmt.inrCompact(data.crm!.revenueWon)} hint={`${data.crm!.wonDeals} deals won`} icon={Trophy} tone="green" />
            <StatCard label="Conversion Rate" value={`${data.crm!.conversionRate}%`} hint={`${data.crm!.convertedLeads} leads converted`} icon={TrendingUp} tone="orange" />
          </>
        )}
        {showLms && (
          <>
            <StatCard label="Courses" value={data.lms!.totalCourses} hint={`${data.lms!.publishedCourses} published`} icon={BookOpen} tone="brand" />
            <StatCard label="Enrollments" value={data.lms!.totalEnrollments} hint={`${data.lms!.activeEnrollments} active learners`} icon={GraduationCap} tone="sky" />
            <StatCard label="Completion Rate" value={`${data.lms!.completionRate}%`} hint={`avg progress ${data.lms!.avgProgress}%`} icon={TrendingUp} tone="green" />
            <StatCard label="Certificates Issued" value={data.lms!.certificatesIssued} hint={data.lms!.pendingGrading ? `${data.lms!.pendingGrading} submissions awaiting grade` : "all graded ✓"} icon={Award} tone="amber" />
          </>
        )}
        {!showCrm && !showLms && (
          <StatCard label="Open Tasks" value={data.myTasks.length} hint="Assigned to you" icon={ClipboardCheck} tone="brand" />
        )}
      </div>

      {/* Charts row */}
      {showReports && data.crm && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="rounded-2xl lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Revenue — deals won</CardTitle>
              <p className="text-xs text-muted-foreground">Last 6 months</p>
            </CardHeader>
            <CardContent>
              <AreaTrend data={data.crm.revenueTrend} xKey="month" yKey="value" currency height={220} />
            </CardContent>
          </Card>
          <Card className="rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Leads by source</CardTitle>
            </CardHeader>
            <CardContent>
              {data.crm.leadsBySource.length ? (
                <DonutChart data={data.crm.leadsBySource} height={220} />
              ) : (
                <p className="py-16 text-center text-xs text-muted-foreground">No leads captured yet</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {showReports && data.lms && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="rounded-2xl lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Enrollments trend</CardTitle>
              <p className="text-xs text-muted-foreground">Last 6 months</p>
            </CardHeader>
            <CardContent>
              <AreaTrend data={data.lms.enrollmentsTrend} xKey="month" yKey="value" height={220} />
            </CardContent>
          </Card>
          <Card className="rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Course performance</CardTitle>
              <p className="text-xs text-muted-foreground">Enrollments & avg progress</p>
            </CardHeader>
            <CardContent>
              {data.lms.coursePerformance.length ? (
                <BarsChart data={data.lms.coursePerformance} xKey="title" bars={[{ key: "enrollments", name: "Enrollments" }]} height={220} />
              ) : (
                <p className="py-16 text-center text-xs text-muted-foreground">No enrollments yet</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* CRM funnel + tasks */}
      {showCrm && data.crm && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="rounded-2xl lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Lead funnel</CardTitle>
              <p className="text-xs text-muted-foreground">Lead → Qualification → Contact → Opportunity → Won/Lost</p>
            </CardHeader>
            <CardContent>
              <FunnelBars funnel={data.crm.funnel} totalLeads={data.crm.totalLeads} />
            </CardContent>
          </Card>
          <Card className="rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base font-bold">
                <CalendarClock className="h-4 w-4 text-brand" /> My tasks
              </CardTitle>
              <p className="text-xs text-muted-foreground">Open items assigned to you</p>
            </CardHeader>
            <CardContent className="space-y-2">
              {data.myTasks.length === 0 ? (
                <p className="py-8 text-center text-xs text-muted-foreground">No open tasks — enjoy the calm 🎯</p>
              ) : (
                data.myTasks.map((t) => {
                  const Icon = activityIcon(t.type);
                  const overdue = t.dueAt && new Date(t.dueAt).getTime() < Date.now();
                  return (
                    <div key={t.id} className="flex items-start gap-2.5 rounded-xl border p-2.5">
                      <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-soft text-brand dark:bg-brand/15 dark:text-violet-300">
                        <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-semibold leading-snug">{t.subject}</p>
                        <p className={`text-[11px] ${overdue ? "font-semibold text-rose-600 dark:text-rose-400" : "text-muted-foreground"}`}>
                          {t.dueAt ? (overdue ? "Overdue · " : "Due ") + fmt.date(t.dueAt) : "No due date"}
                        </p>
                      </div>
                      <StatusBadge value={t.priority} className="hidden sm:inline-flex" />
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* LMS mini stats for instructors */}
      {role === "INSTRUCTOR" && data.lms && (
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Pending grading</CardTitle>
              <p className="text-xs text-muted-foreground">Assignment submissions awaiting review</p>
            </CardHeader>
            <CardContent className="flex items-center gap-4">
              <span className="text-4xl font-extrabold text-brand">{data.lms.pendingGrading}</span>
              <p className="text-xs text-muted-foreground">
                {data.lms.pendingGrading ? "Learners are waiting for your feedback." : "You're all caught up ✓"}
              </p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-bold">Assessment performance</CardTitle>
              <p className="text-xs text-muted-foreground">Quiz pass rate & average score</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="mb-1 flex justify-between text-xs font-medium">
                  <span>Average quiz score</span>
                  <span>{data.lms.avgQuizScore}%</span>
                </div>
                <Progress value={data.lms.avgQuizScore} />
              </div>
              <div>
                <div className="mb-1 flex justify-between text-xs font-medium">
                  <span>Pass rate</span>
                  <span>{data.lms.quizPassRate}%</span>
                </div>
                <Progress value={data.lms.quizPassRate} />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Recent activity */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base font-bold">
            <Flame className="h-4 w-4 text-accento" /> Recent activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.recentActivities.length === 0 ? (
            <p className="py-8 text-center text-xs text-muted-foreground">No activity recorded yet.</p>
          ) : (
            <ul className="divide-y">
              {data.recentActivities.map((a) => {
                const Icon = activityIcon(a.type);
                return (
                  <li key={a.id} className="flex items-center gap-3 py-2.5 first:pt-0 last:pb-0">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold">{a.subject}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {a.owner} · {fmt.relative(a.createdAt)}
                      </p>
                    </div>
                    <StatusBadge value={a.status} className="hidden sm:inline-flex" />
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function FunnelBars({ funnel, totalLeads }: { funnel: { stage: string; count: number }[]; totalLeads: number }) {
  const labels: Record<string, string> = {
    NEW: "New",
    CONTACTED: "Contacted",
    QUALIFIED: "Qualified",
    CONVERTED: "Converted",
    LOST: "Lost",
  };
  const tones: Record<string, string> = {
    NEW: "bg-slate-400/70 dark:bg-slate-500/60",
    CONTACTED: "bg-sky-500/70",
    QUALIFIED: "bg-amber-500/80",
    CONVERTED: "bg-emerald-500/80",
    LOST: "bg-rose-400/70",
  };
  const max = Math.max(1, ...funnel.map((f) => f.count));
  return (
    <div className="space-y-3" role="list" aria-label="Lead funnel">
      {funnel.map((f) => (
        <div key={f.stage} role="listitem">
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="font-semibold">{labels[f.stage] ?? f.stage}</span>
            <span className="text-muted-foreground">
              {f.count}
              {totalLeads > 0 && f.stage !== "LOST" ? ` · ${Math.round((f.count / totalLeads) * 100)}%` : ""}
            </span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
            <div className={`h-full rounded-full transition-all ${tones[f.stage] ?? "bg-brand"}`} style={{ width: `${Math.max(4, (f.count / max) * 100)}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}
