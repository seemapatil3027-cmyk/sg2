"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { fmt } from "@/lib/api-client";

/* Chart wrappers used across dashboards and reports. Colors come from the
 * brand chart palette (no blues/indigos). */
export const CHART_COLORS = ["#7a3be0", "#f97316", "#16a34a", "#f5b301", "#0ea5e9", "#a855f7"];

const tooltipStyle = {
  borderRadius: 12,
  border: "1px solid hsl(var(--border))",
  background: "hsl(var(--popover))",
  color: "hsl(var(--popover-foreground))",
  fontSize: 12,
  boxShadow: "0 8px 24px rgb(0 0 0 / 0.08)",
};

export function AreaTrend({
  data,
  xKey,
  yKey,
  height = 240,
  currency = false,
}: {
  data: Record<string, unknown>[];
  xKey: string;
  yKey: string;
  height?: number;
  currency?: boolean;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7a3be0" stopOpacity={0.25} />
            <stop offset="100%" stopColor="#7a3be0" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis dataKey={xKey} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
        <YAxis
          tickLine={false}
          axisLine={false}
          width={56}
          tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
          tickFormatter={(v: number) => (currency ? fmt.inrCompact(v) : String(v))}
        />
        <Tooltip
          contentStyle={tooltipStyle}
          formatter={(v) => [currency ? fmt.inr(Number(v)) : String(v), ""]}
        />
        <Area
          type="monotone"
          dataKey={yKey}
          stroke="#7a3be0"
          strokeWidth={2.5}
          fill="url(#areaFill)"
          activeDot={{ r: 4 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function BarsChart({
  data,
  xKey,
  bars,
  height = 240,
  currency = false,
  horizontal = false,
}: {
  data: Record<string, unknown>[];
  xKey: string;
  bars: { key: string; name?: string; color?: string }[];
  height?: number;
  currency?: boolean;
  horizontal?: boolean;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} layout={horizontal ? "vertical" : "horizontal"} margin={{ top: 8, right: 8, left: horizontal ? 24 : 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={!horizontal} horizontal={horizontal} />
        {horizontal ? (
          <>
            <XAxis type="number" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v: number) => (currency ? fmt.inrCompact(v) : String(v))} />
            <YAxis type="category" dataKey={xKey} tickLine={false} axisLine={false} width={110} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
          </>
        ) : (
          <>
            <XAxis dataKey={xKey} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
            <YAxis tickLine={false} axisLine={false} width={48} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
          </>
        )}
        <Tooltip cursor={{ fill: "hsl(var(--accent))", opacity: 0.5 }} contentStyle={tooltipStyle} formatter={(v) => [currency ? fmt.inr(Number(v)) : String(v), ""]} />
        {bars.map((b, i) => (
          <Bar key={b.key} dataKey={b.key} name={b.name ?? b.key} fill={b.color ?? CHART_COLORS[i % CHART_COLORS.length]} radius={horizontal ? [0, 6, 6, 0] : [6, 6, 0, 0]} maxBarSize={38} />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}

export function DonutChart({
  data,
  height = 240,
}: {
  data: { name: string; value: number }[];
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="80%" paddingAngle={3} strokeWidth={0}>
          {data.map((_, i) => (
            <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
          ))}
        </Pie>
        <Tooltip contentStyle={tooltipStyle} />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}
