"use client";

import { useState } from "react";
import { useTheme } from "next-themes";
import { toast, Toaster } from "sonner";
import { api } from "@/lib/api-client";
import { PageHeader } from "@/components/platform/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Moon, Sun, KeyRound, Loader2, Monitor } from "lucide-react";

export function SettingsClient({
  name,
  email,
  role,
  roleLabel,
}: {
  name: string;
  email: string;
  role: string;
  roleLabel: string;
}) {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    setSaving(true);
    try {
      await api.post("/api/auth/password", { currentPassword, newPassword });
      toast.success("Password updated", { description: "Use your new password next time you sign in." });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update password");
    } finally {
      setSaving(false);
    }
  }

  const initials = name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Manage your profile, security and appearance." />
      <Toaster position="top-right" richColors />

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Profile */}
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-base font-bold">Profile</CardTitle>
            <CardDescription>Your account details are managed by your administrator.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand text-lg font-bold text-white">
                {initials}
              </span>
              <div className="min-w-0">
                <p className="truncate text-sm font-bold">{name}</p>
                <p className="truncate text-xs text-muted-foreground">{email}</p>
                <Badge className="mt-1.5 bg-brand-soft text-brand hover:bg-brand-soft dark:bg-brand/15 dark:text-violet-300">
                  {roleLabel}
                </Badge>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Full name</Label>
                <Input value={name} disabled className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Work email</Label>
                <Input value={email} disabled className="rounded-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-base font-bold">Appearance</CardTitle>
            <CardDescription>Switch between light and dark themes.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { value: "light", label: "Light", icon: Sun, active: theme === "light" },
              { value: "dark", label: "Dark", icon: Moon, active: theme === "dark" },
              { value: "system", label: "System", icon: Monitor, active: theme === "system" },
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setTheme(opt.value)}
                className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left transition ${
                  opt.active
                    ? "border-brand bg-brand-soft/60 dark:bg-brand/10"
                    : "border-border hover:border-brand/40"
                }`}
              >
                <opt.icon className="h-4.5 w-4.5 text-brand" aria-hidden="true" />
                <span className="flex-1 text-sm font-semibold">{opt.label}</span>
                <Switch checked={opt.active} aria-label={opt.label} tabIndex={-1} />
              </button>
            ))}
            <p className="text-[11px] text-muted-foreground">Current resolved theme: {resolvedTheme}</p>
          </CardContent>
        </Card>

        {/* Password */}
        <Card className="rounded-2xl lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-bold">
              <KeyRound className="h-4 w-4 text-brand" /> Change password
            </CardTitle>
            <CardDescription>Passwords are hashed with scrypt — at least 8 characters.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={changePassword} className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="currentPassword" className="text-xs font-semibold">Current password</Label>
                <Input
                  id="currentPassword"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                  className="rounded-xl"
                  autoComplete="current-password"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="newPassword" className="text-xs font-semibold">New password</Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  minLength={8}
                  className="rounded-xl"
                  autoComplete="new-password"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirmPassword" className="text-xs font-semibold">Confirm new password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={8}
                  className="rounded-xl"
                  autoComplete="new-password"
                />
              </div>
              <div className="sm:col-span-3">
                <Button type="submit" disabled={saving} className="rounded-xl">
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
                  Update password
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
