"use client";

import { useState } from "react";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { LeadDialogButton } from "@/components/shared/lead-dialog-button";
import { cn } from "@/lib/utils";

type Phase = "LEARNING" | "EARNING";

interface TabDialogCta {
  kind: "dialog";
  label: string;
  source: "contact" | "callback";
  dialogTitle: string;
  dialogText?: string;
  submitLabel?: string;
}

interface TabLinkCta {
  kind: "link";
  label: string;
  href: string;
}

interface LearnEarnTab {
  id: string;
  chip: string;
  phase: Phase;
  title: string;
  sub?: string;
  bullets: string[];
  cta: TabDialogCta | TabLinkCta;
}

const TABS: LearnEarnTab[] = [
  {
    id: "curriculum",
    chip: "Curriculum",
    phase: "LEARNING",
    title: "Curriculum that matches industry trends",
    sub: "Learn from the basics with the top experts, gain skills that matter!",
    bullets: [
      "Relevant learning material designed by industry experts from top companies",
      "Learn skills that will give you a head start when you enter the industry",
      "Go from basic to advanced content that will help you to become a pro",
    ],
    cta: {
      kind: "dialog",
      label: "Contact Us",
      source: "contact",
      dialogTitle: "Contact us",
      dialogText: "We'll get back to you in the next 24 hours.",
    },
  },
  {
    id: "mentoring",
    chip: "Mentoring",
    phase: "LEARNING",
    title: "Our mentors are the industry's top 1%",
    bullets: [
      "Learn, ask questions, discuss problems with the best experts",
      "Meet your mentors in live sessions, get every doubt addressed directly",
      "Dedicated mentors will help you to solve every problem you encounter",
      "Build your network with experts from various domains and fields",
    ],
    cta: {
      kind: "dialog",
      label: "Request a Callback",
      source: "callback",
      dialogTitle: "Request a callback",
      submitLabel: "Request a Callback",
    },
  },
  {
    id: "learning-format",
    chip: "Learning format",
    phase: "LEARNING",
    title: "Experience different ways of learning",
    bullets: [
      "Learn with self-paced content and practice problems to understand the core concepts",
      "Solve real life case studies and become the talent industry is looking for",
      "Finish hands-on projects and expand your portfolio and skill sets",
      "Solve problems with experts, know the best practices in the industry",
    ],
    cta: {
      kind: "dialog",
      label: "Book a Consultation",
      source: "callback",
      dialogTitle: "Book a consultation",
      submitLabel: "Book a Consultation",
    },
  },
  {
    id: "career-coaching",
    chip: "Career coaching",
    phase: "EARNING",
    title: "Plan your career with our career counsellors",
    bullets: [
      "Tell us your career objectives, we'll help you achieve them",
      "Identify areas of improvement and build a structured career plan with our counsellors",
      "Get a personalised roadmap from learning to earning",
    ],
    cta: { kind: "link", label: "Explore Tracks", href: "/tracks" },
  },
  {
    id: "preparation",
    chip: "Preparation",
    phase: "EARNING",
    title: "Prepare to get your dream job with us",
    bullets: [
      "Create a resume that stands out with help from our counsellors",
      "Practice in mock sessions with our experts and ace your interviews with ease",
      "Get personalised feedback and tips on how to rock your interviews",
      "Make a good first impression by optimising your LinkedIn profile",
    ],
    cta: { kind: "link", label: "Explore Tracks", href: "/tracks" },
  },
  {
    id: "get-a-job",
    chip: "Get a job",
    phase: "EARNING",
    title: "Now, it's time to get your dream job!",
    bullets: [
      "Extensive support from us to get interviews in top companies",
      "Explore job vacancies in 300+ partner companies",
      "Get access to various digital job fairs that will help you explore available jobs",
    ],
    cta: { kind: "link", label: "Explore Tracks", href: "/tracks" },
  },
];

const PHASE_CHIP_STYLE: Record<Phase, string> = {
  LEARNING: "bg-brand-soft text-brand",
  EARNING: "bg-[#EAF8F0] text-[#15803D]",
};

export function LearnEarnTabs() {
  const [activeId, setActiveId] = useState<string>(TABS[0].id);
  const active = TABS.find((t) => t.id === activeId) ?? TABS[0];
  const learningTabs = TABS.filter((t) => t.phase === "LEARNING");
  const earningTabs = TABS.filter((t) => t.phase === "EARNING");

  return (
    <div>
      {/* Centered phase pill toggle */}
      <div className="flex justify-center">
        <div
          className="inline-flex items-center rounded-full border border-border bg-white p-1.5 shadow-sm"
          role="tablist"
          aria-label="Journey phases"
        >
          {(["LEARNING", "EARNING"] as const).map((p) => (
            <button
              key={p}
              type="button"
              role="tab"
              aria-selected={active.phase === p}
              onClick={() => setActiveId((TABS.find((t) => t.phase === p) ?? TABS[0]).id)}
              className={cn(
                "h-11 rounded-full px-6 text-[13px] font-bold uppercase tracking-[0.14em] transition-colors sm:px-8",
                active.phase === p
                  ? "bg-primary text-white shadow-[0_6px_18px_rgba(93,24,190,0.35)]"
                  : "text-ink-soft hover:text-ink"
              )}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-10 grid items-start gap-8 lg:grid-cols-[290px_1fr]">
        {/* Step chips grouped by phase */}
        <div className="flex flex-col gap-7">
          <ChipGroup label="Phase 1 · Learning" tabs={learningTabs} activeId={activeId} onSelect={setActiveId} />
          <ChipGroup label="Phase 2 · Earning" tabs={earningTabs} activeId={activeId} onSelect={setActiveId} />
        </div>

        {/* Active tab content panel */}
        <div
          key={active.id}
          className="animate-in fade-in slide-in-from-bottom-2 flex flex-col rounded-3xl border border-border bg-white p-6 shadow-[0_10px_36px_rgba(28,15,66,0.08)] duration-300 sm:p-8"
        >
          <span
            className={cn(
              "inline-flex w-fit rounded-full px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.14em]",
              PHASE_CHIP_STYLE[active.phase]
            )}
          >
            {active.phase}
          </span>
          <h3 className="mt-5 text-xl font-bold leading-snug text-ink sm:text-2xl">{active.title}</h3>
          {active.sub && <p className="mt-2 text-[14px] leading-6 text-ink-soft">{active.sub}</p>}
          <ul className="mt-6 flex flex-col gap-4">
            {active.bullets.map((b) => (
              <li key={b} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft">
                  <ChevronRight className="h-4 w-4 text-brand" aria-hidden="true" />
                </span>
                <span className="text-[15px] leading-6 text-ink">{b}</span>
              </li>
            ))}
          </ul>
          <div className="mt-auto pt-8">
            {active.cta.kind === "dialog" ? (
              <LeadDialogButton
                label={active.cta.label}
                source={active.cta.source}
                dialogTitle={active.cta.dialogTitle}
                dialogText={active.cta.dialogText}
                submitLabel={active.cta.submitLabel}
              />
            ) : (
              <Link
                href={active.cta.href}
                className="inline-flex h-12 items-center justify-center rounded-xl bg-primary px-8 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
              >
                {active.cta.label}
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ChipGroup({
  label,
  tabs,
  activeId,
  onSelect,
}: {
  label: string;
  tabs: LearnEarnTab[];
  activeId: string;
  onSelect: (id: string) => void;
}) {
  return (
    <div>
      <p className="mb-3 text-[11px] font-bold uppercase tracking-[0.18em] text-ink-soft/70">{label}</p>
      <div className="flex flex-col gap-2.5" role="tablist" aria-label={label}>
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={activeId === t.id}
            onClick={() => onSelect(t.id)}
            className={cn(
              "rounded-xl border px-4 py-3 text-left text-[14px] font-semibold transition",
              activeId === t.id
                ? "border-primary bg-primary text-white shadow-[0_6px_18px_rgba(93,24,190,0.3)]"
                : "border-border bg-white text-ink hover:border-brand/50 hover:bg-brand-soft/60"
            )}
          >
            {t.chip}
          </button>
        ))}
      </div>
    </div>
  );
}
