"use client";

import type { Company } from "@prisma/client";
import { cn } from "@/lib/utils";

const LOGO_STYLES: Record<string, string> = {
  Razorpay: "font-bold lowercase tracking-tight",
  Swiggy: "font-extrabold uppercase tracking-[0.2em]",
  Accenture: "font-semibold lowercase",
  Shadowfax: "font-medium lowercase tracking-wide",
  Deloitte: "font-bold",
  "Axis Bank": "font-semibold uppercase tracking-wide",
  Citibank: "font-semibold lowercase",
  Zomato: "font-bold lowercase",
  Mamaearth: "font-semibold lowercase",
  Flipkart: "font-bold italic lowercase",
  EXL: "font-bold uppercase tracking-widest",
  ZS: "font-bold uppercase tracking-widest",
  Virtusa: "font-semibold lowercase",
  Amazon: "font-bold lowercase",
  CRED: "font-bold uppercase tracking-[0.25em]",
  Snapdeal: "font-semibold lowercase",
  Kaleyla: "font-medium lowercase",
  Udaan: "font-bold lowercase",
  Rivigo: "font-bold lowercase",
  "Mu Sigma": "font-semibold",
  "HCL Technologies": "font-semibold uppercase text-[11px]",
  "AXIS Bank": "font-semibold uppercase tracking-wide",
};

export function CompanyMarquee({
  companies,
  className,
  slow = false,
  title,
}: {
  companies: Pick<Company, "id" | "name">[];
  className?: string;
  slow?: boolean;
  title?: string;
}) {
  const doubled = [...companies, ...companies];
  return (
    <div className={cn("marquee-paused relative w-full overflow-hidden", className)}>
      {title && <p className="mb-6 text-center text-[15px] text-ink">{title}</p>}
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-background to-transparent" />
      <div className={cn("flex w-max items-center gap-14", slow ? "animate-marquee-slow" : "animate-marquee")}>
        {doubled.map((c, i) => (
          <span
            key={`${c.id}-${i}`}
            aria-hidden={i >= companies.length}
            className={cn(
              "select-none whitespace-nowrap text-[22px] text-gray-400 transition hover:text-gray-600",
              LOGO_STYLES[c.name] ?? "font-semibold"
            )}
          >
            {c.name}
          </span>
        ))}
      </div>
    </div>
  );
}

/** Static grid of company "logos" (text badges) */
export function CompanyGrid({
  companies,
  className,
}: {
  companies: Pick<Company, "id" | "name">[];
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-center justify-center gap-x-8 gap-y-5", className)}>
      {companies.map((c) => (
        <span
          key={c.id}
          className={cn("select-none text-[19px] text-gray-400", LOGO_STYLES[c.name] ?? "font-semibold")}
        >
          {c.name}
        </span>
      ))}
    </div>
  );
}
