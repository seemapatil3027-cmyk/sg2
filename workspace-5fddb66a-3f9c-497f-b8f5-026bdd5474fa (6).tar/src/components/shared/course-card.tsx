"use client";

import Link from "next/link";
import { Star, Users } from "lucide-react";
import type { CourseFull } from "@/lib/data";
import { DynIcon } from "@/lib/icons";
import { cn } from "@/lib/utils";

export function CourseCard({ course, className }: { course: CourseFull; className?: string }) {
  return (
    <div className={cn("group flex flex-col rounded-2xl border border-border bg-white p-6 transition hover:shadow-[0_12px_32px_rgba(34,28,51,0.1)]", className)}>
      <div className="flex items-center justify-between">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-soft">
          <DynIcon name={course.icon} className="h-8 w-8 text-brand" />
        </div>
        <span className="inline-flex items-center gap-1 rounded-full bg-[#FEF3C7] px-3 py-1 text-[12.5px] font-semibold text-[#B45309]">
          <Star className="h-3.5 w-3.5 fill-current" /> {course.rating} Rating
        </span>
      </div>
      <h3 className="mt-4 text-[18px] font-bold leading-snug text-ink group-hover:text-brand">{course.title}</h3>
      <p className="clamp-3 mt-2 text-[13.5px] leading-5.5 text-ink-soft">{course.description}</p>
      <div className="mt-3 flex items-center gap-1.5 text-[13px] font-medium text-ink-soft">
        <Users className="h-4 w-4 text-brand" /> {course.learners} learners
      </div>
      <div className="mt-auto pt-5">
        <Link
          href={`/courses/${course.slug}`}
          className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand text-[14px] font-semibold text-brand transition group-hover:bg-primary group-hover:text-white"
        >
          Know more
        </Link>
      </div>
    </div>
  );
}
