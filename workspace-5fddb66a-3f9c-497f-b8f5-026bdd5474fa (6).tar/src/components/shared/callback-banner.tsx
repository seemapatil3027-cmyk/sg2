"use client";

import { useState } from "react";
import { MessageCircleMore } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LeadForm } from "./lead-form";

export function CallbackBanner() {
  const [open, setOpen] = useState(false);
  return (
    <section className="pb-14">
      <div className="container-sv">
        <div className="flex flex-col items-start justify-between gap-5 rounded-2xl bg-[#EAF8F0] px-6 py-6 sm:flex-row sm:items-center sm:px-10">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-sm">
              <MessageCircleMore className="h-6 w-6 text-[#12A150]" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#0E8A43] sm:text-xl">Still have questions?</h3>
              <p className="text-sm text-[#3E7A58]">Request a callback to get in touch with our academic counsellors.</p>
            </div>
          </div>
          <button
            onClick={() => setOpen(true)}
            className="inline-flex h-11 items-center justify-center rounded-lg bg-[#12A150] px-6 text-[15px] font-semibold text-white transition hover:bg-[#0E8A43]"
          >
            Request a Callback
          </button>
        </div>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md rounded-2xl">
          <DialogHeader className="text-left">
            <DialogTitle className="text-xl font-bold">Request a callback</DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Our academic counsellors will get in touch within 24 hours.
            </DialogDescription>
          </DialogHeader>
          <LeadForm source="callback" submitLabel="Request a Callback" onDone={() => setTimeout(() => setOpen(false), 1800)} />
        </DialogContent>
      </Dialog>
    </section>
  );
}
