"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LeadForm } from "./lead-form";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface LeadDialogButtonProps {
  label: React.ReactNode;
  source: "masterclass" | "enroll" | "contact" | "hire" | "callback";
  itemSlug?: string;
  dialogTitle: string;
  dialogText?: string;
  submitLabel?: string;
  buttonClassName?: string;
  buttonVariant?: "default" | "outline" | "secondary" | "ghost" | "link" | "success";
  icon?: React.ReactNode;
}

export function LeadDialogButton({
  label,
  source,
  itemSlug,
  dialogTitle,
  dialogText,
  submitLabel,
  buttonClassName,
  buttonVariant = "default",
  icon,
}: LeadDialogButtonProps) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        variant={buttonVariant === "success" ? "default" : buttonVariant}
        className={cn(
          "h-12 rounded-xl px-6 text-[15px] font-semibold",
          buttonVariant === "default" && "bg-primary text-white hover:bg-brand-dark",
          buttonVariant === "outline" && "border-brand text-brand hover:bg-brand-soft hover:text-brand",
          buttonVariant === "success" && "bg-[#12A150] text-white hover:bg-[#0E8A43]",
          buttonClassName
        )}
      >
        {icon}
        {label}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md rounded-2xl">
          <DialogHeader className="text-left">
            <DialogTitle className="text-xl font-bold">{dialogTitle}</DialogTitle>
            {dialogText && <DialogDescription className="text-sm text-muted-foreground">{dialogText}</DialogDescription>}
          </DialogHeader>
          <LeadForm
            source={source}
            itemSlug={itemSlug}
            submitLabel={submitLabel ?? "Submit"}
            onDone={() => setTimeout(() => setOpen(false), 1800)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
