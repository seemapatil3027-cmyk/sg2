"use client";

import { useState } from "react";
import { Loader2, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface LeadFormProps {
  source?: string;
  itemSlug?: string;
  note?: string;
  submitLabel?: string;
  successTitle?: string;
  successText?: string;
  className?: string;
  inputClassName?: string;
  buttonClassName?: string;
  onDone?: () => void;
}

export function LeadForm({
  source = "contact",
  itemSlug,
  note,
  submitLabel = "Submit",
  successTitle = "Thank you!",
  successText = "Sit tight! Our experts will get back to you within 24 hrs",
  className,
  inputClassName,
  buttonClassName,
  onDone,
}: LeadFormProps) {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, email, source, note, itemSlug }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong");
      } else {
        setDone(true);
        toast({ title: successTitle, description: data.message });
        onDone?.();
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (done) {
    return (
      <div className={cn("flex flex-col items-center justify-center gap-2 rounded-xl bg-[#EAF8F0] px-6 py-10 text-center", className)}>
        <CheckCircle2 className="h-10 w-10 text-green-600" />
        <p className="text-lg font-bold text-green-700">{successTitle}</p>
        <p className="max-w-xs text-sm text-green-700/80">{successText}</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className={cn("flex flex-col gap-4", className)} noValidate>
      <div>
        <Input
          aria-label="Name"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className={cn("h-12 rounded-xl border-input bg-white px-4 text-[15px]", inputClassName)}
          required
        />
      </div>
      <div>
        <Input
          aria-label="Mobile Number"
          placeholder="Mobile Number"
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className={cn("h-12 rounded-xl border-input bg-white px-4 text-[15px]", inputClassName)}
          required
        />
      </div>
      <div>
        <Input
          aria-label="Email ID"
          placeholder="Email ID"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={cn("h-12 rounded-xl border-input bg-white px-4 text-[15px]", inputClassName)}
          required
        />
      </div>
      {error && <p className="text-sm font-medium text-red-600">{error}</p>}
      <Button
        type="submit"
        disabled={loading}
        className={cn(
          "h-12 rounded-xl bg-primary text-[15px] font-semibold text-white transition hover:bg-brand-dark",
          buttonClassName
        )}
      >
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : submitLabel}
      </Button>
    </form>
  );
}
