"use client";

import { InitialAvatar } from "./initial-avatar";
import type { Testimonial } from "@prisma/client";
import { SectionHeading, Section } from "./section";
import { cn } from "@/lib/utils";

export function TestimonialCarousel({ testimonials }: { testimonials: Testimonial[] }) {
  const doubled = [...testimonials, ...testimonials];
  return (
    <Section className="overflow-hidden">
      <SectionHeading label="TESTIMONIALS" title={<>Read what our alumni are saying 🙌</>} />
      <div className="marquee-paused relative mt-10">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-10 bg-gradient-to-r from-background to-transparent sm:w-24" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-10 bg-gradient-to-l from-background to-transparent sm:w-24" />
        <div className="flex w-max animate-marquee-slow gap-6">
          {doubled.map((t, i) => (
            <article
              key={`${t.id}-${i}`}
              aria-hidden={i >= testimonials.length}
              className="flex w-[320px] shrink-0 flex-col rounded-2xl border border-border bg-white p-6 shadow-[0_4px_18px_rgba(34,28,51,0.05)] sm:w-[380px]"
            >
              <div className="flex items-center gap-3">
                <InitialAvatar name={t.name} className="h-10 w-10 text-[13px]" />
                <p className="text-[15px] font-bold text-ink">{t.name}</p>
              </div>
              <p className="mt-3 line-clamp-[8] text-[13.5px] leading-6 text-ink-soft">{t.content}</p>
              <p className="mt-auto pt-4 text-[12px] text-muted-foreground">{t.date}</p>
            </article>
          ))}
        </div>
      </div>
    </Section>
  );
}

export function TestimonialCard({ testimonial, className }: { testimonial: Testimonial; className?: string }) {
  return (
    <article className={cn("flex flex-col rounded-2xl border border-border bg-white p-6", className)}>
      <div className="flex items-center gap-3">
        <InitialAvatar name={testimonial.name} className="h-10 w-10 text-[13px]" />
        <p className="text-[15px] font-bold text-ink">{testimonial.name}</p>
      </div>
      <p className="mt-3 text-[13.5px] leading-6 text-ink-soft">{testimonial.content}</p>
      <p className="mt-auto pt-4 text-[12px] text-muted-foreground">{testimonial.date}</p>
    </article>
  );
}
