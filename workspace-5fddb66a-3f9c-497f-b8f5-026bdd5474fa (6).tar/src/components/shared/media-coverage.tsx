"use client";

import { useState } from "react";
import { Section, SectionHeading } from "./section";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const MEDIA = [
  {
    id: "yourstory",
    name: "YOURSTORY",
    logoClass: "border border-gray-900 px-2 py-1 font-bold tracking-tight text-gray-900",
    quote: {
      title: "[Funding alert] Edtech platform SkilloVilla raises $300K in seed round from Titan Capital, others",
      body: "Bengaluru-based edtech platform SkilloVilla has raised $300,000 in a seed round of funding from Titan Capital and other investors. According to a statement, the company will utilise the freshly raised investment to expand the team and evolve the learning platform to offer unique technology products.",
      source: "- Yourstory",
    },
  },
  {
    id: "entrepreneur",
    name: "Entrepreneur INDIA",
    logoClass: "font-serif font-bold text-gray-700",
    quote: {
      title: "How this Bengaluru-based edtech startup is skilling India's graduates for data careers",
      body: "SkilloVilla trains young graduates in data analytics and data science through live classes mentored by industry experts from top companies, and connects them with 300+ hiring partners — turning learning into earnings for thousands of alumni.",
      source: "- Entrepreneur India",
    },
  },
  {
    id: "vccircle",
    name: "VCCiRCLE",
    logoClass: "font-bold tracking-wide text-gray-500",
    quote: {
      title: "Edtech startup SkilloVilla onboards top 1% industry mentors to close India's skill gap",
      body: "The upskilling platform's career tracks combine live classes, real-life case studies and placement assistance, reporting a 92% placement rate with alumni working across Swiggy, Razorpay, Deloitte and Accenture.",
      source: "- VCCircle",
    },
  },
];

export function MediaCoverage() {
  const [active, setActive] = useState(MEDIA[0].id);
  const current = MEDIA.find((m) => m.id === active)!;
  return (
    <Section>
      <SectionHeading label="MEDIA COVERAGE" title={<>SkilloVilla in the news 😎</>} />
      <div className="mt-10 grid gap-8 lg:grid-cols-[380px_1fr]">
        <div className="flex flex-col gap-4">
          {MEDIA.map((m) => (
            <button
              key={m.id}
              onClick={() => setActive(m.id)}
              aria-pressed={active === m.id}
              className={cn(
                "flex h-[88px] items-center justify-between rounded-2xl border bg-white px-6 transition",
                active === m.id ? "border-2 border-brand shadow-[0_8px_24px_rgba(93,24,190,0.12)]" : "border-border hover:border-gray-300"
              )}
            >
              <span className={cn("text-[17px]", m.logoClass)}>{m.name}</span>
              <ChevronRight className={cn("h-5 w-5 transition", active === m.id ? "text-brand" : "text-gray-300")} />
            </button>
          ))}
        </div>
        <div className="relative rounded-2xl bg-[#F3EFFA] p-7 sm:p-9">
          <span aria-hidden className="absolute right-8 -top-6 select-none text-[90px] font-black leading-none text-[#FFB020]">
            &rdquo;
          </span>
          <h3 className="max-w-xl text-[17px] font-bold leading-snug text-ink sm:text-[19px]">{current.quote.title}</h3>
          <p className="mt-4 max-w-2xl text-[14.5px] leading-7 text-ink-soft">{current.quote.body}</p>
          <a href="#" className="mt-3 inline-block text-[14px] font-semibold text-brand hover:underline">
            Read more
          </a>
          <p className="mt-6 text-[14px] italic text-ink-soft">{current.quote.source}</p>
        </div>
      </div>
    </Section>
  );
}
