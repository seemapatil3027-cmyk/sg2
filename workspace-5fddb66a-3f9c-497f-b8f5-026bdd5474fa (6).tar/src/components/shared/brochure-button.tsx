"use client";

import { useState } from "react";
import { Download, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LeadForm } from "./lead-form";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function BrochureButton({
  trackSlug,
  trackTitle,
  className,
  variant = "outline",
}: {
  trackSlug: string;
  trackTitle: string;
  className?: string;
  variant?: "outline" | "default";
}) {
  const [open, setOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  function download() {
    setDownloading(true);
    // Trigger the PDF download via a hidden iframe
    const iframe = document.createElement("iframe");
    iframe.style.display = "none";
    iframe.src = `/api/brochure?track=${encodeURIComponent(trackSlug)}`;
    document.body.appendChild(iframe);
    setTimeout(() => {
      iframe.remove();
      setDownloading(false);
    }, 4000);
  }

  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        variant={variant}
        className={cn(
          "h-12 rounded-xl border-brand px-5 text-[15px] font-semibold text-brand hover:bg-brand-soft hover:text-brand",
          variant === "default" && "border-primary bg-primary text-white hover:bg-brand-dark",
          className
        )}
      >
        <Download className="mr-0 h-4 w-4" />
        Download Brochure
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md rounded-2xl">
          <DialogHeader className="text-left">
            <DialogTitle className="text-xl font-bold">Download {trackTitle} brochure</DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Enter your details and we&apos;ll send the complete syllabus to you.
            </DialogDescription>
          </DialogHeader>
          <LeadForm
            source="brochure"
            itemSlug={trackSlug}
            submitLabel={downloading ? "Preparing..." : "Download Brochure"}
            onDone={() => {
              download();
              setTimeout(() => setOpen(false), 1500);
            }}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
