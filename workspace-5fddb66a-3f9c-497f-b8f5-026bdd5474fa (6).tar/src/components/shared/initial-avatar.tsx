import { cn } from "@/lib/utils";

const PALETTE = [
  ["#FDE8D7", "#C25609"],
  ["#E8DFF8", "#5D18BE"],
  ["#DCF2E4", "#15803D"],
  ["#FDE2E2", "#B91C1C"],
  ["#E0F0FE", "#0369A1"],
  ["#FEF3C7", "#B45309"],
  ["#FCE7F3", "#BE185D"],
  ["#E2E8F0", "#334155"],
];

function hashString(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

export function InitialAvatar({
  name,
  className,
  ring = false,
}: {
  name: string;
  className?: string;
  ring?: boolean;
}) {
  const [bg, fg] = PALETTE[hashString(name) % PALETTE.length];
  const initials = name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join("");
  return (
    <span
      aria-hidden="true"
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full font-semibold",
        ring && "ring-2 ring-white",
        className
      )}
      style={{ backgroundColor: bg, color: fg }}
    >
      {initials}
    </span>
  );
}
