"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { SectionHeading, Section } from "./section";
import { cn } from "@/lib/utils";

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export function FaqAccordion({ items, className }: { items: FaqItem[]; className?: string }) {
  const [openId, setOpenId] = useState<string | null>(items[0]?.id ?? null);
  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {items.map((f) => {
        const open = openId === f.id;
        return (
          <div
            key={f.id}
            className={cn(
              "rounded-2xl border border-border bg-white transition-shadow",
              open ? "shadow-[0_8px_24px_rgba(34,28,51,0.07)]" : "hover:shadow-[0_4px_14px_rgba(34,28,51,0.05)]"
            )}
          >
            <button
              onClick={() => setOpenId(open ? null : f.id)}
              aria-expanded={open}
              className="flex w-full items-center justify-between gap-4 rounded-2xl px-6 py-5 text-left"
            >
              <span className="text-[15px] font-semibold leading-snug text-ink sm:text-base">{f.question}</span>
              <ChevronDown className={cn("h-5 w-5 shrink-0 text-ink transition-transform duration-300", open && "rotate-180")} />
            </button>
            <div
              className={cn(
                "grid transition-all duration-300 ease-in-out",
                open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              )}
            >
              <div className="overflow-hidden">
                <p className="whitespace-pre-line px-6 pb-6 text-[14px] leading-6 text-ink-soft">{f.answer}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function FaqSection({
  items,
  label = "FREQUENTLY ASKED QUESTIONS",
  title = "Read more to know more",
}: {
  items: FaqItem[];
  label?: string;
  title?: React.ReactNode;
}) {
  if (!items.length) return null;
  return (
    <Section>
      <SectionHeading label={label} title={title} align="center" />
      <div className="mt-10">
        <FaqAccordion items={items} className="mx-auto max-w-[1000px]" />
      </div>
    </Section>
  );
}
