"use client";

import Link from "next/link";
import { Clock, FileText, Radio } from "lucide-react";
import type { TrackFull } from "@/lib/data";
import { DynIcon } from "@/lib/icons";
import { InitialAvatar } from "./initial-avatar";
import { BrochureButton } from "./brochure-button";
import { cn } from "@/lib/utils";

const AVATAR_NAMES = ["Aarav S", "Diya M", "Kabir R", "Ishita K", "Rohan P"];

export function TrackCard({ track, className }: { track: TrackFull; className?: string }) {
  return (
    <div
      className={cn(
        "relative flex flex-col rounded-2xl bg-white p-6 shadow-[0_10px_36px_rgba(28,15,66,0.18)] sm:p-7",
        className
      )}
    >
      {/* enrollments pill */}
      <div className="absolute -top-5 right-4 flex items-center gap-2 rounded-full bg-white py-1.5 pl-2 pr-4 shadow-[0_4px_14px_rgba(28,15,66,0.15)]">
        <span className="flex -space-x-2">
          {AVATAR_NAMES.slice(0, 3).map((n) => (
            <InitialAvatar key={n} name={n} className="h-6 w-6 text-[9px]" ring />
          ))}
        </span>
        <span className="text-[12.5px] font-semibold text-ink">{track.enrollments} enrollments</span>
      </div>

      <div className="flex items-start justify-between gap-4">
        {/* icon tile */}
        <div className="relative">
          <div className="flex h-[86px] w-[86px] items-center justify-center rounded-[22px] bg-gradient-to-br from-[#5D18BE] via-[#7A1FD8] to-[#9333EA] shadow-[0_10px_24px_rgba(93,24,190,0.35)]">
            <DynIcon name={track.icon} className="h-10 w-10 text-white" />
          </div>
        </div>
        {/* badges */}
        <div className="flex flex-col items-end gap-2 pt-1">
          {track.limitedSeats && (
            <span className="relative inline-flex items-center gap-1.5 rounded-md bg-[#FF7A00] px-3 py-1.5 text-[12px] font-semibold text-white after:absolute after:-bottom-[5px] after:right-0 after:h-[5px] after:w-3 after:bg-[#C2410C] after:[clip-path:polygon(0_0,100%_0,100%_100%)]">
              <Clock className="h-3.5 w-3.5" /> Limited Seats
            </span>
          )}
          {track.discount && (
            <span className="relative inline-flex items-center gap-1.5 rounded-md bg-[#16A34A] px-3 py-1.5 text-[12px] font-semibold text-white after:absolute after:-bottom-[5px] after:right-0 after:h-[5px] after:w-3 after:bg-[#14532D] after:[clip-path:polygon(0_0,100%_0,100%_100%)]">
              <span aria-hidden>✓</span> {track.discount}
            </span>
          )}
        </div>
      </div>

      {/* designed by */}
      <div className="mt-5 inline-flex w-fit items-center gap-3 rounded-xl bg-muted px-4 py-2.5">
        <span className="text-[12px] font-medium italic text-ink-soft">Designed by experts from</span>
        <span className="flex -space-x-2">
          {(track.expertLogos ?? []).slice(0, 3).map((logo) => (
            <span
              key={logo}
              className="flex h-8 w-8 items-center justify-center rounded-full border border-border bg-white text-[8px] font-bold uppercase text-ink-soft shadow-sm"
              title={logo}
            >
              {logo.slice(0, 2)}
            </span>
          ))}
        </span>
      </div>

      <h3 className="mt-4 text-[19px] font-bold leading-snug text-ink">{track.title}</h3>
      <p className="clamp-3 mt-2 text-[13.5px] leading-5.5 text-ink-soft">{track.description}</p>

      <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-[13px] font-medium text-ink">
        <span className="inline-flex items-center gap-1.5">
          <Radio className="h-4 w-4 text-brand" /> {track.liveClasses} Live Classes
        </span>
        <span className="inline-flex items-center gap-1.5">
          <FileText className="h-4 w-4 text-brand" /> {track.projects} Projects
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Clock className="h-4 w-4 text-brand" /> {track.hrPerWeek} hr/week
        </span>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <BrochureButton trackSlug={track.slug} trackTitle={track.title} className="flex-1" />
        <Link
          href={`/tracks/${track.slug}`}
          className="inline-flex h-12 flex-1 items-center justify-center rounded-xl bg-primary px-5 text-[15px] font-semibold text-white transition hover:bg-brand-dark"
        >
          <span className="mr-2 text-lg leading-none">»</span> Learn More
        </Link>
      </div>
    </div>
  );
}
