import { cn } from "@/lib/utils";

interface SectionHeadingProps {
  label?: string;
  title: React.ReactNode;
  sub?: React.ReactNode;
  align?: "left" | "center";
  dark?: boolean;
  className?: string;
  titleClassName?: string;
}

export function SectionHeading({
  label,
  title,
  sub,
  align = "left",
  dark = false,
  className,
  titleClassName,
}: SectionHeadingProps) {
  return (
    <div className={cn(align === "center" && "text-center", className)}>
      {label && <p className="section-label mb-2">{label}</p>}
      <h2
        className={cn(
          "text-[26px] font-bold leading-tight sm:text-[32px]",
          dark ? "text-white" : "text-ink",
          titleClassName
        )}
      >
        {title}
      </h2>
      {sub && (
        <p className={cn("mt-3 text-[15px] leading-6", dark ? "text-white/80" : "text-ink-soft", align === "center" && "mx-auto max-w-2xl")}>
          {sub}
        </p>
      )}
    </div>
  );
}

export function Section({
  children,
  className,
  id,
}: {
  children: React.ReactNode;
  className?: string;
  id?: string;
}) {
  return (
    <section id={id} className={cn("py-14 sm:py-18", className)}>
      <div className="container-sv">{children}</div>
    </section>
  );
}
