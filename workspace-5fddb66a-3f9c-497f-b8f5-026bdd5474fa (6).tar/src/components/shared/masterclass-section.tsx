"use client";

import { Section, SectionHeading } from "./section";
import { LeadDialogButton } from "./lead-dialog-button";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const FEATURES = [
  "Learn core concepts from experts in masterclass",
  "Get a headstart and kickoff your career",
  "Solve a real-life case study, live with the experts",
  "Interact with mentors, ask your doubts away",
];

/** Yellow chevron bullet list */
export function ChevronList({ items, className }: { items: string[]; className?: string }) {
  return (
    <ul className={cn("flex flex-col gap-4", className)}>
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-3">
          <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#FEF3C7]">
            <ChevronRight className="h-4 w-4 text-[#B45309]" />
          </span>
          <span className="text-[15px] leading-6 text-ink">{item}</span>
        </li>
      ))}
    </ul>
  );
}

export function MasterclassSection({
  source = "masterclass",
  itemSlug,
  imageSrc = "/images/masterclass-live.png",
}: {
  source?: string;
  itemSlug?: string;
  imageSrc?: string;
}) {
  return (
    <Section>
      <div className="grid items-center gap-10 lg:grid-cols-2">
        {/* live class mockup */}
        <div className="relative">
          <div className="overflow-hidden rounded-2xl shadow-[0_20px_50px_rgba(34,28,51,0.12)]">
            {/* video area */}
            <div className="relative aspect-[16/10] bg-gradient-to-br from-[#efe7fb] to-[#e2d6f5]">
              {imageSrc ? (
                <img src={imageSrc} alt="Live masterclass in progress" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/80">
                    <ChevronRight className="h-6 w-6 text-brand" />
                  </div>
                </div>
              )}
              {/* rec pill */}
              <div className="absolute left-3 top-3 flex items-center gap-2 rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-semibold text-ink shadow">
                <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" /> 03:52
              </div>
              {/* floating chip */}
              <div className="absolute -left-3 bottom-6 rounded-xl bg-white px-4 py-3 shadow-[0_10px_30px_rgba(34,28,51,0.18)] sm:-left-6">
                <p className="text-[13px] font-bold leading-tight text-ink">
                  Mentored by
                  <br />
                  Top 1% Industry
                  <br />
                  Experts
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* content */}
        <div>
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#FEF3C7] text-xl" aria-hidden>
              🐱‍👤
            </span>
            <div>
              <SectionHeading title="Experience the masterclass" titleClassName="!text-[22px]" />
              <p className="text-[13.5px] text-ink-soft">Learn with the best</p>
            </div>
          </div>
          <ChevronList items={FEATURES} className="mt-7" />
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <LeadDialogButton
              label="Contact Us"
              source="contact"
              buttonVariant="outline"
              buttonClassName="flex-1"
              dialogTitle="Contact us"
              dialogText="We'll get back to you in the next 24 hours."
            />
            <LeadDialogButton
              label="Try Masterclass"
              source="masterclass"
              itemSlug={itemSlug}
              dialogTitle="Try a free masterclass"
              dialogText="Solve a real-life case study, live with the experts. Leave your details and we'll save you a seat."
              buttonClassName="flex-1"
            />
          </div>
        </div>
      </div>
    </Section>
  );
}
