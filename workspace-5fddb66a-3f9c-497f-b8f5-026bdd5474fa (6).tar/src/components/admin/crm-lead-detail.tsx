"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  BadgeCheck,
  CalendarClock,
  CheckCircle2,
  Loader2,
  PartyPopper,
  Send,
  ShieldAlert,
  TriangleAlert,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { cn } from "@/lib/utils";
import {
  ACTION_PRESETS,
  STAGES,
  activityMeta,
  sourceBadgeClass,
  stageBadgeClass,
  type CrmActivity,
  type CrmCounsellor,
  type CrmLead,
} from "@/components/admin/crm-shared";

export interface ConvertResult {
  student: { email: string; name: string; tempPassword: string };
  enrollment: { id: string; itemSlug: string; itemType: string; batchName: string };
}

export interface MutationOutcome {
  ok: boolean;
  error?: string;
  result?: ConvertResult;
}

interface LeadDetailDialogProps {
  lead: CrmLead;
  counsellors: CrmCounsellor[];
  role: "ADMIN" | "COUNSELLOR";
  sessionEmail: string;
  sessionName: string;
  trackTitleBySlug: Record<string, string>;
  activities: CrmActivity[];
  patchLead: (id: string, body: Record<string, unknown>) => Promise<MutationOutcome>;
  postActivity: (
    id: string,
    body: { type: string; title: string; detail?: string; nextFollowUpAt?: string | null }
  ) => Promise<MutationOutcome>;
  convertLead: (id: string, body: { amount: number; plan: string; batchName: string }) => Promise<MutationOutcome>;
  onOpenChange: (open: boolean) => void;
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** yyyy-mm-dd → "15 Jan 2026" (deterministic, no timezone round-trips). */
function isoDateToLabel(value: string): string {
  const [y, m, d] = value.split("-").map((p) => parseInt(p, 10));
  if (!y || !m || !d) return value;
  return `${d} ${MONTHS[m - 1]} ${y}`;
}

export function LeadDetailDialog({
  lead,
  counsellors,
  role,
  sessionEmail,
  sessionName,
  trackTitleBySlug,
  activities,
  patchLead,
  postActivity,
  convertLead,
  onOpenChange,
}: LeadDetailDialogProps) {
  /* ---- per-control pending + error state ---- */
  const [stagePending, setStagePending] = useState(false);
  const [stageError, setStageError] = useState<string | null>(null);
  const [assignPending, setAssignPending] = useState(false);
  const [assignError, setAssignError] = useState<string | null>(null);
  const [followUpPending, setFollowUpPending] = useState(false);
  const [followUpError, setFollowUpError] = useState<string | null>(null);

  /* ---- follow-up date input (synced from server lead data; render-guard
   * pattern instead of a setState-in-effect) ---- */
  const [followUpDate, setFollowUpDate] = useState(lead.nextFollowUpDate);
  const [followUpServer, setFollowUpServer] = useState({ id: lead.id, date: lead.nextFollowUpDate });
  if (followUpServer.id !== lead.id || followUpServer.date !== lead.nextFollowUpDate) {
    setFollowUpServer({ id: lead.id, date: lead.nextFollowUpDate });
    setFollowUpDate(lead.nextFollowUpDate);
  }

  /* ---- activity composer ---- */
  const [composerType, setComposerType] = useState("note");
  const [composerTitle, setComposerTitle] = useState("Note added");
  const [composerDetail, setComposerDetail] = useState("");
  const [composerPending, setComposerPending] = useState(false);
  const [composerError, setComposerError] = useState<string | null>(null);
  const detailRef = useRef<HTMLTextAreaElement | null>(null);

  /* ---- convert to student ---- */
  const [convertAmount, setConvertAmount] = useState("30000");
  const [convertPlan, setConvertPlan] = useState("full");
  const [convertBatch, setConvertBatch] = useState("DA-1126");
  const [convertPending, setConvertPending] = useState(false);
  const [convertError, setConvertError] = useState<string | null>(null);
  const [convertResult, setConvertResult] = useState<ConvertResult | null>(null);

  const programTitle = useMemo(() => {
    if (lead.itemSlug && trackTitleBySlug[lead.itemSlug]) return trackTitleBySlug[lead.itemSlug];
    return lead.program || lead.itemSlug || "—";
  }, [lead.itemSlug, lead.program, trackTitleBySlug]);

  const isEnrolled = lead.status === "Enrolled";
  const canConvert = role === "ADMIN" && !isEnrolled && !convertResult;

  function presetAction(type: string, title: string) {
    setComposerType(type);
    setComposerTitle(title);
    setComposerError(null);
    requestAnimationFrame(() => detailRef.current?.focus());
  }

  async function handleComposerSubmit() {
    if (composerPending) return;
    const title = composerTitle.trim();
    if (!title) {
      setComposerError("Give the activity a short title.");
      return;
    }
    setComposerPending(true);
    setComposerError(null);
    const outcome = await postActivity(lead.id, {
      type: composerType,
      title,
      detail: composerDetail.trim() || undefined,
    });
    setComposerPending(false);
    if (!outcome.ok) {
      setComposerError(outcome.error || "Could not log the activity.");
      return;
    }
    setComposerDetail("");
  }

  async function handleStageChange(stage: string) {
    if (stagePending || stage === lead.status) return;
    setStagePending(true);
    setStageError(null);
    const outcome = await patchLead(lead.id, { status: stage });
    setStagePending(false);
    if (!outcome.ok) setStageError(outcome.error || "Could not update the stage.");
  }

  async function handleAssignChange(value: string) {
    if (assignPending) return;
    setAssignPending(true);
    setAssignError(null);
    const outcome = await patchLead(lead.id, { assignedTo: value === "unassigned" ? null : value });
    setAssignPending(false);
    if (!outcome.ok) setAssignError(outcome.error || "Could not update assignment.");
  }

  async function handleFollowUpChange(value: string) {
    if (followUpPending) return;
    setFollowUpDate(value);
    setFollowUpError(null);
    if (!value) {
      // Cleared → remove the follow-up date directly.
      setFollowUpPending(true);
      const outcome = await patchLead(lead.id, { nextFollowUpAt: null });
      setFollowUpPending(false);
      if (!outcome.ok) setFollowUpError(outcome.error || "Could not clear the follow-up.");
      return;
    }
    setFollowUpPending(true);
    const outcome = await postActivity(lead.id, {
      type: "followup",
      title: "Follow-up scheduled",
      detail: `Next follow-up set for ${isoDateToLabel(value)}.`,
      nextFollowUpAt: new Date(`${value}T00:00:00`).toISOString(),
    });
    setFollowUpPending(false);
    if (!outcome.ok) setFollowUpError(outcome.error || "Could not schedule the follow-up.");
  }

  async function handleConvert() {
    if (convertPending) return;
    const amount = Number(convertAmount);
    if (!Number.isFinite(amount) || !Number.isInteger(amount) || amount <= 0) {
      setConvertError("Enter a valid amount in whole rupees (or 0 to skip payment).");
      return;
    }
    setConvertPending(true);
    setConvertError(null);
    const outcome = await convertLead(lead.id, {
      amount,
      plan: convertPlan,
      batchName: convertBatch.trim() || "DA-1126",
    });
    setConvertPending(false);
    if (!outcome.ok) {
      setConvertError(outcome.error || "Conversion failed. Please try again.");
      return;
    }
    if (outcome.result) setConvertResult(outcome.result);
  }

  const profileRows: { label: string; value: string }[] = [
    { label: "Phone", value: lead.phone },
    { label: "Email", value: lead.email },
    { label: "City", value: lead.city || "—" },
    { label: "Education", value: lead.education || "—" },
    { label: "Experience", value: lead.experience || "—" },
    { label: "Program", value: programTitle },
    { label: "Mode", value: lead.mode ? lead.mode.charAt(0).toUpperCase() + lead.mode.slice(1) : "—" },
    { label: "Source", value: lead.source.charAt(0).toUpperCase() + lead.source.slice(1) },
    { label: "Lead score", value: lead.score !== null ? `${lead.score} / 100` : "—" },
    { label: "Created", value: lead.createdAtLabel },
  ];

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] w-[calc(100vw-1.5rem)] max-w-3xl overflow-y-auto nice-scrollbar rounded-3xl p-4 sm:p-6">
        <DialogHeader className="text-left">
          <div className="flex items-start gap-3 pr-6">
            <InitialAvatar name={lead.name} className="h-12 w-12 text-sm" />
            <div className="min-w-0 flex-1">
              <DialogTitle className="flex flex-wrap items-center gap-2 text-lg font-extrabold text-ink sm:text-xl">
                {lead.name}
                <Badge className={cn("rounded-full border-transparent", stageBadgeClass(lead.status))}>
                  {lead.status}
                </Badge>
              </DialogTitle>
              <DialogDescription className="mt-0.5 truncate">
                {lead.phone} · {lead.email}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* ---- Profile block ---- */}
        <section aria-label="Lead profile" className="rounded-2xl border border-border bg-muted/40 p-4">
          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3 lg:grid-cols-5">
            {profileRows.map((row) => (
              <div key={row.label} className="min-w-0">
                <dt className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                  {row.label}
                </dt>
                <dd className="truncate text-sm font-semibold text-ink" title={row.value}>
                  {row.value}
                </dd>
              </div>
            ))}
          </dl>
        </section>

        {/* ---- Stage + assignment + follow-up controls ---- */}
        <section aria-label="Pipeline controls" className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="lead-stage" className="text-sm font-semibold text-ink">
              Pipeline stage
            </Label>
            <div className="flex items-center gap-2">
              <Select value={lead.status} onValueChange={handleStageChange} disabled={stagePending}>
                <SelectTrigger
                  id="lead-stage"
                  className="h-10 w-full flex-1 rounded-xl border-border bg-white"
                  aria-label="Change pipeline stage"
                >
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent>
                  {STAGES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {stagePending && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-brand" aria-hidden="true" />}
            </div>
            {stageError && (
              <p role="alert" className="text-xs font-medium text-red-600">
                {stageError}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="lead-assignee" className="text-sm font-semibold text-ink">
              Assigned counsellor
            </Label>
            <div className="flex items-center gap-2">
              <Select
                value={lead.assignedTo ?? "unassigned"}
                onValueChange={handleAssignChange}
                disabled={assignPending}
              >
                <SelectTrigger
                  id="lead-assignee"
                  className="h-10 w-full flex-1 rounded-xl border-border bg-white"
                  aria-label="Assign counsellor"
                >
                  <SelectValue placeholder="Select counsellor" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unassigned">Unassigned</SelectItem>
                  {role === "ADMIN"
                    ? counsellors.map((c) => (
                        <SelectItem key={c.email} value={c.email}>
                          {c.name}
                        </SelectItem>
                      ))
                    : (
                      <SelectItem value={sessionEmail}>{sessionName} (me)</SelectItem>
                    )}
                </SelectContent>
              </Select>
              {assignPending && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-brand" aria-hidden="true" />}
            </div>
            {assignError && (
              <p role="alert" className="text-xs font-medium text-red-600">
                {assignError}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1.5 sm:col-span-2">
            <Label htmlFor="lead-followup" className="text-sm font-semibold text-ink">
              Next follow-up
            </Label>
            <div className="flex flex-wrap items-center gap-2">
              <Input
                id="lead-followup"
                type="date"
                value={followUpDate}
                onChange={(e) => handleFollowUpChange(e.target.value)}
                disabled={followUpPending}
                className="h-10 w-auto rounded-xl border-border bg-white"
                aria-label="Schedule next follow-up date"
              />
              {lead.nextFollowUpLabel && (
                <Badge
                  className={cn(
                    "rounded-full border-transparent",
                    lead.followUpOverdue ? "bg-[#FDE2E2] text-[#B91C1C]" : "bg-gold/20 text-[#92400E]"
                  )}
                >
                  <CalendarClock className="h-3 w-3" aria-hidden="true" />
                  {lead.followUpOverdue ? "Overdue: " : "Scheduled: "}
                  {lead.nextFollowUpLabel}
                </Badge>
              )}
              {followUpPending && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-brand" aria-hidden="true" />}
            </div>
            {followUpError && (
              <p role="alert" className="text-xs font-medium text-red-600">
                {followUpError}
              </p>
            )}
          </div>
        </section>

        {/* ---- Quick actions ---- */}
        <section aria-label="Quick actions" className="flex flex-col gap-2">
          <p className="text-sm font-semibold text-ink">Quick actions</p>
          <div className="flex flex-wrap gap-2">
            {ACTION_PRESETS.filter((a) => a.type !== "note" && a.type !== "counselling").map((action) => (
              <Button
                key={action.type}
                type="button"
                variant="outline"
                size="sm"
                onClick={() => presetAction(action.type, action.title)}
                className="h-9 rounded-xl border-border font-semibold text-ink hover:border-brand hover:text-brand"
              >
                {action.label}
              </Button>
            ))}
          </div>
        </section>

        {/* ---- Activity composer ---- */}
        <section aria-label="Log activity" className="rounded-2xl border border-border p-4">
          <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Activity type">
            {ACTION_PRESETS.map((action) => (
              <button
                key={action.type}
                type="button"
                onClick={() => presetAction(action.type, action.title)}
                aria-pressed={composerType === action.type}
                className={cn(
                  "rounded-full px-3 py-1 text-xs font-semibold transition-colors",
                  composerType === action.type
                    ? "bg-primary text-white"
                    : "bg-muted text-ink-soft hover:bg-brand-soft hover:text-brand"
                )}
              >
                {action.label}
              </button>
            ))}
          </div>
          <div className="mt-3 flex flex-col gap-2">
            <Input
              value={composerTitle}
              onChange={(e) => setComposerTitle(e.target.value)}
              placeholder="Activity title"
              aria-label="Activity title"
              className="h-10 rounded-xl border-border bg-white"
            />
            <Textarea
              ref={detailRef}
              value={composerDetail}
              onChange={(e) => setComposerDetail(e.target.value)}
              placeholder="Add details (optional) — e.g. spoke about batch timings, fee breakup…"
              aria-label="Activity details"
              className="min-h-16 rounded-xl border-border bg-white"
            />
            {composerError && (
              <p role="alert" className="text-xs font-medium text-red-600">
                {composerError}
              </p>
            )}
            <div>
              <Button
                type="button"
                onClick={handleComposerSubmit}
                disabled={composerPending}
                className="h-10 rounded-xl bg-primary font-semibold text-white hover:bg-brand-dark"
              >
                {composerPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Send className="h-4 w-4" aria-hidden="true" />
                )}
                Log activity
              </Button>
            </div>
          </div>
        </section>

        {/* ---- Convert to student (ADMIN only) ---- */}
        {role === "ADMIN" && convertResult && (
          <section
            aria-label="Conversion success"
            className="rounded-2xl border border-[#BBE7C8] bg-[#F0FAF3] p-4 sm:p-5"
          >
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#DCF2E4] text-[#15803D]">
                <PartyPopper className="h-5 w-5" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-extrabold text-[#166534]">
                  Student created — LMS access granted
                </p>
                <p className="mt-1 text-sm text-ink-soft">
                  <span className="font-semibold text-ink">{convertResult.student.name}</span> ·{" "}
                  {convertResult.student.email}
                </p>
                <p className="mt-2 text-sm text-ink-soft">
                  Temp password:{" "}
                  <code className="rounded-md bg-white px-2 py-0.5 font-mono text-[13px] font-bold text-[#166534]">
                    {convertResult.student.tempPassword}
                  </code>
                </p>
                <p className="mt-1 text-xs text-ink-soft">
                  Enrollment {convertResult.enrollment.batchName} · {convertResult.enrollment.itemType} ·{" "}
                  {convertResult.enrollment.itemSlug}
                </p>
                <Button
                  asChild
                  size="sm"
                  className="mt-3 h-9 rounded-xl bg-primary font-semibold text-white hover:bg-brand-dark"
                >
                  <Link href="/dashboard">Open student dashboard</Link>
                </Button>
              </div>
            </div>
          </section>
        )}

        {role === "ADMIN" && !convertResult && isEnrolled && (
          <section
            aria-label="Enrolled notice"
            className="flex items-center gap-2.5 rounded-2xl border border-[#BBE7C8] bg-[#F0FAF3] px-4 py-3"
          >
            <CheckCircle2 className="h-5 w-5 shrink-0 text-[#16A34A]" aria-hidden="true" />
            <p className="text-sm font-semibold text-[#166534]">
              This lead is enrolled — student account active with LMS access.
            </p>
          </section>
        )}

        {canConvert && (
          <section aria-label="Convert to student" className="rounded-2xl border border-gold/50 bg-gold/10 p-4 sm:p-5">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gold/25 text-[#92400E]">
                <BadgeCheck className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-extrabold text-ink">Convert to Student</p>
                <p className="text-xs text-ink-soft">
                  Creates the student account, activates enrollment and grants LMS access.
                </p>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="convert-amount" className="text-xs font-semibold text-ink">
                  Amount (₹)
                </Label>
                <Input
                  id="convert-amount"
                  type="number"
                  min={0}
                  step={500}
                  value={convertAmount}
                  onChange={(e) => setConvertAmount(e.target.value)}
                  className="h-10 rounded-xl border-border bg-white"
                  aria-label="Payment amount in rupees"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="convert-plan" className="text-xs font-semibold text-ink">
                  Plan
                </Label>
                <Select value={convertPlan} onValueChange={setConvertPlan}>
                  <SelectTrigger
                    id="convert-plan"
                    className="h-10 w-full rounded-xl border-border bg-white"
                    aria-label="Payment plan"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full">Full payment</SelectItem>
                    <SelectItem value="installment">Installment</SelectItem>
                    <SelectItem value="emi">EMI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="convert-batch" className="text-xs font-semibold text-ink">
                  Batch name
                </Label>
                <Input
                  id="convert-batch"
                  value={convertBatch}
                  onChange={(e) => setConvertBatch(e.target.value)}
                  className="h-10 rounded-xl border-border bg-white"
                  aria-label="Batch name"
                />
              </div>
            </div>
            {convertError && (
              <p role="alert" className="mt-2 flex items-center gap-1.5 text-xs font-medium text-red-600">
                <ShieldAlert className="h-3.5 w-3.5" aria-hidden="true" />
                {convertError}
              </p>
            )}
            <Button
              type="button"
              onClick={handleConvert}
              disabled={convertPending}
              className="mt-3 h-10 rounded-xl bg-primary font-semibold text-white hover:bg-brand-dark"
            >
              {convertPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <BadgeCheck className="h-4 w-4" aria-hidden="true" />
              )}
              {convertPending ? "Converting…" : "Convert & activate LMS access"}
            </Button>
          </section>
        )}

        <Separator className="bg-border" />

        {/* ---- Activity timeline ---- */}
        <section aria-label="Activity timeline" className="flex flex-col gap-3">
          <p className="text-sm font-bold text-ink">
            Activity timeline
            <span className="ml-2 text-xs font-medium text-ink-soft">newest first</span>
          </p>
          {activities.length === 0 ? (
            <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-border py-8 text-center">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-muted text-ink-soft">
                <CalendarClock className="h-5 w-5" aria-hidden="true" />
              </span>
              <p className="text-sm font-semibold text-ink">No activity yet</p>
              <p className="max-w-xs text-xs text-ink-soft">
                Calls, WhatsApp messages, notes and stage changes will appear here.
              </p>
            </div>
          ) : (
            <ol className="nice-scrollbar max-h-96 space-y-0 overflow-y-auto pr-1" aria-label="Activities, newest first">
              {activities.map((activity, index) => {
                const meta = activityMeta(activity.type);
                const Icon = meta.icon;
                return (
                  <li key={activity.id} className="relative flex gap-3 pb-4 last:pb-0">
                    {index < activities.length - 1 && (
                      <span
                        aria-hidden="true"
                        className="absolute left-[17px] top-9 h-[calc(100%-1.5rem)] w-px bg-border"
                      />
                    )}
                    <span
                      className={cn(
                        "relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                        meta.chip
                      )}
                    >
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div className="min-w-0 flex-1 rounded-2xl border border-border/70 bg-card px-3.5 py-2.5">
                      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5">
                        <p className="text-sm font-bold text-ink">{activity.title}</p>
                        <time className="whitespace-nowrap text-[11px] text-muted-foreground">
                          {activity.createdAtLabel}
                        </time>
                      </div>
                      {activity.detail && (
                        <p className="mt-1 whitespace-pre-line break-words text-[13px] leading-relaxed text-ink-soft">
                          {activity.detail}
                        </p>
                      )}
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        by {activity.createdBy || "System"}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </section>

        {lead.followUpOverdue && (
          <p className="flex items-center gap-1.5 rounded-xl bg-gold/10 px-3 py-2 text-xs font-semibold text-[#92400E]">
            <TriangleAlert className="h-3.5 w-3.5" aria-hidden="true" />
            Follow-up is overdue — {lead.nextFollowUpLabel}. Schedule the next touch-point above.
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}
