import {
  ArrowRightCircle,
  Calendar,
  CreditCard,
  FileText,
  Mail,
  MessageCircle,
  MessagesSquare,
  Phone,
  StickyNote,
  Trophy,
  UserPlus,
  Clock,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Pipeline stages                                                     */
/* ------------------------------------------------------------------ */

/** Full lead lifecycle — order defines the stepper/board order. */
export const STAGES = [
  "New",
  "Assigned",
  "Contacted",
  "Counselling",
  "Demo",
  "Interested",
  "Payment Pending",
  "Enrolled",
  "Lost",
] as const;

export type CrmStage = (typeof STAGES)[number];

/** Stage → badge/dot classes (purple/gold/green palette, no indigo/blue). */
export const STAGE_META: Record<string, { badge: string; dot: string }> = {
  New: { badge: "bg-secondary text-secondary-foreground", dot: "bg-ink-soft" },
  Assigned: { badge: "bg-brand-soft text-brand", dot: "bg-brand" },
  Contacted: { badge: "bg-accento-soft text-[#C25609]", dot: "bg-accento" },
  Counselling: { badge: "bg-[#FCE7F3] text-[#BE185D]", dot: "bg-[#BE185D]" },
  Demo: { badge: "bg-gold/20 text-[#92400E]", dot: "bg-gold" },
  Interested: { badge: "bg-[#D9F2EF] text-[#0F766E]", dot: "bg-[#0F766E]" },
  "Payment Pending": { badge: "bg-[#FDE2E2] text-[#B91C1C]", dot: "bg-[#DC2626]" },
  Enrolled: { badge: "bg-[#DCF2E4] text-[#15803D]", dot: "bg-[#16A34A]" },
  Lost: { badge: "bg-muted text-muted-foreground", dot: "bg-muted-foreground" },
};

export function stageBadgeClass(status: string): string {
  return STAGE_META[status]?.badge ?? "bg-muted text-muted-foreground";
}

/* ------------------------------------------------------------------ */
/* Source badges                                                       */
/* ------------------------------------------------------------------ */

const SOURCE_BADGE: Record<string, string> = {
  contact: "bg-brand-soft text-brand",
  callback: "bg-accento-soft text-[#C25609]",
  brochure: "bg-gold/15 text-[#B45309]",
  masterclass: "bg-[#FCE7F3] text-[#BE185D]",
  enroll: "bg-[#DCF2E4] text-[#15803D]",
  hire: "bg-secondary text-secondary-foreground",
  assessment: "bg-gold/20 text-[#92400E]",
};

export function sourceBadgeClass(source: string): string {
  return SOURCE_BADGE[source] ?? "bg-muted text-muted-foreground";
}

/* ------------------------------------------------------------------ */
/* Activity types                                                      */
/* ------------------------------------------------------------------ */

export interface ActivityMeta {
  icon: LucideIcon;
  /** Background + text classes for the timeline icon chip. */
  chip: string;
}

export const ACTIVITY_META: Record<string, ActivityMeta> = {
  note: { icon: StickyNote, chip: "bg-muted text-ink-soft" },
  call: { icon: Phone, chip: "bg-[#DCF2E4] text-[#15803D]" },
  whatsapp: { icon: MessageCircle, chip: "bg-[#DCF2E4] text-[#15803D]" },
  email: { icon: Mail, chip: "bg-brand-soft text-brand" },
  followup: { icon: Clock, chip: "bg-gold/20 text-[#92400E]" },
  demo: { icon: Calendar, chip: "bg-gold/20 text-[#92400E]" },
  counselling: { icon: MessagesSquare, chip: "bg-brand-soft text-brand" },
  status: { icon: ArrowRightCircle, chip: "bg-brand-soft text-brand" },
  assigned: { icon: UserPlus, chip: "bg-brand-soft text-brand" },
  brochure: { icon: FileText, chip: "bg-accento-soft text-[#C25609]" },
  payment_link: { icon: CreditCard, chip: "bg-[#FDE2E2] text-[#B91C1C]" },
  converted: { icon: Trophy, chip: "bg-[#DCF2E4] text-[#15803D]" },
};

export function activityMeta(type: string): ActivityMeta {
  return ACTIVITY_META[type] ?? ACTIVITY_META.note;
}

/* ------------------------------------------------------------------ */
/* Serialized models (dates pre-formatted server-side to avoid any     */
/* hydration mismatch — client components treat them as plain data).   */
/* ------------------------------------------------------------------ */

export interface CrmLead {
  id: string;
  name: string;
  phone: string;
  email: string;
  source: string;
  note: string | null;
  itemSlug: string | null;
  status: string;
  assignedTo: string | null;
  city: string | null;
  education: string | null;
  experience: string | null;
  program: string | null;
  mode: string | null;
  /** ISO string or null. */
  nextFollowUpAt: string | null;
  /** ISO string. */
  createdAt: string;
  /** Server-computed display strings (stable across hydration). */
  createdAtLabel: string;
  createdAgo: string;
  /** Parsed from note's "leadScore:<n>" — null when absent. */
  score: number | null;
  /** yyyy-mm-dd (local) for <input type="date">, or "". */
  nextFollowUpDate: string;
  nextFollowUpLabel: string | null;
  /** Follow-up is in the past and lead is not yet Enrolled/Lost. */
  followUpOverdue: boolean;
  /** Display name of the assigned counsellor (null when unassigned). */
  assignedToName: string | null;
}

export interface CrmActivity {
  id: string;
  leadId: string;
  type: string;
  title: string;
  detail: string | null;
  createdBy: string | null;
  /** ISO string. */
  createdAt: string;
  /** Server-computed display string (stable across hydration). */
  createdAtLabel: string;
}

export interface CrmCounsellor {
  email: string;
  name: string;
}

/** KPI values are computed server-side from fixed ranges. */
export interface CrmKpis {
  todayLeads: number;
  totalLeads: number;
  enrolled: number;
  paymentPending: number;
  conversionLabel: string;
  avgScoreLabel: string;
}

/** Parses the assessment score embedded in structured CRM notes. */
export function parseLeadScore(note: string | null | undefined): number | null {
  if (!note) return null;
  const match = note.match(/leadScore:(\d+)/);
  if (!match) return null;
  return Math.min(100, Math.max(0, parseInt(match[1], 10)));
}

/** Preset titles for the quick-action composer buttons. */
export const ACTION_PRESETS: {
  type: string;
  label: string;
  title: string;
}[] = [
  { type: "call", label: "Log Call", title: "Call logged" },
  { type: "whatsapp", label: "WhatsApp", title: "WhatsApp sent" },
  { type: "email", label: "Email", title: "Email sent" },
  { type: "demo", label: "Schedule Demo", title: "Demo class scheduled" },
  { type: "counselling", label: "Counselling", title: "Counselling session held" },
  { type: "brochure", label: "Send Brochure", title: "Brochure sent" },
  { type: "payment_link", label: "Payment Link", title: "Payment link sent" },
  { type: "note", label: "Note", title: "Note added" },
];
