"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CalendarDays,
  CreditCard,
  GraduationCap,
  Gauge,
  Inbox,
  Percent,
  TriangleAlert,
  Users,
  type LucideIcon,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { SignOutButton } from "@/components/admin/sign-out-button";
import { LeadDetailDialog, type MutationOutcome } from "@/components/admin/crm-lead-detail";
import { cn } from "@/lib/utils";
import {
  STAGES,
  sourceBadgeClass,
  stageBadgeClass,
  type CrmActivity,
  type CrmCounsellor,
  type CrmKpis,
  type CrmLead,
} from "@/components/admin/crm-shared";

interface WorkspaceUser {
  name: string;
  email: string;
  role: "ADMIN" | "COUNSELLOR";
}

interface CrmWorkspaceProps {
  user: WorkspaceUser;
  leads: CrmLead[];
  activitiesByLead: Record<string, CrmActivity[]>;
  counsellors: CrmCounsellor[];
  kpis: CrmKpis;
  trackTitleBySlug: Record<string, string>;
}

interface KpiItem {
  label: string;
  value: string;
  sub: string;
  icon: LucideIcon;
}

export function CrmWorkspace({ user, leads, activitiesByLead, counsellors, kpis, trackTitleBySlug }: CrmWorkspaceProps) {
  const router = useRouter();

  /* Local mirrors of the server data — mutated optimistically, re-synced on refresh.
   * Uses the React-endorsed "adjust state during render when a prop changes"
   * pattern (guarded comparison) instead of a setState-in-effect. */
  const [localLeads, setLocalLeads] = useState<CrmLead[]>(leads);
  const [localActivities, setLocalActivities] = useState<Record<string, CrmActivity[]>>(activitiesByLead);
  const [serverLeads, setServerLeads] = useState<CrmLead[]>(leads);
  const [serverActivities, setServerActivities] = useState<Record<string, CrmActivity[]>>(activitiesByLead);
  const [activeTab, setActiveTab] = useState<string>("All");
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [boardError, setBoardError] = useState<string | null>(null);

  if (serverLeads !== leads) {
    setServerLeads(leads);
    setLocalLeads(leads);
  }
  if (serverActivities !== activitiesByLead) {
    setServerActivities(activitiesByLead);
    setLocalActivities(activitiesByLead);
  }

  const selectedLead = useMemo(
    () => localLeads.find((l) => l.id === selectedLeadId) ?? null,
    [localLeads, selectedLeadId]
  );

  /* ---------------------------------------------------------------- */
  /* API helpers (optimistic update + revert on failure)               */
  /* ---------------------------------------------------------------- */

  async function patchLead(id: string, body: Record<string, unknown>): Promise<MutationOutcome> {
    const snapshot = localLeads;
    setLocalLeads((prev) =>
      prev.map((lead) => {
        if (lead.id !== id) return lead;
        const next = { ...lead };
        if (typeof body.status === "string") next.status = body.status;
        if ("assignedTo" in body) {
          const email = body.assignedTo === null ? null : String(body.assignedTo);
          next.assignedTo = email;
          next.assignedToName = email ? counsellors.find((c) => c.email === email)?.name ?? email : null;
        }
        if ("nextFollowUpAt" in body && body.nextFollowUpAt === null) {
          next.nextFollowUpAt = null;
          next.nextFollowUpDate = "";
          next.nextFollowUpLabel = null;
          next.followUpOverdue = false;
        }
        return next;
      })
    );
    try {
      const res = await fetch(`/api/crm/leads/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!res.ok || !data?.ok) {
        setLocalLeads(snapshot);
        return { ok: false, error: data?.error || "Update failed. Please try again." };
      }
      router.refresh();
      return { ok: true };
    } catch {
      setLocalLeads(snapshot);
      return { ok: false, error: "Network error — please try again." };
    }
  }

  async function postActivity(
    id: string,
    body: { type: string; title: string; detail?: string; nextFollowUpAt?: string | null }
  ): Promise<MutationOutcome> {
    try {
      const res = await fetch(`/api/crm/leads/${id}/activities`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; error?: string; activity?: CrmActivity }
        | null;
      if (!res.ok || !data?.ok || !data.activity) {
        return { ok: false, error: data?.error || "Could not log the activity. Please try again." };
      }
      // Optimistically show the new activity (refresh replaces it with server-computed labels).
      const created: CrmActivity = {
        ...data.activity,
        createdAt: data.activity.createdAt ?? new Date().toISOString(),
        createdAtLabel: data.activity.createdAtLabel || "just now",
      };
      setLocalActivities((prev) => ({
        ...prev,
        [id]: [created, ...(prev[id] ?? [])],
      }));
      router.refresh();
      return { ok: true };
    } catch {
      return { ok: false, error: "Network error — please try again." };
    }
  }

  async function convertLead(
    id: string,
    body: { amount: number; plan: string; batchName: string }
  ): Promise<MutationOutcome> {
    try {
      const res = await fetch(`/api/crm/leads/${id}/convert`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; error?: string; student?: ConvertStudent; enrollment?: ConvertEnrollment }
        | null;
      if (!res.ok || !data?.ok || !data.student || !data.enrollment) {
        return { ok: false, error: data?.error || "Conversion failed. Please try again." };
      }
      router.refresh();
      return {
        ok: true,
        result: { student: data.student, enrollment: data.enrollment },
      };
    } catch {
      return { ok: false, error: "Network error — please try again." };
    }
  }

  /* ---------------------------------------------------------------- */
  /* Derived board data                                                */
  /* ---------------------------------------------------------------- */

  const counts = useMemo(() => {
    const map: Record<string, number> = { All: localLeads.length };
    for (const stage of STAGES) map[stage] = 0;
    for (const lead of localLeads) map[lead.status] = (map[lead.status] ?? 0) + 1;
    return map;
  }, [localLeads]);

  const visibleLeads = useMemo(
    () => (activeTab === "All" ? localLeads : localLeads.filter((l) => l.status === activeTab)),
    [localLeads, activeTab]
  );

  const kpiItems: KpiItem[] = [
    { label: "Today's Leads", value: String(kpis.todayLeads), sub: "captured since midnight", icon: CalendarDays },
    { label: "Total Leads", value: String(kpis.totalLeads), sub: user.role === "ADMIN" ? "all sources" : "your pipeline", icon: Users },
    { label: "Enrolled", value: String(kpis.enrolled), sub: "active students", icon: GraduationCap },
    { label: "Payment Pending", value: String(kpis.paymentPending), sub: "awaiting payment", icon: CreditCard },
    { label: "Conversion", value: kpis.conversionLabel, sub: "enrolled ÷ total", icon: Percent },
    { label: "Avg Lead Score", value: kpis.avgScoreLabel, sub: "parsed from notes", icon: Gauge },
  ];

  return (
    <div className="container-sv py-8 sm:py-10">
      {/* 1. Header */}
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="section-label">Admin Control Center · Internal</p>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-2">
            <h1 className="text-2xl font-extrabold text-ink sm:text-3xl">CRM — Admissions Pipeline</h1>
            <Badge
              className={cn(
                "rounded-full border-transparent",
                user.role === "ADMIN" ? "bg-gold/20 text-[#92400E]" : "bg-brand-soft text-brand"
              )}
            >
              {user.role}
            </Badge>
          </div>
          <p className="mt-2 text-sm text-ink-soft">
            {user.role === "ADMIN"
              ? "Full pipeline visibility — assign, nurture and convert leads into students."
              : "Your assigned leads plus unassigned ones you can claim — move stages, log activity."}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <InitialAvatar name={user.name} className="h-10 w-10 text-sm" />
          <div className="hidden min-w-0 sm:block">
            <p className="truncate text-sm font-bold text-ink">{user.name}</p>
            <p className="truncate text-xs text-ink-soft">{user.email}</p>
          </div>
          <SignOutButton className="rounded-xl border-border font-semibold text-ink hover:border-brand hover:text-brand" />
        </div>
      </header>

      {/* 2. KPI row */}
      <section aria-label="Pipeline KPIs" className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-6 xl:grid-cols-6">
        {kpiItems.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <Card
              key={kpi.label}
              className="rounded-3xl shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md"
            >
              <CardContent className="flex items-center gap-3 p-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-xl font-extrabold leading-tight text-ink">{kpi.value}</p>
                  <p className="text-xs font-semibold leading-snug text-ink-soft">{kpi.label}</p>
                  <p className="text-[11px] leading-snug text-muted-foreground">{kpi.sub}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      {/* 3. Pipeline board */}
      <section aria-label="Pipeline board" className="mt-6 sm:mt-8">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-extrabold text-ink">Pipeline</h2>
          <Badge className="rounded-full border-transparent bg-brand-soft text-brand">
            {counts.All} leads
          </Badge>
        </div>

        {/* Stage tabs */}
        <div
          className="nice-scrollbar mt-3 flex gap-2 overflow-x-auto pb-2"
          role="tablist"
          aria-label="Filter leads by stage"
        >
          {["All", ...STAGES].map((tab) => (
            <button
              key={tab}
              type="button"
              role="tab"
              aria-selected={activeTab === tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-semibold transition-colors",
                activeTab === tab
                  ? "bg-primary text-white shadow-sm"
                  : "border border-border bg-card text-ink-soft hover:border-brand/40 hover:text-brand"
              )}
            >
              {tab}
              <span
                className={cn(
                  "rounded-full px-1.5 py-0.5 text-[11px] font-bold",
                  activeTab === tab ? "bg-white/20 text-white" : "bg-muted text-ink-soft"
                )}
              >
                {counts[tab] ?? 0}
              </span>
            </button>
          ))}
        </div>

        {boardError && (
          <p role="alert" className="mt-2 rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-red-600">
            {boardError}
          </p>
        )}

        {/* Lead cards */}
        {visibleLeads.length === 0 ? (
          <div className="mt-4 flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border py-12 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
              <Inbox className="h-6 w-6" aria-hidden="true" />
            </span>
            <p className="text-sm font-bold text-ink">
              {activeTab === "All" ? "No leads in your pipeline yet" : `No leads in ${activeTab}`}
            </p>
            <p className="max-w-sm text-sm text-ink-soft">
              {activeTab === "All"
                ? "Contact requests, callbacks and assessment leads will appear here the moment they come in."
                : "Move a lead into this stage from its detail panel, or check another tab."}
            </p>
          </div>
        ) : (
          <div className="nice-scrollbar mt-3 grid max-h-[32rem] grid-cols-1 gap-4 overflow-y-auto pr-1 md:grid-cols-2 xl:grid-cols-3">
            {visibleLeads.map((lead) => (
              <LeadCard key={lead.id} lead={lead} onOpen={() => setSelectedLeadId(lead.id)} />
            ))}
          </div>
        )}
      </section>

      {/* 4. Lead detail dialog */}
      {selectedLead && (
        <LeadDetailDialog
          lead={selectedLead}
          counsellors={counsellors}
          role={user.role}
          sessionEmail={user.email}
          sessionName={user.name}
          trackTitleBySlug={trackTitleBySlug}
          activities={localActivities[selectedLead.id] ?? []}
          patchLead={patchLead}
          postActivity={postActivity}
          convertLead={convertLead}
          onOpenChange={(open) => {
            if (!open) setSelectedLeadId(null);
          }}
        />
      )}
    </div>
  );
}

interface ConvertStudent {
  email: string;
  name: string;
  tempPassword: string;
}
interface ConvertEnrollment {
  id: string;
  itemSlug: string;
  itemType: string;
  batchName: string;
}

/* ------------------------------------------------------------------ */
/* Lead card                                                           */
/* ------------------------------------------------------------------ */

function LeadCard({ lead, onOpen }: { lead: CrmLead; onOpen: () => void }) {
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label={`Open lead ${lead.name}`}
      className="group flex h-full flex-col gap-3 rounded-3xl border border-border bg-card p-4 text-left shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-brand/40 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
    >
      <div className="flex items-start gap-3">
        <InitialAvatar name={lead.name} className="h-10 w-10 text-xs" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold text-ink">{lead.name}</p>
          <p className="truncate text-xs text-ink-soft">{lead.phone}</p>
        </div>
        {lead.score !== null ? (
          <span
            className="shrink-0 rounded-full bg-gold/20 px-2 py-0.5 text-xs font-extrabold text-[#92400E]"
            title="Assessment lead score"
          >
            {lead.score}
          </span>
        ) : (
          <span className="shrink-0 text-xs text-muted-foreground" aria-label="No lead score">
            —
          </span>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        <Badge className={cn("rounded-full border-transparent", stageBadgeClass(lead.status))}>
          {lead.status}
        </Badge>
        <Badge className={cn("rounded-full border-transparent capitalize", sourceBadgeClass(lead.source))}>
          {lead.source}
        </Badge>
        {(lead.program || lead.itemSlug) && (
          <span
            title={lead.program || lead.itemSlug || ""}
            className="inline-flex max-w-full items-center truncate rounded-full bg-brand-soft px-2.5 py-0.5 text-xs font-medium text-brand"
          >
            {lead.program || lead.itemSlug}
          </span>
        )}
      </div>

      <div className="mt-auto flex items-center justify-between gap-2 border-t border-border/60 pt-2.5">
        <span className="flex min-w-0 items-center gap-1.5">
          {lead.assignedTo ? (
            <>
              <InitialAvatar name={lead.assignedToName || lead.assignedTo} className="h-5 w-5 text-[9px]" />
              <span className="truncate text-xs text-ink-soft">{lead.assignedToName || lead.assignedTo}</span>
            </>
          ) : (
            <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
              Unassigned
            </span>
          )}
        </span>
        <span className="flex shrink-0 items-center gap-2">
          {lead.followUpOverdue && (
            <span className="flex items-center gap-1 text-[11px] font-bold text-[#B91C1C]" title="Follow-up overdue">
              <TriangleAlert className="h-3.5 w-3.5" aria-hidden="true" />
              overdue
            </span>
          )}
          <time className="text-[11px] text-muted-foreground">{lead.createdAgo}</time>
        </span>
      </div>
    </button>
  );
}
