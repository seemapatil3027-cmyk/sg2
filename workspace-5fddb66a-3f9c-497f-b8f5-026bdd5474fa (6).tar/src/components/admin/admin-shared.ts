import { DEFAULT_ROLES } from "@/lib/rbac";

/* Shared types + helpers for the Administration module (Users / Roles / Audit). */

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: string;
  roleLabel: string;
  phone: string | null;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}

export interface UsersListResponse {
  items: AdminUser[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  stats: { total: number; active: number; admins: number; roles: number };
}

export interface RoleMatrix {
  id: string;
  key: string;
  name: string;
  description: string;
  permissions: string[];
  isSystem: boolean;
  order: number;
  userCount: number;
}

export interface RolesResponse {
  items: RoleMatrix[];
  catalog: { group: string; items: { key: string; label: string }[] }[];
  allKeys: string[];
}

export interface AuditEntry {
  id: string;
  actorEmail: string;
  actorRole: string;
  action: string;
  entity: string;
  entityId: string | null;
  summary: string | null;
  meta: string | null;
  createdAt: string;
}

export interface AuditResponse {
  items: AuditEntry[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  actions: string[];
}

/* ── Role badge tones (no blue/indigo) ── */

const ROLE_TONES: Record<string, string> = {
  SUPER_ADMIN:
    "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-500/15 dark:text-purple-300 dark:border-purple-500/30",
  ADMIN:
    "bg-violet-50 text-violet-700 border-violet-200 dark:bg-violet-500/15 dark:text-violet-300 dark:border-violet-500/30",
};

const CRM_TONE =
  "bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-500/15 dark:text-orange-300 dark:border-orange-500/30";
const LMS_TONE =
  "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30";
const INSTRUCTOR_TONE =
  "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30";
const SLATE_TONE =
  "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/15 dark:text-slate-300 dark:border-slate-500/30";

export function roleBadgeTone(role: string): string {
  if (ROLE_TONES[role]) return ROLE_TONES[role];
  if (role.startsWith("CRM_")) return CRM_TONE;
  if (role.startsWith("LMS_")) return LMS_TONE;
  if (role === "INSTRUCTOR") return INSTRUCTOR_TONE;
  return SLATE_TONE;
}

/* ── Audit action domain → chip tone ── */

const CRM_DOMAINS = ["lead.", "contact.", "organization.", "deal.", "activity.", "crm."];
const ADMIN_DOMAINS = ["user.", "roles.", "admin.", "auth."];
const LMS_DOMAINS = ["lms.", "course", "enrollment", "quiz", "assignment", "certificate.", "batch."];

export function auditActionTone(action: string): string {
  const a = action.toLowerCase();
  if (ADMIN_DOMAINS.some((d) => a.startsWith(d)))
    return "bg-purple-50 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300";
  if (LMS_DOMAINS.some((d) => a.startsWith(d)))
    return "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300";
  if (CRM_DOMAINS.some((d) => a.startsWith(d)))
    return "bg-orange-50 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300";
  return "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300";
}

/* ── Role helpers ── */

export function roleDescription(key: string): string {
  return DEFAULT_ROLES.find((r) => r.key === key)?.description ?? "";
}

/** Avatar initials, e.g. "Priya Sharma" → "PS". */
export function initials(name: string): string {
  return name
    .split(/\s+/)
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

const PASSWORD_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*";

/** Cryptographically random password (12 chars, mixed alphabet + symbols). */
export function generatePassword(length = 12): string {
  const arr = new Uint32Array(length);
  crypto.getRandomValues(arr);
  return Array.from(arr, (n) => PASSWORD_CHARS[n % PASSWORD_CHARS.length]).join("");
}

/** Safe JSON pretty-print for audit meta. */
export function prettyMeta(meta: string | null): string | null {
  if (!meta) return null;
  try {
    return JSON.stringify(JSON.parse(meta), null, 2);
  } catch {
    return meta;
  }
}
