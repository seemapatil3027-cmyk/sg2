"use client";

import { useMemo, useState } from "react";
import { api, useApi, fmt } from "@/lib/api-client";
import { ROLE_KEYS, roleLabel } from "@/lib/rbac";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { DataTable, type Column } from "@/components/platform/data-table";
import { StatusBadge } from "@/components/platform/status-badge";
import {
  AdminUser,
  UsersListResponse,
  initials,
  roleBadgeTone,
  roleDescription,
  generatePassword,
} from "@/components/admin/admin-shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  UserCheck,
  ShieldCheck,
  Layers,
  Plus,
  Pencil,
  Trash2,
  Copy,
  Dice5,
  Eye,
  EyeOff,
  Loader2,
  Phone,
} from "lucide-react";

export function UsersClient({ sessionUid }: { sessionUid: string }) {
  const { toast } = useToast();
  const { can } = useUser();
  const canManage = can("admin.users.manage");

  const { data, loading, error, refetch } = useApi<UsersListResponse>(
    "/api/admin/users?pageSize=100&sort=createdAt&dir=desc"
  );

  /* ── Filters ── */
  const [roleFilter, setRoleFilter] = useState<string>("ALL");
  const [busyId, setBusyId] = useState<string | null>(null);

  const filterFn = useMemo(() => {
    return (row: AdminUser, q: string) => {
      if (roleFilter !== "ALL" && row.role !== roleFilter) return false;
      if (!q) return true;
      return row.name.toLowerCase().includes(q) || row.email.toLowerCase().includes(q);
    };
  }, [roleFilter]);

  /* ── Dialog state ── */
  const [addOpen, setAddOpen] = useState(false);
  const [editUser, setEditUser] = useState<AdminUser | null>(null);
  const [deleteUser, setDeleteUser] = useState<AdminUser | null>(null);

  const stats = data?.stats;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Users & Access"
        description="Every staff account on SkillGorila — roles, active status and sign-in history."
        actions={
          canManage ? (
            <Button className="rounded-xl" onClick={() => setAddOpen(true)}>
              <Plus className="mr-2 h-4 w-4" aria-hidden="true" /> Add user
            </Button>
          ) : null
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total users" value={stats?.total ?? "—"} icon={Users} tone="brand" hint="All staff accounts" />
        <StatCard label="Active" value={stats?.active ?? "—"} icon={UserCheck} tone="green" hint="Can sign in today" />
        <StatCard
          label="Admins & Super Admins"
          value={stats?.admins ?? "—"}
          icon={ShieldCheck}
          tone="orange"
          hint="Privileged accounts"
        />
        <StatCard label="Roles in use" value={stats?.roles ?? "—"} icon={Layers} tone="amber" hint="Distinct roles assigned" />
      </div>

      <DataTable<AdminUser>
        columns={userColumns({ canManage, sessionUid, onEdit: setEditUser, onDelete: setDeleteUser, onToggleActive: handleToggleActive, busyId: busyId })}
        rows={data?.items ?? []}
        loading={loading}
        error={error}
        onRetry={refetch}
        rowKey={(r) => r.id}
        searchPlaceholder="Search name or email…"
        emptyTitle="No users match"
        emptyHint="Try a different search term or role filter."
        filterFn={filterFn}
        toolbar={
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="h-9 w-full rounded-xl sm:w-52" aria-label="Filter by role">
              <SelectValue placeholder="All roles" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All roles</SelectItem>
              {ROLE_KEYS.map((key) => (
                <SelectItem key={key} value={key}>
                  {roleLabel(key)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        }
      />

      {canManage && (
        <>
          <AddUserDialog
            open={addOpen}
            onOpenChange={setAddOpen}
            onCreated={() => {
              setAddOpen(false);
              void refetch();
            }}
          />
          <EditUserDialog
            user={editUser}
            sessionUid={sessionUid}
            onClose={() => setEditUser(null)}
            onSaved={() => {
              setEditUser(null);
              void refetch();
            }}
          />
          <DeleteUserDialog
            user={deleteUser}
            onClose={() => setDeleteUser(null)}
            onDeleted={() => {
              setDeleteUser(null);
              void refetch();
            }}
          />
        </>
      )}
    </div>
  );

  /* ── Inline active toggle ── */
  async function handleToggleActive(u: AdminUser, next: boolean) {
    setBusyId(u.id);
    try {
      await api.patch(`/api/admin/users/${u.id}`, { isActive: next });
      toast({
        title: next ? "User activated" : "User deactivated",
        description: `${u.name} can${next ? " now" : " no longer"} sign in.`,
      });
      await refetch();
    } catch (e) {
      toast({
        title: "Update failed",
        description: e instanceof Error ? e.message : "Could not update the user.",
        variant: "destructive",
      });
    } finally {
      setBusyId(null);
    }
  }
}

/* ── Table columns ── */

function userColumns({
  canManage,
  sessionUid,
  onEdit,
  onDelete,
  onToggleActive,
  busyId,
}: {
  canManage: boolean;
  sessionUid: string;
  onEdit: (u: AdminUser) => void;
  onDelete: (u: AdminUser) => void;
  onToggleActive: (u: AdminUser, next: boolean) => Promise<void>;
  busyId: string | null;
}): Column<AdminUser>[] {
  const cols: Column<AdminUser>[] = [
    {
      key: "name",
      header: "User",
      sortable: true,
      render: (u) => (
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-soft text-xs font-bold text-brand dark:bg-brand/15 dark:text-violet-300">
            {initials(u.name)}
          </span>
          <div className="min-w-0">
            <p className="truncate font-semibold text-foreground">
              {u.name}
              {u.id === sessionUid && <span className="ml-2 text-[11px] font-normal text-muted-foreground">(you)</span>}
            </p>
            {u.phone ? (
              <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
                <Phone className="h-3 w-3" aria-hidden="true" /> {u.phone}
              </p>
            ) : null}
          </div>
        </div>
      ),
    },
    {
      key: "email",
      header: "Email",
      sortable: true,
      render: (u) => <span className="text-muted-foreground">{u.email}</span>,
    },
    {
      key: "role",
      header: "Role",
      render: (u) => (
        <StatusBadge value={u.roleLabel} fallbackTone={roleBadgeTone(u.role)} />
      ),
    },
    {
      key: "isActive",
      header: "Active",
      render: (u) =>
        canManage ? (
          <Switch
            checked={u.isActive}
            disabled={u.id === sessionUid || busyId === u.id}
            onCheckedChange={(v) => void onToggleActive(u, v)}
            aria-label={u.isActive ? `Deactivate ${u.name}` : `Activate ${u.name}`}
          />
        ) : (
          <StatusBadge value={u.isActive ? "ACTIVE" : "INACTIVE"} />
        ),
    },
    {
      key: "lastLoginAt",
      header: "Last sign-in",
      render: (u) => <span className="text-muted-foreground">{u.lastLoginAt ? fmt.relative(u.lastLoginAt) : "Never"}</span>,
    },
    {
      key: "createdAt",
      header: "Created",
      sortable: true,
      render: (u) => <span className="text-muted-foreground">{fmt.date(u.createdAt)}</span>,
    },
  ];

  if (canManage) {
    cols.push({
      key: "actions",
      header: "",
      headerClassName: "w-24",
      render: (u) => (
        <div className="flex items-center justify-end gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-lg"
            onClick={() => onEdit(u)}
            aria-label={`Edit ${u.name}`}
          >
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-lg text-destructive hover:text-destructive"
            disabled={u.id === sessionUid}
            onClick={() => onDelete(u)}
            aria-label={`Delete ${u.name}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    });
  }

  return cols;
}

/* ── Add user dialog ── */

function AddUserDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: () => void;
}) {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "EMPLOYEE", phone: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [saving, setSaving] = useState(false);

  function reset() {
    setForm({ name: "", email: "", password: "", role: "EMPLOYEE", phone: "" });
    setShowPassword(false);
  }

  function randomPassword() {
    const pwd = generatePassword();
    setForm((f) => ({ ...f, password: pwd }));
    setShowPassword(true);
  }

  async function copyPassword() {
    if (!form.password) return;
    try {
      await navigator.clipboard.writeText(form.password);
      toast({ title: "Password copied", description: "Share it with the user securely." });
    } catch {
      toast({ title: "Copy failed", description: "Select the password and copy manually.", variant: "destructive" });
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post("/api/admin/users", {
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role,
        phone: form.phone || null,
      });
      toast({
        title: "User created",
        description: `${form.name} can now sign in with the shared password.`,
      });
      reset();
      onCreated();
    } catch (err) {
      toast({
        title: "Could not create user",
        description: err instanceof Error ? err.message : "Something went wrong.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) reset(); onOpenChange(v); }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add user</DialogTitle>
          <DialogDescription>Create a staff account and assign a role.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="nu-name" className="text-xs font-semibold">Full name *</Label>
            <Input
              id="nu-name"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="e.g. Ananya Verma"
              required
              minLength={2}
              className="rounded-xl"
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="nu-email" className="text-xs font-semibold">Work email *</Label>
            <Input
              id="nu-email"
              type="email"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              placeholder="name@skillgorila.com"
              required
              className="rounded-xl"
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="nu-password" className="text-xs font-semibold">Temporary password * (min 8 characters)</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  id="nu-password"
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                  required
                  minLength={8}
                  autoComplete="new-password"
                  className="rounded-xl pr-9"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <Button type="button" variant="outline" className="rounded-xl" onClick={randomPassword} title="Generate random password">
                <Dice5 className="h-4 w-4" />
                <span className="sr-only">Generate random password</span>
              </Button>
              <Button
                type="button"
                variant="outline"
                className="rounded-xl"
                onClick={() => void copyPassword()}
                disabled={!form.password}
                title="Copy password"
              >
                <Copy className="h-4 w-4" />
                <span className="sr-only">Copy password</span>
              </Button>
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="nu-role" className="text-xs font-semibold">Role *</Label>
            <Select value={form.role} onValueChange={(v) => setForm((f) => ({ ...f, role: v }))}>
              <SelectTrigger id="nu-role" className="rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ROLE_KEYS.map((key) => (
                  <SelectItem key={key} value={key}>
                    {roleLabel(key)}
                    {key === "SUPER_ADMIN" ? " — full access" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">{roleDescription(form.role)}</p>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="nu-phone" className="text-xs font-semibold">Phone (optional)</Label>
            <Input
              id="nu-phone"
              value={form.phone}
              onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
              placeholder="+91 98765 43210"
              className="rounded-xl"
            />
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="rounded-xl" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="rounded-xl" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
              Create user
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ── Edit user dialog ── */

function EditUserDialog({
  user,
  sessionUid,
  onClose,
  onSaved,
}: {
  user: AdminUser | null;
  sessionUid: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("EMPLOYEE");
  const [isActive, setIsActive] = useState(true);
  const [loadedFor, setLoadedFor] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Sync local state when a different user is opened.
  if (user && loadedFor !== user.id) {
    setLoadedFor(user.id);
    setName(user.name);
    setPhone(user.phone ?? "");
    setRole(user.role);
    setIsActive(user.isActive);
  }

  const isSelf = user?.id === sessionUid;
  const isLastSuperAdmin = user?.role === "SUPER_ADMIN" && user.isActive;
  const lockedProfile = isSelf; // cannot change own role/active (server enforced)

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      await api.patch(`/api/admin/users/${user.id}`, {
        name,
        phone: phone || null,
        ...(lockedProfile ? {} : { role, isActive }),
      });
      toast({ title: "User updated", description: `${name}'s account was saved.` });
      onSaved();
    } catch (err) {
      toast({
        title: "Update failed",
        description: err instanceof Error ? err.message : "Could not update the user.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!user} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit user</DialogTitle>
          <DialogDescription>{user?.email}</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="eu-name" className="text-xs font-semibold">Full name</Label>
            <Input id="eu-name" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} className="rounded-xl" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="eu-phone" className="text-xs font-semibold">Phone</Label>
            <Input id="eu-phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 98765 43210" className="rounded-xl" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="eu-role" className="text-xs font-semibold">Role</Label>
            <Select value={role} onValueChange={setRole} disabled={lockedProfile}>
              <SelectTrigger id="eu-role" className="rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ROLE_KEYS.map((key) => (
                  <SelectItem key={key} value={key}>
                    {roleLabel(key)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">{roleDescription(role)}</p>
          </div>
          <div className="flex items-center justify-between rounded-xl border p-3">
            <div>
              <p className="text-sm font-semibold">Active</p>
              <p className="text-xs text-muted-foreground">
                {lockedProfile
                  ? "You cannot deactivate your own account."
                  : isLastSuperAdmin
                    ? "Cannot deactivate the last active Super Admin."
                    : "Inactive users cannot sign in."}
              </p>
            </div>
            <Switch checked={isActive} onCheckedChange={setIsActive} disabled={lockedProfile || isLastSuperAdmin} aria-label="User active" />
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="rounded-xl" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="rounded-xl" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
              Save changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ── Delete confirmation ── */

function DeleteUserDialog({
  user,
  onClose,
  onDeleted,
}: {
  user: AdminUser | null;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const { toast } = useToast();
  const [deleting, setDeleting] = useState(false);

  async function confirm() {
    if (!user) return;
    setDeleting(true);
    try {
      await api.delete(`/api/admin/users/${user.id}`);
      toast({ title: "User deleted", description: `${user.email} was removed from the platform.` });
      onDeleted();
    } catch (err) {
      toast({
        title: "Delete failed",
        description: err instanceof Error ? err.message : "Could not delete the user.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  }

  return (
    <AlertDialog open={!!user} onOpenChange={(v) => !v && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete this user?</AlertDialogTitle>
          <AlertDialogDescription>
            <span className="font-semibold text-foreground">{user?.name}</span> ({user?.email}) will permanently lose
            access. Their records stay intact for audit purposes. This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="rounded-xl">Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
            disabled={deleting}
            onClick={(e) => {
              e.preventDefault();
              void confirm();
            }}
          >
            {deleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
            Delete user
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
