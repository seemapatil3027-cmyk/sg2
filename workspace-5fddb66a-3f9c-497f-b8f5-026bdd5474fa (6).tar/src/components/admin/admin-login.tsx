"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Loader2, LockKeyhole, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

/**
 * Branded admin sign-in card — shown on /-admin when there is no session.
 * Posts to the existing /api/auth/signin endpoint; on success the server
 * components are refreshed so the CRM dashboard renders.
 */
export function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (res.ok) {
        // Session cookie is set — re-render the server component tree.
        router.refresh();
        return;
      }
      if (res.status === 401) {
        setError("Invalid credentials");
      } else {
        const data = (await res.json().catch(() => null)) as { error?: string } | null;
        setError(data?.error || "Sign in failed. Please try again.");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container-sv flex min-h-[60vh] items-center justify-center py-12 sm:py-16">
      <div className="w-full max-w-md">
        <div className="rounded-3xl border border-border bg-card p-6 shadow-lg sm:p-8">
          <div className="flex flex-col items-center text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-soft text-brand">
              <ShieldCheck className="h-7 w-7" aria-hidden="true" />
            </span>
            <h1 className="mt-4 text-xl font-extrabold text-ink sm:text-2xl">Admin Control Center</h1>
            <p className="mt-1.5 text-sm text-ink-soft">
              Restricted area — sign in with your staff account to manage leads, users and content.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4" noValidate>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="admin-email" className="text-sm font-semibold text-ink">
                Email
              </Label>
              <Input
                id="admin-email"
                name="email"
                type="email"
                autoComplete="email"
                required
                placeholder="you@skillgorila.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 rounded-xl border-border bg-white focus-visible:border-brand focus-visible:ring-brand/30"
                aria-invalid={error ? true : undefined}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="admin-password" className="text-sm font-semibold text-ink">
                Password
              </Label>
              <Input
                id="admin-password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11 rounded-xl border-border bg-white focus-visible:border-brand focus-visible:ring-brand/30"
                aria-invalid={error ? true : undefined}
              />
            </div>

            {error && (
              <p role="alert" className="rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-red-600">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="h-11 rounded-xl bg-primary text-[15px] font-semibold text-white hover:bg-brand-dark"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <LockKeyhole className="h-4 w-4" aria-hidden="true" />
              )}
              {loading ? "Signing in…" : "Sign in to admin"}
            </Button>
          </form>
        </div>

        <p className="mt-4 text-center text-xs text-ink-soft">
          Demo access — sign in with <span className="font-semibold text-brand">admin@skillgorila.com</span>
        </p>
      </div>
    </div>
  );
}
