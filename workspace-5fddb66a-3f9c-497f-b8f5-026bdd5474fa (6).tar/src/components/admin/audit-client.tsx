"use client";

import { useEffect, useMemo, useState } from "react";
import { useApi, fmt } from "@/lib/api-client";
import { PageHeader, StatCard } from "@/components/platform/page-header";
import { DataTable, type Column } from "@/components/platform/data-table";
import { StatusBadge } from "@/components/platform/status-badge";
import { AuditEntry, AuditResponse, auditActionTone, prettyMeta, roleBadgeTone } from "@/components/admin/admin-shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  ChevronLeft,
  ChevronRight,
  ScrollText,
  Search,
  X,
  History,
  Database,
} from "lucide-react";

const PAGE_SIZE = 20;

export function AuditClient() {
  /* Server-side filters + pagination */
  const [page, setPage] = useState(1);
  const [qInput, setQInput] = useState("");
  const [q, setQ] = useState("");
  const [domain, setDomain] = useState("ALL");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  // Debounce the actor-email search.
  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(t);
  }, [qInput]);

  const url = useMemo(() => {
    const sp = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
    if (q) sp.set("q", q);
    if (domain !== "ALL") sp.set("action", domain);
    if (from) sp.set("from", new Date(`${from}T00:00:00`).toISOString());
    if (to) sp.set("to", new Date(`${to}T23:59:59.999`).toISOString());
    return `/api/admin/audit?${sp.toString()}`;
  }, [page, q, domain, from, to]);

  const { data, loading, error, refetch } = useApi<AuditResponse>(url);

  const items = data?.items ?? [];
  const total = data?.total ?? 0;
  const pages = data?.pages ?? 1;

  // Distinct action domains for the select (derived from the full action list).
  const domainOptions = useMemo(() => {
    const set = new Set<string>();
    for (const a of data?.actions ?? []) {
      const idx = a.indexOf(".");
      set.add(idx > 0 ? a.slice(0, idx + 1) : a);
    }
    return Array.from(set).sort();
  }, [data?.actions]);

  const hasFilters = q !== "" || domain !== "ALL" || from !== "" || to !== "";

  function resetFilters() {
    setQInput("");
    setQ("");
    setDomain("ALL");
    setFrom("");
    setTo("");
    setPage(1);
  }

  const [detail, setDetail] = useState<AuditEntry | null>(null);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Audit Log"
        description="Who did what across the platform — every write action is recorded here."
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Audit entries (filtered)" value={total} icon={ScrollText} tone="brand" hint="Matching current filters" />
        <StatCard label="Action domains" value={domainOptions.length} icon={Database} tone="orange" hint="Distinct action prefixes" />
        <StatCard
          label="Latest entry"
          value={items[0]?.createdAt ? fmt.relative(items[0].createdAt) : "—"}
          icon={History}
          tone="green"
          hint={items[0]?.actorEmail ?? "No activity yet"}
        />
      </div>

      <div>
        <DataTable<AuditEntry>
          columns={auditColumns}
          rows={items}
          loading={loading}
          error={error}
          onRetry={refetch}
          onRowClick={(row) => setDetail(row)}
          rowKey={(r) => r.id}
          pageSize={PAGE_SIZE}
          emptyTitle={hasFilters ? "No matching entries" : "No audit entries yet"}
          emptyHint={
            hasFilters
              ? "Try widening the date range or clearing filters."
              : "Actions across CRM, LMS and Administration will appear here."
          }
          toolbar={
            <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center">
              <div className="relative sm:w-56">
                <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <Input
                  value={qInput}
                  onChange={(e) => setQInput(e.target.value)}
                  placeholder="Actor email…"
                  className="h-9 rounded-xl pl-9"
                  aria-label="Search by actor email"
                />
              </div>
              <Select
                value={domain}
                onValueChange={(v) => {
                  setDomain(v);
                  setPage(1);
                }}
              >
                <SelectTrigger className="h-9 rounded-xl sm:w-40" aria-label="Filter by action domain">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All domains</SelectItem>
                  {domainOptions.map((d) => (
                    <SelectItem key={d} value={d}>
                      {d.endsWith(".") ? d : `${d}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center gap-2">
                <Input
                  type="date"
                  value={from}
                  onChange={(e) => {
                    setFrom(e.target.value);
                    setPage(1);
                  }}
                  className="h-9 rounded-xl"
                  aria-label="From date"
                />
                <span className="text-xs text-muted-foreground">→</span>
                <Input
                  type="date"
                  value={to}
                  onChange={(e) => {
                    setTo(e.target.value);
                    setPage(1);
                  }}
                  className="h-9 rounded-xl"
                  aria-label="To date"
                />
                {hasFilters ? (
                  <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 rounded-xl" onClick={resetFilters} aria-label="Clear filters" title="Clear filters">
                    <X className="h-4 w-4" />
                  </Button>
                ) : null}
              </div>
            </div>
          }
        />

        {/* Server-side pagination */}
        <div className="mt-3 flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            {total === 0 ? "No entries" : `Showing ${(page - 1) * PAGE_SIZE + 1}–${Math.min(page * PAGE_SIZE, total)} of ${total}`}
          </p>
          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8 rounded-lg"
              disabled={page <= 1 || loading}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              aria-label="Previous page"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="min-w-16 text-center text-xs font-medium text-muted-foreground">
              {page} / {pages}
            </span>
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8 rounded-lg"
              disabled={page >= pages || loading}
              onClick={() => setPage((p) => Math.min(pages, p + 1))}
              aria-label="Next page"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <AuditDetailSheet entry={detail} onClose={() => setDetail(null)} />
    </div>
  );
}

/* ── Columns ── */

const auditColumns: Column<AuditEntry>[] = [
  {
    key: "createdAt",
    header: "When",
    render: (e) => <span className="whitespace-nowrap text-muted-foreground">{fmt.dateTime(e.createdAt)}</span>,
  },
  {
    key: "actorEmail",
    header: "Actor",
    render: (e) => (
      <div className="flex items-center gap-2">
        <span className="max-w-44 truncate font-medium text-foreground" title={e.actorEmail}>
          {e.actorEmail}
        </span>
        <StatusBadge value={e.actorRole} fallbackTone={roleBadgeTone(e.actorRole)} className="hidden md:inline-flex" />
      </div>
    ),
  },
  {
    key: "action",
    header: "Action",
    render: (e) => (
      <span className={`inline-block whitespace-nowrap rounded-md px-2 py-0.5 font-mono text-xs font-medium ${auditActionTone(e.action)}`}>
        {e.action}
      </span>
    ),
  },
  {
    key: "entity",
    header: "Entity",
    render: (e) => (
      <span className="whitespace-nowrap text-muted-foreground">
        {e.entity}
        {e.entityId ? <span className="ml-1 font-mono text-[11px] opacity-70">#{e.entityId.slice(-6)}</span> : null}
      </span>
    ),
  },
  {
    key: "summary",
    header: "Summary",
    render: (e) => (
      <span className="block max-w-sm truncate text-muted-foreground" title={e.summary ?? undefined}>
        {e.summary ?? "—"}
      </span>
    ),
  },
];

/* ── Detail sheet ── */

function AuditDetailSheet({ entry, onClose }: { entry: AuditEntry | null; onClose: () => void }) {
  const meta = entry ? prettyMeta(entry.meta) : null;
  return (
    <Sheet open={!!entry} onOpenChange={(v) => !v && onClose()}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-mono text-base">{entry?.action}</SheetTitle>
          <SheetDescription>{entry ? fmt.dateTime(entry.createdAt) : ""}</SheetDescription>
        </SheetHeader>
        {entry ? (
          <div className="space-y-4 px-4 pb-8">
            <div className="grid gap-3 rounded-2xl border p-4 text-sm">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Actor</p>
                <p className="mt-0.5 font-medium">{entry.actorEmail}</p>
                <Badge variant="outline" className="mt-1">
                  {entry.actorRole}
                </Badge>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Entity</p>
                <p className="mt-0.5 font-medium">
                  {entry.entity}
                  {entry.entityId ? <span className="ml-2 font-mono text-xs text-muted-foreground">{entry.entityId}</span> : null}
                </p>
              </div>
              {entry.summary ? (
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Summary</p>
                  <p className="mt-0.5">{entry.summary}</p>
                </div>
              ) : null}
            </div>
            {meta ? (
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Metadata</p>
                <pre className="max-h-96 overflow-y-auto rounded-xl bg-muted p-3 font-mono text-xs leading-relaxed">{meta}</pre>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No metadata recorded for this entry.</p>
            )}
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}
