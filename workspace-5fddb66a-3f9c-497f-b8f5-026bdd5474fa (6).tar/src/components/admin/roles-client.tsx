"use client";

import { useMemo, useState } from "react";
import { api, useApi } from "@/lib/api-client";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/platform/page-header";
import { LoadingBlock, ErrorBlock } from "@/components/platform/states";
import { RoleMatrix, RolesResponse, roleBadgeTone, initials } from "@/components/admin/admin-shared";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Info, Loader2, Save, Users, ShieldCheck, RotateCcw } from "lucide-react";

export function RolesClient() {
  const { toast } = useToast();
  const { can } = useUser();
  const canManage = can("admin.roles.manage");

  const { data, loading, error, refetch } = useApi<RolesResponse>("/api/admin/roles");

  /* Draft state per role key — permissions + description edited locally until saved. */
  const [permDrafts, setPermDrafts] = useState<Record<string, string[]>>({});
  const [descDrafts, setDescDrafts] = useState<Record<string, string>>({});
  const [activeKey, setActiveKey] = useState<string>("ADMIN");
  const [saving, setSaving] = useState(false);

  // People directory for "who has this role" chips.
  const { data: people } = useApi<{ items: { id: string; name: string; email: string; role: string }[] }>(
    "/api/platform/users/basic"
  );

  const roles = data?.items ?? [];

  const active = useMemo<RoleMatrix | null>(
    () => roles.find((r) => r.key === activeKey) ?? roles[0] ?? null,
    [roles, activeKey]
  );

  const draftPerms = useMemo<string[] | null>(() => {
    if (!active) return null;
    return permDrafts[active.key] ?? active.permissions;
  }, [active, permDrafts]);

  const draftDesc = active ? descDrafts[active.key] ?? active.description : "";

  const dirty = useMemo(() => {
    if (!active) return false;
    const permsChanged = JSON.stringify(draftPerms ?? []) !== JSON.stringify(active.permissions);
    const descChanged = draftDesc !== active.description;
    return permsChanged || descChanged;
  }, [active, draftPerms, draftDesc]);

  const isWildcard = active?.permissions.includes("*") ?? false;
  const locked = !active || isWildcard || !canManage;

  function setDraft(next: string[]) {
    if (!active) return;
    setPermDrafts((d) => ({ ...d, [active.key]: next }));
  }

  function togglePerm(key: string, on: boolean) {
    if (!draftPerms) return;
    setDraft(on ? [...draftPerms, key] : draftPerms.filter((k) => k !== key));
  }

  function toggleGroup(groupKeys: string[], on: boolean) {
    if (!draftPerms) return;
    const set = new Set(draftPerms);
    for (const k of groupKeys) {
      if (on) set.add(k);
      else set.delete(k);
    }
    // Keep draft ordered like the catalog (allKeys follows PERMISSION_CATALOG order).
    setDraft((data?.allKeys ?? []).filter((k) => set.has(k)));
  }

  async function save() {
    if (!active) return;
    setSaving(true);
    try {
      await api.put(`/api/admin/roles/${active.key}`, {
        permissions: draftPerms ?? [],
        description: draftDesc.trim() ? draftDesc.trim() : undefined,
      });
      toast({
        title: "Role updated",
        description: `${active.name} now has ${draftPerms?.length ?? 0} permissions — applied instantly.`,
      });
      // Drop local drafts for this role and sync from server.
      setPermDrafts((d) => {
        const rest = { ...d };
        delete rest[active.key];
        return rest;
      });
      setDescDrafts((d) => {
        const rest = { ...d };
        delete rest[active.key];
        return rest;
      });
      await refetch();
    } catch (err) {
      toast({
        title: "Save failed",
        description: err instanceof Error ? err.message : "Could not update the role.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  if (loading && !data) return <LoadingBlock label="Loading roles…" />;
  if (error && !data) return <ErrorBlock message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Roles & Permissions"
        description="Configure what each role can see and do across the platform."
      />

      <Card className="rounded-2xl border-brand/20 bg-brand-soft/40 dark:border-brand/30 dark:bg-brand/10">
        <CardContent className="flex items-start gap-3 p-4">
          <Info className="mt-0.5 h-4.5 w-4.5 shrink-0 text-brand dark:text-violet-300" aria-hidden="true" />
          <div className="text-sm">
            <p className="font-semibold text-foreground">Permissions are configurable at runtime</p>
            <p className="mt-1 text-muted-foreground">
              This matrix is stored in the database — flip any switch and press{" "}
              <span className="font-semibold text-foreground">Save</span>; changes apply instantly for every user with
              that role (they refresh on next navigation). Super Admin always keeps full wildcard access.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Role selector tabs */}
      <Tabs value={active?.key ?? ""} onValueChange={setActiveKey}>
        <TabsList className="h-auto w-full flex-wrap justify-start gap-1 rounded-2xl p-1.5">
          {roles.map((r) => (
            <TabsTrigger
              key={r.key}
              value={r.key}
              className="gap-1.5 rounded-xl px-3 py-1.5 data-[state=active]:shadow-sm"
            >
              <span
                className={`inline-block h-2 w-2 rounded-full ${
                  r.key === "SUPER_ADMIN" ? "bg-purple-500" : r.key.startsWith("CRM_") ? "bg-orange-500" : r.key.startsWith("LMS_") ? "bg-emerald-500" : r.key === "INSTRUCTOR" ? "bg-amber-500" : "bg-slate-400"
                }`}
                aria-hidden="true"
              />
              {r.name}
              <Badge variant="secondary" className="ml-1 rounded-full px-1.5 text-[10px]">
                {r.userCount}
              </Badge>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {active ? (
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Permission matrix */}
          <div className="space-y-4 lg:col-span-2">
            {isWildcard && (
              <div className="flex items-center gap-2 rounded-xl border border-purple-200 bg-purple-50 p-3 text-sm text-purple-700 dark:border-purple-500/30 dark:bg-purple-500/10 dark:text-purple-300">
                <ShieldCheck className="h-4 w-4 shrink-0" aria-hidden="true" />
                Full access — wildcard. Every permission is granted to this role and cannot be edited.
              </div>
            )}
            {(data?.catalog ?? []).map((group) => {
              const groupKeys = group.items.map((i) => i.key);
              const checkedCount = groupKeys.filter((k) => draftPerms?.includes(k) || isWildcard).length;
              const allChecked = checkedCount === groupKeys.length;
              const someChecked = checkedCount > 0 && !allChecked;
              return (
                <Card key={group.group} className="rounded-2xl">
                  <CardHeader className="flex-row items-center justify-between space-y-0 border-b p-4">
                    <div className="flex items-center gap-2.5">
                      <Checkbox
                        id={`group-${group.group}`}
                        checked={allChecked ? true : someChecked ? "indeterminate" : false}
                        onCheckedChange={(v) => toggleGroup(groupKeys, v === true)}
                        disabled={locked}
                        aria-label={`Toggle all ${group.group} permissions`}
                      />
                      <CardTitle className="text-sm font-bold">{group.group}</CardTitle>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {checkedCount}/{groupKeys.length}
                    </span>
                  </CardHeader>
                  <CardContent className="divide-y p-0">
                    {group.items.map((item) => {
                      const checked = isWildcard || draftPerms?.includes(item.key);
                      return (
                        <div key={item.key} className="flex items-center justify-between gap-3 px-4 py-3">
                          <div className="min-w-0">
                            <Label htmlFor={`perm-${item.key}`} className="cursor-pointer text-[13px] font-medium leading-snug">
                              {item.label}
                            </Label>
                            <p className="truncate font-mono text-[11px] text-muted-foreground">{item.key}</p>
                          </div>
                          <Switch
                            id={`perm-${item.key}`}
                            checked={!!checked}
                            onCheckedChange={(v) => togglePerm(item.key, v)}
                            disabled={locked}
                            aria-label={`${item.label} for ${active.name}`}
                          />
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Role summary sidebar */}
          <div className="space-y-4">
            <Card className="rounded-2xl">
              <CardHeader className="p-4 pb-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={roleBadgeTone(active.key)}>
                    {active.name}
                  </Badge>
                  <span className="font-mono text-[11px] text-muted-foreground">{active.key}</span>
                </div>
                <CardDescription className="pt-1 text-xs">
                  {isWildcard
                    ? "This role carries the wildcard permission and cannot be edited."
                    : `${draftPerms?.length ?? 0} of ${data?.allKeys.length ?? 0} permissions enabled`}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 p-4 pt-2">
                <div className="grid gap-1.5">
                  <Label htmlFor="role-desc" className="text-xs font-semibold">
                    Role description
                  </Label>
                  <Textarea
                    id="role-desc"
                    value={draftDesc}
                    onChange={(e) => {
                      if (!active) return;
                      setDescDrafts((d) => ({ ...d, [active.key]: e.target.value }));
                    }}
                    disabled={locked}
                    rows={3}
                    maxLength={200}
                    placeholder="What is this role for?"
                    className="rounded-xl text-[13px]"
                  />
                  <p className="text-[11px] text-muted-foreground">{draftDesc.length}/200 characters</p>
                </div>

                {canManage && !isWildcard && (
                  <div className="flex items-center gap-2">
                    <Button onClick={() => void save()} disabled={!dirty || saving} className="flex-1 rounded-xl">
                      {saving ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                      ) : (
                        <Save className="mr-2 h-4 w-4" aria-hidden="true" />
                      )}
                      {saving ? "Saving…" : "Save changes"}
                    </Button>
                    {dirty ? (
                      <Button
                        variant="outline"
                        className="rounded-xl"
                        onClick={() => {
                          setPermDrafts((d) => {
                            const rest = { ...d };
                            delete rest[active.key];
                            return rest;
                          });
                          setDescDrafts((d) => {
                            const rest = { ...d };
                            delete rest[active.key];
                            return rest;
                          });
                        }}
                        title="Discard unsaved changes"
                      >
                        <RotateCcw className="h-4 w-4" />
                        <span className="sr-only">Discard changes</span>
                      </Button>
                    ) : null}
                  </div>
                )}
                {dirty && <p className="text-xs font-medium text-orange-600 dark:text-orange-300">Unsaved changes</p>}
              </CardContent>
            </Card>

            {/* Who has this role */}
            <Card className="rounded-2xl">
              <CardHeader className="p-4 pb-2">
                <CardTitle className="flex items-center gap-2 text-sm font-bold">
                  <Users className="h-4 w-4 text-brand" aria-hidden="true" />
                  Who has this role
                </CardTitle>
                <CardDescription className="text-xs">Active staff accounts holding {active.name}.</CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-2">
                {(() => {
                  const holders = (people?.items ?? []).filter((u) => u.role === active.key);
                  if (holders.length === 0)
                    return <p className="py-3 text-xs text-muted-foreground">No active users with this role right now.</p>;
                  return (
                    <div className="flex max-h-48 flex-wrap gap-2 overflow-y-auto">
                      {holders.map((u) => (
                        <span
                          key={u.id}
                          className="flex max-w-full items-center gap-2 rounded-full border bg-muted/40 py-1 pl-1 pr-3 text-xs"
                        >
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-white">
                            {initials(u.name)}
                          </span>
                          <span className="truncate text-muted-foreground" title={u.email}>
                            {u.email}
                          </span>
                        </span>
                      ))}
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <Card className="rounded-2xl">
          <CardContent className="p-8 text-center text-sm text-muted-foreground">No roles found.</CardContent>
        </Card>
      )}
    </div>
  );
}
