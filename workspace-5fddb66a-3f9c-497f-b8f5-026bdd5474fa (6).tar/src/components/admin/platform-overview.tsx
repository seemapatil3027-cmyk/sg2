"use client";

import { useState } from "react";
import {
  BarChart3,
  BookOpen,
  BrainCircuit,
  Braces,
  ChevronDown,
  ChevronUp,
  Code2,
  Cpu,
  Database,
  LineChart,
  Network,
  School,
  Sigma,
  Sparkles,
  Table,
  Users,
  type LucideIcon,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { InitialAvatar } from "@/components/shared/initial-avatar";
import { cn } from "@/lib/utils";

export interface OverviewUser {
  id: string;
  name: string;
  email: string;
  role: string;
  joinedLabel: string;
}

export interface OverviewTrack {
  id: string;
  title: string;
  learners: string | null;
  weeks: number | null;
  projects: number;
  icon: string;
}

export interface OverviewCourse {
  id: string;
  title: string;
  learners: number;
}

interface PlatformOverviewProps {
  users: OverviewUser[];
  tracks: OverviewTrack[];
  courses: OverviewCourse[];
}

const ROLE_BADGE: Record<string, string> = {
  ADMIN: "bg-gold/20 text-[#92400E]",
  COUNSELLOR: "bg-[#FCE7F3] text-[#BE185D]",
  INSTRUCTOR: "bg-brand-soft text-brand",
  STUDENT: "bg-secondary text-secondary-foreground",
};

/** Known track icon names → lucide icon, graceful Sparkles fallback. */
const ICON_MAP: Record<string, LucideIcon> = {
  BarChart3,
  School,
  LineChart,
  BrainCircuit,
  Network,
  Code2,
  Braces,
  Sigma,
  Cpu,
  Table,
  Database,
};

function trackIcon(name: string): LucideIcon {
  return ICON_MAP[name] ?? Sparkles;
}

/**
 * Collapsed "Platform overview" section — keeps the original Task 26 admin
 * panel's users + content inventory accessible below the CRM workspace.
 */
export function PlatformOverview({ users, tracks, courses }: PlatformOverviewProps) {
  const [open, setOpen] = useState(false);

  const topCourses = [...courses].sort((a, b) => b.learners - a.learners).slice(0, 3);

  return (
    <Collapsible open={open} onOpenChange={setOpen} className="mt-8">
      <div className="flex justify-center">
        <CollapsibleTrigger asChild>
          <Button
            variant="outline"
            className="h-10 rounded-xl border-border font-semibold text-ink hover:border-brand hover:text-brand"
            aria-expanded={open}
          >
            {open ? (
              <ChevronUp className="h-4 w-4" aria-hidden="true" />
            ) : (
              <ChevronDown className="h-4 w-4" aria-hidden="true" />
            )}
            {open ? "Hide platform overview" : "Show platform overview"}
          </Button>
        </CollapsibleTrigger>
      </div>

      <CollapsibleContent>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:gap-6 lg:grid-cols-3">
          {/* Platform users */}
          <Card className="rounded-3xl shadow-sm transition-all duration-300 hover:shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2.5 text-base text-ink">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                  <Users className="h-5 w-5" aria-hidden="true" />
                </span>
                Platform users
              </CardTitle>
              <CardDescription>{users.length} registered accounts</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {users.length === 0 ? (
                <p className="px-6 pb-6 text-sm text-ink-soft">No registered users found.</p>
              ) : (
                <ul
                  className="nice-scrollbar max-h-96 divide-y divide-border overflow-y-auto"
                  tabIndex={0}
                  aria-label="Platform users list, scrollable"
                >
                  {users.map((u) => (
                    <li key={u.id} className="flex items-center gap-3 px-6 py-3.5">
                      <InitialAvatar name={u.name} className="h-9 w-9 text-xs" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-ink">{u.name}</p>
                        <p className="truncate text-xs text-ink-soft">{u.email}</p>
                        <p className="mt-0.5 text-[11px] text-muted-foreground">Joined {u.joinedLabel}</p>
                      </div>
                      <Badge
                        className={cn(
                          "shrink-0 rounded-full border-transparent",
                          ROLE_BADGE[u.role] ?? "bg-muted text-muted-foreground"
                        )}
                      >
                        {u.role}
                      </Badge>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>

          {/* Content overview */}
          <Card className="rounded-3xl shadow-sm transition-all duration-300 hover:shadow-md lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2.5 text-base text-ink">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                  <Sparkles className="h-5 w-5" aria-hidden="true" />
                </span>
                Content overview
              </CardTitle>
              <CardDescription>Live tracks and courses on the platform</CardDescription>
            </CardHeader>
            <CardContent>
              {tracks.length === 0 && courses.length === 0 ? (
                <p className="text-sm text-ink-soft">No tracks or courses published yet.</p>
              ) : (
                <div
                  className="nice-scrollbar grid max-h-96 gap-3 overflow-y-auto sm:grid-cols-2"
                  tabIndex={0}
                  aria-label="Tracks and courses overview, scrollable"
                >
                  {tracks.map((t) => {
                    const Icon = trackIcon(t.icon);
                    return (
                      <div
                        key={t.id}
                        className="flex items-center gap-3 rounded-2xl border border-border p-3 transition-all duration-300 hover:border-brand/40 hover:shadow-md"
                      >
                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                          <Icon className="h-5 w-5" aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-ink">{t.title}</p>
                          <p className="truncate text-xs text-ink-soft">
                            {t.learners ?? "—"} learners · {t.weeks ? `${t.weeks} weeks` : "self-paced"} ·{" "}
                            {t.projects} projects
                          </p>
                        </div>
                      </div>
                    );
                  })}

                  {/* Courses summary card */}
                  <div className="rounded-2xl border border-gold/40 bg-gold/10 p-3">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gold/20 text-[#B45309]">
                        <BookOpen className="h-5 w-5" aria-hidden="true" />
                      </span>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-ink">{courses.length} courses live</p>
                        <p className="text-xs text-ink-soft">Most popular right now</p>
                      </div>
                    </div>
                    <ul className="mt-2.5 flex flex-col gap-1.5">
                      {topCourses.map((c) => (
                        <li key={c.id} className="flex items-center justify-between gap-2 text-xs">
                          <span className="truncate text-ink">{c.title}</span>
                          <span className="shrink-0 font-semibold text-ink-soft">{c.learners} learners</span>
                        </li>
                      ))}
                      {topCourses.length === 0 && (
                        <li className="text-xs text-ink-soft">No courses published yet.</li>
                      )}
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
