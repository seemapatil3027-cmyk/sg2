/**
 * SkillGorila Career Assessment engine.
 *
 * Pure, isomorphic logic (no DB / no React) — used by:
 *  - the client-side assessment widget (instant results, zero network)
 *  - /api/leads (embeds a structured summary + lead score into the CRM note)
 *
 * Recommends one of the career tracks that exist in the database.
 */

export interface AssessmentAnswers {
  education: "school" | "bachelor" | "master" | "other";
  role: "student" | "fresher" | "working" | "career-gap";
  experience: "none" | "0-2" | "2-5" | "5+";
  skills: string[]; // excel | sql | python | powerbi | ml | coding | genai | sap
  goal: string; // free text — desired role
  salary: "3-6" | "6-12" | "12+";
  learning: "live-online" | "self-paced" | "classroom";
  hours: "0-5" | "5-10" | "10-20" | "20+";
}

export interface TrackInfo {
  slug: string;
  title: string;
  tagline: string;
  months: number;
  projects: number;
  liveSessions: number;
  skills: string[]; // skills the track teaches
  keywords: string[]; // goal keywords that point at this track
  minHours: number; // weekly hours the track expects
}

export const TRACKS: TrackInfo[] = [
  {
    slug: "data-analytics-and-ai",
    title: "Data Analytics & Generative AI",
    tagline: "Excel → SQL → Power BI → Python → GenAI",
    months: 5,
    projects: 7,
    liveSessions: 20,
    skills: ["excel", "sql", "powerbi", "python", "genai"],
    keywords: ["data analyst", "analyst", "business analyst", "bi", "analytics", "power bi", "mis"],
    minHours: 10,
  },
  {
    slug: "data-analytics-python",
    title: "Data Analytics + Python",
    tagline: "Python-first analytics with real datasets",
    months: 4,
    projects: 6,
    liveSessions: 16,
    skills: ["python", "sql", "excel", "powerbi"],
    keywords: ["python analytics", "data analyst", "python"],
    minHours: 8,
  },
  {
    slug: "data-analytics-offline",
    title: "Data Analytics Classroom Program",
    tagline: "In-classroom, Bengaluru — peer learning + placement drive",
    months: 4,
    projects: 6,
    liveSessions: 40,
    skills: ["excel", "sql", "powerbi", "python"],
    keywords: ["classroom", "offline", "in-person", "bengaluru"],
    minHours: 12,
  },
  {
    slug: "data-science-and-ai",
    title: "Data Science & AI",
    tagline: "Statistics → ML → Deep Learning → MLOps basics",
    months: 6,
    projects: 8,
    liveSessions: 24,
    skills: ["python", "ml", "sql", "genai"],
    keywords: ["data scientist", "data science", "ml engineer", "machine learning", "ai engineer"],
    minHours: 12,
  },
  {
    slug: "data-science-machine-learning",
    title: "Data Science & Machine Learning",
    tagline: "ML systems end-to-end — from EDA to deployment",
    months: 6,
    projects: 8,
    liveSessions: 24,
    skills: ["python", "ml", "sql"],
    keywords: ["machine learning", "ml", "deep learning", "mlops"],
    minHours: 12,
  },
  {
    slug: "ai-mastery-program",
    title: "AI Mastery Program",
    tagline: "GenAI, LLM apps and AI product skills",
    months: 4,
    projects: 6,
    liveSessions: 18,
    skills: ["genai", "python", "ml"],
    keywords: ["genai", "generative", "llm", "ai", "prompt", "chatgpt"],
    minHours: 8,
  },
  {
    slug: "software-development",
    title: "Software Development",
    tagline: "Full-stack fundamentals → production projects",
    months: 6,
    projects: 8,
    liveSessions: 24,
    skills: ["coding", "python", "sql"],
    keywords: ["developer", "software engineer", "sde", "full stack", "full-stack", "web developer", "backend", "frontend", "coding"],
    minHours: 12,
  },
];

export interface AssessmentResult {
  recommended: TrackInfo;
  runnerUp: TrackInfo;
  readiness: number; // 0-100 — estimated current job-readiness for the track
  skillGap: number; // 0-100 — how much of the track is new to you
  plan: string[]; // ordered learning modules
  rationale: string;
}

const GOAL_ALIASES: Record<string, string[]> = {
  "data analyst": ["analyst", "bi", "power bi", "mis", "reporting"],
  "business analyst": ["analyst", "requirements", "domain"],
  "data scientist": ["ml", "python", "statistics"],
  "ml engineer": ["ml", "python", "deployment"],
  "ai engineer": ["genai", "llm"],
  "software developer": ["coding", "web", "full stack"],
  "web developer": ["coding", "web"],
};

function normalize(value: string): string {
  return value.trim().toLowerCase();
}

function goalTokens(goal: string): string[] {
  return normalize(goal).split(/[^a-z0-9+#]+/).filter(Boolean);
}

function scoreTrack(track: TrackInfo, answers: AssessmentAnswers): number {
  let score = 0;
  const goal = normalize(answers.goal);
  const tokens = goalTokens(answers.goal);

  // 1. Goal keyword match (strongest signal)
  for (const kw of track.keywords) {
    if (goal.includes(kw)) score += 30;
    else if (kw.split(" ").every((w) => tokens.includes(w))) score += 15;
  }

  // 2. Existing skills — reward tracks that build on what they know,
  //    but a total beginner fits the broadest entry track.
  const overlap = track.skills.filter((s) => answers.skills.includes(s)).length;
  const beginner = answers.skills.length === 0;
  if (beginner) score += track.skills.includes("excel") ? 12 : 4;
  else score += Math.min(overlap, 4) * 8;

  // 3. Experience level
  if (answers.experience === "none" || answers.experience === "0-2") {
    if (track.months <= 5) score += 10;
    if (track.skills.includes("excel")) score += 4;
  } else if (answers.experience === "2-5") {
    if (track.skills.includes("python") || track.skills.includes("ml")) score += 8;
  } else if (answers.experience === "5+") {
    if (track.skills.includes("ml") || track.skills.includes("genai")) score += 10;
  }

  // 4. Learning preference
  if (answers.learning === "classroom" && track.slug === "data-analytics-offline") score += 34;
  if (answers.learning === "live-online" && track.slug !== "data-analytics-offline") score += 10;
  if (answers.learning === "self-paced" && track.months <= 5) score += 4;

  // 5. Available hours vs track intensity
  const hours = parseInt(answers.hours.replace("+", ""), 10) || 0;
  if (hours > 0 && hours < track.minHours) score -= 14;

  // 6. Salary ambition — stretch tracks for high goals
  if (answers.salary === "12+" && (track.skills.includes("ml") || track.skills.includes("genai") || track.skills.includes("coding"))) score += 6;

  // 7. Role nudges
  if (answers.role === "student" && track.months <= 5) score += 6;
  if (answers.role === "working" && track.minHours <= 10) score += 6;

  return score;
}

function buildPlan(track: TrackInfo, answers: AssessmentAnswers): string[] {
  const known = track.skills.filter((s) => answers.skills.includes(s));
  const fresh = track.skills.filter((s) => !answers.skills.includes(s));
  const modules: string[] = [];
  if (track.skills.includes("excel")) modules.push(known.includes("excel") ? "Excel for Analytics — refresher + advanced formulas" : "Excel for Analytics — foundations");
  if (track.skills.includes("sql")) modules.push(known.includes("sql") ? "SQL — window functions & performance" : "SQL — from joins to analytics queries");
  if (track.skills.includes("powerbi")) modules.push("Power BI — dashboards that get interviews");
  if (track.skills.includes("python")) modules.push(known.includes("python") ? "Python — analytics & automation deep-dive" : "Python — zero to analytics-ready");
  if (track.skills.includes("ml")) modules.push("Machine Learning — models to deployment");
  if (track.skills.includes("genai")) modules.push("Generative AI — LLM apps & AI workflows");
  if (track.skills.includes("coding")) modules.push("Full-stack development — APIs, databases, deployment");
  modules.push(`Capstone: ${track.projects} industry-grade portfolio projects`);
  modules.push("Career sprint — resume, LinkedIn, mock interviews, job matching");
  return modules.slice(0, fresh.length >= 3 ? 6 : 5);
}

export function runAssessment(answers: AssessmentAnswers): AssessmentResult {
  const ranked = TRACKS.map((t) => ({ track: t, score: scoreTrack(t, answers) })).sort(
    (a, b) => b.score - a.score
  );
  const recommended = ranked[0].track;
  const runnerUp = (ranked[1] ?? ranked[0]).track;

  const knownCount = recommended.skills.filter((s) => answers.skills.includes(s)).length;
  const readiness = Math.min(92, 18 + knownCount * 14 + (answers.experience === "5+" ? 18 : answers.experience === "2-5" ? 12 : answers.experience === "0-2" ? 7 : 2));
  const skillGap = Math.max(25, 100 - readiness);

  const rationale = knownCount === 0
    ? `You're starting fresh — ${recommended.title} is the most structured route from zero to job-ready, with mentor support and placement assistance built in.`
    : `Your background covers ${knownCount} of ${recommended.skills.length} core skills — ${recommended.title} closes the remaining gap fastest while adding portfolio projects and placement support.`;

  return {
    recommended,
    runnerUp,
    readiness,
    skillGap,
    plan: buildPlan(recommended, answers),
    rationale,
  };
}

/* ------------------------------------------------------------------ */
/* CRM integration helpers                                             */
/* ------------------------------------------------------------------ */

/** Compact, human-readable assessment summary stored on the CRM lead note. */
export function buildAssessmentNote(answers: AssessmentAnswers, result: AssessmentResult): string {
  const parts = [
    `[assessment] leadScoreBase:${result.readiness}`,
    `education:${answers.education}`,
    `role:${answers.role}`,
    `experience:${answers.experience}`,
    `skills:${answers.skills.join("+") || "none"}`,
    `goal:${answers.goal}`,
    `salaryGoal:${answers.salary}LPA`,
    `learning:${answers.learning}`,
    `hours:${answers.hours}/wk`,
    `recommended:${result.recommended.slug}`,
    `runnerUp:${result.runnerUp.slug}`,
  ];
  return parts.join(" | ");
}

/**
 * Server-side lead score (0-100) — the website never sends this number;
 * it is always recomputed from the payload for trustworthiness.
 */
export function computeLeadScore(input: {
  name: string;
  phone: string;
  email: string;
  source: string;
  itemSlug: string | null;
  note: string | null;
}): number {
  let score = 10;
  if (input.name.length >= 3) score += 10;
  if (/^[+]?[\d\s-]{10,15}$/.test(input.phone)) score += 20;
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email)) score += 15;
  if (input.source === "assessment") score += 20;
  else if (input.source === "callback" || input.source === "brochure") score += 12;
  if (input.itemSlug) score += 15;
  if (input.note && input.note.length > 80) score += 10;
  return Math.min(100, score);
}
