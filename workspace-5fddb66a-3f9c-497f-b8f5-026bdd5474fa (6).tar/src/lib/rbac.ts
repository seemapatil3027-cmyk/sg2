/* SkillGorila RBAC — permission catalog, role matrix and runtime checks.
 *
 * Permissions are configurable at runtime: the `Role` table stores the live
 * matrix (seeded from DEFAULT_ROLES below). SUPER_ADMIN carries the "*"
 * wildcard. API routes call requirePermission(); the UI filters navigation
 * and actions through usePermissions(). */

export const ALL_PERMISSIONS = "*" as const;

export const PERMISSION_CATALOG: { group: string; items: { key: string; label: string }[] }[] = [
  {
    group: "General",
    items: [
      { key: "dashboard.view", label: "View dashboard" },
      { key: "notifications.view", label: "View notifications" },
    ],
  },
  {
    group: "CRM · Leads",
    items: [
      { key: "crm.leads.view", label: "View leads" },
      { key: "crm.leads.manage", label: "Create / edit / assign / delete leads" },
    ],
  },
  {
    group: "CRM · Contacts & Organizations",
    items: [
      { key: "crm.contacts.view", label: "View contacts" },
      { key: "crm.contacts.manage", label: "Create / edit / delete contacts" },
      { key: "crm.organizations.view", label: "View organizations" },
      { key: "crm.organizations.manage", label: "Create / edit / delete organizations" },
    ],
  },
  {
    group: "CRM · Deals & Pipeline",
    items: [
      { key: "crm.deals.view", label: "View deals & pipeline" },
      { key: "crm.deals.manage", label: "Create / edit / move / delete deals" },
    ],
  },
  {
    group: "CRM · Activities & Reports",
    items: [
      { key: "crm.activities.view", label: "View activities & tasks" },
      { key: "crm.activities.manage", label: "Create / complete / delete activities" },
      { key: "crm.reports.view", label: "View CRM reports" },
    ],
  },
  {
    group: "LMS · Courses",
    items: [
      { key: "lms.courses.view", label: "View courses & content" },
      { key: "lms.courses.manage", label: "Create / edit / publish courses, modules, lessons" },
    ],
  },
  {
    group: "LMS · Learners",
    items: [
      { key: "lms.enrollments.view", label: "View enrollments" },
      { key: "lms.enrollments.manage", label: "Enroll learners / update status" },
      { key: "lms.progress.view", label: "View learning progress" },
    ],
  },
  {
    group: "LMS · Assessments & Certificates",
    items: [
      { key: "lms.assessments.view", label: "View quizzes & submissions" },
      { key: "lms.assessments.manage", label: "Grade submissions / record attempts" },
      { key: "lms.certificates.view", label: "View certificates" },
      { key: "lms.certificates.issue", label: "Issue certificates" },
      { key: "lms.reports.view", label: "View LMS reports" },
    ],
  },
  {
    group: "Administration",
    items: [
      { key: "admin.users.view", label: "View users" },
      { key: "admin.users.manage", label: "Invite / edit / deactivate users" },
      { key: "admin.roles.view", label: "View roles & permissions" },
      { key: "admin.roles.manage", label: "Edit role permission matrix" },
      { key: "admin.audit.view", label: "View audit logs" },
      { key: "admin.settings.manage", label: "Manage platform settings" },
    ],
  },
];

export const ALL_PERMISSION_KEYS: string[] = PERMISSION_CATALOG.flatMap((g) =>
  g.items.map((i) => i.key)
);

export type RoleKey =
  | "SUPER_ADMIN"
  | "ADMIN"
  | "CRM_MANAGER"
  | "CRM_EXECUTIVE"
  | "LMS_MANAGER"
  | "INSTRUCTOR"
  | "EMPLOYEE";

export const ROLE_KEYS: RoleKey[] = [
  "SUPER_ADMIN",
  "ADMIN",
  "CRM_MANAGER",
  "CRM_EXECUTIVE",
  "LMS_MANAGER",
  "INSTRUCTOR",
  "EMPLOYEE",
];

export interface RoleDef {
  key: RoleKey;
  name: string;
  description: string;
  permissions: string[];
  order: number;
}

export const DEFAULT_ROLES: RoleDef[] = [
  {
    key: "SUPER_ADMIN",
    name: "Super Admin",
    description: "Full system access — users, roles, configuration, CRM and LMS.",
    permissions: [ALL_PERMISSIONS],
    order: 1,
  },
  {
    key: "ADMIN",
    name: "Admin",
    description: "Full CRM + LMS access, user management and reports.",
    permissions: ALL_PERMISSION_KEYS.filter(
      (p) => p !== "admin.roles.manage" && p !== "admin.settings.manage"
    ),
    order: 2,
  },
  {
    key: "CRM_MANAGER",
    name: "CRM Manager",
    description: "Owns the sales pipeline — leads, contacts, organizations, deals, team reports.",
    permissions: [
      "dashboard.view",
      "notifications.view",
      "crm.leads.view",
      "crm.leads.manage",
      "crm.contacts.view",
      "crm.contacts.manage",
      "crm.organizations.view",
      "crm.organizations.manage",
      "crm.deals.view",
      "crm.deals.manage",
      "crm.activities.view",
      "crm.activities.manage",
      "crm.reports.view",
      "lms.enrollments.view",
      "lms.progress.view",
      "lms.certificates.view",
    ],
    order: 3,
  },
  {
    key: "CRM_EXECUTIVE",
    name: "Sales / CRM Executive",
    description: "Works assigned leads, contacts, deals and follow-ups (own-scope data).",
    permissions: [
      "dashboard.view",
      "notifications.view",
      "crm.leads.view",
      "crm.leads.manage",
      "crm.contacts.view",
      "crm.contacts.manage",
      "crm.deals.view",
      "crm.deals.manage",
      "crm.activities.view",
      "crm.activities.manage",
      "crm.reports.view",
    ],
    order: 4,
  },
  {
    key: "LMS_MANAGER",
    name: "LMS Manager",
    description: "Owns the catalog — courses, enrollments, assessments, certificates.",
    permissions: [
      "dashboard.view",
      "notifications.view",
      "lms.courses.view",
      "lms.courses.manage",
      "lms.enrollments.view",
      "lms.enrollments.manage",
      "lms.progress.view",
      "lms.assessments.view",
      "lms.assessments.manage",
      "lms.certificates.view",
      "lms.certificates.issue",
      "lms.reports.view",
      "crm.contacts.view",
    ],
    order: 5,
  },
  {
    key: "INSTRUCTOR",
    name: "Trainer / Instructor",
    description: "Delivers assigned courses — content, assessments, grading, learner progress.",
    permissions: [
      "dashboard.view",
      "notifications.view",
      "lms.courses.view",
      "lms.courses.manage",
      "lms.enrollments.view",
      "lms.progress.view",
      "lms.assessments.view",
      "lms.assessments.manage",
    ],
    order: 6,
  },
  {
    key: "EMPLOYEE",
    name: "Employee / Staff",
    description: "Internal staff — tasks, activities and course catalog (view).",
    permissions: [
      "dashboard.view",
      "notifications.view",
      "crm.activities.view",
      "lms.courses.view",
    ],
    order: 7,
  },
];

/** Legacy role aliases → canonical RoleKey (old session tokens keep working). */
export const LEGACY_ROLE_MAP: Record<string, RoleKey> = {
  COUNSELLOR: "CRM_EXECUTIVE",
};

/* ── Server-side permission lookup lives in @/lib/rbac-server (DB-backed).
 * This module is client-safe: pure data + pure functions only. ── */

export function permissionsHas(list: string[], perm: string): boolean {
  if (list.includes(ALL_PERMISSIONS)) return true;
  if (list.includes(perm)) return true;
  // "crm.*" style wildcard support
  const [domain] = perm.split(".");
  return list.includes(`${domain}.*`);
}

/** Pure check against a permission list — usable on the client too. */
export function canIn(permissions: string[] | undefined, perm: string): boolean {
  if (!permissions) return false;
  return permissionsHas(permissions, perm);
}

export function roleLabel(key: string): string {
  const def = DEFAULT_ROLES.find((r) => r.key === key);
  if (def) return def.name;
  const legacy: Record<string, string> = { COUNSELLOR: "Sales / CRM Executive", STUDENT: "Learner" };
  return legacy[key] ?? key;
}
