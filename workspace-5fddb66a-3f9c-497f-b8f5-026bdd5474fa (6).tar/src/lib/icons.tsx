import {
  BarChart3, School, Sparkles, LineChart, BrainCircuit, Network, Code2, Braces, Sigma, Cpu, Table, Database,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  BarChart3,
  School,
  Sparkles,
  LineChart,
  BrainCircuit,
  Network,
  Code2,
  Braces,
  Sigma,
  Cpu,
  Table,
  Database,
};

export function DynIcon({ name, className }: { name: string; className?: string }) {
  const Icon = ICONS[name] ?? BarChart3;
  return <Icon className={className} />;
}
