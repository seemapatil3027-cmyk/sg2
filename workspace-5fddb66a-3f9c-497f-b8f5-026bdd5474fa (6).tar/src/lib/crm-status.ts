/* Shared CRM vocabulary — safe to import from both client and server code.
 * Contains the canonical lead/deal status enums, the legacy-status mapper and
 * small pure helpers used by API routes and CRM UI alike. */

export const LEAD_STATUSES = ["NEW", "CONTACTED", "QUALIFIED", "CONVERTED", "LOST"] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

/** Canonical deal pipeline stages (order matters — Kanban board columns). */
export const DEAL_STAGES = [
  "NEW",
  "CONTACTED",
  "QUALIFIED",
  "PROPOSAL",
  "NEGOTIATION",
  "WON",
  "LOST",
] as const;
export type DealStage = (typeof DEAL_STAGES)[number];

export const ACTIVITY_TYPES = [
  "CALL",
  "MEETING",
  "TASK",
  "FOLLOW_UP",
  "NOTE",
  "EMAIL",
  "WHATSAPP",
  "DEMO",
] as const;
export type ActivityType = (typeof ACTIVITY_TYPES)[number];

export const ACTIVITY_PRIORITIES = ["LOW", "MEDIUM", "HIGH"] as const;

export const CONTACT_STATUSES = ["ACTIVE", "INACTIVE", "CHURNED"] as const;
export const CONTACT_LIFECYCLES = ["CONTACT", "CUSTOMER", "CHURNED"] as const;

export const LEAD_SOURCES = [
  "website",
  "contact",
  "callback",
  "brochure",
  "masterclass",
  "enroll",
  "hire",
  "assessment",
  "referral",
  "campaign",
  "inbound",
  "outbound",
  "event",
] as const;

/** Human labels for lead statuses (used in tabs + selects). */
export const LEAD_STATUS_LABELS: Record<LeadStatus, string> = {
  NEW: "New",
  CONTACTED: "Contacted",
  QUALIFIED: "Qualified",
  CONVERTED: "Converted",
  LOST: "Lost",
};

export const DEAL_STAGE_LABELS: Record<DealStage, string> = {
  NEW: "New",
  CONTACTED: "Contacted",
  QUALIFIED: "Qualified",
  PROPOSAL: "Proposal",
  NEGOTIATION: "Negotiation",
  WON: "Won",
  LOST: "Lost",
};

/** Legacy funnel values that rolled up into each canonical status. */
const LEGACY_STATUS_MAP: Record<LeadStatus, string[]> = {
  NEW: ["NEW", "New"],
  CONTACTED: ["CONTACTED", "Contacted", "Assigned"],
  QUALIFIED: ["QUALIFIED", "Counselling", "Demo", "Interested", "Payment Pending"],
  CONVERTED: ["CONVERTED", "Enrolled"],
  LOST: ["LOST", "Lost"],
};

/** All raw DB values that roll up to a canonical status (for Prisma `in`). */
export function rawStatusesFor(status: LeadStatus): string[] {
  return LEGACY_STATUS_MAP[status];
}

/**
 * Maps any stored lead status (canonical or legacy funnel value) to the
 * canonical NEW | CONTACTED | QUALIFIED | CONVERTED | LOST set.
 */
export function normalizeLeadStatus(raw?: string | null): LeadStatus {
  const value = (raw ?? "").trim();
  if (!value) return "NEW";
  const lower = value.toLowerCase();
  if (lower === "new") return "NEW";
  if (lower === "assigned" || lower === "contacted") return "CONTACTED";
  if (lower === "counselling" || lower === "demo" || lower === "interested" || lower === "payment pending")
    return "QUALIFIED";
  if (lower === "enrolled" || lower === "converted") return "CONVERTED";
  if (lower === "lost") return "LOST";
  return "NEW";
}

/** True when the role may see all CRM data (no owner scoping). */
export function isCrmWideRole(role: string): boolean {
  return role === "SUPER_ADMIN" || role === "ADMIN" || role === "CRM_MANAGER";
}

/** Tailwind dot/border colors per deal stage (Kanban headers). */
export const DEAL_STAGE_TONES: Record<DealStage, string> = {
  NEW: "bg-slate-500",
  CONTACTED: "bg-sky-500",
  QUALIFIED: "bg-amber-500",
  PROPOSAL: "bg-orange-500",
  NEGOTIATION: "bg-purple-500",
  WON: "bg-emerald-500",
  LOST: "bg-rose-500",
};

/** Initials from a person/org name ("Rahul Sharma" → "RS"). */
export function initialsOf(name?: string | null): string {
  if (!name) return "?";
  return name
    .split(/\s+/)
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}
