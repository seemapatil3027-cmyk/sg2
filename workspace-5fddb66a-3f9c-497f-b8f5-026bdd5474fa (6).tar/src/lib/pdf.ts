/* Minimal dependency-free PDF generator for brochure downloads */

function escapePdfText(text: string): string {
  return text.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

interface Line {
  text: string;
  size?: number;
  bold?: boolean;
  gap?: number; // extra spacing after line
  color?: [number, number, number];
}

export function buildPdf(title: string, lines: Line[]): Buffer {
  const content: string[] = [];
  content.push("BT");
  let y = 780;
  for (const line of lines) {
    const size = line.size ?? 11;
    const font = line.bold ? "/F2" : "/F1";
    const [r, g, b] = line.color ?? [0.13, 0.11, 0.2];
    y -= size + 6;
    content.push(`1 0 0 1 50 ${y} Tm`);
    content.push(`${font} ${size} Tf`);
    content.push(`${r} ${g} ${b} rg`);
    content.push(`(${escapePdfText(line.text)}) Tj`);
    if (line.gap) y -= line.gap;
  }
  content.push("ET");
  const stream = content.join("\n");

  const objects: string[] = [];
  objects.push("<< /Type /Catalog /Pages 2 0 R >>");
  objects.push("<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
  objects.push("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>");
  objects.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  objects.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
  objects.push(`<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`);

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  objects.forEach((body, i) => {
    offsets.push(Buffer.byteLength(pdf));
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xrefStart = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) {
    pdf += `${String(off).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
  return Buffer.from(pdf, "binary");
}

export function buildTrackBrochure(t: {
  title: string;
  description: string;
  weeks?: number | null;
  liveClasses?: number;
  projects?: number;
  hrPerWeek?: number;
  skills?: string[];
  syllabus?: { title: string; weeks: number; tags: string[] }[];
  outcomes?: string[];
}): Buffer {
  const lines: Line[] = [
    { text: "SkilloVilla", size: 26, bold: true, color: [0.36, 0.09, 0.75], gap: 4 },
    { text: `${t.title} — Program Brochure`, size: 16, bold: true, gap: 10 },
    { text: t.description, size: 10, gap: 14 },
    { text: "Program Highlights", size: 13, bold: true, color: [0.36, 0.09, 0.75], gap: 4 },
    { text: `- ${t.weeks ?? 20} weeks program | ${t.liveClasses ?? 20} live classes | ${t.projects ?? 7} projects | ${t.hrPerWeek ?? 14} hrs/week`, size: 10, gap: 12 },
    { text: "Skills you will master", size: 13, bold: true, color: [0.36, 0.09, 0.75], gap: 2 },
    { text: (t.skills ?? []).join(" | "), size: 10, gap: 12 },
    { text: "Syllabus", size: 13, bold: true, color: [0.36, 0.09, 0.75], gap: 2 },
  ];
  for (const s of t.syllabus ?? []) {
    lines.push({ text: `- ${s.title} (${s.weeks} weeks): ${s.tags.join(", ")}`, size: 10, gap: 0 });
  }
  lines.push({ text: "", size: 10, gap: 8 });
  lines.push({ text: "Outcomes", size: 13, bold: true, color: [0.36, 0.09, 0.75], gap: 2 });
  for (const o of (t.outcomes ?? []).slice(0, 8)) {
    lines.push({ text: `- ${o}`, size: 10, gap: 0 });
  }
  lines.push({ text: "", size: 10, gap: 8 });
  lines.push({ text: "Placement assistance included: resume building, mock interviews,", size: 10, gap: 0 });
  lines.push({ text: "and interview invites from 300+ partner companies.", size: 10, gap: 12 });
  lines.push({ text: "Talk to our counsellors: admissions@skillovilla.com | www.skillovilla.com", size: 10, bold: true, color: [0.36, 0.09, 0.75] });
  return buildPdf(t.title, lines);
}
