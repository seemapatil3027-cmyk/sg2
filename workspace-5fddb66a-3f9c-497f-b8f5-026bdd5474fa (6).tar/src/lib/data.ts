import { db } from "@/lib/db";
import type { Track, Course, Mentor, Testimonial, BlogPost, Faq, PlacedStudent, Company } from "@prisma/client";

export interface SyllabusItem {
  title: string;
  weeks: number;
  tags: string[];
}
export interface ProjectItem {
  title: string;
  description: string;
}
export interface ChapterItem {
  title: string;
  mins: number;
  videos: number;
  readings: number;
  quizzes: number;
}

export function parseJson<T>(value: string, fallback: T): T {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export interface TrackFull extends Omit<Track, "skills" | "outcomes" | "syllabus" | "projectsList" | "highlights" | "expertLogos"> {
  skills: string[];
  outcomes: string[];
  syllabus: SyllabusItem[];
  projectsList: ProjectItem[];
  highlights: string[];
  expertLogos: string[];
}

export async function getTracks(): Promise<TrackFull[]> {
  const rows = await db.track.findMany({ orderBy: { order: "asc" } });
  return rows.map(mapTrack);
}

export function mapTrack(t: Track): TrackFull {
  return {
    ...t,
    skills: parseJson<string[]>(t.skills, []),
    outcomes: parseJson<string[]>(t.outcomes, []),
    syllabus: parseJson<SyllabusItem[]>(t.syllabus, []),
    projectsList: parseJson<ProjectItem[]>(t.projectsList, []),
    highlights: parseJson<string[]>(t.highlights, []),
    expertLogos: parseJson<string[]>(t.expertLogos, []),
  };
}

export async function getTrack(slug: string): Promise<TrackFull | null> {
  const row = await db.track.findUnique({ where: { slug } });
  return row ? mapTrack(row) : null;
}

export interface CourseFull extends Omit<Course, "skills" | "highlights" | "chapters"> {
  skills: string[];
  highlights: string[];
  chapters: ChapterItem[];
}

export function mapCourse(c: Course): CourseFull {
  return {
    ...c,
    skills: parseJson<string[]>(c.skills, []),
    highlights: parseJson<string[]>(c.highlights, []),
    chapters: parseJson<ChapterItem[]>(c.chapters, []),
  };
}

export async function getCourses(): Promise<CourseFull[]> {
  const rows = await db.course.findMany({ orderBy: { order: "asc" } });
  return rows.map(mapCourse);
}

export async function getCourse(slug: string): Promise<CourseFull | null> {
  const row = await db.course.findUnique({ where: { slug } });
  return row ? mapCourse(row) : null;
}

export async function getMentors(): Promise<Mentor[]> {
  return db.mentor.findMany({ orderBy: { order: "asc" } });
}

export async function getTestimonials(): Promise<Testimonial[]> {
  return db.testimonial.findMany({ orderBy: { order: "asc" } });
}

export async function getFaqs(category?: string): Promise<Faq[]> {
  return db.faq.findMany({
    where: category ? { category } : undefined,
    orderBy: { order: "asc" },
  });
}

export async function getPlacedStudents(): Promise<PlacedStudent[]> {
  return db.placedStudent.findMany({ orderBy: { order: "asc" } });
}

export async function getCompanies(category?: string): Promise<Company[]> {
  return db.company.findMany({
    where: category ? { category } : undefined,
    orderBy: { order: "asc" },
  });
}

export interface BlogSummary {
  slug: string;
  title: string;
  excerpt: string;
  author: string;
  readTime: string;
  category: string;
  cover: string;
  publishedAt: Date;
}

export async function getBlogs(page = 1, pageSize = 8): Promise<{ items: BlogSummary[]; total: number; totalPages: number }> {
  const [rows, total] = await Promise.all([
    db.blogPost.findMany({
      orderBy: { publishedAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    db.blogPost.count(),
  ]);
  return {
    items: rows,
    total,
    totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

export async function getBlog(slug: string): Promise<BlogPost | null> {
  return db.blogPost.findUnique({ where: { slug } });
}

export function formatDate(d: Date | string): string {
  return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
