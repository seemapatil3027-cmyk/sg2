import { PrismaClient } from "@prisma/client";
import { resolvedDatabaseUrl, databaseUrlSource } from "@/lib/db-url";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    // explicit URL override: works even when DATABASE_URL is not exported
    datasourceUrl: resolvedDatabaseUrl,
    // query logging is a dev aid only — keep production logs clean
    log: process.env.NODE_ENV === "production" ? ["error"] : ["query"],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db

export { resolvedDatabaseUrl, databaseUrlSource }
