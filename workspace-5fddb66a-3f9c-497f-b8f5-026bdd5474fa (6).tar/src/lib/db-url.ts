import fs from "fs";
import path from "path";

/**
 * Resilient SQLite URL resolution for zero-surprise deployments.
 *
 * Precedence:
 *  1. DATABASE_URL env var — used as-is if it points to an existing file
 *     (non-file URLs are always trusted).
 *  2. Discovered project database — <root>/db/custom.db, searched from
 *     process.cwd() upward (handles hosting panels that boot the app from an
 *     unexpected working directory).
 *  3. If nothing exists yet (brand-new server), the project path is returned
 *     anyway — instrumentation.ts provisions schema + seed data on first boot.
 *
 * Relative `file:` URLs are resolved the way Prisma does — relative to the
 * prisma/ schema directory.
 */

export type DatabaseUrlSource =
  | "env"
  | "fallback-project-db"
  | "env-unverified"
  | "default-project-db";

const FILE_PREFIX = "file:";

/** Absolute candidate locations for the project SQLite file, nearest first. */
function candidatePaths(): string[] {
  const paths: string[] = [];
  let dir = process.cwd();
  for (let depth = 0; depth < 6 && dir; depth++) {
    paths.push(path.join(dir, "db", "custom.db"));
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return paths;
}

function isFileUrl(url: string): boolean {
  return url.startsWith(FILE_PREFIX);
}

/** Resolve a file: URL (absolute or schema-relative) to an absolute path. */
function fileUrlToAbsolutePath(url: string): string {
  const raw = url.slice(FILE_PREFIX.length);
  if (path.isAbsolute(raw)) return raw;
  // Prisma resolves relative SQLite paths against the prisma/ schema directory
  return path.resolve(process.cwd(), "prisma", raw);
}

function fileExists(p: string): boolean {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
}

function resolve(): {
  url: string;
  source: DatabaseUrlSource;
  filePath: string | null;
  searchedPaths: { path: string; exists: boolean }[];
} {
  const searchedPaths = candidatePaths().map((p) => ({
    path: p,
    exists: fileExists(p),
  }));
  const envUrl = process.env.DATABASE_URL?.trim() || "";
  const projectUrl = FILE_PREFIX + path.join(process.cwd(), "db", "custom.db");

  if (envUrl) {
    if (!isFileUrl(envUrl)) {
      return { url: envUrl, source: "env", filePath: null, searchedPaths };
    }
    const envPath = fileUrlToAbsolutePath(envUrl);
    if (fileExists(envPath)) {
      return { url: envUrl, source: "env", filePath: envPath, searchedPaths };
    }
    const existing = searchedPaths.find((c) => c.exists);
    if (existing) {
      console.warn(
        `[db] DATABASE_URL (${envUrl}) points to a missing file on this machine — ` +
          `falling back to discovered project database (${existing.path}).`
      );
      return {
        url: FILE_PREFIX + existing.path,
        source: "fallback-project-db",
        filePath: existing.path,
        searchedPaths,
      };
    }
    console.warn(
      `[db] DATABASE_URL (${envUrl}) points to a missing file and no project ` +
        `database was found — using DATABASE_URL as configured. The database ` +
        `will be provisioned automatically on first boot.`
    );
    return { url: envUrl, source: "env-unverified", filePath: envPath, searchedPaths };
  }

  const existing = searchedPaths.find((c) => c.exists);
  if (existing) {
    console.warn(
      `[db] DATABASE_URL is not set — using discovered project database (${existing.path}).`
    );
    return {
      url: FILE_PREFIX + existing.path,
      source: "default-project-db",
      filePath: existing.path,
      searchedPaths,
    };
  }
  console.warn(
    `[db] DATABASE_URL is not set and no project database file exists — ` +
      `defaulting to (${projectUrl}). It will be provisioned automatically on first boot.`
  );
  return {
    url: projectUrl,
    source: "default-project-db",
    filePath: path.join(process.cwd(), "db", "custom.db"),
    searchedPaths,
  };
}

const resolved = resolve();

/** Final SQLite connection URL the Prisma client will use (always absolute for file: URLs). */
export const resolvedDatabaseUrl: string = resolved.url;
/** Where the URL came from — surfaced by /api/health for deploy diagnostics. */
export const databaseUrlSource: DatabaseUrlSource = resolved.source;
/** Absolute path of the SQLite file (null for non-file URLs). */
export const databaseFilePath: string | null = resolved.filePath;
/** Every location searched for the project database — surfaced by /api/health. */
export const databaseSearchedPaths: { path: string; exists: boolean }[] =
  resolved.searchedPaths;
