import crypto from "crypto";
import { cookies } from "next/headers";
import { LEGACY_ROLE_MAP, type RoleKey } from "@/lib/rbac";

/** Canonical platform roles. COUNSELLOR is accepted as a legacy alias of
 * CRM_EXECUTIVE; STUDENT tokens still verify (legacy learner accounts) but
 * are rejected by the sign-in API — students no longer log in to the app. */
export type UserRole = RoleKey | "COUNSELLOR" | "STUDENT";

const SECRET = process.env.AUTH_SECRET || "skillovilla-clone-dev-secret-2024";
const COOKIE_NAME = "sv_session";
const SESSION_DAYS = 7;

export interface SessionUser {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
}

const KNOWN_ROLES: Set<string> = new Set([
  "SUPER_ADMIN",
  "ADMIN",
  "CRM_MANAGER",
  "CRM_EXECUTIVE",
  "LMS_MANAGER",
  "INSTRUCTOR",
  "EMPLOYEE",
  "COUNSELLOR",
  "STUDENT",
]);

function sign(payload: string): string {
  return crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
}

export function createToken(user: SessionUser): string {
  const exp = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  const payload = Buffer.from(JSON.stringify({ ...user, exp })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function verifyToken(token: string | undefined): SessionUser | null {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  try {
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString()) as {
      exp?: number;
      uid?: string;
      name?: string;
      email?: string;
      role?: string;
    };
    if (typeof data.exp !== "number" || data.exp < Date.now()) return null;
    if (!data.uid || !data.email) return null;
    let role = KNOWN_ROLES.has(data.role ?? "") ? (data.role as UserRole) : "STUDENT";
    // Legacy tokens: COUNSELLOR → CRM_EXECUTIVE
    if (role === "COUNSELLOR" && LEGACY_ROLE_MAP.COUNSELLOR) role = LEGACY_ROLE_MAP.COUNSELLOR;
    return {
      uid: data.uid,
      name: data.name ?? data.email,
      email: data.email,
      role,
    };
  } catch {
    return null;
  }
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  return verifyToken(store.get(COOKIE_NAME)?.value);
}

export async function setSessionCookie(token: string) {
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    path: "/",
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.set(COOKIE_NAME, "", { httpOnly: true, maxAge: 0, path: "/" });
}

export { hashPassword, verifyPassword } from "@/lib/password";
