/* Server-only RBAC runtime: DB-backed permission lookup with a short
 * in-memory cache. Client code must import from @/lib/rbac instead. */
import { db } from "@/lib/db";
import { DEFAULT_ROLES, LEGACY_ROLE_MAP, permissionsHas } from "@/lib/rbac";

type CacheEntry = { at: number; map: Map<string, string[]> };
let cache: CacheEntry | null = null;
const CACHE_TTL = 30_000;

export function invalidateRoleCache() {
  cache = null;
}

/** Reads the Role table and returns roleKey → permissions[] (cached 30s). */
export async function rolePermissionMap(): Promise<Map<string, string[]>> {
  if (cache && Date.now() - cache.at < CACHE_TTL) return cache.map;
  const map = new Map<string, string[]>();
  try {
    const roles = await db.role.findMany();
    for (const role of roles) {
      try {
        map.set(role.key, JSON.parse(role.permissions) as string[]);
      } catch {
        map.set(role.key, []);
      }
    }
  } catch {
    // DB unavailable → fall back to compiled defaults below
  }
  for (const def of DEFAULT_ROLES) {
    if (!map.has(def.key)) map.set(def.key, def.permissions);
  }
  cache = { at: Date.now(), map };
  return map;
}

/** Server-side check for a role key (async, DB-backed). */
export async function can(role: string, perm: string): Promise<boolean> {
  const map = await rolePermissionMap();
  const list = map.get(role) ?? map.get(LEGACY_ROLE_MAP[role] ?? "") ?? [];
  return permissionsHas(list, perm);
}

export async function permissionsForRole(role: string): Promise<string[]> {
  const map = await rolePermissionMap();
  return map.get(role) ?? map.get(LEGACY_ROLE_MAP[role] ?? "") ?? [];
}
