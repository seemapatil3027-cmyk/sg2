/* Server-side helpers shared by the LMS API routes: instructor scoping,
 * course ownership checks, slug generation and JSON field parsing. */
import { db } from "@/lib/db";
import type { SessionUser } from "@/lib/auth";

/** INSTRUCTOR users only see courses they own; managers/admins see all. */
export function courseScope(session: SessionUser): { ownerId?: string } {
  return session.role === "INSTRUCTOR" ? { ownerId: session.uid } : {};
}

export function isInstructor(session: SessionUser): boolean {
  return session.role === "INSTRUCTOR";
}

/** True when the session may act on the given course (owner for instructors). */
export async function ownsCourse(session: SessionUser, courseId: string | null | undefined): Promise<boolean> {
  if (!courseId) return !isInstructor(session);
  const course = await db.course.findUnique({
    where: { id: courseId },
    select: { ownerId: true },
  });
  if (!course) return false;
  return !isInstructor(session) || course.ownerId === session.uid;
}

export function slugify(title: string): string {
  const base = title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
  return base || "course";
}

/** Slug uniqueness with -2, -3… suffixes. */
export async function uniqueSlug(base: string): Promise<string> {
  let slug = base;
  let i = 1;
  while (await db.course.findUnique({ where: { slug }, select: { id: true } })) {
    i += 1;
    slug = `${base}-${i}`;
  }
  return slug;
}

/** Parse a JSON string[] column safely. */
export function jsonStrings(value: string | null | undefined): string[] {
  try {
    const parsed = JSON.parse(value ?? "[]");
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

/** Parse a JSON number[] column safely. */
export function jsonNumbers(value: string | null | undefined): number[] {
  try {
    const parsed = JSON.parse(value ?? "[]");
    return Array.isArray(parsed) ? parsed.map((n) => Number(n) || 0) : [];
  } catch {
    return [];
  }
}

/** Sorted-set equality for auto-grading (answer index sets). */
export function sameSet(a: number[], b: number[]): boolean {
  const sa = [...a].sort((x, y) => x - y).join(",");
  const sb = [...b].sort((x, y) => x - y).join(",");
  return sa === sb;
}
