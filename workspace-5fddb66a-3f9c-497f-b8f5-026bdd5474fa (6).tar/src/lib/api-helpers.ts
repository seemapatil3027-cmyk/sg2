/* Shared API toolkit for the SkillGorila platform backend.
 * Provides: JSON responses, auth/permission guards, pagination + filtering
 * parsers, zod body validation, audit logging and notification helpers. */
import { NextRequest, NextResponse } from "next/server";
import { ZodSchema } from "zod";
import { getSessionUser, type SessionUser } from "@/lib/auth";
import { can, permissionsForRole } from "@/lib/rbac-server";
import { db } from "@/lib/db";

/* ── Responses ── */

export function ok<T>(data: T, init?: number | ResponseInit) {
  const responseInit = typeof init === "number" ? { status: init } : init;
  return NextResponse.json({ ok: true, data }, responseInit);
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ ok: false, error: message, ...extra }, { status });
}

/* ── Guards ── */

export interface Guard {
  session: SessionUser;
  permissions: string[];
}

/** Returns the session or null (caller decides the response). */
export async function auth(): Promise<SessionUser | null> {
  return getSessionUser();
}

/** 401/403 response helper for API routes. */
export function unauthorized() {
  return fail("You must be signed in to do that.", 401);
}

export function forbidden(perm?: string) {
  return fail(
    perm
      ? `Your role does not have the "${perm}" permission.`
      : "You do not have permission to perform this action.",
    403
  );
}

export function studentBlocked() {
  return fail(
    "Student sign-in has been disabled. Learners are managed internally by the LMS team.",
    403
  );
}

/** Combines auth + permission check. Returns { guard } or { response }. */
export async function guard(
  perm: string
): Promise<{ guard: Guard; response?: never } | { guard?: never; response: NextResponse }> {
  const session = await auth();
  if (!session) return { response: unauthorized() };
  const permissions = await permissionsForRole(session.role);
  if (!permissions.includes("*") && !permissions.includes(perm)) {
    return { response: forbidden(perm) };
  }
  return { guard: { session, permissions } };
}

/* ── Body validation ── */

export async function parseBody<T>(
  req: NextRequest,
  schema: ZodSchema<T>
): Promise<{ data: T; response?: never } | { data?: never; response: NextResponse }> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return { response: fail("Request body must be valid JSON.") };
  }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    const field = first?.path?.join(".") ?? "";
    return {
      response: fail(field ? `${field}: ${first.message}` : first?.message ?? "Invalid request body.", 422),
    };
  }
  return { data: parsed.data };
}

/* ── Pagination ── */

export interface PageParams {
  page: number;
  pageSize: number;
  skip: number;
  q: string | null;
  sort: string | null;
  dir: "asc" | "desc";
  searchParams: URLSearchParams;
}

export function pageParams(req: NextRequest, defaultSize = 20, maxSize = 100): PageParams {
  const sp = req.nextUrl.searchParams;
  const page = Math.max(1, Number(sp.get("page")) || 1);
  const pageSize = Math.min(maxSize, Math.max(1, Number(sp.get("pageSize")) || defaultSize));
  const dir = sp.get("dir") === "asc" ? "asc" : "desc";
  return {
    page,
    pageSize,
    skip: (page - 1) * pageSize,
    q: sp.get("q")?.trim() || null,
    sort: sp.get("sort"),
    dir,
    searchParams: sp,
  };
}

export function paginated<T>(
  items: T[],
  total: number,
  p: { page: number; pageSize: number }
) {
  return {
    items,
    total,
    page: p.page,
    pageSize: p.pageSize,
    pages: Math.max(1, Math.ceil(total / p.pageSize)),
  };
}

/* ── Audit log ── */

export async function audit(
  session: SessionUser,
  action: string,
  entity: string,
  entityId?: string | null,
  summary?: string,
  meta?: Record<string, unknown>
) {
  try {
    await db.auditLog.create({
      data: {
        actorEmail: session.email,
        actorRole: session.role,
        action,
        entity,
        entityId: entityId ?? null,
        summary: summary ?? null,
        meta: meta ? JSON.stringify(meta) : null,
      },
    });
  } catch (error) {
    console.error("[audit] failed:", error);
  }
}

/* ── Notifications ── */

export async function notify(
  userId: string,
  title: string,
  opts?: { body?: string; type?: string; link?: string }
) {
  try {
    await db.notification.create({
      data: {
        userId,
        title,
        body: opts?.body ?? null,
        type: opts?.type ?? "INFO",
        link: opts?.link ?? null,
      },
    });
  } catch (error) {
    console.error("[notify] failed:", error);
  }
}

/** Notify every user holding a permission (e.g. all CRM managers). */
export async function notifyPermission(
  perm: string,
  title: string,
  opts?: { body?: string; type?: string; link?: string; excludeUserId?: string }
) {
  try {
    const users = await db.user.findMany({ where: { isActive: true } });
    const targets: string[] = [];
    for (const u of users) {
      if (u.id === opts?.excludeUserId) continue;
      if (await can(u.role, perm)) targets.push(u.id);
    }
    if (targets.length) {
      await db.notification.createMany({
        data: targets.map((userId) => ({
          userId,
          title,
          body: opts?.body ?? null,
          type: opts?.type ?? "INFO",
          link: opts?.link ?? null,
        })),
      });
    }
  } catch (error) {
    console.error("[notifyPermission] failed:", error);
  }
}

/* ── Utilities ── */

export function dateOrNull(value: unknown): Date | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function inr(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

/** Serial generator for certificates: SG-CERT-2026-000001 */
export async function nextSerial(prefix: string): Promise<string> {
  const year = new Date().getFullYear();
  const base = `${prefix}-${year}-`;
  const count = await db.certificate.count({ where: { serial: { startsWith: base } } });
  return `${base}${String(count + 1).padStart(6, "0")}`;
}
