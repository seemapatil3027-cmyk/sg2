import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const leads = await db.lead.findMany({ select: { id: true, email: true, name: true, status: true } });
  console.log(JSON.stringify(leads, null, 0));
}
main().finally(() => db.$disconnect());
