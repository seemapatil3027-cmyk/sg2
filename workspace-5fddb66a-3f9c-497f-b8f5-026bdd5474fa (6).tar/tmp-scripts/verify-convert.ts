import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const user = await db.user.findUnique({ where: { email: "amit.verma@example.com" } });
  console.log("user:", JSON.stringify(user ? { id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone } : null));
  if (user) {
    const enr = await db.enrollment.findFirst({ where: { userId: user.id } });
    console.log("enrollment:", JSON.stringify(enr));
    const pays = await db.payment.findMany({ where: { userId: user.id } });
    console.log("payments:", JSON.stringify(pays));
  }
  const lead = await db.lead.findFirst({ where: { email: "amit.verma@example.com" } });
  console.log("lead status:", lead?.status);
  const rahul = await db.lead.findFirst({ where: { email: "rahul.sharma@example.com" } });
  console.log("rahul status:", rahul?.status);
  const recentActs = await db.leadActivity.findMany({ orderBy: { createdAt: "desc" }, take: 4, select: { type: true, title: true, createdBy: true } });
  console.log("recent activities:", JSON.stringify(recentActs, null, 0));
}
main().finally(() => db.$disconnect());
