import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const lead = await db.lead.findUnique({ where: { id: "cmuwl9eeo001dolb8ojqjszvz" }, select: { nextFollowUpAt: true, status: true, assignedTo: true } });
  console.log(JSON.stringify(lead));
}
main().finally(() => db.$disconnect());
