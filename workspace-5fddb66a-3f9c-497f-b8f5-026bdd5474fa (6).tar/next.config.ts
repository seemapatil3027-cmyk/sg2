import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // The deploy platform packages .next/standalone/server.js (see .zscripts/build.sh),
  // so standalone output is REQUIRED for publishing. `next start` still serves
  // the same build for panels that boot with `npm start`.
  output: "standalone",
  distDir: process.env.NEXT_DIST_DIR || ".next",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
